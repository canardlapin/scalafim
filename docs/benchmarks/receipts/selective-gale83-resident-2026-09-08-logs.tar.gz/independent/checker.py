#!/usr/bin/env python3
"""Independently check exported selected-estimation fixtures with NumPy SVD.

The exporter must supply realized design matrices, actual run row/column
projections, response samples and requested readout weights. No shared random
seed, expected beta, or scalar contrast-first pooling substitutes for those data.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path

# This checker runs separately from performance measurement.
os.environ.setdefault('OPENBLAS_NUM_THREADS', '1')
os.environ.setdefault('VECLIB_MAXIMUM_THREADS', '1')
import numpy as np


def matrix(value, name):
    result = np.asarray(value, dtype=np.float64)
    if result.ndim != 2 or not result.size or not np.isfinite(result).all():
        raise ValueError(f'{name} must be a nonempty finite matrix')
    return result


def indices(value, size, name):
    if (not value or any(type(i) is not int or not 0 <= i < size for i in value)
            or len(value) != len(set(value))):
        raise ValueError(f'{name} must identify unique in-range positions')
    return np.asarray(value, dtype=np.int64)


def ols(design, response):
    u, singular, vt = np.linalg.svd(design, full_matrices=False)
    if design.shape[0] <= design.shape[1] or singular[-1] <= 1e-12 * singular[0]:
        raise ValueError('Qualification fixture must have full rank and positive residual degrees of freedom')
    beta = vt.T @ ((u.T @ response) / singular[:, None])
    covariance = (vt.T / singular**2) @ vt
    residual = response - design @ beta
    variance = np.sum(residual**2, axis=0) / (design.shape[0] - design.shape[1])
    if np.any(variance <= 0) or not np.isfinite(variance).all():
        raise ValueError('Fixture must have positive finite residual variance')
    return beta, covariance, variance


def check(case):
    design = matrix(case['design'], 'design')
    response = matrix(case['response'], 'response')
    weights = matrix(case['weights'], 'weights')
    observed = matrix(case['estimates'], 'estimates')
    if response.shape[0] != design.shape[0] or weights.shape[1] != design.shape[1]:
        raise ValueError('Design, response and output coefficient axes do not align')
    if case['route'] == 'shared':
        beta, _, _ = ols(design, response)
        expected = weights @ beta
    elif case['route'] == 'pooled':
        pooled = indices(case['pooledSourceColumns'], design.shape[1], 'pooled columns')
        absent = np.setdiff1d(np.arange(design.shape[1]), pooled)
        if np.any(weights[:, absent] != 0):
            raise ValueError('Requested output depends on an unpooled coefficient')
        precision = np.zeros((response.shape[1], len(pooled), len(pooled)))
        rhs = np.zeros((response.shape[1], len(pooled)))
        seen = []
        runs = case['runs']
        if not runs:
            raise ValueError('Pooled fixture requires explicit run projections')
        for run in runs:
            rows = indices(run['rows'], design.shape[0], 'run rows')
            columns = indices(run['sourceColumns'], design.shape[1], 'run source columns')
            local = {int(column): i for i, column in enumerate(columns)}
            if any(int(column) not in local for column in pooled):
                raise ValueError('A pooled coefficient is absent from a run')
            positions = np.asarray([local[int(column)] for column in pooled])
            beta, covariance, variance = ols(design[np.ix_(rows, columns)], response[rows])
            selected_covariance = covariance[np.ix_(positions, positions)]
            base_precision = np.linalg.solve(selected_covariance, np.eye(len(pooled)))
            run_precision = base_precision[None, :, :] / variance[:, None, None]
            precision += run_precision
            rhs += np.einsum('vij,jv->vi', run_precision, beta[positions])
            seen.extend(rows.tolist())
        if sorted(seen) != list(range(design.shape[0])):
            raise ValueError('Run projections must partition every exported response row exactly once')
        pooled_beta = np.linalg.solve(precision, rhs[..., None])[..., 0].T
        expected = weights[:, pooled] @ pooled_beta
    else:
        raise ValueError('Unknown scientific route')
    if expected.shape != observed.shape:
        raise ValueError('Selected output and response axes differ')
    error = np.abs(expected - observed)
    if not np.all(error <= 1e-9 * np.maximum(1.0, np.abs(expected))):
        raise ValueError(f"{case['name']}: independent maximum estimate error {error.max()}")
    return {'name': case['name'], 'route': case['route'], 'design_shape': list(design.shape),
            'response_shape': list(response.shape), 'outputs': weights.shape[0],
            'maximum_absolute_error': float(error.max())}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    if args.output.exists():
        raise ValueError('Use a new receipt path')
    raw = args.input.read_bytes()
    document = json.loads(raw)
    if document['schema'] != 'scalafim.selected-estimation-fixtures.v1':
        raise ValueError('Unsupported fixture schema')
    cases = document['cases']
    if not cases or len({case['name'] for case in cases}) != len(cases):
        raise ValueError('Fixtures must be nonempty and uniquely identified')
    results = [check(case) for case in cases]
    receipt = {'schema': 'plsneuro.selected-estimation-numpy.v1', 'status': 'passed',
               'input_sha256': hashlib.sha256(raw).hexdigest(), 'numpy_version': np.__version__,
               'cases': results}
    args.output.write_text(json.dumps(receipt, indent=2, allow_nan=False) + '\n')
    print(args.output)


if __name__ == '__main__':
    main()

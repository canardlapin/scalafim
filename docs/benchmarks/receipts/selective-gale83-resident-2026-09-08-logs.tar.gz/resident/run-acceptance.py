#!/usr/bin/env python3
"""Run an explicit PLS Neuro probe lane; retain logs, identities and fail-closed receipts."""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import signal
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
MANIFEST = ROOT / 'tools/acceptance-manifest.json'
START = re.compile(r'^\[info\] running (?:\(fork\) )?([\w.]+)(?:\s|$)')
FAIL = re.compile(r'Exception in thread|(?:[\w.$]+\.)[\w$]*(?:Exception|Error)(?::|$)|nonzero exit code|^\[error\] (?:\(|--)')
RUNTIME_EXPORT = re.compile(r'^\[info\] ACCEPTANCE_RUNTIME_INPUTS (\w+) (.+)$', re.MULTILINE)
freeze_spec = importlib.util.spec_from_file_location('frozen_runtime', ROOT / 'tools/freeze-runtime-inputs.py')
frozen_runtime = importlib.util.module_from_spec(freeze_spec)
freeze_spec.loader.exec_module(frozen_runtime)


def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def source_snapshot(root=ROOT):
    paths = [root / 'build.sbt', root / '.jvmopts', root / 'docs/provider-contract.json']
    for folder in ('modules', 'project', 'tools'):
        for directory, dirs, files in os.walk(root / folder):
            dirs[:] = sorted(d for d in dirs if d not in ('target', '__pycache__', '.git'))
            paths.extend(Path(directory) / f for f in sorted(files)
                         if Path(f).suffix in ('.scala', '.sbt', '.py', '.json', '.css', '.properties', '.R', '.patch'))
    return {str(p.relative_to(root)): digest(p) for p in sorted(paths) if p.is_file()}


def load_manifest(path=MANIFEST, root=ROOT):
    manifest = json.loads(path.read_text())
    if manifest.get('schema') != 'plsneuro.acceptance.v1':
        raise ValueError('Unknown acceptance manifest schema')
    probes = manifest['probes']
    names = [p['main'] for p in probes]
    if not probes or len(set(names)) != len(names):
        raise ValueError('Empty or duplicate probe catalog')
    actual = {str(p.relative_to(root)) for p in (root / 'modules').glob('*/src/test/scala/**/*Probe.scala')}
    if {p['source'] for p in probes} != actual:
        raise ValueError('Probe source inventory drift: update the explicit catalog')
    for p in probes:
        if not (root / p['source']).is_file():
            raise ValueError('Missing probe source: ' + p['source'])
        if p['lane'] is None:
            if not p.get('pending_reason'):
                raise ValueError('Unscheduled probe needs an explicit reason')
        else:
            if p['lane'] not in manifest['lanes'] or p['pass_count'] < 1 or not p['pass_patterns']:
                raise ValueError('Scheduled probe needs a lane and positive PASS contract')
            if not re.fullmatch(r'(core|adapters|desktop|glmReview|glmReviewJavafx)', p['module']) or not re.fullmatch(r'[\w.]+', p['main']):
                raise ValueError('Invalid sbt task identity')
            for pattern, count in p['pass_patterns'].items():
                if not isinstance(count, int) or count < 1:
                    raise ValueError('PASS pattern count must be positive')
                re.compile(pattern)
    for lane, settings in manifest['lanes'].items():
        if not any(p['lane'] == lane for p in probes) or settings['timeout_seconds'] <= 0:
            raise ValueError('Empty lane or invalid timeout: ' + lane)
    return manifest


def analyze_log(text, probes, exit_code, timed_out=False):
    problems = []
    if not probes:
        problems.append('Empty acceptance selection')
    if exit_code != 0:
        problems.append(f'Process exit: {exit_code}')
    if timed_out:
        problems.append('Lane timed out')
    blocks = []
    for line in text.splitlines():
        start = START.match(line)
        if start:
            blocks.append({'main': start[1], 'passes': []})
        clean = re.sub(r'^\[(?:info|error)\] ', '', line)
        if clean.startswith('PASS:'):
            if blocks:
                blocks[-1]['passes'].append(clean)
            else:
                problems.append('PASS outside a probe execution')
        if FAIL.search(line):
            problems.append(line.strip())
    if [b['main'] for b in blocks] != [p['main'] for p in probes]:
        problems.append('Executed probe order/count differs from required manifest')
    results = []
    for index, p in enumerate(probes):
        b = blocks[index] if index < len(blocks) and blocks[index]['main'] == p['main'] else None
        errors = []
        if b is None:
            errors.append('Probe did not run in its required position')
        else:
            if len(b['passes']) != p['pass_count']:
                errors.append(f"Expected {p['pass_count']} PASS records; found {len(b['passes'])}")
            for pattern, count in p['pass_patterns'].items():
                found = sum(re.fullmatch(pattern, line) is not None for line in b['passes'])
                if found != count:
                    errors.append(f'PASS pattern {pattern!r}: expected {count}, found {found}')
        problems.extend(p['main'] + ': ' + e for e in errors)
        results.append({'main': p['main'], 'pass_count': len(b['passes']) if b else 0,
                        'errors': errors})
    return results, problems


def run_process(argv, log, timeout, cwd=ROOT):
    """Own a fresh process group; never attach to or clean up another session."""
    started = time.monotonic()
    timed_out = False
    leftovers = False
    with log.open('w') as output:
        process = subprocess.Popen(argv, cwd=cwd, stdout=output, stderr=subprocess.STDOUT,
                                   start_new_session=True)
        try:
            code = process.wait(timeout=timeout)
        except (subprocess.TimeoutExpired, KeyboardInterrupt):
            timed_out = True
            os.killpg(process.pid, signal.SIGTERM)
            try:
                process.wait(timeout=3)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGKILL)
                process.wait()
            code = process.returncode
        finally:
            # Descendants of this owned launcher must not survive a lane exit.
            try:
                os.killpg(process.pid, 0)
            except ProcessLookupError:
                pass
            else:
                leftovers = True
                os.killpg(process.pid, signal.SIGKILL)
    return code, timed_out, leftovers, time.monotonic() - started


def sbt_token(value):
    # sbt parses its own command string after subprocess argv; refuse ambiguous text.
    if not re.fullmatch(r'[A-Za-z0-9_./:-]+', value):
        raise ValueError('Acceptance paths/arguments must currently use simple characters without spaces: ' + value)
    return value


def lane_probes(manifest, lane):
    selected = set()
    ordered = []
    active = set()
    def visit(name):
        if name in active:
            raise ValueError('Lane dependency cycle')
        if name in selected:
            return
        active.add(name)
        for dependency in manifest['lanes'][name]['requires']:
            visit(dependency)
        active.remove(name)
        selected.add(name)
        ordered.append(name)
    visit(lane)
    return [p for name in ordered for p in manifest['probes'] if p['lane'] == name]


def runtime_inputs(log, modules):
    exports = RUNTIME_EXPORT.findall(log)
    if [module for module, _ in exports] != modules:
        raise ValueError('Compiled runtime export order/count differs from the required modules')
    inputs = {}
    for module, path in exports:
        data = json.loads(Path(path).read_text())
        if data.get('schema') != 'plsneuro.acceptance-runtime.v1' or data.get('module') != module:
            raise ValueError('Runtime export identity differs from its build task')
        if not data['classpath'] or not all(Path(entry).is_absolute() for entry in data['classpath']):
            raise ValueError('Runtime classpath must contain explicit absolute paths')
        if not Path(data['java_home']).is_absolute() or not Path(data['working_directory']).is_absolute():
            raise ValueError('Runtime Java home and working directory must be explicit')
        inputs[module] = data
    return inputs


def probe_argv(probe, runtime, classpath, output):
    arguments = [arg.replace('{work}', str(output / 'work')).replace('{root}', str(ROOT)) for arg in probe['args']]
    java = Path(runtime['java_home']) / 'bin' / ('java.exe' if os.name == 'nt' else 'java')
    return [str(java), *runtime['java_options'], '-cp', os.pathsep.join(classpath), probe['main'], *arguments]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--lane')
    parser.add_argument('--providers', type=Path)
    parser.add_argument('--output', type=Path)
    parser.add_argument('--list', action='store_true')
    args = parser.parse_args()
    manifest = load_manifest()
    if args.list:
        for lane in manifest['lanes']:
            print(lane + ': ' + ', '.join(p['main'].split('.')[-1] for p in lane_probes(manifest, lane)))
        print('Unscheduled: ' + ', '.join(p['main'].split('.')[-1] for p in manifest['probes'] if p['lane'] is None))
        return 0
    if args.lane not in manifest['lanes'] or args.providers is None or args.output is None:
        parser.error('--lane, --providers and fresh --output are required')
    providers = args.providers.resolve(strict=True)
    output = args.output.resolve()
    if output.exists():
        parser.error('--output must not exist; earlier evidence is never overwritten')
    sbt_token(str(output))
    sbt_token(str(providers))
    probes = lane_probes(manifest, args.lane)
    modules = list(dict.fromkeys(p['module'] for p in probes))
    commands = [module + '/acceptanceRuntimeInputs' for module in modules]
    argv = ['sbt', '-Dsbt.color=false', '-Dsbt.supershell=false', '-Dplsneuro.providers=' + str(providers), *commands]
    output.mkdir(parents=True)
    (output / 'work').mkdir()
    before = source_snapshot()
    receipt = {'schema': 'plsneuro.acceptance-receipt.v1', 'status': 'running',
               'lane': args.lane, 'coverage': 'declared lane only; not full product or scientific admission',
               'manifest_sha256': digest(MANIFEST), 'sources_before': before,
               'provider_contract': json.loads((ROOT / 'docs/provider-contract.json').read_text()),
               'provider_root': str(providers), 'argv': argv, 'cwd': str(ROOT),
               'java_home': os.environ.get('JAVA_HOME'), 'required': [p['main'] for p in probes],
               'not_run': [p['main'] for p in manifest['probes'] if p not in probes]}
    receipt_path = output / 'receipt.json'
    receipt_path.write_text(json.dumps(receipt, indent=2) + '\n')
    print(f'Compiling and freezing runtime for {len(probes)} required probes; log: {output / "build.log"}', flush=True)
    started = time.monotonic()
    deadline = started + manifest['lanes'][args.lane]['timeout_seconds']
    try:
        code, timeout, leftovers, elapsed = run_process(argv, output / 'build.log', max(.001, deadline - time.monotonic()))
        build_text = (output / 'build.log').read_text(errors='replace')
        receipt['build'] = {'exit_code': code, 'timed_out': timeout, 'leftovers': leftovers, 'seconds': elapsed}
        if code != 0 or timeout or leftovers or '[error]' in build_text:
            raise ValueError('Runtime compilation did not complete cleanly')
        inputs = runtime_inputs(build_text, modules)
        required = {module: [p['main'].replace('.', '/') + '.class' for p in probes if p['module'] == module]
                    for module in modules}
        classpaths, copied = frozen_runtime.freeze_classpaths(
            {module: data['classpath'] for module, data in inputs.items()}, output / 'runtime', required)
        frozen_runtime.verify_frozen(copied)
        receipt['runtime_inputs'] = inputs
        receipt['frozen_runtime_receipt'] = str(output / 'runtime/input-receipt.json')
        receipt['executions'] = []
        (output / 'probes').mkdir()
        print(f'Running {len(probes)} probes from verified copied runtime inputs; log: {output / "run.log"}', flush=True)
        with (output / 'run.log').open('w') as combined:
            for index, probe in enumerate(probes):
                if time.monotonic() >= deadline:
                    code, timeout = 124, True
                    break
                runtime = inputs[probe['module']]
                command = probe_argv(probe, runtime, classpaths[probe['module']], output)
                combined.write('[info] running (fork) ' + probe['main'] + '\n')
                combined.flush()
                log = output / 'probes' / f'{index:03d}-{probe["main"].split(".")[-1]}.log'
                code, timeout, remaining, seconds = run_process(command, log,
                    max(.001, deadline - time.monotonic()), cwd=runtime['working_directory'])
                leftovers = leftovers or remaining
                combined.write(log.read_text(errors='replace'))
                combined.write('\n')
                combined.flush()
                receipt['executions'].append({'main': probe['main'], 'argv': command,
                    'cwd': runtime['working_directory'], 'exit_code': code, 'timed_out': timeout,
                    'leftovers': remaining, 'seconds': seconds})
                if code != 0 or timeout or remaining:
                    break
        frozen_runtime.verify_frozen(copied)
        results, problems = analyze_log((output / 'run.log').read_text(errors='replace'), probes, code, timeout)
        if leftovers:
            problems.append('Owned descendant processes survived launcher exit and required cleanup')
        after = source_snapshot()
        if before != after:
            problems.append('Source inventory changed during acceptance')
        receipt.update(exit_code=code, timed_out=timeout, owned_descendants_at_exit=leftovers,
                       elapsed_seconds=time.monotonic() - started, results=results, problems=problems, sources_after=after,
                       artifacts={str(p.relative_to(output)): digest(p) for p in sorted(output.rglob('*')) if p.is_file() and p != receipt_path})
        receipt['status'] = 'failed' if problems else 'passed'
    except Exception as error:
        receipt.update(status='failed', problems=[f'{type(error).__name__}: {error}'])
    receipt_path.write_text(json.dumps(receipt, indent=2) + '\n')
    print(receipt['status'].upper() + ': ' + str(receipt_path), flush=True)
    for problem in receipt.get('problems', []):
        print(problem, file=sys.stderr)
    return 0 if receipt['status'] == 'passed' else 1


if __name__ == '__main__':
    raise SystemExit(main())

#!/usr/bin/env python3
"""Copy and verify runtime classpaths before launching scientific acceptance.

The source, frozen bytes and source again must agree. A missing or changing
input leaves a failed receipt and must never be used to launch a JVM.
"""
import hashlib
import json
import os
from pathlib import Path
import shutil
import zipfile


def file_digest(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()


def snapshot(path):
    if path.is_file():
        return {'kind': 'file', 'sha256': file_digest(path)}
    if not path.is_dir():
        raise ValueError(f'Missing runtime input: {path}')
    files = {}
    for entry in sorted(path.rglob('*')):
        if entry.is_symlink():
            raise ValueError(f'Runtime directory contains a live symbolic link: {entry}')
        if entry.is_file():
            files[str(entry.relative_to(path))] = file_digest(entry)
        elif not entry.is_dir():
            raise ValueError(f'Unsupported runtime input: {entry}')
    identity = hashlib.sha256(json.dumps(files, sort_keys=True).encode()).hexdigest()
    return {'kind': 'directory', 'sha256': identity, 'files': files}


def contains_class(entries, name):
    for entry in entries:
        path = Path(entry)
        if path.is_dir() and (path / name).is_file():
            return True
        if path.is_file() and zipfile.is_zipfile(path):
            with zipfile.ZipFile(path) as archive:
                if name in archive.namelist():
                    return True
    return False


def freeze_classpaths(classpaths, destination, required_classes=None):
    """Return immutable-by-convention copied entries and a complete byte receipt.

    Classpath order is preserved, and repeated canonical entries share one copy.
    Callers supply the classes required to launch their actual probes. Source
    directories may be empty when the build legitimately supplies an empty entry.
    """
    destination = Path(destination).resolve()
    if not classpaths or any(not entries for entries in classpaths.values()):
        raise ValueError('Every runtime classpath must contain explicit entries')
    destination.mkdir(parents=True, exist_ok=False)
    receipt_path = destination / 'input-receipt.json'
    receipt = {'schema': 'plsneuro.frozen-runtime.v1', 'status': 'preparing',
               'inputs': [], 'classpaths': {}, 'required_classes': required_classes or {}}
    try:
        canonical = {name: [Path(entry).resolve(strict=True) for entry in entries]
                     for name, entries in classpaths.items()}
        sources = list(dict.fromkeys(path for entries in canonical.values() for path in entries))
        # Take the complete initial inventory before any copy, and validate the
        # complete source inventory again after all copies have finished.
        before = {path: snapshot(path) for path in sources}
        copies = {}
        for index, source in enumerate(sources):
            target = destination / f'{index:04d}'
            if before[source]['kind'] == 'directory':
                shutil.copytree(source, target)
            else:
                target = target.with_suffix(source.suffix)
                shutil.copyfile(source, target)
            if snapshot(target) != before[source]:
                raise ValueError(f'Runtime bytes changed while copying: {source}')
            copies[source] = target
            receipt['inputs'].append({'source': str(source), 'frozen': str(target), **before[source]})
        for source in sources:
            if snapshot(source) != before[source]:
                raise ValueError(f'Concurrent runtime input mutation: {source}')
        frozen = {name: [str(copies[path]) for path in entries] for name, entries in canonical.items()}
        for name, classes in (required_classes or {}).items():
            if name not in frozen:
                raise ValueError(f'Required classes name an unknown classpath: {name}')
            for required in classes:
                if not contains_class(frozen[name], required):
                    raise ValueError(f'Incomplete runtime {name}: missing {required}')
        receipt.update(status='passed', classpaths=frozen)
        receipt_path.write_text(json.dumps(receipt, indent=2, sort_keys=True) + '\n')
        return frozen, receipt
    except Exception as error:
        receipt.update(status='failed', error=f'{type(error).__name__}: {error}')
        receipt_path.write_text(json.dumps(receipt, indent=2, sort_keys=True) + '\n')
        raise


def verify_frozen(receipt):
    """Refuse modified copied inputs before reuse or accepting a completed run."""
    if receipt.get('status') != 'passed':
        raise ValueError('Runtime freezing did not complete')
    for entry in receipt['inputs']:
        expected = {key: entry[key] for key in ('kind', 'sha256', 'files') if key in entry}
        if snapshot(Path(entry['frozen'])) != expected:
            raise ValueError(f'Frozen runtime input changed: {entry["frozen"]}')


def joined(classpaths):
    return {name: os.pathsep.join(entries) for name, entries in classpaths.items()}

import gzip,hashlib,io,json,statistics,tarfile
from pathlib import Path
root=Path('/Users/bbuchsbaum/code/scala/plsneuro')
mainroot=Path('/private/tmp/plsneuro-selected-file-32768-1')
smokeroot=Path('/private/tmp/plsneuro-selected-file-smoke-1')
nmtroot=Path('/private/tmp/plsneuro-selected-file-nmt-1')
main=json.loads((mainroot/'receipt.json').read_text())
nmt=json.loads((nmtroot/'receipt.json').read_text())
smoke=json.loads((smokeroot/'receipt.json').read_text())
assert all(r['status']=='passed' for r in [main,nmt,smoke])
assert len(main['executions'])==26 and len(main['comparisons'])==12 and len(nmt['executions'])==4
entries={}
for label,directory in [('file',mainroot),('smoke',smokeroot),('native-memory',nmtroot)]:
 for path in sorted(directory.rglob('*')):
  if not path.is_file(): continue
  relative=path.relative_to(directory)
  if relative.parts[0]=='runtime' and relative.as_posix()!='runtime/input-receipt.json': continue
  if path.name.endswith('.nii.gz'): continue
  if path.suffix not in ['.json','.log','.py','.scala','.patch','.gz']: continue
  entries[label+'/'+relative.as_posix()]=path.read_bytes()
entries['retention-script.py']=Path(__file__).read_bytes()
archive=root/'docs/verification/selective-estimation-file-logs.tar.gz'
with archive.open('wb') as out:
 with gzip.GzipFile(fileobj=out,mode='wb',mtime=0) as compressed:
  with tarfile.open(fileobj=compressed,mode='w') as tar:
   for name,data in sorted(entries.items()):
    entry=tarfile.TarInfo(name); entry.size=len(data); entry.mode=0o644; entry.mtime=0
    tar.addfile(entry,io.BytesIO(data))
rows=[]
for representation in ['condition','contrast','FIR']:
 for route in ['shared','pooled']:
  for variant in ['selected','full']:
   es=[e for e in main['executions'] if e['name'].startswith(f'{representation}-{route}-{variant}-')]
   row={'representation':representation,'route':route,'variant':variant,
        'peak_process_rss_bytes':[e['peak_process_rss_bytes'] for e in es],
        'selected_preparation_ns':[e['native_result']['selected_preparation_ns'] for e in es],
        'initial_source_verification_ns':[e['native_result']['initial_source_verification_ns'] for e in es],
        'final_source_verification_ns':[e['native_result']['final_source_verification_ns'] for e in es],
        'header_open_ns':[e['native_result']['header_open_ns'] for e in es]}
   for pass_index,label in enumerate(['first','repeated']):
    row[label]={key:[e['native_result']['passes'][pass_index][key] for e in es] for key in
                ['execution_ns','payload_read_decode_ns','sink_write_ns','sink_force_ns',
                 'fit_conversion_and_remaining_ns','reads','largest_read_voxels']}
   rows.append(row)
receipt={'schema':'plsneuro.selected-file-evidence.v1','status':'passed','scope':main['scope'],
 'production_candidate_patch_sha256':main['provider_patch_sha256'],
 'provider_revision':main['provider_revision'],'gale_revision':main['gale_revision'],
 'qualification_sources':main['qualification_sources'],'hardware':{key:main[key] for key in
 ['cpu','physical_memory_bytes','platform','java_version','java_options','thread_environment']},
 'dimensions':{'voxels':32768,'timepoints':640,'runs':2,'nuisance_columns_per_run':16,'block_voxels':512,
               'output_rows':{'condition':8,'contrast':1,'FIR':64},'forks':2,'passes_per_fork':2},
 'maximum_full_selected_absolute_error':max(c['maximum_absolute_error'] for c in main['comparisons']),
 'maximum_independent_svd_absolute_error':max(c['maximum_absolute_error'] for e in main['executions']
       if 'numpy' in e['native_result'] for c in e['native_result']['numpy']['cases']),
 'equivalence_comparisons':12,'written_output_pass_comparisons':24,'independent_svd_checks':24,
 'deterministic_cancellation_checks':24,'all_first_repeated_output_hashes_identical':all(
   len({p['output_sha256'] for p in e['native_result']['passes']})==1 for e in main['executions'] if 'passes' in e['native_result']),
 'staging':[e['native_result'] for e in main['executions'][:2]],'rows':rows,
 'native_memory':nmt,'file_qualification':main,
 'smoke':{'status':smoke['status'],'source_receipt_sha256':hashlib.sha256((smokeroot/'receipt.json').read_bytes()).hexdigest()},
 'archive':{'path':archive.name,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),
            'entries':{name:hashlib.sha256(data).hexdigest() for name,data in entries.items()}},
 'limits':['Synthetic float64 data with low compression; does not establish throughput for every scanner/mask/storage combination.',
 'Prepared selected execution includes actual reads, native conversion/pooling and a test-only binary sink with fsync; preparation, source verification and staging remain separately reported.',
 'Internal fit phases have no public timing hook and remain combined; no individual kernel or noise/pooling time is inferred.',
 'First/repeated passes are not cold/warm OS-cache measurements; source hashing touches input bytes before each process.',
 'RSS includes the JVM and a 64-voxel fixture; MXBean pool peaks are independent. NMT reserved/committed are not live heap or simultaneous native peak.',
 'File payloads/runtime binaries are omitted from the archive; exact generators, source hashes, output hashes, sampled oracles and compiled input inventories are retained.',
 'No application durable format, saved-project reopening, native vector/FFM throughput or release/publication is implied.']}
output=root/'docs/verification/selective-estimation-file.json.gz'
output.write_bytes(gzip.compress((json.dumps(receipt,indent=2,allow_nan=False)+'\n').encode(),mtime=0))
with tarfile.open(archive,'r:gz') as tar:
 assert tar.getnames()==sorted(entries)
 for name,data in entries.items(): assert tar.extractfile(name).read()==data
assert json.loads(gzip.decompress(output.read_bytes()))['status']=='passed'
print(json.dumps({'receipt':str(output),'receipt_bytes':output.stat().st_size,'archive_bytes':archive.stat().st_size,'entries':len(entries)},indent=2))

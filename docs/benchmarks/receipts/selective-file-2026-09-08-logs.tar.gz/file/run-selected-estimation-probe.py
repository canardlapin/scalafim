#!/usr/bin/env python3
"""Measure resident-data selected/full first-level routes in an owned provider candidate.

This runner records JMH timing/allocation evidence. It does not measure file IO,
source verification, durable sinks, or the complete desktop workflow.
"""
import argparse
import gzip
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import platform
import re
import subprocess

ROOT = Path(__file__).resolve().parents[1]
BENCHMARK = Path('benchmarks/fit-jvm/src/main/scala/scalafim/fmri/fit/SelectedFirstLevelBenchmark.scala')
FILE_BENCHMARK = BENCHMARK.with_name('SelectedFirstLevelFileBenchmark.scala')
QUALIFICATION_SOURCES = (BENCHMARK, FILE_BENCHMARK)


def output(*args):
    return subprocess.check_output([str(x) for x in args], text=True).strip()


def exported_classpath(log):
    """Read the one explicit `export Jmh/fullClasspath` result from sbt."""
    rows = [line.strip() for line in log.splitlines() if line.startswith(os.path.sep)]
    if len(rows) != 1:
        raise ValueError(f'Expected one exported benchmark classpath, found {len(rows)}')
    entries = rows[0].split(os.pathsep)
    if not entries or any(not Path(entry).is_absolute() for entry in entries):
        raise ValueError('Benchmark classpath must contain explicit absolute paths')
    return entries


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--providers', type=Path, required=True)
    parser.add_argument('--destination', type=Path, required=True)
    parser.add_argument('--java-home', type=Path, required=True)
    parser.add_argument('--smoke', action='store_true', help='Fixture validation only; not performance evidence')
    parser.add_argument('--voxels', type=int)
    parser.add_argument('--block-voxels', type=int)
    args = parser.parse_args()
    providers = args.providers.resolve()
    if not (providers / '.plsneuro-provider-probe').is_file():
        raise ValueError('Use an owned prepared provider candidate')
    contract = json.loads((ROOT / 'docs/provider-contract.json').read_text())
    gale = contract['gale_source_coordinate']
    qualification_path = ROOT / gale['qualification_receipt']
    qualification_bytes = qualification_path.read_bytes()
    qualification = json.loads(gzip.decompress(qualification_bytes))
    if qualification['revision'] != gale['revision'] or qualification['native_gale_gates_status'] != 'passed':
        raise ValueError('The declared Gale revision lacks matching native qualification')
    qr_digest = qualification['gale_qr_implementation_sha256']
    if not re.fullmatch(r'[0-9a-f]{64}', qr_digest):
        raise ValueError('Gale qualification must fingerprint the loaded QR implementation')
    declared = contract['providers']['scalafim']
    checkout = providers / ('scalafim-' + declared['revision'])
    if output('git', '-C', checkout, 'rev-parse', 'HEAD') != declared['revision']:
        raise ValueError('Provider base differs from the declared revision')
    patch = (ROOT / declared['candidate_patch']['path']).read_bytes()
    if hashlib.sha256(patch).hexdigest() != declared['candidate_patch']['sha256']:
        raise ValueError('Declared provider patch digest differs')
    actual = subprocess.check_output(['git', '-C', str(checkout), 'diff', 'HEAD', '--binary'])
    if actual != patch:
        raise ValueError('Tracked candidate differs from the exact provider patch')
    untracked = output('git', '-C', checkout, 'ls-files', '--others', '--exclude-standard').splitlines()
    if set(untracked) - {str(path) for path in QUALIFICATION_SOURCES}:
        raise ValueError('Candidate has undeclared sources other than the captured qualification benchmarks')
    source = checkout / BENCHMARK
    source_bytes = source.read_bytes()
    qualification_sources = {str(path): (checkout / path).read_bytes()
                             for path in QUALIFICATION_SOURCES if (checkout / path).is_file()}
    # An untracked benchmark is an explicitly captured qualification source,
    # separate from the exact production provider patch above.
    destination = args.destination.resolve()
    if destination.exists():
        raise ValueError('Use a new evidence directory; previous runs are immutable')
    voxels = args.voxels if args.voxels is not None else (64 if args.smoke else 8192)
    block = args.block_voxels if args.block_voxels is not None else (32 if args.smoke else 512)
    if voxels <= 0 or block <= 0:
        raise ValueError('Voxel and block counts must be positive')
    destination.mkdir(parents=True)
    (destination / '.plsneuro-selected-estimation-probe').write_text('plsneuro.selected-estimation-probe.v1\n')
    for path, content in qualification_sources.items():
        (destination / Path(path).name).write_bytes(content)
    (destination / 'gale-qualification.json.gz').write_bytes(qualification_bytes)
    results_file = destination / 'jmh.json'
    pattern = '.*SelectedFirstLevelBenchmark.selectedPreparation' if args.smoke else '.*SelectedFirstLevelBenchmark.*'
    project = f'{{{checkout.as_uri()}/}}fitBenchJVM'
    # JMH includes the benchmark project's Test output even when it has no
    # test sources/resources. Ask sbt to materialize only that declared empty
    # output; every other missing classpath entry still fails runtime freezing.
    ref = 'ProjectRef(uri(' + json.dumps(checkout.as_uri() + '/') + '), "fitBenchJVM")'
    materialize_empty_test_output = (
        f'set {ref} / ConfigKey("jmh") / fullClasspath := {{ '
        f'val cp = ({ref} / ConfigKey("jmh") / fullClasspath).value; '
        f'val output = ({ref} / Test / classDirectory).value; '
        f'val testSources = ({ref} / Test / sources).value; '
        f'val testResources = ({ref} / Test / resources).value; '
        'if (!output.exists && testSources.isEmpty && testResources.isEmpty) IO.createDirectory(output); cp }')
    build_commands = [materialize_empty_test_output, project + '/Jmh/compile',
                      'export ' + project + '/Jmh/fullClasspath']
    jmh_options = [pattern, '-p', f'voxels={voxels}', '-p', f'blockVoxels={block}',
                   '-t', '1', '-prof', 'gc', '-jvm', str(args.java_home.resolve() / 'bin/java'),
                   '-jvmArgsAppend', '-Xmx4g -XX:ActiveProcessorCount=1']
    jmh_options += (['-wi', '0', '-i', '1', '-r', '100ms', '-f', '1'] if args.smoke
                    else ['-wi', '3', '-w', '1s', '-i', '5', '-r', '1s', '-f', '2'])
    jmh_options += ['-rf', 'json', '-rff', str(results_file)]
    cpu = output('sysctl', '-n', 'machdep.cpu.brand_string') if platform.system() == 'Darwin' else platform.processor()
    receipt = {
        'schema': 'plsneuro.selected-estimation-resident.v1', 'status': 'running',
        'qualification': 'fixture-smoke-only' if args.smoke else 'resident-dataset-jmh',
        'scope': 'Preparation and resident bounded dataset execution; excludes verification, filesystem reads, decompression and durable output.',
        'provider_revision': declared['revision'], 'provider_patch_sha256': hashlib.sha256(patch).hexdigest(),
        'gale_revision': gale['revision'], 'gale_qr_implementation_sha256': qr_digest,
        'gale_qualification_sha256': hashlib.sha256(qualification_bytes).hexdigest(),
        'benchmark_sha256': hashlib.sha256(source_bytes).hexdigest(),
        'qualification_sources': {path: hashlib.sha256(content).hexdigest()
                                  for path, content in qualification_sources.items()},
        'benchmark_is_additional_qualification_source': str(BENCHMARK) in untracked,
        'platform': platform.platform(), 'cpu': cpu, 'java_home': str(args.java_home.resolve()),
        'build_commands': build_commands, 'jmh_options': jmh_options,
        'voxels': voxels, 'block_voxels': block,
    }
    receipt_file = destination / 'receipt.json'
    receipt_file.write_text(json.dumps(receipt, indent=2) + '\n')
    spec = importlib.util.spec_from_file_location('acceptance_process', ROOT / 'tools/run-acceptance.py')
    helper = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(helper)
    os.environ['JAVA_HOME'] = str(args.java_home.resolve())
    os.environ['VECLIB_MAXIMUM_THREADS'] = '1'
    for name in ['run-selected-estimation-probe.py', 'run-acceptance.py', 'freeze-runtime-inputs.py']:
        (destination / name).write_bytes((ROOT / 'tools' / name).read_bytes())
    (destination / 'provider-contract.json').write_text(json.dumps(contract, indent=2) + '\n')
    (destination / 'scalafim-production.patch').write_bytes(patch)
    build_log = destination / 'build.log'
    log = destination / 'execution.log'
    try:
        code, timed_out, leftovers, elapsed = helper.run_process(
            ['sbt', '-Dsbt.supershell=false', '-Dsbt.color=false', *build_commands],
            build_log, 1200, cwd=providers / 'consumer')
        build_text = build_log.read_text()
        receipt['build'] = dict(exit_code=code, timed_out=timed_out, leftovers=leftovers, seconds=elapsed,
                               log_sha256=hashlib.sha256(build_log.read_bytes()).hexdigest())
        if code != 0 or timed_out or leftovers or '[error]' in build_text:
            raise ValueError('Benchmark runtime compilation did not complete cleanly')
        classpaths, copied = helper.frozen_runtime.freeze_classpaths(
            {'jmh': exported_classpath(build_text)}, destination / 'runtime',
            {'jmh': ['org/openjdk/jmh/Main.class', 'META-INF/BenchmarkList',
                     'scalafim/fmri/fit/SelectedFirstLevelBenchmark.class']})
        helper.frozen_runtime.verify_frozen(copied)
        command = [str(args.java_home.resolve() / 'bin/java'), '-Xmx4g', '-XX:ActiveProcessorCount=1',
                   '-cp', os.pathsep.join(classpaths['jmh']), 'org.openjdk.jmh.Main', *jmh_options]
        receipt.update(argv=command, frozen_runtime_receipt='runtime/input-receipt.json')
        code, timed_out, leftovers, elapsed = helper.run_process(command, log, 3600, cwd=providers / 'consumer')
        helper.frozen_runtime.verify_frozen(copied)
        if any((checkout / path).read_bytes() != content for path, content in qualification_sources.items()):
            raise ValueError('Benchmark source changed during qualification')
        if subprocess.check_output(['git', '-C', str(checkout), 'diff', 'HEAD', '--binary']) != patch:
            raise ValueError('Production provider source changed during qualification')
    except Exception as error:
        receipt.update(status='failed', errors=[f'{type(error).__name__}: {error}'])
        receipt_file.write_text(json.dumps(receipt, indent=2) + '\n')
        raise
    text = log.read_text()
    results = json.loads(results_file.read_text()) if results_file.exists() else []
    errors = []
    expected = 6 if args.smoke else 18
    if code != 0 or timed_out or leftovers:
        errors.append('Owned process did not complete cleanly')
    if len(results) != expected:
        errors.append(f'Expected {expected} complete JMH cases, found {len(results)}')
    if any(not math.isfinite(row['primaryMetric']['score']) for row in results):
        errors.append('JMH returned a non-finite primary score')
    equivalence = re.findall(r'SELECTED_EQUIVALENCE ([^\r\n]+)', text)
    expected_checks = expected * (1 if args.smoke else 2)
    if len(equivalence) != expected_checks:
        errors.append(f'Expected {expected_checks} full/selected equivalence checks, found {len(equivalence)}')
    if any(f'galeQrImplementationSha256={qr_digest}' not in check for check in equivalence):
        errors.append('A benchmark fork loaded a different Gale QR implementation')
    if '[error]' in text or '<failure>' in text or 'Exception' in text:
        errors.append('Benchmark log contains a failure')
    receipt.update(status='failed' if errors else 'passed', exit_code=code, timed_out=timed_out,
                   leftover_processes=leftovers, seconds=elapsed, errors=errors,
                   equivalence_checks=equivalence, results=results,
                   log_sha256=hashlib.sha256(log.read_bytes()).hexdigest())
    receipt_file.write_text(json.dumps(receipt, indent=2, allow_nan=False) + '\n')
    if errors:
        raise RuntimeError('; '.join(errors))
    print(receipt_file)


if __name__ == '__main__':
    main()

#!/usr/bin/env python3
"""Qualify native file-backed selected/full estimation and process resources.

Writes test-only numerical payloads for independent comparison. This is not a
scientific result format, application save/reopen test or cold-OS-cache claim.
"""
import argparse
import gzip
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import platform
import re
import subprocess
import time

ROOT = Path(__file__).resolve().parents[1]


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


acceptance = module('acceptance', ROOT / 'tools/run-acceptance.py')
resident = module('resident', ROOT / 'tools/run-selected-estimation-probe.py')


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--providers', type=Path, required=True)
    parser.add_argument('--destination', type=Path, required=True)
    parser.add_argument('--java-home', type=Path, required=True)
    parser.add_argument('--smoke', action='store_true')
    parser.add_argument('--voxels', type=int)
    parser.add_argument('--block-voxels', type=int)
    parser.add_argument('--forks', type=int)
    args = parser.parse_args()
    if platform.system() != 'Darwin':
        raise ValueError('This initial process-RSS runner qualifies macOS /usr/bin/time -l only')
    voxels = args.voxels if args.voxels is not None else (64 if args.smoke else 32768)
    block = args.block_voxels if args.block_voxels is not None else (32 if args.smoke else 512)
    forks = args.forks if args.forks is not None else (1 if args.smoke else 2)
    if not (voxels >= 64 and 0 < block < voxels and forks > 0):
        raise ValueError('Require at least 64 voxels, a smaller positive block, and positive forks')
    destination = args.destination.resolve()
    if destination.exists():
        raise ValueError('Use a new evidence directory')
    providers = args.providers.resolve()
    if not (providers / '.plsneuro-provider-probe').is_file():
        raise ValueError('An owned, prepared provider candidate is required')
    contract_bytes = (ROOT / 'docs/provider-contract.json').read_bytes()
    contract = json.loads(contract_bytes)
    declared = contract['providers']['scalafim']
    checkout = providers / ('scalafim-' + declared['revision'])
    patch = (ROOT / declared['candidate_patch']['path']).read_bytes()
    if sha(patch) != declared['candidate_patch']['sha256']:
        raise ValueError('Declared patch digest differs')
    if subprocess.check_output(['git', '-C', str(checkout), 'rev-parse', 'HEAD'], text=True).strip() != declared['revision']:
        raise ValueError('Provider revision differs')
    if subprocess.check_output(['git', '-C', str(checkout), 'diff', 'HEAD', '--binary']) != patch:
        raise ValueError('Candidate differs from the exact declared patch')
    untracked = subprocess.check_output(['git', '-C', str(checkout), 'ls-files', '--others', '--exclude-standard'], text=True).splitlines()
    if set(untracked) - {str(path) for path in resident.QUALIFICATION_SOURCES}:
        raise ValueError('Unexpected untracked provider input')
    sources = {str(path): (checkout / path).read_bytes() for path in resident.QUALIFICATION_SOURCES}
    gale = contract['gale_source_coordinate']
    qualification_bytes = (ROOT / gale['qualification_receipt']).read_bytes()
    qualified = json.loads(gzip.decompress(qualification_bytes))
    if qualified['revision'] != gale['revision'] or qualified['native_gale_gates_status'] != 'passed':
        raise ValueError('Matching Gale qualification is required')
    expected_kernel = qualified['gale_qr_implementation_sha256']
    destination.mkdir(parents=True)
    (destination / '.plsneuro-selected-file-probe').write_text('plsneuro.selected-file-probe.v1\n')
    (destination / 'provider-contract.json').write_bytes(contract_bytes)
    (destination / 'scalafim-production.patch').write_bytes(patch)
    (destination / 'gale-qualification.json.gz').write_bytes(qualification_bytes)
    for path, data in sources.items():
        (destination / Path(path).name).write_bytes(data)
    for name in ['run-selected-file-probe.py', 'run-selected-estimation-probe.py',
                 'run-acceptance.py', 'freeze-runtime-inputs.py', 'check-selected-estimation-fixtures.py']:
        (destination / name).write_bytes((ROOT / 'tools' / name).read_bytes())
    receipt_path = destination / 'receipt.json'
    receipt = {'schema': 'plsneuro.selected-file-qualification.v1', 'status': 'running',
               'qualification': 'fixture-smoke-only' if args.smoke else 'file-backed-resource-qualification',
               'provider_revision': declared['revision'], 'provider_patch_sha256': sha(patch),
               'gale_revision': gale['revision'], 'gale_qr_implementation_sha256': expected_kernel,
               'qualification_sources': {path: sha(data) for path, data in sources.items()},
               'platform': platform.platform(), 'java_home': str(args.java_home.resolve()),
               'voxels': voxels, 'block_voxels': block, 'forks': forks, 'passes_per_fork': 2,
               'java_options': ['-Xmx4g', '-XX:ActiveProcessorCount=1'], 'executions': [], 'comparisons': []}
    def save():
        receipt_path.write_text(json.dumps(receipt, indent=2, allow_nan=False) + '\n')
    save()
    os.environ['JAVA_HOME'] = str(args.java_home.resolve())
    for name in ['VECLIB_MAXIMUM_THREADS', 'OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS']:
        os.environ[name] = '1'
    started = time.monotonic()
    try:
        version = subprocess.run([str(args.java_home.resolve() / 'bin/java'), '-version'],
                                 capture_output=True, text=True, check=True)
        receipt['java_version'] = version.stdout + version.stderr
        receipt['thread_environment'] = {name: os.environ[name] for name in
            ['VECLIB_MAXIMUM_THREADS', 'OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS']}
        ref = '{' + checkout.as_uri() + '/}fitBenchJVM'
        build = ['sbt', '-Dsbt.color=false', '-Dsbt.supershell=false', ref + '/compile',
                 'export ' + ref + '/Compile/fullClasspath']
        code, timeout, leftovers, seconds = acceptance.run_process(build, destination / 'build.log',
            1200, cwd=providers / 'consumer')
        receipt['build'] = {'argv': build, 'exit_code': code, 'timed_out': timeout,
                            'leftovers': leftovers, 'seconds': seconds}
        text = (destination / 'build.log').read_text()
        if code != 0 or timeout or leftovers or '[error]' in text:
            raise ValueError('Native file qualification did not compile cleanly')
        classpaths, frozen = acceptance.frozen_runtime.freeze_classpaths(
            {'file': resident.exported_classpath(text)}, destination / 'runtime',
            {'file': ['scalafim/fmri/fit/SelectedFirstLevelFileBenchmark.class',
                      'scalafim/fmri/fit/SelectedFirstLevelBenchmark.class']})
        acceptance.frozen_runtime.verify_frozen(frozen)
        java = [str(args.java_home.resolve() / 'bin/java'), *receipt['java_options'], '-cp',
                os.pathsep.join(classpaths['file']), 'scalafim.fmri.fit.SelectedFirstLevelFileBenchmark']
        (destination / 'jobs').mkdir()
        receipt['cpu'] = subprocess.check_output(['sysctl', '-n', 'machdep.cpu.brand_string'], text=True).strip()
        receipt['physical_memory_bytes'] = int(subprocess.check_output(['sysctl', '-n', 'hw.memsize'], text=True))
        def execute(name, arguments, result_path):
            log = destination / 'jobs' / (name + '.log')
            command = ['/usr/bin/time', '-l', *java, *map(str, arguments)]
            code, timeout, leftovers, seconds = acceptance.run_process(command, log, 900, cwd=providers / 'consumer')
            text = log.read_text()
            rss = re.findall(r'^\s*(\d+)\s+maximum resident set size\s*$', text, re.MULTILINE)
            entry = {'name': name, 'argv': command, 'exit_code': code, 'timed_out': timeout,
                     'leftovers': leftovers, 'seconds': seconds, 'log_sha256': sha(log.read_bytes())}
            receipt['executions'].append(entry)
            save()
            if code != 0 or timeout or leftovers or len(rss) != 1 or 'Exception' in text:
                raise ValueError('Native job did not complete cleanly: ' + name)
            if f'galeQrImplementationSha256={expected_kernel}' not in text:
                raise ValueError('Native job loaded a different Gale kernel: ' + name)
            result = json.loads(result_path.read_text())
            if result['status'] != 'passed':
                raise ValueError('Native result did not pass: ' + name)
            entry.update(peak_process_rss_bytes=int(rss[0]), native_result=result)
            save()
            print('PASS ' + name, flush=True)
            return result
        # Condition and contrast use exactly the same model and response fixture.
        for representation in ['condition', 'FIR']:
            fixture = destination / ('fixture-' + representation)
            execute('create-' + representation, ['create', fixture, representation, voxels], fixture / 'fixture.json')
        import numpy as np
        for representation in ['condition', 'contrast', 'FIR']:
            fixture = destination / ('fixture-FIR' if representation == 'FIR' else 'fixture-condition')
            for route in ['shared', 'pooled']:
                for fork in range(forks):
                    results = {}
                    for variant in ['selected', 'full']:
                        name = f'{representation}-{route}-{variant}-{fork}'
                        target = destination / name
                        result = execute(name, ['run', fixture, representation, route, variant, voxels, block, target], target / 'receipt.json')
                        if result['gale_qr_implementation_sha256'] != expected_kernel:
                            raise ValueError('Written receipt kernel differs')
                        for item in result['passes']:
                            if item['fit_conversion_and_remaining_ns'] < 0:
                                raise ValueError('Invalid overlapping phase timing')
                            if variant == 'selected' and item['largest_read_voxels'] > block:
                                raise ValueError('Selected reader exceeded the bound')
                        oracle_command = [os.sys.executable, str(ROOT / 'tools/check-selected-estimation-fixtures.py'),
                                          '--input', str(target / 'oracle.json'), '--output', str(target / 'numpy.json')]
                        oracle = subprocess.run(oracle_command, capture_output=True, text=True)
                        (target / 'numpy.log').write_text(oracle.stdout + oracle.stderr)
                        if oracle.returncode != 0:
                            raise ValueError('Independent file oracle failed: ' + name)
                        result['numpy'] = json.loads((target / 'numpy.json').read_text())
                        results[variant] = result
                        save()
                    if results['selected']['output_ids'] != results['full']['output_ids']:
                        raise ValueError('Selected/full output identities differ')
                    if results['selected']['source_sha256'] != results['full']['source_sha256']:
                        raise ValueError('Selected/full source identities differ')
                    maximum = 0.0
                    shape = (results['selected']['outputs'], voxels)
                    for pass_index in range(2):
                        selected = np.memmap(results['selected']['passes'][pass_index]['output'], mode='r', dtype='<f8', shape=shape)
                        full = np.memmap(results['full']['passes'][pass_index]['output'], mode='r', dtype='<f8', shape=shape)
                        for start in range(0, voxels, 4096):
                            a, b = selected[:, start:start + 4096], full[:, start:start + 4096]
                            if not np.isfinite(a).all() or not np.isfinite(b).all():
                                raise ValueError('Non-finite written estimates')
                            difference = np.abs(a - b)
                            maximum = max(maximum, float(difference.max()))
                            if np.any(difference > 1e-8 * np.maximum(1.0, np.abs(b))):
                                raise ValueError('Written selected/full estimates differ')
                        del selected, full
                    receipt['comparisons'].append({'representation': representation, 'route': route,
                        'fork': fork, 'shape': shape, 'passes': 2, 'maximum_absolute_error': maximum})
                    save()
        acceptance.frozen_runtime.verify_frozen(frozen)
        if any((checkout / path).read_bytes() != data for path, data in sources.items()):
            raise ValueError('Qualification source changed during execution')
        if subprocess.check_output(['git', '-C', str(checkout), 'diff', 'HEAD', '--binary']) != patch:
            raise ValueError('Provider patch changed during execution')
        receipt.update(status='passed', seconds=time.monotonic() - started,
            scope='Verified staging miss/reuse, first/repeated file reads, native selected/full estimates, test-only output writes/fsync, independent sampled SVD checks, all-output equivalence, deterministic cancellation and process RSS. Includes real native conversion/pooling; does not isolate these internal phases or claim cold OS caches, scientific save/reopen or complete application throughput.')
    except Exception as error:
        receipt.update(status='failed', seconds=time.monotonic() - started, error=f'{type(error).__name__}: {error}')
        save()
        raise
    save()
    print(receipt_path)


if __name__ == '__main__':
    main()

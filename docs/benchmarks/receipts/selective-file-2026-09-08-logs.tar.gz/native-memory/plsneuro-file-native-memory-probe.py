#!/usr/bin/env python3
"""A separate instrumented resource pass over an already qualified frozen runtime."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import subprocess
import sys

root = Path('/Users/bbuchsbaum/code/scala/plsneuro')
spec = importlib.util.spec_from_file_location('acceptance', root / 'tools/run-acceptance.py')
acceptance = importlib.util.module_from_spec(spec)
spec.loader.exec_module(acceptance)
source = Path(sys.argv[1]).resolve()
destination = Path(sys.argv[2]).resolve()
if destination.exists():
    raise ValueError('Use a new resource evidence directory')
main = json.loads((source / 'receipt.json').read_text())
if main['status'] != 'passed':
    raise ValueError('Complete file qualification is required')
frozen = json.loads((source / 'runtime/input-receipt.json').read_text())
acceptance.frozen_runtime.verify_frozen(frozen)
destination.mkdir(parents=True)
(destination / Path(__file__).name).write_bytes(Path(__file__).read_bytes())
for key, value in main['thread_environment'].items():
    os.environ[key] = value
flags = ['-XX:NativeMemoryTracking=summary', '-XX:+UnlockDiagnosticVMOptions', '-XX:+PrintNMTStatistics']
receipt = {'schema': 'plsneuro.selected-file-native-memory.v1', 'status': 'running',
           'source_receipt_sha256': hashlib.sha256((source / 'receipt.json').read_bytes()).hexdigest(),
           'source': str(source), 'flags': flags, 'executions': [],
           'scope': 'Separate instrumented FIR resource checks, excluded from throughput results. NMT accounts for JVM-tracked memory, not all third-party allocations or process RSS. Reserved/committed are distinct from used memory. Category high-water marks are independent, not a simultaneous total.'}
def save():
    (destination / 'receipt.json').write_text(json.dumps(receipt, indent=2, allow_nan=False) + '\n')
save()
try:
    for route in ['shared', 'pooled']:
        for variant in ['selected', 'full']:
            name = f'FIR-{route}-{variant}'
            baseline = next(e['native_result'] for e in main['executions'] if e['name'] == name + '-0')
            target = destination / name
            java = [str(Path(main['java_home']) / 'bin/java'), *main['java_options'], *flags,
                    '-cp', os.pathsep.join(frozen['classpaths']['file']),
                    'scalafim.fmri.fit.SelectedFirstLevelFileBenchmark', 'run',
                    str(source / 'fixture-FIR'), 'FIR', route, variant,
                    str(main['voxels']), str(main['block_voxels']), str(target)]
            command = ['/usr/bin/time', '-l', *java]
            log = destination / (name + '.log')
            code, timeout, leftovers, seconds = acceptance.run_process(command, log, 900, cwd=root)
            text = log.read_text()
            entry = {'name': name, 'argv': command, 'exit_code': code, 'timed_out': timeout,
                     'leftovers': leftovers, 'seconds': seconds,
                     'log_sha256': hashlib.sha256(log.read_bytes()).hexdigest()}
            receipt['executions'].append(entry)
            save()
            if code != 0 or timeout or leftovers or 'Exception' in text:
                raise ValueError('Instrumented process failed: ' + name)
            native = json.loads((target / 'receipt.json').read_text())
            if native['status'] != 'passed' or native['source_sha256'] != baseline['source_sha256']:
                raise ValueError('Instrumented scientific source/result differs')
            if native['gale_qr_implementation_sha256'] != main['gale_qr_implementation_sha256']:
                raise ValueError('Instrumented process kernel differs')
            if any(a['output_sha256'] != b['output_sha256'] for a,b in zip(native['passes'],baseline['passes'],strict=True)):
                raise ValueError('Instrumented outputs differ from qualified numerical payloads')
            rss = re.findall(r'^\s*(\d+)\s+maximum resident set size\s*$', text, re.MULTILINE)
            total = re.findall(r'^Total: reserved=(\d+), committed=(\d+)\s*$', text, re.MULTILINE)
            malloc = re.findall(r'^\s+malloc: (\d+) #\d+\s*$', text, re.MULTILINE)
            categories = re.findall(r'^-\s+(.+?) \(reserved=(\d+), committed=(\d+)(?:, [^)]*)?\)\s*$', text, re.MULTILINE)
            if len(rss) != 1 or len(total) != 1 or len(malloc) != 1 or not categories:
                raise ValueError('Expected complete NMT and process RSS records')
            native_categories = {name: {'reserved_bytes_at_exit': int(reserved), 'committed_bytes_at_exit': int(committed)} for name,reserved,committed in categories}
            entry.update(native_result=native, peak_process_rss_bytes=int(rss[0]),
                         nmt_total_reserved_bytes_at_exit=int(total[0][0]), nmt_total_committed_bytes_at_exit=int(total[0][1]),
                         nmt_tracked_malloc_bytes_at_exit=int(malloc[0]), nmt_categories=native_categories,
                         nmt_nonheap_committed_bytes_at_exit=int(total[0][1])-native_categories['Java Heap']['committed_bytes_at_exit'],
                         qualified_output_hashes_match=True)
            save()
            print('PASS ' + name, flush=True)
    acceptance.frozen_runtime.verify_frozen(frozen)
    receipt['status'] = 'passed'
except Exception as error:
    receipt.update(status='failed', error=f'{type(error).__name__}: {error}')
    save()
    raise
save()
print(destination / 'receipt.json')

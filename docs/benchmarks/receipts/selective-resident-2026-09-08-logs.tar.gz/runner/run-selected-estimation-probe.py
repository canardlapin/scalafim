#!/usr/bin/env python3
"""Measure resident-data selected/full first-level routes in an owned provider candidate.

This runner records JMH timing/allocation evidence. It does not measure file IO,
source verification, durable sinks, or the complete desktop workflow.
"""
import argparse
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import platform
import re
import subprocess

ROOT = Path(__file__).resolve().parents[1]
BENCHMARK = Path('benchmarks/fit-jvm/src/main/scala/scalafim/fmri/fit/SelectedFirstLevelBenchmark.scala')


def output(*args):
    return subprocess.check_output([str(x) for x in args], text=True).strip()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--providers', type=Path, required=True)
    parser.add_argument('--destination', type=Path, required=True)
    parser.add_argument('--java-home', type=Path, required=True)
    parser.add_argument('--smoke', action='store_true', help='Fixture validation only; not performance evidence')
    parser.add_argument('--voxels', type=int)
    parser.add_argument('--block-voxels', type=int)
    args = parser.parse_args()
    providers = args.providers.resolve()
    if not (providers / '.plsneuro-provider-probe').is_file():
        raise ValueError('Use an owned prepared provider candidate')
    contract = json.loads((ROOT / 'docs/provider-contract.json').read_text())
    declared = contract['providers']['scalafim']
    checkout = providers / ('scalafim-' + declared['revision'])
    if output('git', '-C', checkout, 'rev-parse', 'HEAD') != declared['revision']:
        raise ValueError('Provider base differs from the declared revision')
    patch = (ROOT / declared['candidate_patch']['path']).read_bytes()
    if hashlib.sha256(patch).hexdigest() != declared['candidate_patch']['sha256']:
        raise ValueError('Declared provider patch digest differs')
    actual = subprocess.check_output(['git', '-C', str(checkout), 'diff', 'HEAD', '--binary'])
    if actual != patch:
        raise ValueError('Tracked candidate differs from the exact provider patch')
    untracked = output('git', '-C', checkout, 'ls-files', '--others', '--exclude-standard').splitlines()
    if set(untracked) - {str(BENCHMARK)}:
        raise ValueError('Candidate has undeclared sources other than the qualification benchmark')
    source = checkout / BENCHMARK
    source_bytes = source.read_bytes()
    # An untracked benchmark is an explicitly captured qualification source,
    # separate from the exact production provider patch above.
    destination = args.destination.resolve()
    if destination.exists():
        raise ValueError('Use a new evidence directory; previous runs are immutable')
    voxels = args.voxels if args.voxels is not None else (64 if args.smoke else 8192)
    block = args.block_voxels if args.block_voxels is not None else (32 if args.smoke else 512)
    if voxels <= 0 or block <= 0:
        raise ValueError('Voxel and block counts must be positive')
    destination.mkdir(parents=True)
    (destination / '.plsneuro-selected-estimation-probe').write_text('plsneuro.selected-estimation-probe.v1\n')
    (destination / 'SelectedFirstLevelBenchmark.scala').write_bytes(source_bytes)
    results_file = destination / 'jmh.json'
    pattern = '.*SelectedFirstLevelBenchmark.selectedPreparation' if args.smoke else '.*SelectedFirstLevelBenchmark.*'
    command = (f'{{{checkout.as_uri()}/}}fitBenchJVM/Jmh/run {pattern} '
               f'-p voxels={voxels} -p blockVoxels={block} -t 1 -prof gc '
               f'-jvmArgsAppend "-Xmx4g -XX:ActiveProcessorCount=1" '
               + ('-wi 0 -i 1 -r 100ms -f 1 ' if args.smoke else '-wi 3 -w 1s -i 5 -r 1s -f 2 ')
               + f'-rf json -rff "{results_file}"')
    cpu = output('sysctl', '-n', 'machdep.cpu.brand_string') if platform.system() == 'Darwin' else platform.processor()
    receipt = {
        'schema': 'plsneuro.selected-estimation-resident.v1', 'status': 'running',
        'qualification': 'fixture-smoke-only' if args.smoke else 'resident-dataset-jmh',
        'scope': 'Preparation and resident bounded dataset execution; excludes verification, filesystem reads, decompression and durable output.',
        'provider_revision': declared['revision'], 'provider_patch_sha256': hashlib.sha256(patch).hexdigest(),
        'benchmark_sha256': hashlib.sha256(source_bytes).hexdigest(),
        'benchmark_is_additional_qualification_source': str(BENCHMARK) in untracked,
        'platform': platform.platform(), 'cpu': cpu, 'java_home': str(args.java_home.resolve()),
        'command': command, 'voxels': voxels, 'block_voxels': block,
    }
    receipt_file = destination / 'receipt.json'
    receipt_file.write_text(json.dumps(receipt, indent=2) + '\n')
    spec = importlib.util.spec_from_file_location('acceptance_process', ROOT / 'tools/run-acceptance.py')
    helper = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(helper)
    os.environ['JAVA_HOME'] = str(args.java_home.resolve())
    os.environ['VECLIB_MAXIMUM_THREADS'] = '1'
    log = destination / 'execution.log'
    code, timed_out, leftovers, elapsed = helper.run_process(
        ['sbt', '-Dsbt.supershell=false', '-Dsbt.color=false', command], log, 3600, cwd=providers / 'consumer')
    text = log.read_text()
    results = json.loads(results_file.read_text()) if results_file.exists() else []
    errors = []
    expected = 6 if args.smoke else 18
    if code != 0 or timed_out or leftovers:
        errors.append('Owned process did not complete cleanly')
    if len(results) != expected:
        errors.append(f'Expected {expected} complete JMH cases, found {len(results)}')
    if any(not math.isfinite(row['primaryMetric']['score']) for row in results):
        errors.append('JMH returned a non-finite primary score')
    equivalence = re.findall(r'SELECTED_EQUIVALENCE ([^\r\n]+)', text)
    expected_checks = expected * (1 if args.smoke else 2)
    if len(equivalence) != expected_checks:
        errors.append(f'Expected {expected_checks} full/selected equivalence checks, found {len(equivalence)}')
    if '[error]' in text or '<failure>' in text or 'Exception' in text:
        errors.append('Benchmark log contains a failure')
    receipt.update(status='failed' if errors else 'passed', exit_code=code, timed_out=timed_out,
                   leftover_processes=leftovers, seconds=elapsed, errors=errors,
                   equivalence_checks=equivalence, results=results,
                   log_sha256=hashlib.sha256(log.read_bytes()).hexdigest())
    receipt_file.write_text(json.dumps(receipt, indent=2, allow_nan=False) + '\n')
    if errors:
        raise RuntimeError('; '.join(errors))
    print(receipt_file)


if __name__ == '__main__':
    main()

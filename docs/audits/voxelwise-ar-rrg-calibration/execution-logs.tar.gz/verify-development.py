from pathlib import Path
import json,gzip,collections,statistics,hashlib
base=Path('/private/tmp/scalafim-rrg-calibration');audit=base/'work/docs/audits'
new=[json.loads(x) for x in (base/'development.jsonl').read_text().splitlines()]
old=[json.loads(x) for x in gzip.decompress((audit/'voxelwise-ar-rrg-coverage.jsonl.gz').read_bytes()).splitlines()]
known=[json.loads(x) for x in gzip.decompress((audit/'voxelwise-ar-rrg-known-whitening.jsonl.gz').read_bytes()).splitlines()]
references={('oracle_refit_rank1',r['dataset']):r for r in old if r['scenario']=='baseline' and r['mode']=='FrozenWhitening' and r['budget']=='main'}
references.update({('oracle_known_rank1' if r['scenario']=='baseline_known_rank1' else 'oracle_known_full',r['dataset']):r for r in known})
errors=collections.defaultdict(list)
for r in new:
 ref=references.get((r['arm'],r['dataset']))
 if ref and r['status']=='ok' and ref['status']=='ok':
  errors[r['arm']].append(max(abs(a-b) for a,b in zip(r['estimate'],ref['estimate'])))
assert all(len(v)==400 and max(v)<1e-12 for v in errors.values()),{k:(len(v),max(v)) for k,v in errors.items()}
assert len(errors)==3
summary=json.loads((base/'development-summary.json').read_text()); independent=[]
for group in summary['groups']:
 rows=[r for r in new if r['arm']==group['arm'] and r['status']=='ok']
 for j,m in enumerate(group['metrics']):
  k=sum(r['lower'][j]<=r['truth'][j]<=r['upper'][j] for r in rows)
  errors_j=[r['estimate'][j]-r['truth'][j] for r in rows]
  empirical=statistics.variance([r['estimate'][j] for r in rows]); boot=statistics.mean([r['variance'][j] for r in rows])
  assert abs(m['coverage']-k/len(rows))<1e-15
  assert abs(m['variance_ratio']-boot/empirical)<1e-12
  independent.append({'arm':group['arm'],'coordinate':m['estimand'],'covered':k,'successful_attempts':len(rows),'coverage':k/len(rows),'variance_ratio':boot/empirical,'bias':statistics.mean(errors_j)})
result={'archived_point_parity':{k:{'datasets':len(v),'max_absolute_difference':max(v)} for k,v in errors.items()},'independent_metrics':independent,'development_sha256':hashlib.sha256((base/'development.jsonl').read_bytes()).hexdigest()}
(base/'development-independent.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result['archived_point_parity']))

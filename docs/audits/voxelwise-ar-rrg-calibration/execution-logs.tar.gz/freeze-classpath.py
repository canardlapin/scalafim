from pathlib import Path
import hashlib,json,zipfile,shutil,datetime
base=Path('/private/tmp/scalafim-rrg-calibration')
lines=(base/'harness-tests-05.log').read_text().splitlines()
lines=[s for s in lines if s.startswith('/') and 'scala3-library' in s and ':' in s]
assert len(lines)==1, len(lines)
out=base/'frozen-classpath'; out.mkdir()
entries=[]
for i, name in enumerate(lines[0].split(':')):
 p=Path(name)
 if p.is_dir():
  dst=out/f'{i:03d}-classes.jar'
  before={str(f.relative_to(p)):hashlib.sha256(f.read_bytes()).hexdigest() for f in sorted(p.rglob('*')) if f.is_file()}
  with zipfile.ZipFile(dst,'w',zipfile.ZIP_DEFLATED) as z:
   for n,h in before.items():
    body=(p/n).read_bytes(); assert hashlib.sha256(body).hexdigest()==h, 'capture race'
    info=zipfile.ZipInfo(n, date_time=(2026,9,30,0,0,0)); info.compress_type=zipfile.ZIP_DEFLATED; z.writestr(info,body)
  after={str(f.relative_to(p)):hashlib.sha256(f.read_bytes()).hexdigest() for f in sorted(p.rglob('*')) if f.is_file()}
  assert before==after, 'capture race'
 else:
  dst=out/f'{i:03d}-{p.name}'; shutil.copy2(p,dst)
  assert hashlib.sha256(p.read_bytes()).digest()==hashlib.sha256(dst.read_bytes()).digest()
 entries.append({'source':str(p),'snapshot':str(dst),'sha256':hashlib.sha256(dst.read_bytes()).hexdigest(),'bytes':dst.stat().st_size})
(base/'frozen-classpath.txt').write_text(':'.join(e['snapshot'] for e in entries)+'\n')
(base/'frozen-classpath.json').write_text(json.dumps({'frozen_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'entries':entries},indent=2)+'\n')
print('Frozen',len(entries),'classpath entries;',sum(e['bytes'] for e in entries),'bytes')

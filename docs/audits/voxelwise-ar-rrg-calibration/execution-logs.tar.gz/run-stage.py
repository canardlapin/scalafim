from pathlib import Path
import subprocess,sys,time,json,datetime,hashlib
base=Path('/private/tmp/scalafim-rrg-calibration')
mode=sys.argv[1]
cp=(base/'frozen-classpath.txt').read_text().strip()
java=['java','-Xmx3g','-XX:ActiveProcessorCount=4','-cp',cp,'scalafim.fmri.fit.VoxelwiseReducedRankCalibration']
summarizer=base/'work/tools/qualification/summarize_voxelwise_rrg_calibration.py'

def execute(name,args,timeout):
 log=base/(name+'.log'); started=time.monotonic(); utc=datetime.datetime.now(datetime.timezone.utc).isoformat()
 with log.open('x') as f:
  try:
   result=subprocess.run(java+args,stdout=f,stderr=subprocess.STDOUT,timeout=timeout); code=result.returncode; reason='exited'
  except subprocess.TimeoutExpired:
   code=124; reason='timeout'
 meta={'name':name,'started_utc':utc,'seconds':time.monotonic()-started,'exit_code':code,'reason':reason,'command':java[:3]+['-cp','<frozen-classpath.txt>']+java[5:]+args,'classpath_manifest_sha256':hashlib.sha256((base/'frozen-classpath.json').read_bytes()).hexdigest()}
 (base/(name+'.meta.json')).write_text(json.dumps(meta,indent=2)+'\n')
 print(json.dumps(meta),flush=True)
 return code

def summarize(name,paths,phase,count,incomplete=False):
 command=[sys.executable,str(summarizer),*map(str,paths),'--output',str(base/(name+'-summary.json')),'--phase',phase,'--count',str(count)]
 if incomplete: command.append('--allow-incomplete')
 subprocess.run(command,check=True)
 return json.loads((base/(name+'-summary.json')).read_text())

if mode in ('smoke','pilot','development','stress'):
 count={'smoke':2,'pilot':20,'development':400,'stress':200}[mode]
 phase='stress' if mode=='stress' else 'development'
 path=base/(mode+'.jsonl')
 code=execute(mode,[phase,str(path),str(count)],1800 if phase=='stress' else 3600)
 summarize(mode,[path],phase,count,code!=0)
 sys.exit(code)
elif mode=='fresh':
 started=time.monotonic(); paths=[]; start=0
 for checkpoint in (500,1000,2000):
  name=f'fresh-{checkpoint}'; path=base/(name+'.jsonl'); paths.append(path)
  remaining=7200-(time.monotonic()-started)
  if remaining<=0: raise RuntimeError('fresh budget exhausted before next checkpoint')
  code=execute(name,['fresh',str(start),str(checkpoint-start),str(path)],remaining)
  result=summarize(name,paths,'fresh',checkpoint,code!=0)
  verdict=result['qualification']['verdict']
  print('CHECKPOINT',checkpoint,verdict,flush=True)
  if code or verdict!='continue_to_next_checkpoint':
   (base/'fresh-decision.json').write_text(json.dumps({'checkpoint':checkpoint,'verdict':verdict,'wall_seconds':time.monotonic()-started,'inputs':[str(p) for p in paths]},indent=2)+'\n')
   sys.exit(code)
  start=checkpoint
else: raise ValueError(mode)

from pathlib import Path
import json,hashlib,tarfile,io,gzip,subprocess,datetime
base=Path('/private/tmp/scalafim-rrg-calibration'); snapshot=json.loads((base/'integration-snapshot.json').read_text())
paths=set().union(*(snapshot[k].keys() for k in ('root_dirty_source_sha256','rrg_integrated_sha256','calibration_overlay_sha256')))
manifest={}; payload=io.BytesIO()
with tarfile.open(fileobj=payload,mode='w') as t:
 for name in sorted(paths):
  p=base/'integration'/name
  if not p.exists(): manifest[name]=None;continue
  body=p.read_bytes();manifest[name]=hashlib.sha256(body).hexdigest()
  info=tarfile.TarInfo(name); info.size=len(body); info.mode=0o644; t.addfile(info,io.BytesIO(body))
archive=gzip.compress(payload.getvalue(),mtime=0)
(base/'integration-source-overlay.tar.gz').write_bytes(archive)
source={'frozen_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'base_commit':snapshot['root_head'],'overlay_sha256':hashlib.sha256(archive).hexdigest(),'final_source_hashes':manifest,'replay':'Checkout base_commit; extract overlay archive; remove files whose hash is null. The integration snapshot records prior inputs and conflict resolution.'}
source['analysis_sha256']={str(p.relative_to(base/'work')):hashlib.sha256(p.read_bytes()).hexdigest() for p in [base/'work/tools/qualification/summarize_voxelwise_rrg_calibration.py',base/'work/docs/audits/voxelwise-ar-rrg-calibration/design.json']}
(base/'source-freeze.json').write_text(json.dumps(source,indent=2)+'\n')
print('Source frozen:',len(manifest),'paths;',len(archive),'archive bytes')

# scalafim

This repository consolidates the Scala fMRI and neuroimaging libraries into one
cross-compiled sbt build.

> **Maturity:** `0.1-development` / pre-release research software. Module
> ownership and workflow boundaries are still being consolidated; APIs may
> change and no stable production-support promise is implied.

## Modules

- `locus-data`: ScalaFIM domain adapters, supported parcellations, and searchlights over standalone locus4s spaces and data; aggregation over parcellations uses `locus4s.data.Aggregation`.
- `pipeline`: generic typed pipeline graphs, artifact references, deterministic staging, local execution, and receipts.
- `response`: dependency-light response identity, axis-safe selections, owned time-by-sample `Double` blocks, source planning, provenance, and physical-read receipts.
- `response-laws`: reusable JVM/Scala.js law checks for response ordering, shape, decode consistency, partitions, raw-bit persistence, receipts, and provenance.
- `latent`: archive-independent fMRI response mathematics, inspectable applicative decode plans, explicit basis/loadings responses, coefficient projection, and locus-backed active/full-grid selections.
- `ar`: checked run/censor-aware AR estimation, AR/ARMA whitening plans, diagnostics, and pure design/data prewhitening.
- `hrf`: causal hemodynamic kernels with enforced causality and declared support, pulse-shaped neural drive (impulse, unit-height and unit-mass boxes), convergent box quadrature, response bases with typed dual coefficients and reported basis transforms, sampling, convolution, and regressors.
- `hrf-laws`: reusable JVM/Scala.js law checks for kernel causality and support, event additivity, homogeneity, permutation invariance, translation equivariance, pulse and quadrature convergence, basis reconstruction and gauge invariance, and evaluation-plan equivalence.
- `first-level-laws`: non-published generated JVM/Scala.js laws for constrained HRF, design, and fit workflows, with reproducible counterexample shrinking and separate PR/calibration budgets.
- `scenario-testkit`: non-published cross-built scenario verdicts, caveat policies, tolerances, and matrix/vector comparison views shared by design and fit tests.
- `design`: fMRI event models, formulas, baselines, contrasts, and design matrices.
- `image`: neuroimaging volumes, locus-backed masks/selections and volume domains, metric searchlight construction, affine/dense-field spatial morphisms, statistics, clustering, and image IO.
- `provider-spike`: unpublished JVM/Scala.js compile contract proving direct composition of image4s, image4s-locus, locus4s, Gale, Ravel, and reframe4s without a ScalaFIM wrapper algebra.
- `image-view`: renderer-neutral world-space slice viewing, typed colorizers and layers, orthogonal scene compilation, and interaction receipts.
- `image-view-canvas`: thin Scala.js Canvas host for image-view scenes and device-event translation.
- `image-view-java2d`: thin JVM Java2D host with direct `Graphics2D` and `BufferedImage` rendering.
- `image-view-javafx`: thin JVM JavaFX Canvas host behind the existing toolkit-free drawing contract.
- `threshold`: spatial inference over statistic maps — locus-backed active support, LR-MFT set scoring, maxT/stepdown correction, octree candidates, and thresholding primitives.
- `motion`: fMRI rigid-motion traces, baseline rigid estimation, motion QC metrics, and one-pass motion application over 4D runs.
- `surface`: surface-mesh data structures, frame-typed surfaces, cortical-ribbon fill and masks, exact locus domains, topology, vertex fields, region-backed ROIs, quotient-backed labels, geodesic searchlights, parcel operations, and JVM surface IO.
- `surface-view`: renderer-neutral surface layers, thresholds, layouts, cameras, interaction, projection/network primitives, scene documents, and versioned render plans.
- `surface-view-raster`: deterministic JVM/Scala.js CPU raster, depth, clipping, compositing, and picking oracle.
- `surface-view-javafx`: retained JVM JavaFX Scene3D backend, controller, picking, snapshots, and resource/timing receipts.
- `surface-view-three`: retained Scala.js Three.js/WebGL backend, browser picking/snapshots, and optional GPU volume projection.
- `surface-view-connectivity`: cross-platform adapter from typed connectivity edge spaces into surface network render resources.
- `transform`: reads ITK/ANTs, FSL (FLIRT, FNIRT fields and cubic/quadratic spline coefficients), AFNI and FreeSurfer (LTA, xfm, register.dat) registration files and X5, interprets them as typed world-space transforms, converts between toolkits, and writes all but ITK `.h5`, X5 and FNIRT coefficients (read-only). Generic transform algebra stays in reframe4s. Guide: `docs/spatial-transforms.md`; design: `docs/plans/spatial-transform-parity.md`.
- `spatial`: spatial-functor infrastructure — typed domains with locus packages, sampled geometries, exact/crisp/sampled transport, selections, lazy fields, and graph/operator compilation.
- `atlas`: typed standard-atlas metadata plus locus parcellations, registry, transform plans, parcel/network lookup, one-pass reduction, explicit-alignment overlap, and quotient adjacency.
- `archive`: format-neutral revisions and publication state, separately versioned normalized manifests, exact canonical encoding, transactional write orchestration, and typed resource-backed payload execution and receipts.
- `estimates`: fit-independent estimate catalogs, scientific identities, product/validity/uncertainty metadata and bounded read/write contracts.
- `estimates-io`: shared development-schema JSON codecs and a JVM local NIfTI sink, verified reader and immutable collection publication. See [implementation scope](docs/estimate-sets.md).
- `fit-estimates`: physical-IO-independent shared-OLS effects and joint-uncertainty producer, plus the eager direct-fit group adapter.
- `archive-lna`: typed LNA 2 schema, pure manifest normalization, validation, shared-basis artifacts, payload codecs, JVM HDF5 stores, and the eager physical driver; no scientific reconstruction.
- `interop-archived-response`: typed representation-to-archive lowering for LNA and Zarr, LNA pipeline reconstruction, archive-aware dataset adapters, first-class narrow representation envelopes, canonical dense-BOLD response binding, explicit registries, and resource-safe runtime assembly.
- `dataset`: pure fMRI descriptions and queries, explicit synchronous readers, checked effectful response attachment, acquisition locus domains, typed study/run indexing, segmented reads, evidence propagation, and series adapters.
- `model`: fMRI model composition and typed fitting plans/configuration.
- `fit`: portable fit kernels plus explicit synchronous-reader and effectful opened-dataset execution boundaries.
- `phrf-comparison`: unpublished comparative-evaluation preparation and scoring on JVM/Scala.js, with JVM runners and custody tooling. [Pilot integration scope](modules/phrf-comparison/README.md) excludes the pending S10 launch and rehearsal.
- `mvpa`: portable MVPA engine primitives, fold plans, ROI feature sets, and RDM/crossnobis kernels.
- `mvpa-fit`: shared composition of fit-owned trial readouts with MVPA pattern operators, run metadata, and leave-one-run-out execution.
- Multivariate perturbation inference now lives in standalone [`multivar-inference`](https://github.com/canardlapin/multivar/tree/main/modules/inference); ScalaFIM keeps only downstream domain adapters.
- `connectivity`: shared typed connectivity algebra, locus-backed node/edge domains and masks, explicit vectorization orders, static/dynamic containers, and inspectable estimator plans.
- `mvpa-dataset`: typed synchronous-reader and effectful opened-dataset adapters into MVPA pattern sources.
- `mvpa-artifacts`: bounded, fitter-independent pattern profiles with verified external Float64 payloads over existing archive IO; durable fitter checkpoints are unsupported.
- `mvpa-spatial`: adapters from locus regions, selections, parcellations, and searchlights plus image/surface/atlas objects into MVPA feature-set plans.
- `group`: second-level (group) analysis — group GLM, fixed/random-effects meta-analysis, group contrasts, and FDR over subjects-by-samples effect maps.
- `fmri-workflow`: typed, payload-free study plans and catalogs that compose BIDS ingest, first-level fitting, durable results, group analysis, and scheduler-neutral orchestration.
- Generic Zarr mechanics and the optional Blosc/Zstandard provider now live in the standalone `zarr4s` repository. ScalaFIM consumes its core through a pinned source build and retains only neuroimaging-specific adapters.
- `archive-zarr`: NeuroArchive Zarr 0.1 refinement with canonical BOLD archive metadata, immutable publication, measured sharded layout policy, and resource-safe typed async payload execution with exact object/range evidence.
- `dataset-zarr`: JVM NeuroArchive-to-`FmriDataset` composition, bounded reads, regular-timing refinement, streaming NIfTI import, and BIDS/NIfTI export over NeuroArchive Zarr revisions.

Each module is built for both the JVM and Scala.js with `sbt-crossproject`.

The unified MVPA replacement has an unpublished
[foundation admission court](modules/mvpa-foundation-spike/README.md) in the
root build. It pins and exercises the accepted external provider graph and
typed-axis laws while M1 migrates those laws into production APIs; it is not a
shipping module or an alternate MVPA engine. See the
[implementation epic](docs/plans/unified-mvpa-epic.md).

The immutable typed dataframe work formerly incubated here now lives in the
standalone [`frame4s`](https://github.com/canardlapin/frame4s) repository.

Reusable BIDS names, manifests, queries, metadata tables, confound selection,
and resource-safe loaders formerly incubated here now live in the standalone
[`bids4s`](https://github.com/canardlapin/bids4s) repository. ScalaFIM pins an
immutable source revision and consumes it only at BIDS-facing integration
boundaries.

General multivariate analysis and its language-neutral IR now live in the
standalone [`multivar`](https://github.com/canardlapin/multivar) repository.
ScalaFIM pins an immutable source revision and owns only downstream
neuroimaging integrations.

Nonlinear registration and the experimental HalfFlow engine now live in
standalone [`reframe4s`](https://github.com/canardlapin/reframe4s). ScalaFIM
does not retain a registration module or depend on reframe4s.

Renderer-neutral graphics, plotting, and the SVG/Canvas/Java2D/JavaFX backends
live in standalone [`Intaglio`](https://github.com/canardlapin/intaglio).
ScalaFIM pins an immutable source revision; design and viewer modules consume
only the smallest required Intaglio core or backend project.

Generic graph topology and algorithms formerly incubated here now live in
standalone [`graph4s`](https://github.com/canardlapin/graph4s). ScalaFIM pins an
immutable source revision. The optional `graph4s-gale` module now owns indexed
numerical graph operators, spectra, embeddings, and similarities. Pipeline,
surface, atlas, and connectivity retain only ScalaFIM domain metadata and
adapters.

Generic finite domains, points, regions, selections, maps, relations, indexed
fields, and their laws formerly incubated here now live in standalone
[`locus4s`](https://github.com/canardlapin/locus4s). ScalaFIM pins an immutable
source revision; `locus-data` retains only ScalaFIM-specific adapters and
higher-level parcellation and searchlight policy. Aggregation over
parcellations is owned by `locus4s.data.Aggregation`.

Generic dense and sparse matrices, linear operators, factorizations, and
spectral algorithms now live in standalone
[`Gale`](https://github.com/canardlapin/gale). ScalaFIM pins an immutable source
revision and keeps only neuroimaging-specific numerical policy and adapters; it
does not retain local `linalg` or Breeze-adapter modules.

An ordinary build loads both libraries from their pinned GitHub revisions. To
test coordinated changes in sibling checkouts, select those checkouts
explicitly:

```sh
sbt \
  -Dscalafim.alder.build=../alder \
  -Dscalafim.gale.build=../gale \
  -Dscalafim.graph4s.build=../graph4s \
  -Dscalafim.linop4s.build=../linop4s \
  -Dscalafim.locus4s.build=../locus4s \
  -Dscalafim.resample4s.build=../resample4s \
  scalafimCompileAll
```

The override applies only to that sbt process. Removing the properties restores
the immutable GitHub source dependencies.

Numerical capability that ScalaFIM lacks (for example banded factorizations)
is written upstream in Gale, not as a private helper here. The workflow is:
develop in a sibling Gale checkout, run the affected ScalaFIM suites with
`-Dscalafim.gale.build`, open the Gale pull request, then bump `galeRevision`
in `build.sbt` after merge and rerun `sbt scalafimCompileAll` plus the affected
suites against the pinned revision.

See [docs/release-assurance.md](docs/release-assurance.md) for the enforced
first-level compiler, formatting, coverage, parity, and CI courts, including
the gates intentionally deferred during `0.1-development`.

See [docs/first-level-analysis.md](docs/first-level-analysis.md) for the staged,
executable first-level workflow: compile and inspect a model plan, fit it, then
compile basis-aware semantic hypotheses without column-number bookkeeping.

See [docs/image-viewer.md](docs/image-viewer.md) for the world-coordinate
contract, slice and layer APIs, interaction reducer, caching receipts, and
platform-host boundaries.

See [docs/surface-viewer.md](docs/surface-viewer.md) for surface layers,
orientation and coordinate contracts, JavaFX/Three.js backends, lifecycle,
serialization, performance gates, and the cross-platform example.

## Common Commands

Use a JDK 21 installation for local development and an sbt launcher;
`project/build.properties` selects sbt 1.11.7 for this build. CI checks the
JDK 17 API baseline, and Scala.js tests require Node.js (CI uses Node 24).
For repeated local gates, use `python3 tools/build/sbt-warm hrfJVM/test hrfJS/test`
to reuse a worktree-specific server. Run large test campaigns in bounded
batches, as described in `AGENTS.md`. The
[local sbt/Mill comparison](docs/benchmarks/build-tools-20261005.md) records
the rationale for retaining the current build.

The warm server uses a 3 GB heap by default. For `reload` followed by `set`
or repeated settings changes, use the explicitly qualified 4 GB profile:

```sh
python3 tools/build/sbt-warm --shutdown
SBT_WARM_HEAP=4g python3 tools/build/sbt-warm reload 'set atlasJVM / Test / envVars += ("MY_TEST_OPTION" -> "value")'
SBT_WARM_HEAP=4g python3 tools/build/sbt-warm hrfJVM/test hrfJS/test
python3 tools/build/sbt-warm --shutdown
```

Keep the same profile for commands while that server runs. The wrapper refuses
an unknown or differing recorded startup profile; restart after changing heap,
processor count or idle timeout. `--status` reports requested and recorded
startup values. An existing server from an older wrapper needs one shutdown
before reuse. See the [reconfiguration evidence](docs/verification/sbt-reconfiguration-20261006/README.md)
for measured limits; source pins and the ordinary 3 GB default are preserved.

On a fresh machine, first run `./tools/prepare-pinned-dependencies.sh`.
Multivar consumes Gale and Resample4s through revision-tagged artifacts that
are not yet on Maven Central. This helper checks out the exact pinned Multivar
revision and runs both provider bootstraps into the local artifact cache.
Repeat after changing the Gale, Resample4s, or Multivar pins. Ordinary builds
then use the committed source pins; no sibling checkout or provider override
is needed.

```sh
sbt scalafimCompileAll
sbt scalafimTestAll
sbt mvpaFoundationAdmissionJVM/test
sbt mvpaFoundationAdmissionJS/test
sbt locusDataJVM/test
sbt locusDataJS/test
sbt pipelineJVM/test
sbt pipelineJS/test
sbt responseJVM/test
sbt responseJS/test
sbt responseLawsJVM/test
sbt responseLawsJS/test
sbt latentJVM/test
sbt latentJS/test
sbt arJVM/test
sbt arJS/test
sbt hrfJVM/test
sbt hrfJS/test
sbt scenarioTestkitJVM/test
sbt scenarioTestkitJS/test
sbt designJVM/test
sbt designJS/test
sbt imageJVM/test
sbt imageJS/test
sbt imageViewJVM/test
sbt imageViewJS/test
sbt imageViewCanvasJS/test
sbt imageViewJava2dJVM/test
sbt imageViewJavafxJVM/test
sbt thresholdJVM/test
sbt thresholdJS/test
sbt motionJVM/test
sbt motionJS/test
sbt surfaceJVM/test
sbt surfaceJS/test
sbt surfaceViewJVM/test
sbt surfaceViewJS/test
sbt surfaceViewRasterJVM/test
sbt surfaceViewRasterJS/test
sbt surfaceViewJavafxJVM/test
sbt surfaceViewThreeJS/test
sbt surfaceViewConnectivityJVM/test
sbt surfaceViewConnectivityJS/test
sbt spatialJVM/test
sbt spatialJS/test
sbt atlasJVM/test
sbt atlasJS/test
sbt archiveJVM/test
sbt archiveJS/test
sbt archiveLnaJVM/test
sbt archiveLnaJS/test
sbt archivedResponseInteropJVM/test
sbt archivedResponseInteropJS/test
sbt datasetJVM/test
sbt datasetJS/test
sbt modelJVM/test
sbt modelJS/test
sbt fitJVM/test
sbt fitJS/test
sbt archiveZarrJVM/test
sbt archiveZarrJS/test
sbt datasetZarrJVM/test
sbt datasetZarrJS/test
sbt mvpaJVM/test
sbt mvpaJS/test
sbt mvpaFitJVM/test
sbt mvpaFitJS/test
sbt connectivityJVM/test
sbt connectivityJS/test
sbt mvpaDatasetJVM/test
sbt mvpaDatasetJS/test
sbt workflowExamplesJVM/test
sbt workflowExamplesJS/test
sbt mvpaSpatialJVM/test
sbt mvpaSpatialJS/test
sbt groupJVM/test
sbt groupJS/test
sbt fmriWorkflowJVM/test
sbt fmriWorkflowJS/test
```

Runnable examples live under `examples/`. They are non-published sbt projects
with smoke tests:

```sh
sbt examplesTest
sbt surfaceViewExamplesJVM/test surfaceViewExamplesJS/test
sbt "atlasExamplesJVM/runMain scalafim.examples.atlas.describeStandardAtlases"
```

See [docs/ecosystem-port.md](docs/ecosystem-port.md) for the rewrite plan for
`fmridataset`, `fmrireg`, and later ecosystem modules.
See [docs/module-relations.md](docs/module-relations.md) for a concise map of
how the modules relate and where new code should live.
See [docs/plans/scenario-parity-harness.md](docs/plans/scenario-parity-harness.md)
for the Scala-native plan to add realistic workflow scenarios, parity fixtures,
and regenerable receipts without making Python/R part of the sbt test runtime.

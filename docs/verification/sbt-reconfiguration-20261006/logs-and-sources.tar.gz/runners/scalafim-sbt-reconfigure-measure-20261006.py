from pathlib import Path
import subprocess, os, json, time, re, hashlib, signal

root = Path('/private/tmp/scalafim-sbt-reconfigure-20261006')
logs = Path('/private/tmp/scalafim-sbt-reconfiguration-20261006')
logs.mkdir(exist_ok=True)
java_home = subprocess.check_output(['/usr/libexec/java_home','-v','21'],text=True).strip()
base = str(Path.home()/'.cache/scalafim-sbt/bases'/hashlib.sha256(str(root).encode()).hexdigest()[:16])
rows = []
processes = {}
for heap in ['3g','4g','6g']:
    env = dict(os.environ, SBT_WARM_HEAP=heap, COURSIER_REPOSITORIES='https://repo.maven.apache.org/maven2',
               JDK_JAVA_OPTIONS='-Xlog:gc:file='+str(logs)+'/gc-%p.log:time,uptime')
    tasks = [
        ('load','show scalaVersion'),
        ('reload','reload'),
        ('set-one','set atlasJVM / Test / envVars += ("SCALAFIM_SETTINGS_PROBE" -> "one")'),
        ('set-two','set atlasJVM / Test / envVars += ("SCALAFIM_SETTINGS_PROBE" -> "two")'),
        ('read-setting','show atlasJVM / Test / envVars')]
    failed = False
    for label, task in tasks:
        name = heap+'-'+label
        command = ['python3','tools/build/sbt-warm',task]
        started = time.monotonic()
        observed = set()
        timeout = False
        with (logs/(name+'.log')).open('w') as out:
            client = subprocess.Popen(command,cwd=root,env=env,stdout=out,stderr=subprocess.STDOUT)
            while client.poll() is None:
                for line in subprocess.check_output(['ps','-axo','pid=,rss=,args='],text=True).splitlines():
                    parts = line.strip().split(None,2)
                    if len(parts)!=3:
                        continue
                    pid,rss = map(int,parts[:2])
                    args = parts[2]
                    if '--detach-stdio' not in args or '-Dsbt.global.base='+base not in args:
                        continue
                    observed.add(pid)
                    record = processes.setdefault(pid,dict(pid=pid,heap_profile=heap,peak_sampled_rss_kib=0,flags_exit_code=1,gates=[]))
                    record['peak_sampled_rss_kib'] = max(record['peak_sampled_rss_kib'],rss)
                    if name not in record['gates']:
                        record['gates'].append(name)
                    if record['flags_exit_code']!=0:
                        flags = subprocess.run([java_home+'/bin/jcmd',str(pid),'VM.flags'],capture_output=True,text=True,timeout=15)
                        record.update(flags_exit_code=flags.returncode,flags=flags.stdout)
                if time.monotonic()-started>180:
                    timeout = True
                    for pid in observed:
                        try:os.kill(pid,signal.SIGTERM)
                        except ProcessLookupError:pass
                    try:client.wait(timeout=10)
                    except subprocess.TimeoutExpired:client.terminate()
                    break
                time.sleep(0.25)
        client.wait(timeout=15)
        content = (logs/(name+'.log')).read_text()
        row = dict(profile=heap,label=label,command=command,exit_code=client.returncode,timed_out=timeout,
                   seconds=round(time.monotonic()-started,3),observed_pids=sorted(observed),
                   gc_warnings=[line for line in content.splitlines() if 'spent in GC' in line],
                   settings_counts=[int(n) for n in re.findall(r'\((\d+) settings\)',content)])
        rows.append(row)
        (logs/'runs.json').write_text(json.dumps(rows,indent=2)+'\n')
        (logs/'processes.json').write_text(json.dumps(list(processes.values()),indent=2)+'\n')
        print(json.dumps(row),flush=True)
        if client.returncode or timeout:
            failed = True
            break
    with (logs/(heap+'-shutdown.log')).open('w') as out:
        subprocess.run(['python3','tools/build/sbt-warm','--shutdown'],cwd=root,env=env,stdout=out,stderr=subprocess.STDOUT,timeout=90)
    if heap!='3g' and not failed:
        (logs/'supported-profile.txt').write_text(heap+'\n')
        print('Supported measured reconfiguration profile: '+heap,flush=True)
        break

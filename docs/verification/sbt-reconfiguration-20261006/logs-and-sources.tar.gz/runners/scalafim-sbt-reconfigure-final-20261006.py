from pathlib import Path
import subprocess, os, json, time, re, hashlib

root = Path('/private/tmp/scalafim-sbt-reconfigure-20261006')
logs = Path('/private/tmp/scalafim-sbt-reconfiguration-20261006/final')
logs.mkdir(exist_ok=True)
java_home = subprocess.check_output(['/usr/libexec/java_home','-v','21'],text=True).strip()
base = Path.home()/'.cache/scalafim-sbt/bases'/hashlib.sha256(str(root).encode()).hexdigest()[:16]
rows = []
env = dict(os.environ,COURSIER_REPOSITORIES='https://repo.maven.apache.org/maven2')
env.pop('SBT_WARM_HEAP',None)
env['JDK_JAVA_OPTIONS']='-Xlog:gc:file='+str(logs)+'/gc-%p.log:time,uptime'

def run(label,tasks,expected=0,heap=None):
    requested = dict(env)
    if heap is not None:requested['SBT_WARM_HEAP']=heap
    source_hash = hashlib.sha256((root/'tools/build/sbt-warm').read_bytes()).hexdigest()
    start = time.monotonic()
    command = ['python3','tools/build/sbt-warm',*tasks]
    with (logs/(label+'.log')).open('w') as out:
        result = subprocess.run(command,cwd=root,env=requested,stdout=out,stderr=subprocess.STDOUT,timeout=180)
    content = (logs/(label+'.log')).read_text()
    counts = [dict(total=int(m[0]),failed=int(m[1]),errors=int(m[2]),passed=int(m[3]))
              for m in re.findall(r'(?:Passed|Failed): Total (\d+), Failed (\d+), Errors (\d+), Passed (\d+)',content)]
    row = dict(label=label,command=command,heap_override=heap,source_sha256=source_hash,exit_code=result.returncode,
               expected_exit_code=expected,seconds=round(time.monotonic()-start,3),counts=counts,
               warnings=[line for line in content.splitlines() if line.startswith('[warn]')])
    rows.append(row)
    (logs/'runs.json').write_text(json.dumps(rows,indent=2)+'\n')
    print(json.dumps(row),flush=True)
    assert result.returncode==expected and not row['warnings'],label
    return content

run('hrf-jvm-final',['hrfJVM/test'])
pid = None
for line in subprocess.check_output(['ps','-axo','pid=,args='],text=True).splitlines():
    parts = line.strip().split(None,1)
    if len(parts)==2 and '--detach-stdio' in parts[1] and '-Dsbt.global.base='+str(base) in parts[1]:pid=int(parts[0])
assert pid is not None
flags = subprocess.run([java_home+'/bin/jcmd',str(pid),'VM.flags'],capture_output=True,text=True,timeout=15)
assert flags.returncode==0 and 'MaxHeapSize=3221225472' in flags.stdout
(logs/'server.json').write_text(json.dumps(dict(pid=pid,flags=flags.stdout,requested_profile='default 3g'),indent=2)+'\n')
run('hrf-js-final',['hrfJS/test'])
assert [r['counts'][0]['passed'] for r in rows]==[386,386]
run('matching-status-final',['--status'])
active = root/'project/target/active.json'
saved = active.read_bytes()
active.write_text('[]\n')
try:
    unknown = run('malformed-status-final',['--status'])
    assert 'config   unknown' in unknown
    refusal = run('malformed-run-final',['show atlasJVM / scalaVersion'],expected=1)
    assert 'configuration is unknown' in refusal and '[info]' not in refusal
    run('malformed-shutdown-final',['--shutdown'],heap='4g')
    if active.exists():
        restored = json.loads(active.read_text())
        assert isinstance(restored,dict) and isinstance(restored['uri'],str)
    stopped = run('stopped-status-final',['--status'])
    assert 'server   not running' in stopped
finally:
    if active.exists() and active.read_text().strip()=='[]':active.write_bytes(saved)
deadline=time.monotonic()+10
while subprocess.run(['ps','-p',str(pid)],capture_output=True).returncode==0 and time.monotonic()<deadline:time.sleep(0.1)
assert subprocess.run(['ps','-p',str(pid)],capture_output=True).returncode!=0
print('Final source passed JVM/JS, malformed active record refusal and safe live-base shutdown recovery.',flush=True)

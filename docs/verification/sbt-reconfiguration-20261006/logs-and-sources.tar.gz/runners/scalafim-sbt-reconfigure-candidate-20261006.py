from pathlib import Path
import subprocess, os, json, time, re, hashlib, signal

root = Path('/private/tmp/scalafim-sbt-reconfigure-20261006')
logs = Path('/private/tmp/scalafim-sbt-reconfiguration-20261006/candidate')
logs.mkdir(exist_ok=True)
java_home = subprocess.check_output(['/usr/libexec/java_home','-v','21'],text=True).strip()
base = Path.home()/'.cache/scalafim-sbt/bases'/hashlib.sha256(str(root).encode()).hexdigest()[:16]
rows = []
processes = {}

def run(label, heap, tasks, expected=0):
    env = dict(os.environ, SBT_WARM_HEAP=heap, COURSIER_REPOSITORIES='https://repo.maven.apache.org/maven2',
               JDK_JAVA_OPTIONS='-Xlog:gc:file='+str(logs)+'/gc-%p.log:time,uptime')
    command = ['python3','tools/build/sbt-warm',*tasks]
    started = time.monotonic()
    observed = set()
    with (logs/(label+'.log')).open('w') as out:
        client = subprocess.Popen(command,cwd=root,env=env,stdout=out,stderr=subprocess.STDOUT)
        while client.poll() is None:
            for line in subprocess.check_output(['ps','-axo','pid=,rss=,args='],text=True).splitlines():
                parts = line.strip().split(None,2)
                if len(parts)!=3:
                    continue
                pid,rss = map(int,parts[:2])
                if '--detach-stdio' not in parts[2] or '-Dsbt.global.base='+str(base) not in parts[2]:
                    continue
                observed.add(pid)
                record = processes.setdefault(pid,dict(pid=pid,requested_heap=heap,peak_sampled_rss_kib=0,flags_exit_code=1,gates=[]))
                record['peak_sampled_rss_kib'] = max(record['peak_sampled_rss_kib'],rss)
                if label not in record['gates']:record['gates'].append(label)
                if record['flags_exit_code']!=0:
                    flags = subprocess.run([java_home+'/bin/jcmd',str(pid),'VM.flags'],capture_output=True,text=True,timeout=15)
                    record.update(flags_exit_code=flags.returncode,flags=flags.stdout)
            if time.monotonic()-started>180:
                for pid in observed:
                    try:os.kill(pid,signal.SIGTERM)
                    except ProcessLookupError:pass
                client.terminate()
                raise RuntimeError('bounded command timed out: '+label)
            time.sleep(0.1)
    client.wait(timeout=15)
    content = (logs/(label+'.log')).read_text()
    counts = [dict(total=int(m[0]),failed=int(m[1]),errors=int(m[2]),passed=int(m[3]))
              for m in re.findall(r'(?:Passed|Failed): Total (\d+), Failed (\d+), Errors (\d+), Passed (\d+)',content)]
    row = dict(label=label,requested_heap=heap,command=command,exit_code=client.returncode,expected_exit_code=expected,
               seconds=round(time.monotonic()-started,3),observed_pids=sorted(observed),counts=counts,
               warnings=[line for line in content.splitlines() if line.startswith('[warn]')])
    rows.append(row)
    (logs/'runs.json').write_text(json.dumps(rows,indent=2)+'\n')
    (logs/'processes.json').write_text(json.dumps(list(processes.values()),indent=2)+'\n')
    print(json.dumps(row),flush=True)
    assert client.returncode==expected and not row['warnings'],label
    return content

run('load-4g','4g',['show atlasJVM / scalaVersion'])
startup = base/'.server-startup.json'
record = json.loads(startup.read_text())
assert record['config']['heap']=='4g'
(logs/'startup-4g.json').write_text(startup.read_text())
run('reload-4g','4g',['reload'])
run('set-one-4g','4g',['set atlasJVM / Test / envVars += ("SCALAFIM_SETTINGS_PROBE" -> "one")'])
run('set-two-4g','4g',['set atlasJVM / Test / envVars += ("SCALAFIM_SETTINGS_PROBE" -> "two")'])
value = run('read-setting-4g','4g',['show atlasJVM / Test / envVars'])
assert 'SCALAFIM_SETTINGS_PROBE -> two' in value
assert 'config   matches' in run('status-4g','4g',['--status'])
assert 'config   differs' in run('status-3g-request','3g',['--status'])
watched = ['global.sbt','.pin-key','.pin-key-v2','.server-startup.json']
before = {p:hashlib.sha256((base/p).read_bytes()).hexdigest() for p in watched}
refusal = run('mismatch-3g-request','3g',['show atlasJVM / scalaVersion'],expected=1)
assert 'differs from requested' in refusal and '--shutdown' in refusal and '[info]' not in refusal
assert before=={p:hashlib.sha256((base/p).read_bytes()).hexdigest() for p in watched}
saved = startup.read_bytes()
startup.unlink()
try:
    unknown = run('unknown-startup','4g',['show atlasJVM / scalaVersion'],expected=1)
    assert 'configuration is unknown' in unknown and '[info]' not in unknown
finally:
    startup.write_bytes(saved)
run('ordinary-read-after-refusals','4g',['show atlasJVM / scalaVersion'])
run('shutdown-with-3g-request','3g',['--shutdown'])
run('hrf-jvm-default','3g',['hrfJVM/test'])
run('hrf-js-default','3g',['hrfJS/test'])
assert all(c['failed']==0 and c['errors']==0 and c['passed']>0 for r in rows for c in r['counts'])
assert 'config   matches' in run('status-default','3g',['--status'])
(logs/'startup-3g.json').write_text(startup.read_text())
assert json.loads(startup.read_text())['config']['heap']=='3g'
run('reverse-mismatch-4g-request','4g',['show atlasJVM / scalaVersion'],expected=1)
assert len(processes)==2,processes
assert all(p['flags_exit_code']==0 for p in processes.values())
assert {p['requested_heap'] for p in processes.values()}=={'3g','4g'}
for p in processes.values():
    expected_size=3221225472 if p['requested_heap']=='3g' else 4294967296
    assert 'MaxHeapSize='+str(expected_size) in p['flags']
run('shutdown-with-4g-request','4g',['--shutdown'])
assert all(subprocess.run(['ps','-p',str(pid)],capture_output=True).returncode!=0 for pid in processes)
print('Candidate resource guards, repeated settings reapplication and default JVM/JS gates passed.',flush=True)

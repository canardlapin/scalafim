package scalafim.fmri.hrf

class HrfConstructorMutationSuite extends HrfConstructorCalibrationSuite:
  override def munitTests(): Seq[munit.Test] =
    val selected = super.munitTests().filter(_.name == "HrfSpec-constructor-refusal-is-typed")
    require(selected.size == 1)
    selected

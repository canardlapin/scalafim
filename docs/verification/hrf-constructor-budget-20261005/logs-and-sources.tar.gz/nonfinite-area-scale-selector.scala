package scalafim.fmri.hrf

class HrfConstructorMutationSuite extends HrfConstructorCalibrationSuite:
  override def munitTests(): Seq[munit.Test] =
    val selected = super.munitTests().filter(_.name == "finite-LWU-inputs-refuse-overflowing-area-calibration")
    require(selected.size == 1)
    selected

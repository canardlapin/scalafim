package scalafim.fmri.hrf

class HrfConstructorMutationSuite extends HrfConstructorCalibrationSuite:
  override def munitTests(): Seq[munit.Test] =
    val selected = super.munitTests().filter(_.name == "LWU-calibration-sample-boundary")
    require(selected.size == 1)
    selected

package scalafim.fmri.hrf

class HrfConstructorMutationSuite extends HrfConstructorCalibrationSuite:
  override def munitTests(): Seq[munit.Test] =
    val selected = super.munitTests().filter(_.name == "Daguerre-calibration-recurrence-work-boundary")
    require(selected.size == 1)
    selected

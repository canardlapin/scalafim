import org.scalajs.sbtplugin.ScalaJSPlugin.autoImport.*
import sbtcrossproject.CrossPlugin.autoImport.*
import scalajscrossproject.ScalaJSCrossPlugin.autoImport.*

lazy val imageAlgebraBoundaryCheck = taskKey[Unit](
  "Reject removed ScalaFIM axis, space, matrix, affine, congruence, and transform algebras"
)

lazy val transformBoundaryCheck = taskKey[Unit](
  "Keep shared transform codecs platform-neutral and toolkit conventions inside the convention kernel"
)

ThisBuild / organization := "scalafim"
ThisBuild / scalaVersion := "3.7.4"
ThisBuild / version      := "0.1.0-SNAPSHOT"

// Ravel is the single dense-array substrate shared by response and image
// semantics. The local override coordinates cross-repository development;
// ordinary builds remain pinned to an immutable source revision.
lazy val ravelRevision = "9c5669399ab8e2a11402e71973dd5f1e2f2c13f4"
lazy val ravelBuild =
  sys.props
    .get("scalafim.ravel.build")
    .map(path => file(path).getCanonicalFile.toURI)
    .getOrElse(uri(s"https://github.com/canardlapin/ravel.git#$ravelRevision"))
lazy val ravelCoreJVM = ProjectRef(ravelBuild, "coreJVM")
lazy val ravelCoreJS  = ProjectRef(ravelBuild, "coreJS")

// Immutable source dependency: sbt clones this exact Gale commit into its
// staging area. Multivar also needs its revision-tagged artifact; prepare it
// with tools/prepare-pinned-dependencies.sh. `scalafim.gale.build` is the explicit
// sibling-checkout override for coordinated upstream development (numerical
// capabilities such as banded factors are written in Gale, then pinned here).
lazy val galeRevision = "18d24dbb5056122032b0278f8bad557a9bb1cf23"
lazy val galeBuild =
  sys.props
    .get("scalafim.gale.build")
    .map(path => file(path).getCanonicalFile.toURI)
    .getOrElse(uri(s"https://github.com/canardlapin/gale.git#$galeRevision"))
lazy val galeCoreJVM = ProjectRef(galeBuild, "coreJVM")
lazy val galeCoreJS  = ProjectRef(galeBuild, "coreJS")

// Resample4s owns typed reindexing and resampling designs. The source pin is
// also consumed by Alder's admitted integration module below.
lazy val resample4sRevision =
  "6bc4172a966c92f1b06811eac64ac2bada9fef9b"
lazy val resample4sBuild =
  sys.props
    .get("scalafim.resample4s.build")
    .map(path => file(path).getCanonicalFile.toURI)
    .getOrElse(
      uri(
        s"https://github.com/canardlapin/resample4s.git#$resample4sRevision"
      )
    )
lazy val resample4sCoreJVM    = ProjectRef(resample4sBuild, "coreJVM")
lazy val resample4sCoreJS     = ProjectRef(resample4sBuild, "coreJS")
lazy val resample4sDesignsJVM = ProjectRef(resample4sBuild, "designsJVM")
lazy val resample4sDesignsJS  = ProjectRef(resample4sBuild, "designsJS")

// Alder owns fit lifecycles, stage-aware cross-fitting, and fitted artifacts.
// Keep its coordinated provider overrides explicit and process-local.
lazy val alderRevision = "c56a6b17989e77bdab8d57220fe3299fe9348e30"
lazy val alderBuild = {
  sys.props
    .get("scalafim.resample4s.build")
    .foreach(System.setProperty("alder.resample4s.build", _))
  sys.props
    .get("scalafim.gale.build")
    .foreach(System.setProperty("alder.gale.build", _))
  sys.props
    .get("scalafim.linop4s.build")
    .foreach(System.setProperty("alder.linop4s.build", _))
  sys.props
    .get("scalafim.alder.build")
    .map(path => file(path).getCanonicalFile.toURI)
    .getOrElse(uri(s"https://github.com/canardlapin/alder.git#$alderRevision"))
}
lazy val alderKernelJVM = ProjectRef(alderBuild, "kernelJVM")
lazy val alderKernelJS  = ProjectRef(alderBuild, "kernelJS")
lazy val alderDataJVM   = ProjectRef(alderBuild, "dataJVM")
lazy val alderDataJS    = ProjectRef(alderBuild, "dataJS")

// locus4s is independently owned. Ordinary builds clone the exact reviewed
// revision; the property is an explicit sibling-checkout override for
// coordinated development.
lazy val locus4sRevision = "58c9739be51345ad9adc4bc9c9e7335023254ec9"
lazy val locus4sBuild =
  sys.props
    .get("scalafim.locus4s.build")
    .map(path => file(path).getCanonicalFile.toURI)
    .getOrElse(uri(s"https://github.com/canardlapin/locus4s.git#$locus4sRevision"))
lazy val locus4sCoreJVM = ProjectRef(locus4sBuild, "locus4s-coreJVM")
lazy val locus4sCoreJS  = ProjectRef(locus4sBuild, "locus4s-coreJS")
lazy val locus4sDataJVM = ProjectRef(locus4sBuild, "locus4s-dataJVM")
lazy val locus4sDataJS  = ProjectRef(locus4sBuild, "locus4s-dataJS")

// image4s is independently owned. Ordinary builds use its immutable source
// revision; coordinated development can select a sibling checkout explicitly.
lazy val image4sRevision = "2c0638fb0767058ccd59b37f93754e95fc27df28"
lazy val image4sBuild = {
  sys.props
    .get("scalafim.locus4s.build")
    .foreach(System.setProperty("image4s.locus4s.build", _))
  sys.props
    .get("scalafim.image4s.build")
    .map(path => file(path).getCanonicalFile.toURI)
    .getOrElse(uri(s"https://github.com/canardlapin/image4s.git#$image4sRevision"))
}
lazy val image4sCoreJVM = ProjectRef(image4sBuild, "image4s-coreJVM")
lazy val image4sCoreJS  = ProjectRef(image4sBuild, "image4s-coreJS")
lazy val image4sGeometryJVM = ProjectRef(image4sBuild, "image4s-geometryJVM")
lazy val image4sGeometryJS  = ProjectRef(image4sBuild, "image4s-geometryJS")
lazy val image4sLocusJVM = ProjectRef(image4sBuild, "image4s-locusJVM")
lazy val image4sLocusJS  = ProjectRef(image4sBuild, "image4s-locusJS")
lazy val image4sFilterJVM = ProjectRef(image4sBuild, "image4s-filterJVM")
lazy val image4sFilterJS  = ProjectRef(image4sBuild, "image4s-filterJS")
lazy val image4sNiftiJVM  = ProjectRef(image4sBuild, "image4s-niftiJVM")

// reframe4s owns generic spatial maps and resampling execution. ScalaFIM
// retains neuroimaging policy and delegates affine kernels to this exact
// reviewed source revision.
lazy val reframe4sRevision = "9a4508351d74567147b8ea3221d82db89e5892b0"
lazy val reframe4sBuild =
  sys.props
    .get("scalafim.reframe4s.build")
    .map(path => file(path).getCanonicalFile.toURI)
    .getOrElse(uri(s"https://github.com/canardlapin/reframe4s.git#$reframe4sRevision"))
lazy val reframe4sLieJVM      = ProjectRef(reframe4sBuild, "reframe4s-lieJVM")
lazy val reframe4sLieJS       = ProjectRef(reframe4sBuild, "reframe4s-lieJS")
lazy val reframe4sFieldJVM    = ProjectRef(reframe4sBuild, "reframe4s-fieldJVM")
lazy val reframe4sFieldJS     = ProjectRef(reframe4sBuild, "reframe4s-fieldJS")
lazy val reframe4sResampleJVM = ProjectRef(reframe4sBuild, "reframe4s-resampleJVM")
lazy val reframe4sResampleJS  = ProjectRef(reframe4sBuild, "reframe4s-resampleJS")

// graph4s is an independently owned topology and algorithms library. Ordinary
// builds clone the exact reviewed revision; the property is an explicit local
// source override for coordinated development.
lazy val graph4sRevision = "b585e594eec4567bad78ae23206c1a8f535bcd5e"
lazy val graph4sBuild =
  sys.props
    .get("scalafim.graph4s.build")
    .map(path => file(path).getCanonicalFile.toURI)
    .getOrElse(uri(s"https://github.com/canardlapin/graph4s.git#$graph4sRevision"))
lazy val graph4sCoreJVM       = ProjectRef(graph4sBuild, "coreJVM")
lazy val graph4sCoreJS        = ProjectRef(graph4sBuild, "coreJS")
lazy val graph4sAlgorithmsJVM = ProjectRef(graph4sBuild, "algorithmsJVM")
lazy val graph4sAlgorithmsJS  = ProjectRef(graph4sBuild, "algorithmsJS")

// General multivariate analysis is developed independently. The optional
// system property is an explicit local-development override; ordinary builds
// clone the exact committed source revision.
lazy val multivarRevision = "f74d631720d65147c51496dcbdd37c01912de1cb"
lazy val multivarBuild =
  sys.props
    .get("scalafim.multivar.build")
    .map(path => file(path).getCanonicalFile.toURI)
    .getOrElse(
      uri(
        s"https://github.com/canardlapin/multivar.git#$multivarRevision"
      )
    )
lazy val multivarJVM   = ProjectRef(multivarBuild, "coreJVM")
lazy val multivarJS    = ProjectRef(multivarBuild, "coreJS")
lazy val multivarIrJVM = ProjectRef(multivarBuild, "irJVM")
lazy val multivarIrJS  = ProjectRef(multivarBuild, "irJS")

// Renderer-neutral graphics and platform backends are developed independently.
// Ordinary builds clone the exact public revision; the system property is an
// explicit local-development override.
lazy val intaglioRevision = "596b398af380079e4b251535230d0bc03cd88c51"
lazy val intaglioBuild =
  uri(
    sys.props.getOrElse(
      "scalafim.intaglio.build",
      s"https://github.com/canardlapin/intaglio.git#$intaglioRevision"
    )
  )
lazy val intaglioCoreJVM   = ProjectRef(intaglioBuild, "coreJVM")
lazy val intaglioCoreJS    = ProjectRef(intaglioBuild, "coreJS")
lazy val intaglioSvgJVM    = ProjectRef(intaglioBuild, "svgJVM")
lazy val intaglioCanvasJS  = ProjectRef(intaglioBuild, "canvasJS")
lazy val intaglioJava2dJVM = ProjectRef(intaglioBuild, "java2dJVM")
lazy val intaglioJavafxJVM = ProjectRef(intaglioBuild, "javafxJVM")

// Reusable BIDS semantics are developed independently. Ordinary builds clone
// the exact reviewed revision; the property is an explicit local-development
// override for downstream rehearsal.
lazy val bids4sRevision = "a33678390614a91fadbdef13f22970e78c26e091"
lazy val bids4sBuild =
  uri(
    sys.props.getOrElse(
      "scalafim.bids4s.build",
      s"https://github.com/canardlapin/bids4s.git#$bids4sRevision"
    )
  )
lazy val bids4sJVM = ProjectRef(bids4sBuild, "coreJVM")
lazy val bids4sJS  = ProjectRef(bids4sBuild, "coreJS")

// Generic Zarr mechanics are independently owned by zarr4s. Ordinary builds
// clone the exact reviewed revision; the property is an explicit local source
// override for coordinated development.
lazy val zarr4sRevision = "2a5ba963b151b62c739d1bf5a19d49202bb6ff29"
lazy val zarr4sBuild =
  sys.props
    .get("scalafim.zarr4s.build")
    .map(path => file(path).getCanonicalFile.toURI)
    .getOrElse(uri(s"https://github.com/canardlapin/zarr4s.git#$zarr4sRevision"))
lazy val zarr4sCoreJVM = ProjectRef(zarr4sBuild, "coreJVM")
lazy val zarr4sCoreJS  = ProjectRef(zarr4sBuild, "coreJS")

lazy val jhdfVersion = "0.12.0"

lazy val commonSettings = Seq(
  scalacOptions ++= Seq(
    "-deprecation",
    "-feature",
    "-unchecked",
    "-Xmax-inlines:64"
  ),
  Test / fork := false,
  libraryDependencies += "org.scalameta" %%% "munit" % "1.2.1" % Test
)

// The first-level scientific stack is the initial strict-warning court. Keep
// these options scoped until the remaining modules have been migrated rather
// than weakening the signal with repository-wide exclusions.
lazy val strictFirstLevelCompilerSettings = Seq(
  scalacOptions ++= Seq(
    "-Werror",
    "-Wunused:all",
    "-Wvalue-discard"
  )
)

def scientificCoverageSettings(statementMinimum: Double, branchMinimum: Double) = Seq(
  coverageMinimumStmtTotal := statementMinimum,
  coverageMinimumBranchTotal := branchMinimum,
  coverageFailOnMinimum := true
)

lazy val jsSettingsBase = Seq(
  scalaJSLinkerConfig ~= (_.withModuleKind(ModuleKind.CommonJSModule)),
  Test / jsEnv := new org.scalajs.jsenv.nodejs.NodeJSEnv()
)

lazy val locusData =
  crossProject(JSPlatform, JVMPlatform)
    .crossType(CrossType.Full)
    .in(file("modules/locus-data"))
    .settings(commonSettings)
    .settings(
      name := "scalafim-locus-data",
      libraryDependencies += "org.typelevel" %%% "cats-kernel" % "2.12.0"
    )
    .jvmConfigure(_.dependsOn(locus4sCoreJVM, locus4sDataJVM))
    .jsConfigure(_.dependsOn(locus4sCoreJS, locus4sDataJS))
    .jsSettings(jsSettingsBase)

lazy val locusDataJS  = locusData.js
lazy val locusDataJVM = locusData.jvm

lazy val pipeline =
  crossProject(JSPlatform, JVMPlatform)
    .crossType(CrossType.Full)
    .in(file("modules/pipeline"))
    .settings(commonSettings)
    .settings(
      name := "scalafim-pipeline",
      // graph4s is a source ProjectRef. Re-declare its runtime collection
      // dependency at this public boundary so second-order ScalaFIM consumers
      // such as fit receive it on both JVM and Scala.js classpaths.
      libraryDependencies +=
        "org.typelevel" %%% "cats-collections-core" % "0.9.10"
    )
    .jvmConfigure(_.dependsOn(graph4sAlgorithmsJVM))
    .jsConfigure(_.dependsOn(graph4sAlgorithmsJS))
    .jsSettings(jsSettingsBase)

lazy val pipelineJS  = pipeline.js
lazy val pipelineJVM = pipeline.jvm

// OpenJFX publishes platform-specific artifacts by classifier; resolve the one
// matching the build machine so ScalaFIM's JavaFX hosts compile and test locally.
lazy val javafxPlatformClassifier: String = {
  val os = sys.props.getOrElse("os.name", "").toLowerCase
  val arch = sys.props.getOrElse("os.arch", "").toLowerCase
  val base =
    if (os.contains("mac")) "mac"
    else if (os.contains("win")) "win"
    else "linux"
  if (arch.contains("aarch64") && base != "win") base + "-aarch64" else base
}

lazy val response =
  crossProject(JSPlatform, JVMPlatform)
    .crossType(CrossType.Full)
    .in(file("modules/response"))
    .settings(commonSettings)
    .settings(
      name := "scalafim-response",
      libraryDependencies ++= Seq(
        "org.typelevel" %%% "cats-core"   % "2.12.0",
        "org.typelevel" %%% "cats-effect" % "3.5.4"
      )
    )
    .jvmConfigure(_.dependsOn(ravelCoreJVM))
    .jsConfigure(_.dependsOn(ravelCoreJS))
    .jsSettings(jsSettingsBase)

lazy val responseJS  = response.js
lazy val responseJVM = response.jvm

lazy val responseLaws =
  crossProject(JSPlatform, JVMPlatform)
    .crossType(CrossType.Full)
    .in(file("modules/response-laws"))
    .dependsOn(response)
    .settings(commonSettings)
    .settings(
      name := "scalafim-response-laws"
    )
    .jsSettings(jsSettingsBase)

lazy val responseLawsJS  = responseLaws.js
lazy val responseLawsJVM = responseLaws.jvm

lazy val latent =
  crossProject(JSPlatform, JVMPlatform)
    .crossType(CrossType.Full)
    .in(file("modules/latent"))
    .dependsOn(
      response,
      responseLaws % "test->compile",
      image,
      locusData
    )
    .settings(commonSettings)
    .settings(
      name := "scalafim-fmri-latent",
      Test / unmanagedSources ~= (_.filterNot(
        _.getName == "ResponseArchiveMigrationBaselineSuite.scala"
      ))
    )
    .jvmConfigure(_.dependsOn(galeCoreJVM))
    .jsConfigure(_.dependsOn(galeCoreJS))
    .jsSettings(jsSettingsBase)

lazy val latentJS  = latent.js
lazy val latentJVM = latent.jvm

lazy val ar =
  crossProject(JSPlatform, JVMPlatform)
    .crossType(CrossType.Full)
    .in(file("modules/ar"))
    .settings(commonSettings)
    .settings(strictFirstLevelCompilerSettings)
    .settings(
      name := "scalafim-fmri-ar"
    )
    .jvmConfigure(_.dependsOn(galeCoreJVM))
    .jvmSettings(scientificCoverageSettings(statementMinimum = 75.0, branchMinimum = 62.0))
    .jsConfigure(_.dependsOn(galeCoreJS))
    .jsSettings(jsSettingsBase)

lazy val arJS  = ar.js
lazy val arJVM = ar.jvm

// Cross-built scenario verdict/policy core. It is test-support only: design,
// fit, transform and surface depend on its main classes from test scope, so
// published production artifacts do not acquire MUnit or scenario-testkit
// dependencies.
lazy val scenarioTestkit =
  crossProject(JSPlatform, JVMPlatform)
    .crossType(CrossType.Full)
    .in(file("modules/scenario-testkit"))
    .settings(commonSettings)
    .settings(
      name := "scalafim-scenario-testkit",
      publish / skip := true
    )
    .jsSettings(jsSettingsBase)

lazy val scenarioTestkitJS  = scenarioTestkit.js
lazy val scenarioTestkitJVM = scenarioTestkit.jvm

lazy val hrf =
  crossProject(JSPlatform, JVMPlatform)
    .crossType(CrossType.Full)
    .in(file("modules/hrf"))
    .settings(commonSettings)
    .settings(strictFirstLevelCompilerSettings)
    .settings(
      name := "scalafim-fmri-hrf",
      libraryDependencies ++= Seq(
        "org.typelevel" %%% "cats-core" % "2.12.0",
        "org.typelevel" %%% "spire"     % "0.18.0",
        "org.scalameta" %%% "munit-scalacheck" % "1.1.0" % Test
      )
    )
    .jvmSettings(
      libraryDependencies ++= Seq(
        "com.github.wendykierp" % "JTransforms" % "3.1"
      )
    )
    .jvmSettings(scientificCoverageSettings(statementMinimum = 70.0, branchMinimum = 60.0))
    .jsSettings(jsSettingsBase)

lazy val hrfJS  = hrf.js
lazy val hrfJVM = hrf.jvm

lazy val hrfLaws =
  crossProject(JSPlatform, JVMPlatform)
    .crossType(CrossType.Full)
    .in(file("modules/hrf-laws"))
    .dependsOn(hrf)
    .settings(commonSettings)
    .settings(
      name := "scalafim-fmri-hrf-laws",
      libraryDependencies += "org.scalameta" %%% "munit" % "1.2.1"
    )
    .jsSettings(jsSettingsBase)

lazy val hrfLawsJS  = hrfLaws.js
lazy val hrfLawsJVM = hrfLaws.jvm

lazy val design =
  crossProject(JSPlatform, JVMPlatform)
    .crossType(CrossType.Full)
    .in(file("modules/design"))
    .dependsOn(hrf, scenarioTestkit % "test->compile")
    .settings(commonSettings)
    .settings(strictFirstLevelCompilerSettings)
    .settings(
      name := "scalafim-fmri-design",
      libraryDependencies ++= Seq(
        "com.lihaoyi" %%% "upickle" % "4.1.0",
        "org.typelevel" %%% "cats-core" % "2.12.0",
        "org.typelevel" %%% "spire"     % "0.18.0"
      )
    )
    .jvmConfigure(_.dependsOn(galeCoreJVM, intaglioCoreJVM, intaglioSvgJVM % "test->compile"))
    .jvmSettings(scientificCoverageSettings(statementMinimum = 70.0, branchMinimum = 58.0))
    .jsConfigure(_.dependsOn(galeCoreJS, intaglioCoreJS))
    .jsSettings(jsSettingsBase)

lazy val designJS  = design.js
lazy val designJVM = design.jvm

lazy val image =
  crossProject(JSPlatform, JVMPlatform)
    .crossType(CrossType.Full)
    .in(file("modules/image"))
    .dependsOn(locusData)
    .settings(commonSettings)
    .settings(
      name := "scalafim-image",
      Test / scalacOptions +=
        "-Wconf:src=.*NeuroImageErrorContractSuite\\.scala&id=E29:e",
      imageAlgebraBoundaryCheck := {
        val repository = (LocalRootProject / baseDirectory).value
        val removedFiles = Vector(
          repository / "modules" / "image" / "shared" / "src" / "main" / "scala" / "scalafim" / "image" / "Axis.scala",
          repository / "modules" / "image" / "shared" / "src" / "main" / "scala" / "scalafim" / "image" / "AxisSet.scala",
          repository / "modules" / "image" / "shared" / "src" / "main" / "scala" / "scalafim" / "image" / "GridCompatibility.scala",
          repository / "modules" / "image" / "shared" / "src" / "main" / "scala" / "scalafim" / "image" / "DMat.scala",
          repository / "modules" / "image" / "shared" / "src" / "main" / "scala" / "scalafim" / "image" / "Affine.scala",
          repository / "modules" / "image" / "shared" / "src" / "main" / "scala" / "scalafim" / "image" / "Morphism.scala",
          repository / "modules" / "image" / "shared" / "src" / "main" / "scala" / "scalafim" / "image" / "MorphismExecutionPlan.scala",
          repository / "modules" / "image" / "shared" / "src" / "main" / "scala" / "scalafim" / "image" / "DenseFieldInterpolationPlan.scala",
          repository / "modules" / "image" / "shared" / "src" / "main" / "scala" / "scalafim" / "image" / "DenseFieldInverse.scala"
        ).filter(_.exists)
        val productionSources =
          (repository / "modules" ** "*.scala").get.filter { source =>
            source.getPath.contains("/src/main/scala/")
          }
        val legacyReferences =
          productionSources.filter { source =>
            val contents = IO.read(source)
            contents.contains("scalafim.image.Axis") ||
            contents.contains("scalafim.image.DMat") ||
            "\\bAxisSet\\b".r.findFirstIn(contents).nonEmpty ||
            "\\bAffine3DError\\b|\\bDMat\\.invert\\b".r
              .findFirstIn(contents)
              .nonEmpty ||
            "(?m)^\\s*(?:final\\s+)?(?:case\\s+)?(?:class|object|enum|type)\\s+(?:DMat|Affine3D)\\b|(?m)^\\s*object\\s+Affine\\s*:".r
              .findFirstIn(contents)
              .nonEmpty ||
            "\\b(?:ImageDim|Slice2D|Volume3D|Series4D|ImageDimEvidence|ImageSpace|VolumeSpace|SeriesSpace|GridCompatibility|GridMismatch|CertifiedGridCongruence)\\b".r
              .findFirstIn(contents)
              .nonEmpty ||
            "\\b(?:SpatialMorphism|Affine3DMorphism|IdentityMorphism|DenseFieldMorphism|SpatialDomainId|MorphismExecutionPlan|DenseFieldInterpolationPlan|DenseFieldInverse|JacobianField|JacobianMode|MorphismFields)\\b".r
              .findFirstIn(contents)
              .nonEmpty ||
            "\\b(?:DenseCoordinateMap|CompositeCoordinateMap)\\b|\\bCoordinateMap\\.(?:Affine3D|Dense3D|Composite3D|dense3D|composite3D)\\b".r
              .findFirstIn(contents)
              .nonEmpty
          }
        val obsoleteDependencies =
          libraryDependencies.value.filter { module =>
            module.organization == "ai.dragonfly" && module.name.contains("slash")
          }
        val sampleSpacesSource =
          repository / "modules" / "image" / "shared" / "src" / "main" / "scala" / "scalafim" / "image" / "SampleSpaces.scala"
        val packageSource =
          repository / "modules" / "image" / "shared" / "src" / "main" / "scala" / "scalafim" / "image" / "package.scala"
        val publicProviderStateAliases =
          "(?m)^\\s+(?:inline\\s+)?def\\s+(?:dims|ndim|spatialDims|spatialShape|spacing|origin|orientation|affineD3|inverseAffineD3|gridToIndex|indexToGrid|gridToIndex3D|indexToGrid3D|indexToVoxel3D|spatialSpace|addDim|dropDim|indexToCoord|indexToPoint|voxelToWorld|coordToIndex|coordToIndexPoint|worldToVoxel)\\b".r
            .findFirstIn(IO.read(sampleSpacesSource))
        val packageFacadeReturned =
          "(?m)^\\s*export SampleSpaces\\.\\*\\s*$".r
            .findFirstIn(IO.read(packageSource))
            .nonEmpty
        if (removedFiles.nonEmpty)
          sys.error(s"removed ScalaFIM algebra sources returned: ${removedFiles.mkString(", ")}")
        if (legacyReferences.nonEmpty)
          sys.error(s"production sources reference a removed ScalaFIM algebra: ${legacyReferences.mkString(", ")}")
        if (obsoleteDependencies.nonEmpty)
          sys.error(s"obsolete image algebra dependency returned: ${obsoleteDependencies.mkString(", ")}")
        if (publicProviderStateAliases.nonEmpty)
          sys.error(s"public SampleSpaces provider-state alias returned: ${publicProviderStateAliases.get}")
        if (packageFacadeReturned)
          sys.error("package-wide SampleSpaces export returned")
        // STP P1.07 exit gate, image half: the same frame-erasure scan as transformBoundaryCheck.
        FrameErasureGate.selfTest()
        val erasedSignatures = FrameErasureGate.check(repository)
        if (erasedSignatures.nonEmpty)
          sys.error(s"frame-erased signatures outside the allowlist (STP P1.07):\n${erasedSignatures.mkString("\n")}")
      },
      Compile / compile := (Compile / compile).dependsOn(imageAlgebraBoundaryCheck).value,
      libraryDependencies ++= Seq(
        "org.typelevel" %%% "cats-core"   % "2.12.0",
        "org.typelevel" %%% "cats-effect" % "3.5.4",
        "org.typelevel" %%% "spire"       % "0.18.0",
        "org.scalameta" %%% "munit-scalacheck" % "1.1.0" % Test
      )
    )
    .jvmConfigure(
      _.dependsOn(
        galeCoreJVM,
        image4sCoreJVM,
        image4sGeometryJVM,
        image4sLocusJVM,
        image4sFilterJVM,
        image4sNiftiJVM,
        reframe4sLieJVM,
        reframe4sFieldJVM,
        reframe4sResampleJVM
      )
    )
    .jsConfigure(
      _.dependsOn(
        galeCoreJS,
        image4sCoreJS,
        image4sGeometryJS,
        image4sLocusJS,
        image4sFilterJS,
        reframe4sLieJS,
        reframe4sFieldJS,
        reframe4sResampleJS
      )
    )
    .jsSettings(jsSettingsBase)

lazy val imageJS  = image.js
lazy val imageJVM = image.jvm

// Unpublished cross-platform compile contract proving that ScalaFIM consumers
// can compose the admitted provider APIs directly. Sources deliberately live
// outside package scalafim and define no adapter algebra.
lazy val providerSpike =
  crossProject(JSPlatform, JVMPlatform)
    .crossType(CrossType.Full)
    .in(file("modules/provider-spike"))
    .settings(commonSettings)
    .settings(
      name := "scalafim-provider-spike",
      publish / skip := true
    )
    .jvmConfigure(
      _.dependsOn(
        ravelCoreJVM,
        galeCoreJVM,
        locus4sCoreJVM,
        image4sCoreJVM,
        image4sGeometryJVM,
        image4sLocusJVM,
        reframe4sLieJVM,
        reframe4sResampleJVM
      )
    )
    .jsConfigure(
      _.dependsOn(
        ravelCoreJS,
        galeCoreJS,
        locus4sCoreJS,
        image4sCoreJS,
        image4sGeometryJS,
        image4sLocusJS,
        reframe4sLieJS,
        reframe4sResampleJS
      )
    )
    .jsSettings(jsSettingsBase)

lazy val providerSpikeJS  = providerSpike.js
lazy val providerSpikeJVM = providerSpike.jvm

lazy val hrfBenchJVM =
  project
    .in(file("benchmarks/hrf-jvm"))
    .dependsOn(hrfJVM)
    .enablePlugins(JmhPlugin)
    .settings(commonSettings)
    .settings(strictFirstLevelCompilerSettings)
    .settings(
      name := "scalafim-hrf-benchmarks",
      publish / skip := true
    )

lazy val imageView =
  crossProject(JSPlatform, JVMPlatform)
    .crossType(CrossType.Full)
    .in(file("modules/image-view"))
    .dependsOn(image)
    .jvmConfigure(_.dependsOn(intaglioCoreJVM))
    .jsConfigure(_.dependsOn(intaglioCoreJS))
    .settings(commonSettings)
    .settings(
      name := "scalafim-image-view"
    )
    .jsSettings(jsSettingsBase)

lazy val imageViewJS  = imageView.js
lazy val imageViewJVM = imageView.jvm

lazy val imageViewCanvas =
  crossProject(JSPlatform)
    .crossType(CrossType.Full)
    .in(file("modules/image-view-canvas"))
    .dependsOn(imageView)
    .jsConfigure(_.dependsOn(intaglioCanvasJS))
    .settings(commonSettings)
    .settings(
      name := "scalafim-image-view-canvas"
    )
    .jsSettings(jsSettingsBase)

lazy val imageViewCanvasJS = imageViewCanvas.js

lazy val imageViewJava2d =
  crossProject(JVMPlatform)
    .crossType(CrossType.Full)
    .in(file("modules/image-view-java2d"))
    .dependsOn(imageView)
    .jvmConfigure(_.dependsOn(intaglioJava2dJVM))
    .settings(commonSettings)
    .settings(
      name := "scalafim-image-view-java2d"
    )

lazy val imageViewJava2dJVM = imageViewJava2d.jvm

lazy val imageViewJavafx =
  crossProject(JVMPlatform)
    .crossType(CrossType.Full)
    .in(file("modules/image-view-javafx"))
    .dependsOn(imageView)
    .jvmConfigure(_.dependsOn(intaglioJavafxJVM))
    .settings(commonSettings)
    .settings(
      name := "scalafim-image-view-javafx",
      libraryDependencies ++= Seq(
        "org.openjfx" % "javafx-base" % "21.0.5" % Provided classifier javafxPlatformClassifier,
        "org.openjfx" % "javafx-graphics" % "21.0.5" % Provided classifier javafxPlatformClassifier
      )
    )

lazy val imageViewJavafxJVM = imageViewJavafx.jvm

lazy val threshold =
  crossProject(JSPlatform, JVMPlatform)
    .crossType(CrossType.Full)
    .in(file("modules/threshold"))
    .dependsOn(image, scenarioTestkit % "test->compile")
    .settings(commonSettings)
    .settings(
      name := "scalafim-fmri-threshold"
    )
    .jvmConfigure(_.dependsOn(galeCoreJVM))
    .jsConfigure(_.dependsOn(galeCoreJS))
    .jsSettings(jsSettingsBase)

lazy val thresholdJS  = threshold.js
lazy val thresholdJVM = threshold.jvm

lazy val motion =
  crossProject(JSPlatform, JVMPlatform)
    .crossType(CrossType.Full)
    .in(file("modules/motion"))
    .dependsOn(image)
    .settings(commonSettings)
    .settings(
      name := "scalafim-fmri-motion"
    )
    .jvmConfigure(_.dependsOn(image4sGeometryJVM))
    .jsConfigure(_.dependsOn(image4sGeometryJS))
    .jsSettings(jsSettingsBase)

lazy val motionJS  = motion.js
lazy val motionJVM = motion.jvm.dependsOn(bids4sJVM)

lazy val surface =
  crossProject(JSPlatform, JVMPlatform)
    .crossType(CrossType.Full)
    .in(file("modules/surface"))
    .dependsOn(image, locusData, scenarioTestkit % "test->compile")
    .settings(commonSettings)
    .settings(
      name := "scalafim-surface",
      libraryDependencies ++= Seq(
        "org.scala-lang.modules" %%% "scala-xml" % "2.4.0"
      )
    )
    .jvmConfigure(_.dependsOn(image4sGeometryJVM, graph4sAlgorithmsJVM))
    .jsConfigure(_.dependsOn(image4sGeometryJS, graph4sAlgorithmsJS))
    .jsSettings(jsSettingsBase)

lazy val surfaceJS  = surface.js
lazy val surfaceJVM = surface.jvm

lazy val surfaceView =
  crossProject(JSPlatform, JVMPlatform)
    .crossType(CrossType.Full)
    .in(file("modules/surface-view"))
    .dependsOn(surface)
    .jvmConfigure(_.dependsOn(intaglioCoreJVM))
    .jsConfigure(_.dependsOn(intaglioCoreJS))
    .settings(commonSettings)
    .settings(
      name := "scalafim-surface-view"
    )
    .jsSettings(jsSettingsBase)

lazy val surfaceViewJS  = surfaceView.js
lazy val surfaceViewJVM = surfaceView.jvm

lazy val surfaceViewRaster =
  crossProject(JSPlatform, JVMPlatform)
    .crossType(CrossType.Full)
    .in(file("modules/surface-view-raster"))
    .dependsOn(surfaceView)
    .jvmConfigure(_.dependsOn(intaglioCoreJVM))
    .jsConfigure(_.dependsOn(intaglioCoreJS))
    .settings(commonSettings)
    .settings(
      name := "scalafim-surface-view-raster"
    )
    .jsSettings(jsSettingsBase)

lazy val surfaceViewRasterJS  = surfaceViewRaster.js
lazy val surfaceViewRasterJVM = surfaceViewRaster.jvm

lazy val surfaceViewJavafx =
  crossProject(JVMPlatform)
    .crossType(CrossType.Full)
    .in(file("modules/surface-view-javafx"))
    .dependsOn(surfaceView, surfaceViewRaster % "test->compile")
    .jvmConfigure(_.dependsOn(intaglioCoreJVM))
    .settings(commonSettings)
    .settings(
      name := "scalafim-surface-view-javafx",
      Test / run / fork := true,
      libraryDependencies ++= Seq(
        "org.openjfx" % "javafx-base" % "21.0.5" % Provided classifier javafxPlatformClassifier,
        "org.openjfx" % "javafx-graphics" % "21.0.5" % Provided classifier javafxPlatformClassifier
      )
    )

lazy val surfaceViewJavafxJVM = surfaceViewJavafx.jvm

lazy val surfaceViewThree =
  crossProject(JSPlatform)
    .crossType(CrossType.Full)
    .in(file("modules/surface-view-three"))
    .dependsOn(surfaceView)
    .jsConfigure(_.dependsOn(intaglioCoreJS))
    .settings(commonSettings)
    .settings(
      name := "scalafim-surface-view-three"
    )
    .jsSettings(jsSettingsBase)

lazy val surfaceViewThreeJS = surfaceViewThree.js

lazy val surfaceViewExamples =
  crossProject(JSPlatform, JVMPlatform)
    .crossType(CrossType.Full)
    .in(file("examples/surface-view"))
    .dependsOn(surfaceView, surfaceViewRaster)
    .jvmConfigure(_.dependsOn(intaglioCoreJVM))
    .jsConfigure(_.dependsOn(intaglioCoreJS))
    .settings(commonSettings)
    .settings(
      name := "scalafim-examples-surface-view",
      publish / skip := true,
      libraryDependencies += "org.scala-lang.modules" %%% "scala-xml" % "2.4.0"
    )
    .jsSettings(jsSettingsBase)

lazy val surfaceViewExamplesJS = surfaceViewExamples.js.dependsOn(surfaceViewThreeJS)
lazy val surfaceViewExamplesJVM = surfaceViewExamples.jvm
  .dependsOn(surfaceViewJavafxJVM)
  .settings(
    Test / run / fork := true,
    libraryDependencies ++= Seq(
      "org.openjfx" % "javafx-base" % "21.0.5" classifier javafxPlatformClassifier,
      "org.openjfx" % "javafx-graphics" % "21.0.5" classifier javafxPlatformClassifier
    )
  )

lazy val surfaceExamplesJVM =
  project
    .in(file("examples/surface-jvm"))
    .dependsOn(surfaceJVM)
    .settings(commonSettings)
    .settings(
      name := "scalafim-examples-surface-jvm",
      publish / skip := true,
      libraryDependencies += "org.scala-lang.modules" %% "scala-xml" % "2.4.0"
    )

lazy val spatial =
  crossProject(JSPlatform, JVMPlatform)
    .crossType(CrossType.Full)
    .in(file("modules/spatial"))
    .dependsOn(image, surface, locusData, transform)
    .settings(commonSettings)
    .settings(
      name := "scalafim-spatial"
    )
    .jvmSettings(
      // HDF5 transform files are read by transform's jHDF container; tests silence jHDF's logging.
      libraryDependencies += "org.slf4j" % "slf4j-nop" % "2.0.18" % Test
    )
    .jvmConfigure(_.dependsOn(galeCoreJVM))
    .jsConfigure(_.dependsOn(galeCoreJS))
    .jsSettings(jsSettingsBase)

lazy val spatialJS  = spatial.js
lazy val spatialJVM = spatial.jvm

// Toolkit transform formats (ITK/ANTs, FSL, AFNI, FreeSurfer, X5), their
// interpretation into typed world-space transforms, and conversion between
// them. Generic transform algebra stays in reframe4s; frame identity and
// coordinate conventions stay in image (scalafim.image.space).
lazy val transform =
  crossProject(JSPlatform, JVMPlatform)
    .crossType(CrossType.Full)
    .in(file("modules/transform"))
    .dependsOn(image, scenarioTestkit % "test->compile")
    .settings(commonSettings)
    .settings(strictFirstLevelCompilerSettings)
    .settings(
      name := "scalafim-transform",
      libraryDependencies += "org.scalameta" %%% "munit-scalacheck" % "1.1.0" % Test,
      transformBoundaryCheck := {
        val repository = (LocalRootProject / baseDirectory).value
        val sharedMain = repository / "modules" / "transform" / "shared" / "src" / "main" / "scala"
        val sharedSources = (sharedMain ** "*.scala").get
        val platformLeaks = sharedSources.filter { source =>
          "\\bjava\\.(?:io|nio)\\b|\\bio\\.jhdf\\b|\\bscala\\.io\\.Source\\b".r
            .findFirstIn(IO.read(source))
            .nonEmpty
        }
        if (platformLeaks.nonEmpty)
          sys.error(s"shared transform sources use platform IO: ${platformLeaks.mkString(", ")}")
        // STP P1.07: world frames stay typed (project/FrameErasureGate.scala). Frame-erased maps, pullbacks, grids,
        // sample spaces, boxes and points are allowed only in IO packages and where the heterogeneity is genuinely
        // dynamic and ownership is re-checked at runtime (FrameErasureGate.Allowlist, by repository-relative path):
        //   spatial Morphism.scala      graph edges between arbitrary domains (reframe4s eraseFrameRefinements boundary)
        //   transform StageChain.scala  private stage composition, re-typed to the chain's endpoints on every call
        FrameErasureGate.selfTest()
        val erasedSignatures = FrameErasureGate.check(repository)
        if (erasedSignatures.nonEmpty)
          sys.error(s"frame-erased signatures outside the allowlist (STP P1.07):\n${erasedSignatures.mkString("\n")}")
      },
      Compile / compile := (Compile / compile).dependsOn(transformBoundaryCheck).value
    )
    .jvmSettings(libraryDependencies += "io.jhdf" % "jhdf" % jhdfVersion)
    .jvmConfigure(_.dependsOn(image4sGeometryJVM, reframe4sLieJVM, reframe4sFieldJVM, reframe4sResampleJVM))
    .jsConfigure(_.dependsOn(image4sGeometryJS, reframe4sLieJS, reframe4sFieldJS, reframe4sResampleJS))
    .jsSettings(jsSettingsBase)

lazy val transformJS  = transform.js
lazy val transformJVM = transform.jvm

lazy val atlas =
  crossProject(JSPlatform, JVMPlatform)
    .crossType(CrossType.Full)
    .in(file("modules/atlas"))
    .dependsOn(image, surface, locusData, spatial, transform)
    .settings(commonSettings)
    .settings(
      name := "scalafim-atlas",
      libraryDependencies += "com.lihaoyi" %%% "upickle" % "4.1.0"
    )
    .jvmSettings(
      libraryDependencies += "org.scala-lang.modules" %% "scala-xml" % "2.4.0"
    )
    .jvmConfigure(_.dependsOn(image4sGeometryJVM, graph4sAlgorithmsJVM))
    .jsConfigure(_.dependsOn(image4sGeometryJS, graph4sAlgorithmsJS))
    .jsSettings(jsSettingsBase)

lazy val atlasJS  = atlas.js
lazy val atlasJVM = atlas.jvm

lazy val atlasExamplesJVM =
  project
    .in(file("examples/atlas-jvm"))
    .dependsOn(atlasJVM, mvpaSpatialJVM)
    .settings(commonSettings)
    .settings(
      name := "scalafim-examples-atlas-jvm",
      publish / skip := true
    )

lazy val workflowExamplesJVM =
  project
    .in(file("examples/workflows-jvm"))
    .dependsOn(atlasJVM, mvpaSpatialJVM, fitJVM)
    .settings(commonSettings)
    .settings(
      name := "scalafim-examples-workflows-jvm",
      publish / skip := true
    )

lazy val archive =
  crossProject(JSPlatform, JVMPlatform)
    .crossType(CrossType.Full)
    .in(file("modules/archive"))
    .settings(commonSettings)
    .settings(
      name := "scalafim-archive",
      libraryDependencies ++= Seq(
        "org.typelevel" %%% "cats-core"   % "2.12.0",
        "org.typelevel" %%% "cats-effect" % "3.5.4"
      )
    )
    .jsSettings(jsSettingsBase)

lazy val archiveJS  = archive.js
lazy val archiveJVM = archive.jvm

lazy val estimates =
  crossProject(JSPlatform, JVMPlatform)
    .crossType(CrossType.Full)
    .in(file("modules/estimates"))
    .dependsOn(archive, image)
    .settings(commonSettings)
    .settings(name := "scalafim-estimates")
    .jsSettings(jsSettingsBase)

lazy val estimatesJS = estimates.js
lazy val estimatesJVM = estimates.jvm

lazy val estimatesIo =
  crossProject(JSPlatform, JVMPlatform)
    .crossType(CrossType.Full)
    .in(file("modules/estimates-io"))
    .dependsOn(estimates)
    .settings(commonSettings)
    .settings(
      name := "scalafim-estimates-io",
      libraryDependencies += "com.lihaoyi" %%% "upickle" % "4.1.0"
    )
    .jsSettings(jsSettingsBase)

lazy val estimatesIoJS = estimatesIo.js
lazy val estimatesIoJVM = estimatesIo.jvm

lazy val fitEstimates =
  crossProject(JSPlatform, JVMPlatform)
    .crossType(CrossType.Full)
    .in(file("modules/fit-estimates"))
    .dependsOn(fit, estimates, group % "compile->compile;test->test", estimatesIo % "test->compile")
    .settings(commonSettings)
    .settings(name := "scalafim-fit-estimates")
    .jsSettings(jsSettingsBase)

lazy val fitEstimatesJS = fitEstimates.js
lazy val fitEstimatesJVM = fitEstimates.jvm

lazy val archiveLna =
  crossProject(JSPlatform, JVMPlatform)
    .crossType(CrossType.Full)
    .in(file("modules/archive-lna"))
    .dependsOn(archive, image)
    .settings(commonSettings)
    .settings(
      name := "scalafim-archive-lna"
    )
    .jvmConfigure(_.dependsOn(galeCoreJVM))
    .jsConfigure(_.dependsOn(galeCoreJS))
    .jvmSettings(
      libraryDependencies += "io.jhdf" % "jhdf" % jhdfVersion
    )
    .jsSettings(jsSettingsBase)

lazy val archiveLnaJS  = archiveLna.js
lazy val archiveLnaJVM = archiveLna.jvm

lazy val archivedResponseInterop =
  crossProject(JSPlatform, JVMPlatform)
    .crossType(CrossType.Full)
    .in(file("modules/interop-archived-response"))
    .dependsOn(
      response,
      responseLaws % "test->compile",
      latent % "compile->compile;test->test",
      archive,
      archiveLna % "compile->compile;test->test",
      archiveZarr % "compile->compile;test->test",
      dataset % "compile->compile;test->test"
    )
    .settings(commonSettings)
    .settings(
      name := "scalafim-interop-archived-response",
      Test / unmanagedSources += file(
        "modules/latent/shared/src/test/scala/scalafim/latent/" +
          "ResponseArchiveMigrationBaselineSuite.scala"
      )
    )
    .jvmConfigure(_.dependsOn(galeCoreJVM, bids4sJVM, zarr4sCoreJVM))
    .jsConfigure(_.dependsOn(galeCoreJS, zarr4sCoreJS))
    .jsSettings(jsSettingsBase)

lazy val archivedResponseInteropJS  = archivedResponseInterop.js
lazy val archivedResponseInteropJVM = archivedResponseInterop.jvm

lazy val dataset =
  crossProject(JSPlatform, JVMPlatform)
    .crossType(CrossType.Full)
    .in(file("modules/dataset"))
    .dependsOn(
      response,
      responseLaws % "test->compile",
      image,
      hrf,
      locusData
    )
    .settings(commonSettings)
    .settings(
      name := "scalafim-dataset",
      libraryDependencies ++= Seq(
      )
    )
    .jvmConfigure(_.dependsOn(galeCoreJVM))
    .jsConfigure(_.dependsOn(galeCoreJS))
    .jsSettings(jsSettingsBase)

lazy val datasetJS  = dataset.js
lazy val datasetJVM = dataset.jvm

lazy val model =
  crossProject(JSPlatform, JVMPlatform)
    .crossType(CrossType.Full)
    .in(file("modules/model"))
    .dependsOn(design, dataset)
    .settings(commonSettings)
    .settings(strictFirstLevelCompilerSettings)
    .settings(
      name := "scalafim-fmri-model"
    )
    .jvmConfigure(_.dependsOn(galeCoreJVM))
    .jvmSettings(scientificCoverageSettings(statementMinimum = 58.0, branchMinimum = 52.0))
    .jsConfigure(_.dependsOn(galeCoreJS))
    .jsSettings(jsSettingsBase)

lazy val modelJS  = model.js
lazy val modelJVM = model.jvm

lazy val fit =
  crossProject(JSPlatform, JVMPlatform)
    .crossType(CrossType.Full)
    .in(file("modules/fit"))
    .dependsOn(model, ar, pipeline % "test->compile", scenarioTestkit % "test->compile")
    .settings(commonSettings)
    .settings(strictFirstLevelCompilerSettings)
    .settings(
      name := "scalafim-fmri-fit"
    )
    .jvmConfigure(_.dependsOn(galeCoreJVM))
    .jvmSettings(scientificCoverageSettings(statementMinimum = 75.0, branchMinimum = 62.0))
    .jsConfigure(_.dependsOn(galeCoreJS))
    .jsSettings(jsSettingsBase)

lazy val fitJS  = fit.js
lazy val fitJVM = fit.jvm

lazy val fitBenchJVM =
  project
    .in(file("benchmarks/fit-jvm"))
    .dependsOn(fitJVM)
    .enablePlugins(JmhPlugin)
    .settings(commonSettings)
    .settings(strictFirstLevelCompilerSettings)
    .settings(
      name := "scalafim-fit-benchmarks",
      publish / skip := true
    )

// Cross-built generated-law court for the complete public first-level stack.
// It is deliberately non-published: generated evidence belongs beside the
// production modules, without making property-testing part of their API.
lazy val firstLevelLaws =
  crossProject(JSPlatform, JVMPlatform)
    .crossType(CrossType.Full)
    .in(file("modules/first-level-laws"))
    .dependsOn(fit, hrfLaws)
    .settings(commonSettings)
    .settings(strictFirstLevelCompilerSettings)
    .settings(
      name := "scalafim-fmri-first-level-laws",
      publish / skip := true,
      libraryDependencies += "org.scalameta" %%% "munit-scalacheck" % "1.1.0" % Test
    )
    .jsSettings(jsSettingsBase)

lazy val firstLevelLawsJS  = firstLevelLaws.js
lazy val firstLevelLawsJVM = firstLevelLaws.jvm

lazy val mvpa =
  crossProject(JSPlatform, JVMPlatform)
    .crossType(CrossType.Full)
    .in(file("modules/mvpa"))
    .settings(commonSettings)
    .settings(
      name := "scalafim-fmri-mvpa"
    )
    .jvmConfigure(_.dependsOn(galeCoreJVM))
    .jsConfigure(_.dependsOn(galeCoreJS))
    .jsSettings(jsSettingsBase)

lazy val mvpaJS  = mvpa.js
lazy val mvpaJVM = mvpa.jvm

lazy val mvpaFit =
  crossProject(JSPlatform, JVMPlatform)
    .crossType(CrossType.Full)
    .in(file("modules/mvpa-fit"))
    .dependsOn(fit, mvpa)
    .settings(commonSettings)
    .settings(
      name := "scalafim-fmri-mvpa-fit"
    )
    .jvmConfigure(
      _.dependsOn(
        galeCoreJVM,
        multivarJVM % "compile->compile;test->test"
      )
    )
    .jsConfigure(
      _.dependsOn(
        galeCoreJS,
        multivarJS % "compile->compile;test->test"
      )
    )
    .jsSettings(jsSettingsBase)

lazy val mvpaFitJS  = mvpaFit.js
lazy val mvpaFitJVM = mvpaFit.jvm

lazy val connectivity =
  crossProject(JSPlatform, JVMPlatform)
    .crossType(CrossType.Full)
    .in(file("modules/connectivity"))
    .dependsOn(locusData)
    .settings(commonSettings)
    .settings(
      name := "scalafim-connectivity"
    )
    .jvmConfigure(_.dependsOn(galeCoreJVM, graph4sCoreJVM))
    .jsConfigure(_.dependsOn(galeCoreJS, graph4sCoreJS))
    .jsSettings(jsSettingsBase)

lazy val connectivityJS  = connectivity.js
lazy val connectivityJVM = connectivity.jvm


lazy val atlasWorkflows =
  crossProject(JSPlatform, JVMPlatform)
    .crossType(CrossType.Full)
    .in(file("modules/atlas-workflows"))
    .dependsOn(atlas, connectivity)
    .settings(commonSettings)
    .settings(name := "scalafim-atlas-workflows")
    .jsSettings(jsSettingsBase)

lazy val atlasWorkflowsJS = atlasWorkflows.js
lazy val atlasWorkflowsJVM = atlasWorkflows.jvm

lazy val surfaceViewConnectivity =
  crossProject(JSPlatform, JVMPlatform)
    .crossType(CrossType.Full)
    .in(file("modules/surface-view-connectivity"))
    .dependsOn(surfaceView, connectivity)
    .settings(commonSettings)
    .settings(
      name := "scalafim-surface-view-connectivity"
    )
    .jsSettings(jsSettingsBase)

lazy val surfaceViewConnectivityJS  = surfaceViewConnectivity.js
lazy val surfaceViewConnectivityJVM = surfaceViewConnectivity.jvm

lazy val mvpaDataset =
  crossProject(JSPlatform, JVMPlatform)
    .crossType(CrossType.Full)
    .in(file("modules/mvpa-dataset"))
    .dependsOn(mvpa, dataset)
    .settings(commonSettings)
    .settings(
      name := "scalafim-fmri-mvpa-dataset"
    )
    .jsSettings(jsSettingsBase)

lazy val mvpaDatasetJS  = mvpaDataset.js
lazy val mvpaDatasetJVM = mvpaDataset.jvm

lazy val mvpaSpatial =
  crossProject(JSPlatform, JVMPlatform)
    .crossType(CrossType.Full)
    .in(file("modules/mvpa-spatial"))
    .dependsOn(mvpa, image, surface, atlas, locusData)
    .settings(commonSettings)
    .settings(
      name := "scalafim-fmri-mvpa-spatial"
    )
    .jsSettings(jsSettingsBase)

lazy val mvpaSpatialJS  = mvpaSpatial.js
lazy val mvpaSpatialJVM = mvpaSpatial.jvm

/** Unpublished M0 admission court for the provider graph and typed-axis laws.
  * Production APIs begin in M1; this module prevents the admitted provider
  * closure from drifting while those laws migrate to their permanent homes.
  */
lazy val mvpaFoundationAdmission =
  crossProject(JSPlatform, JVMPlatform)
    .crossType(CrossType.Full)
    .in(file("modules/mvpa-foundation-spike"))
    .dependsOn(response, locusData)
    .settings(commonSettings)
    .settings(
      name := "scalafim-mvpa-foundation-admission",
      publish / skip := true,
      scalacOptions += "-Werror",
      libraryDependencies ++= Seq(
        "org.scalameta" %%% "munit"       % "1.3.4" % Test,
        "org.typelevel" %%% "cats-core"   % "2.12.0" % Test,
        "org.typelevel" %%% "cats-effect" % "3.5.4" % Test
      )
    )
    .jvmConfigure(
      _.dependsOn(
        multivarJVM,
        alderKernelJVM,
        alderDataJVM,
        resample4sCoreJVM,
        resample4sDesignsJVM
      )
    )
    .jsConfigure(
      _.dependsOn(
        multivarJS,
        alderKernelJS,
        alderDataJS,
        resample4sCoreJS,
        resample4sDesignsJS
      )
    )
    .jsSettings(jsSettingsBase)

lazy val mvpaFoundationAdmissionJS  = mvpaFoundationAdmission.js
lazy val mvpaFoundationAdmissionJVM = mvpaFoundationAdmission.jvm

lazy val group =
  crossProject(JSPlatform, JVMPlatform)
    .crossType(CrossType.Full)
    .in(file("modules/group"))
    .dependsOn(image, dataset, design, estimates)
    .settings(commonSettings)
    .settings(
      name := "scalafim-fmri-group"
    )
    .jvmConfigure(_.dependsOn(galeCoreJVM))
    .jsConfigure(_.dependsOn(galeCoreJS))
    .jsSettings(jsSettingsBase)

lazy val groupJS  = group.js
lazy val groupJVM = group.jvm

lazy val fmriWorkflow =
  crossProject(JSPlatform, JVMPlatform)
    .crossType(CrossType.Full)
    .in(file("modules/fmri-workflow"))
    .dependsOn(dataset, model, fit, group)
    .settings(commonSettings)
    .settings(
      name := "scalafim-fmri-workflow"
    )
    .jvmConfigure(_.dependsOn(galeCoreJVM, bids4sJVM))
    .jsConfigure(_.dependsOn(galeCoreJS, bids4sJS))
    .jsSettings(jsSettingsBase)

lazy val fmriWorkflowJS  = fmriWorkflow.js
lazy val fmriWorkflowJVM = fmriWorkflow.jvm

lazy val archiveZarr =
  crossProject(JSPlatform, JVMPlatform)
    .crossType(CrossType.Full)
    .in(file("modules/archive-zarr"))
    .dependsOn(archive)
    .settings(commonSettings)
    .settings(
      name := "scalafim-archive-zarr",
      libraryDependencies ++= Seq(
        "org.typelevel" %%% "cats-core"   % "2.12.0",
        "org.typelevel" %%% "cats-effect" % "3.5.4"
      )
    )
    .jvmConfigure(_.dependsOn(zarr4sCoreJVM))
    .jsConfigure(_.dependsOn(zarr4sCoreJS))
    .jsSettings(jsSettingsBase)

lazy val archiveZarrJS  = archiveZarr.js
lazy val archiveZarrJVM = archiveZarr.jvm

lazy val datasetZarr =
  crossProject(JSPlatform, JVMPlatform)
    .crossType(CrossType.Full)
    .in(file("modules/dataset-zarr"))
    .dependsOn(dataset, archiveZarr, image, fit % "test->compile")
    .settings(commonSettings)
    .settings(
      name := "scalafim-dataset-zarr"
    )
    .jvmConfigure(_.dependsOn(galeCoreJVM, bids4sJVM, zarr4sCoreJVM))
    .jsConfigure(_.dependsOn(galeCoreJS, bids4sJS, zarr4sCoreJS))
    .jsSettings(jsSettingsBase)

lazy val datasetZarrJS  = datasetZarr.js
lazy val datasetZarrJVM = datasetZarr.jvm

lazy val root =
  project
    .in(file("."))
    .aggregate(
      locusDataJS,
      locusDataJVM,
      pipelineJS,
      pipelineJVM,
      responseJS,
      responseJVM,
      responseLawsJS,
      responseLawsJVM,
      latentJS,
      latentJVM,
      arJS,
      arJVM,
      hrfJS,
      hrfJVM,
      hrfLawsJS,
      hrfLawsJVM,
      scenarioTestkitJS,
      scenarioTestkitJVM,
      designJS,
      designJVM,
      imageJS,
      imageJVM,
      providerSpikeJS,
      providerSpikeJVM,
      imageViewJS,
      imageViewJVM,
      imageViewCanvasJS,
      imageViewJava2dJVM,
      imageViewJavafxJVM,
      thresholdJS,
      thresholdJVM,
      motionJS,
      motionJVM,
      surfaceJS,
      surfaceJVM,
      surfaceViewJS,
      surfaceViewJVM,
      surfaceViewRasterJS,
      surfaceViewRasterJVM,
      surfaceViewJavafxJVM,
      surfaceViewThreeJS,
      surfaceViewExamplesJS,
      surfaceViewExamplesJVM,
      transformJS,
      transformJVM,
      spatialJS,
      spatialJVM,
      atlasJS,
      atlasJVM,
      archiveJS,
      archiveJVM,
      estimatesJS,
      estimatesJVM,
      estimatesIoJS,
      estimatesIoJVM,
      fitEstimatesJS,
      fitEstimatesJVM,
      archiveLnaJS,
      archiveLnaJVM,
      archivedResponseInteropJS,
      archivedResponseInteropJVM,
      datasetJS,
      datasetJVM,
      modelJS,
      modelJVM,
      fitJS,
      fitJVM,
      firstLevelLawsJS,
      firstLevelLawsJVM,
      mvpaJS,
      mvpaJVM,
      mvpaFitJS,
      mvpaFitJVM,
      connectivityJS,
      connectivityJVM,
      atlasWorkflowsJS,
      atlasWorkflowsJVM,
      surfaceViewConnectivityJS,
      surfaceViewConnectivityJVM,
      mvpaDatasetJS,
      mvpaDatasetJVM,
      mvpaSpatialJS,
      mvpaSpatialJVM,
      mvpaFoundationAdmissionJS,
      mvpaFoundationAdmissionJVM,
      surfaceExamplesJVM,
      atlasExamplesJVM,
      workflowExamplesJVM,
      groupJS,
      groupJVM,
      fmriWorkflowJS,
      fmriWorkflowJVM,
      archiveZarrJS,
      archiveZarrJVM,
      datasetZarrJS,
      datasetZarrJVM
    )
    .settings(
      name := "scalafim",
      publish / skip := true
    )

addCommandAlias("scalafimCompileAll", ";locusDataJVM/compile;locusDataJS/compile;pipelineJVM/compile;pipelineJS/compile;responseJVM/compile;responseJS/compile;responseLawsJVM/compile;responseLawsJS/compile;latentJVM/compile;latentJS/compile;arJVM/compile;arJS/compile;hrfJVM/compile;hrfJS/compile;hrfLawsJVM/compile;hrfLawsJS/compile;scenarioTestkitJVM/compile;scenarioTestkitJS/compile;designJVM/compile;designJS/compile;imageJVM/compile;imageJS/compile;providerSpikeJVM/compile;providerSpikeJS/compile;imageViewJVM/compile;imageViewJS/compile;imageViewCanvasJS/compile;imageViewJava2dJVM/compile;imageViewJavafxJVM/compile;thresholdJVM/compile;thresholdJS/compile;motionJVM/compile;motionJS/compile;surfaceJVM/compile;surfaceJS/compile;surfaceViewJVM/compile;surfaceViewJS/compile;surfaceViewRasterJVM/compile;surfaceViewRasterJS/compile;surfaceViewJavafxJVM/compile;surfaceViewThreeJS/compile;surfaceViewConnectivityJVM/compile;surfaceViewConnectivityJS/compile;surfaceViewExamplesJVM/compile;surfaceViewExamplesJS/compile;transformJVM/compile;transformJS/compile;spatialJVM/compile;spatialJS/compile;atlasJVM/compile;atlasJS/compile;archiveJVM/compile;archiveJS/compile;estimatesJVM/compile;estimatesJS/compile;estimatesIoJVM/compile;estimatesIoJS/compile;fitEstimatesJVM/compile;fitEstimatesJS/compile;archiveLnaJVM/compile;archiveLnaJS/compile;archivedResponseInteropJVM/compile;archivedResponseInteropJS/compile;datasetJVM/compile;datasetJS/compile;modelJVM/compile;modelJS/compile;fitJVM/compile;fitJS/compile;firstLevelLawsJVM/compile;firstLevelLawsJS/compile;mvpaJVM/compile;mvpaJS/compile;mvpaFitJVM/compile;mvpaFitJS/compile;connectivityJVM/compile;connectivityJS/compile;atlasWorkflowsJVM/compile;atlasWorkflowsJS/compile;mvpaDatasetJVM/compile;mvpaDatasetJS/compile;mvpaSpatialJVM/compile;mvpaSpatialJS/compile;mvpaFoundationAdmissionJVM/compile;mvpaFoundationAdmissionJS/compile;groupJVM/compile;groupJS/compile;fmriWorkflowJVM/compile;fmriWorkflowJS/compile;archiveZarrJVM/compile;archiveZarrJS/compile;datasetZarrJVM/compile;datasetZarrJS/compile")
addCommandAlias("scalafimTestAll", ";locusDataJVM/test;locusDataJS/test;pipelineJVM/test;pipelineJS/test;responseJVM/test;responseJS/test;responseLawsJVM/test;responseLawsJS/test;latentJVM/test;latentJS/test;arJVM/test;arJS/test;hrfJVM/test;hrfJS/test;hrfLawsJVM/test;hrfLawsJS/test;scenarioTestkitJVM/test;scenarioTestkitJS/test;designJVM/test;designJS/test;imageJVM/test;imageJS/test;providerSpikeJVM/test;providerSpikeJS/test;imageViewJVM/test;imageViewJS/test;imageViewCanvasJS/test;imageViewJava2dJVM/test;imageViewJavafxJVM/test;thresholdJVM/test;thresholdJS/test;motionJVM/test;motionJS/test;surfaceJVM/test;surfaceJS/test;surfaceViewJVM/test;surfaceViewJS/test;surfaceViewRasterJVM/test;surfaceViewRasterJS/test;surfaceViewJavafxJVM/test;surfaceViewThreeJS/test;surfaceViewConnectivityJVM/test;surfaceViewConnectivityJS/test;surfaceViewExamplesJVM/test;surfaceViewExamplesJS/test;transformJVM/test;transformJS/test;spatialJVM/test;spatialJS/test;atlasJVM/test;atlasJS/test;archiveJVM/test;archiveJS/test;estimatesJVM/test;estimatesJS/test;estimatesIoJVM/test;estimatesIoJS/test;fitEstimatesJVM/test;fitEstimatesJS/test;archiveLnaJVM/test;archiveLnaJS/test;archivedResponseInteropJVM/test;archivedResponseInteropJS/test;datasetJVM/test;datasetJS/test;modelJVM/test;modelJS/test;fitJVM/test;fitJS/test;firstLevelLawsJVM/test;firstLevelLawsJS/test;mvpaJVM/test;mvpaJS/test;mvpaFitJVM/test;mvpaFitJS/test;connectivityJVM/test;connectivityJS/test;atlasWorkflowsJVM/test;atlasWorkflowsJS/test;mvpaDatasetJVM/test;mvpaDatasetJS/test;mvpaSpatialJVM/test;mvpaSpatialJS/test;mvpaFoundationAdmissionJVM/test;mvpaFoundationAdmissionJS/test;groupJVM/test;groupJS/test;fmriWorkflowJVM/test;fmriWorkflowJS/test;archiveZarrJVM/test;archiveZarrJS/test;datasetZarrJVM/test;datasetZarrJS/test")
addCommandAlias("compileAll", "scalafimCompileAll")
addCommandAlias("testAll", "scalafimTestAll")
addCommandAlias("examplesCompile", ";surfaceExamplesJVM/compile;surfaceViewExamplesJVM/compile;surfaceViewExamplesJS/compile;atlasExamplesJVM/compile;workflowExamplesJVM/compile")
addCommandAlias("examplesTest", ";surfaceExamplesJVM/test;surfaceViewExamplesJVM/test;surfaceViewExamplesJS/test;atlasExamplesJVM/test;workflowExamplesJVM/test")
addCommandAlias("surfaceViewConformance", ";surfaceJVM/test;surfaceJS/test;surfaceViewJVM/test;surfaceViewJS/test;surfaceViewRasterJVM/test;surfaceViewRasterJS/test;surfaceViewJavafxJVM/test;surfaceViewThreeJS/test;surfaceViewConnectivityJVM/test;surfaceViewConnectivityJS/test")
addCommandAlias("surfaceViewAdmissionJVM", ";surfaceViewRasterJVM/runMain scalafim.surface.view.raster.SurfaceRasterAdmissionBenchmark;surfaceViewJavafxJVM/Test/runMain scalafim.surface.view.javafx.JavaFxSurfaceAdmissionBenchmark")
addCommandAlias("surfaceViewVisualQaJVM", ";surfaceViewExamplesJVM/Test/runMain scalafim.surface.view.javafx.JavaFxGiftiParityProbe;surfaceViewJavafxJVM/Test/runMain scalafim.surface.view.javafx.JavaFxSurfaceCorrectnessProbe;surfaceViewJavafxJVM/Test/runMain scalafim.surface.view.javafx.JavaFxSurfaceInteractionProbe")
addCommandAlias("atlasCoverage", ";set atlasJVM / coverageEnabled := true;atlasJVM/test;atlasJVM/coverageReport;set atlasJVM / coverageEnabled := false")

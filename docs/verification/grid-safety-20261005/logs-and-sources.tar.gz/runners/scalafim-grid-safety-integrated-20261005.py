from pathlib import Path
import subprocess,os,re,json,time
root=Path('/Users/bbuchsbaum/code/scala/scalafim')
logs=Path('/private/tmp/scalafim-grid-safety-integrated-20261005')
logs.mkdir(exist_ok=True)
env=dict(os.environ,COURSIER_REPOSITORIES='https://repo.maven.apache.org/maven2')
results=[]
gates=[('hrf-design',['hrfJVM/test','hrfJS/test','designJVM/test','designJS/test']),
 ('fit',['fitJVM/test','fitJS/test']),
 ('admission-consumers',['firstLevelLawsJVM/testOnly scalafim.fmri.laws.profile.ObservedFamilyAdmissionSuite','firstLevelLawsJS/testOnly scalafim.fmri.laws.profile.ObservedFamilyAdmissionSuite'])]
allowed="[warn] multiple main classes detected: run 'show discoveredMainClasses' to see the list"
for label,tasks in gates:
 command=['python3','tools/build/sbt-warm',*tasks]
 start=time.monotonic()
 with (logs/(label+'.log')).open('w') as out:
  result=subprocess.run(command,cwd=root,env=env,stdout=out,stderr=subprocess.STDOUT)
 content=(logs/(label+'.log')).read_text()
 counts=[dict(total=int(m[0]),failed=int(m[1]),errors=int(m[2]),passed=int(m[3]))
  for m in re.findall(r'(?:Passed|Failed): Total (\d+), Failed (\d+), Errors (\d+), Passed (\d+)',content)]
 warnings=[line for line in content.splitlines() if line.startswith('[warn]')]
 row=dict(label=label,command=command,exit_code=result.returncode,seconds=round(time.monotonic()-start,3),counts=counts,
  compiler_warnings=[line for line in warnings if line!=allowed],sbt_diagnostics=[line for line in warnings if line==allowed])
 results.append(row)
 (logs/'runs.json').write_text(json.dumps(results,indent=2)+'\n')
 print(json.dumps(row),flush=True)
 if result.returncode: raise SystemExit(result.returncode)
 assert len(counts)==len(tasks),label
 assert all(c['failed']==0 and c['errors']==0 and c['passed']>0 for c in counts),label
 assert not row['compiler_warnings'],label
print('All integrated JVM/JS gates passed, no compiler warnings.',flush=True)

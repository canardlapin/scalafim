from pathlib import Path
import hashlib, json, re, subprocess, time, platform
source = Path('modules/fit/shared/src/main/scala/scalafim/fmri/fit/ResultArtifacts.scala')
folder = Path('docs/verification/export-allocation-20261005')
original = source.read_bytes()
needle = b'result.runs.map(_.voxelStatuses.fold(VoxelFitStatus.Estimable)(_(position)))'
replacement = b'result.runs.map(_.resolvedVoxelStatuses(position))'
assert original.count(needle) == 1
records = []
def run(label, commands):
    args = ['python3', 'tools/build/sbt-warm', *commands]
    started = time.monotonic()
    with (folder / (label + '.log')).open('w') as output:
        result = subprocess.run(args, stdout=output, stderr=subprocess.STDOUT)
    records.append({'label': label, 'command': args, 'exit_code': result.returncode, 'elapsed_seconds': round(time.monotonic() - started, 3)})
    print(json.dumps(records[-1]), flush=True)
    return result.returncode
try:
    source.write_bytes(original.replace(needle, replacement))
    mutation_exit = run('mutation', ['fitJVM/testOnly scalafim.fmri.fit.ResultArtifactsAllocationSuite'])
finally:
    source.write_bytes(original)
assert source.read_bytes() == original
mutation_log = (folder / 'mutation.log').read_text()
assert mutation_exit != 0
for label in ('runwise', 'patterned'):
    assert label + ' export of 4096 voxels allocated' in mutation_log, mutation_log[-6000:]
restored_exit = run('restored', ['fitJVM/testOnly scalafim.fmri.fit.ResultArtifactsSuite scalafim.fmri.fit.ResultArtifactsAllocationSuite', 'fitJS/testOnly scalafim.fmri.fit.ResultArtifactsSuite'])
assert restored_exit == 0
allocations = {}
for label in ('focused', 'mutation', 'restored'):
    allocations[label] = [{'kind': kind, 'voxels': int(voxels), 'bytes': int(count)} for kind, voxels, count in re.findall(r'EXPORT_ALLOCATION kind=(\w+) voxels=(\d+) bytes=(\d+)', (folder / (label + '.log')).read_text())]
receipt = {'mote': 'bd-01M43ZTQCPH834TY936D7YYGKD', 'date': '2026-10-05', 'scope': 'Complete StatMap construction including AnalysisProvenance.fromResult, source identity/status records, payload and selected-axis validation; input fit fixtures are prepared before measurement.', 'platform': platform.system() + ' ' + platform.machine(), 'toolchain': {'jdk': 'Temurin 21.0.12.1', 'sbt': '1.11.7', 'scala': '3.7.4'}, 'mutation': {'description': 'Restore resolvedVoxelStatuses(position) expansion in the shared runwise status producer used by runwise and patterned provenance.', 'from': needle.decode(), 'to': replacement.decode(), 'restored_source_sha256': hashlib.sha256(source.read_bytes()).hexdigest(), 'both_whole_export_regressions_rejected_mutation': True}, 'commands': records, 'allocations': allocations, 'limitations': ['JVM allocation counters require a supported ThreadMXBean; the allocation suite assumes this capability and skips on unsupported runtimes.', 'Allocation measurements use two status-free runs and 1024/4096 voxels; they are regression evidence, not general runtime or throughput benchmarks.'], 'combined_fit_gates': 'Parent will record full fit JVM/JS gate after integrating parallel work.'}
(folder / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'restored': True, 'allocations': allocations}), flush=True)

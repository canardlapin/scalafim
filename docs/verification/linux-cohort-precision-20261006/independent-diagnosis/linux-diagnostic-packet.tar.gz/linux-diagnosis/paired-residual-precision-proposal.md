# Bounded paired residual comparison proposal

Status: design and diagnostic reference only. No production decoder policy change.
Baseline: 37a84e990e6e28d1a00cbf6d1be841c56691564c. Admission remains at least
22 of24; latency .02, relative amplitude .002 and relative SD .05 unchanged;
6 Newton steps, 8 jets, 2 exact evaluations, 90 bank scores, raw correction1e-9 unchanged.

## Observed distinction

DarwinJVM observations refused voxels2 and15; matching Node24.21 observations
refused4 and15. Their reported scalar energy changes were uphill by1–3ULP.
MP comparisons of exact captured binary64 designs and actual returned beta find
JVM2/JVM15/JS4 genuinely downhill. JS15 is genuinely uphill by3.43976221594476e-18
for those stored models, although analytic Gaussian MP evaluation descends.
A stored-model comparator must reject JS15; this slice does not repair kernel
evaluation or reinstate the archived sqrt(tolerance)/energy-ULP policy.

The earlier unobserved JVM admitted24; the diagnostic JVM admitted22. Additional
observational evaluation/logging/JIT scheduling is not a proof of whole-cohort
nonperturbation. Refused-voxel observational decoder replays produced identical
full results and separate counter receipts. Linux needs separate untouched
baseline and diagnostic artifacts.

## Minimal upstream Gale capability

A generic `gale.numeric` capability accepts one response z, previous/candidate
row-major real-double designs D0/D1, and actual returned beta0/beta1. Shared
additive energy offsets are absent from the API and cancel algebraically.
Use typed errors for shape mismatch/nonfinite/overflow, and conservative
`Unresolved` for bounds that cannot establish a sign or positive Gram lower bound.
A reusable workspace plus primitive output buffer can keep interval arithmetic
allocation-free; validate dimensions/products before workspace allocation.

Return/report:

- An outward enclosure of the actual returned-model squared residual difference.
- A proven previous-Gram eigenvalue lower bound, if available.
- A conservative previous-amplitude suboptimality upper bound.
- A profile-difference upper bound or explicit unavailable reason.

Every binary64 +, -, *, / result must be outward enclosed, including zero and
subnormal cases. Finite-input overflow and unbounded endpoints are unresolved;
never assert a sign from NaN or an infinite enclosure. Generic interval/norm
math belongs upstream, with JVM and Scala.js fixtures and independent MP references.

### Stable difference

For r0=z−D0 beta0, deltaBeta=beta1−beta0, deltaD=D1−D0:

    deltaPredictor = deltaD beta1 + D0 deltaBeta
    modelDifference = sum(deltaPredictor * (deltaPredictor − 2 r0))

Form the small matrix/coefficient differences before summation. Subtracting two
independently rounded large predictions can introduce error larger than the
terminal decrease. The reference `certify-paired-rss.py` encloses all operations.
Its endpoints contain the independently recomputed100-digit MP difference.

### Profile minimum guard

A decrease in returned models alone does not prove a decrease in profiled minima
when previous beta is inaccurate. For G0=D0' D0 and q0=D0' r0:

    oldGap = q0' inverse(G0) q0
    oldGap <= upper(||q0||^2) / lower(lambdaMin(G0))
    newProfileMinimum − oldProfileMinimum <= modelDifferenceUpper + oldGapUpper

Obtain a conservative eigenvalue lower bound without a new eigensolver using
interval Gershgorin rows: diagonalLower − sum(maxAbs(offDiagonalEndpoints)).
If any necessary bound is unavailable/nonpositive, profile decrease is unresolved.
Certify profile decrease only when its final outward upper bound is strictly negative.

## Compact-condition adapter and decoder use

Only the explicit frozen-response compact condition backend opts into the
capability. It owns the geometry-response identity, unnormalised design/beta
units, cached accepted D0/beta0 and candidate D1/beta1. Cache the initial bank
point and every accepted point before later callbacks overwrite reusable arrays.
Coordinates, design, beta and full jet must describe the same point/voxel.
Clear caches across response changes; copied/aliased caller buffers cannot
retroactively change the accepted state. Do not reconstruct an old design by
uncounted kernel evaluation. Workspace/cached array sizes are admitted and
reported at preparation.

The repair is attempted only for a blocked scalar candidate comparison when:

1. The candidate already has a successful finite coherent full jet.
2. Existing prior-augmented free Newton correction is at most1e-9 and curvature
   is positive; all later boundary/identification/ambiguity gates stay in force.
3. The original exact-evaluation quota has room. Reserve and charge one exact
   comparison before invoking the capability; no uncounted retries or extra jets.
4. The capability proves profile decrease with a strictly negative upper bound.

Then commit the candidate coordinates, energy, amplitudes and both Hessians from
that coherent full jet. Rejection/unresolved/error changes no accepted state,
and ordinary halving/quota exits remain. Unrepresentable proposals still stall.
Energy-only candidates cannot use stale derivatives for this path. If a remaining
jet is needed, it must use the existing terminal-verification reserve and quota.

Unsupported ShapeObjective callbacks retain the existing scalar behavior. An
arbitrary scripted higher-value/stationary callback cannot gain admission merely
by presenting derivatives. Comparison evidence must bind the actual backend
criterion and full-jet predictor state; copied, stale or foreign data rejects.

### Priors

First implementation safely leaves every Some(prior) on the existing path. A
future supported prior must outward enclose the paired quadratic energy change
using the exact same mean/precision and augment the data comparison before sign
certification. For symmetric P and delta=theta1−theta0, priorDelta is
delta' P ((theta1−mu)+(theta0−mu)); general P needs both cross terms. No data-only
certificate can authorize an uphill augmented objective. Scalar prior offsets
are excluded/cancelled. Prior matrix validation and coherent augmented jets
remain mandatory.

## Discriminating fixture requirements

- Captured binary64 model/profile descents JVM2/JVM15/JS4 with actual beta arrays;
  interval endpoints must contain the independent MP reference.
- Captured JS15 positive returned-model difference must never certify decrease.
- Old poor beta: z=[1,1], D0=[1,1], beta0=0, D1=[1,0], beta1=1. Model decreases2→1
  but profile minimum increases0→1; the old-gap guard must prevent admission.
- Common additive energy constants of0,1e8,1e16 cannot change comparison truth.
- Positive definite but non-diagonally-dominant Gram[[1,2],[2,5]] has a nonpositive
  Gershgorin bound: return unresolved profile evidence, not a false certificate.
- Exact equality, genuine increase, tiny subnormal changes, overflow/NaN inputs,
  invalid shapes, scaled and coupled columns with explicitly checked ownership.
- Decoder coherent-full-jet vs inconsistent energy/full-jet, unsupported callback,
  nonstationary plateau and boundary/coupled constraints retain existing gates.
- No exact quota, final-jet quota, counted successful/failed comparisons, rejected
  state preservation and deterministic terminal telemetry.
- Some(prior) unsupported initially; future coherent data/prior oppositely signed
  changes prove total augmented descent before admission.

## Qualification boundary

The generic reference/API and domain adapter are separate evidence layers. Linux
Ubuntu24 x64, Node24.21 and the recorded JDK17 runtime must run the unchanged
cohort and all original accuracy/resource assertions. One legitimately rescued
Linux voxel could restore >=22/24; no admission count is assumed before that run.
The remaining rounded-kernel uphill case stays refused. Full affected JVM/JS
regressions and exact source/artifact hashes are required before promotion.

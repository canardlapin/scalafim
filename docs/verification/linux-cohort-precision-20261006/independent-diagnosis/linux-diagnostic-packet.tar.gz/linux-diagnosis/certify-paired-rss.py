#!/usr/bin/env python3
"""Diagnostic outward-rounded binary64 enclosure for paired returned predictors.

Prototype/reference only; a shipping generic kernel belongs upstream in Gale.
Inputs are captured binary64 D/beta/z. No Gaussian/optimizer policy appears here.
"""
import argparse
import importlib.util
import json
import math
from pathlib import Path


def outward(value, positive):
    if not math.isfinite(value):
        raise ValueError("nonfinite interval endpoint")
    return math.nextafter(value, math.inf if positive else -math.inf)


class Interval:
    def __init__(self, low, high=None):
        self.low = float(low)
        self.high = self.low if high is None else float(high)
        if not math.isfinite(self.low) or not math.isfinite(self.high) or self.low > self.high:
            raise ValueError("invalid interval")

    def __add__(self, other):
        return Interval(outward(self.low + other.low, False), outward(self.high + other.high, True))

    def __sub__(self, other):
        return Interval(outward(self.low - other.high, False), outward(self.high - other.low, True))

    def __mul__(self, other):
        products = (self.low * other.low, self.low * other.high, self.high * other.low, self.high * other.high)
        return Interval(outward(min(products), False), outward(max(products), True))


def enclosure(old, new, beta_old, beta_new, response, rows, columns):
    total = Interval(0)
    for row in range(rows):
        predicted_old = Interval(0)
        predicted_delta = Interval(0)
        for column in range(columns):
            index = row * columns + column
            d0, d1 = Interval(old[index]), Interval(new[index])
            b0, b1 = Interval(beta_old[column]), Interval(beta_new[column])
            predicted_old = predicted_old + d0 * b0
            # (D1-D0)beta1 + D0(beta1-beta0) retains small differences.
            predicted_delta = predicted_delta + (d1 - d0) * b1 + d0 * (b1 - b0)
        residual = Interval(response[row]) - predicted_old
        total = total + predicted_delta * (predicted_delta - Interval(2) * residual)
    return total


def old_suboptimality(old, beta_old, response, rows, columns):
    gram = [[Interval(0) for _ in range(columns)] for _ in range(columns)]
    normal = [Interval(0) for _ in range(columns)]
    for row in range(rows):
        residual = Interval(response[row])
        for column in range(columns):
            residual = residual - Interval(old[row * columns + column]) * Interval(beta_old[column])
        for left in range(columns):
            dleft = Interval(old[row * columns + left])
            normal[left] = normal[left] + dleft * residual
            for right in range(columns):
                gram[left][right] = gram[left][right] + dleft * Interval(old[row * columns + right])
    lower = math.inf
    for row in range(columns):
        off_diagonal = Interval(0)
        for column in range(columns):
            if column != row:
                entry = gram[row][column]
                off_diagonal = off_diagonal + Interval(max(abs(entry.low), abs(entry.high)))
        lower = min(lower, (gram[row][row] - off_diagonal).low)
    if lower <= 0:
        return {"gram_eigenvalue_lower": lower, "old_suboptimality_upper": None}
    squared = Interval(0)
    for entry in normal:
        magnitude = Interval(max(abs(entry.low), abs(entry.high)))
        squared = squared + magnitude * magnitude
    bound = outward(squared.high / lower, True)
    return {"gram_eigenvalue_lower": lower, "old_suboptimality_upper": bound}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("log", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    source = Path(__file__).with_name("compact-precision-replay.py")
    spec = importlib.util.spec_from_file_location("replay", source)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    module.mp.mp.dps = 100
    header, _, arrays, points, voxels = module.load(args.log)
    rank, conditions = header["rank"], header["conditions"]
    result = []
    for voxel in voxels:
        if voxel["status"] == "Accepted":
            continue
        index = voxel["voxel"]
        old, new = f"voxel-{index}-terminal", f"voxel-{index}-candidate"
        bound = enclosure(arrays[(old, "design")], arrays[(new, "design")], points[old]["amplitudes"],
                          points[new]["amplitudes"], arrays[(f"voxel-{index}", "response")], rank, conditions)
        # Independent MP residual difference of exact captured binary64 entries.
        response = module.mp.matrix(arrays[(f"voxel-{index}", "response")])
        energy_old = module.fit(module.matrix(arrays[(old, "design")], rank, conditions), response,
                                points[old]["amplitudes"])[0]
        energy_new = module.fit(module.matrix(arrays[(new, "design")], rank, conditions), response,
                                points[new]["amplitudes"])[0]
        exact = energy_new - energy_old
        if not module.mp.mpf(bound.low) <= exact <= module.mp.mpf(bound.high):
            raise ValueError("independent MP reference outside enclosure")
        profile = old_suboptimality(arrays[(old, "design")], points[old]["amplitudes"],
                                   arrays[(f"voxel-{index}", "response")], rank, conditions)
        bias = profile["old_suboptimality_upper"]
        profile_upper = None if bias is None else outward(bound.high + bias, True)
        result.append({"voxel": index, "lower": bound.low, "upper": bound.high,
                       "certified_decrease": bound.high < 0,
                       "certified_increase": bound.low > 0,
                       **profile, "profile_difference_upper": profile_upper,
                       "certified_profile_decrease": profile_upper is not None and profile_upper < 0,
                       "exact_stored_predictor_difference_mp": module.mp.nstr(exact, 60)})
    output = {"status": "diagnostic-prototype", "scope": "Captured returned predictors; no optimizer/admission policy", "results": result}
    args.output.write_text(json.dumps(output, indent=2, sort_keys=True) + "\n")
    print(json.dumps(output, indent=2))


if __name__ == "__main__":
    main()

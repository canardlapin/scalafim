# Compact paired profile descent candidate

Status: local full fit gates passed; native Linux qualification pending; both full first-level runs83/84 with the separate LWU blocker. Source is frozen and uncommitted. No ROOT source, Mote, or public repository writes by this agent.

## Scope

Seven source/test files implement the closed compact-objective capability, owned response and stamped model snapshots, typed optional workspace admission receipt, paid exact-comparison transaction, and narrow route provenance marker. Generic outward interval arithmetic and old-profile-gap certification remain upstream in Gale. The source-only patch excludes build.sbt because the published provider pins were already adopted separately.

The precision path requires no prior, at least three jet evaluations, positive Newton/exact quotas, and raw stationarity tolerance at most 1e-9. Energy-only candidates, arbitrary ShapeObjective callbacks, looser tolerances, and prior-bearing criteria retain scalar behavior. Accepted comparison requires a coherent counted full jet, same response epoch and fixed energy, and a strict Gale profile-decrease certificate. Every invoked comparison charges one existing exact evaluation before invocation; unresolved or numerical failures retain the old accepted state.

No cohort, accuracy, admission, Newton/jet/exact/node quota, or raw step threshold is relaxed. The original compact cohort source hash is 72f99bedd386a9c5721aeb214d08ee429aa3be1d0d92b96233e751f0db24aadb.

## Qualified local gates

- fitJVM/test: 686 passed, zero failed.
- fitJS/test: 629 passed, zero failed, Node24.21.0.
- Focused decoder/tangent/adapter controls: JVM+JS green. The final full fit runs include all 17 new adapter tests.
- Unchanged CompactConditionRuntimeSuite: 3 JVM and 3 JS tests passed; admitted JVM24/24, Darwin JS23/24. Native Linux admission remains a separate required gate.
- Initial two positive fixture assertions correctly failed with a rank-one basis; the corrected fixture requires identifiable rank>=3 and preserves positive-decrease assertions. The initial failed log is retained.

Both final full fit gates are warning-clean. Runs use 4g heap, 2 CPUs, explicit local Gale override, and isolated per-worktree sbt state. The source manifest binds every file. Source-only patch SHA256: 1bc061800cf68844a176fd255acf868af8b9e5bed0c0e2b37c67cf7829ec4ea6.

## Upstream requirement

Generic comparator source is the sealed Gale source-only patch a18e2746e43e0414436d69c23534df74c3220c42d8ab5dc350fd032adc49736c against public Gale54e73f8e. This candidate uses an explicit local checkout override, not an unpublished default dependency pin. Publication and default-pin adoption require the parent workflow after qualification.

## Full first-level JVM result

firstLevelLawsJVM/test completed 83/84 passed, exit1. The sole failure is the unchanged LWU milestone compiler admission:321 samples ×14×9×7 grid nodes ×10 components=2,831,220 training cells exceeds the fixed 2,000,000-cell compiler policy. This happens before basis allocation and before any decoder comparison. All contributing files match base0a99. Gaussian SNR1/.5 accuracy gates pass with98% admission, and the10k-voxel throughput receipt reports98.2% admission. No threshold has been raised or fixture changed to disguise this failure.

## Full first-level JS result

firstLevelLawsJS/test completed83/84 passed, exit1, under Node24.21.0 in1247.8seconds. Sole failure is the same LWU training-cell admission. All other tests passed, including the unchanged compact cohort23/24, gated Gaussian200-voxel cohorts97%/99%, and10k throughput98.3%. Existing multiple-main warning and0.7%GC performance notice were emitted; no production scalac warning. Final explicit isolated --shutdown returned0 and reported no server running.

# Independent compact paired-comparison review

Initial source binding: /private/tmp/scalafim-compact-paired-review-20261006.json, base0a99c49949b1d1f48e1bb53e97acb65745dd2bc7. Read-only review; no source edits or gates by this reviewer. Refreeze remains required after the root-requested fixes.

## Numeric units and criterion

CompactConditionPreparation fixes whitening, nuisance projection and expanded geometry. It computes z=U'wy and e=||wy||²−||qF'wy||². CompactConditionJets forms D(theta)=rHat*(I_C tensor basisCoefficients(theta)), then b=D'z and G=D'D. ProfileReduction emits beta=G^-1b and scalar E=e−b'beta. The matching mathematical least-squares profile min||z−D(theta)beta||² differs by the shape-free constant C=e−||z||². Thus paired stored-model/profile RSS comparison uses the correct response/design units when all input states belong to the same fixed voxel.

The adapter captures valueDesign and ProfileJetBuffer.amplitudes from the successful full jet, before CompactConditionRuntime's final library-normalization division. It does not compare the normalized readout against unnormalized D. Gale certifies actual stored D/beta/y, not a reconstructed analytic refit or independently rounded scalar E.

## Consumption and state

The capability is private and sealed in the same file as the final CompactConditionObjective, so arbitrary ShapeObjective callbacks cannot opt in. Previous/current design and raw coefficients are owned copies; response is owned at pointAt, and responseEpoch invalidates snapshots across voxels. Full-jet coordinates, energy, gradient, Hessian, amplitudes and curvature are compared by raw bits. Energy-only evaluation invalidates full-jet availability. Comparator success requires certifiesProfileDecrease, not only a returned-model decrease. The exact-evaluation slot is charged before comparison, including unresolved/numerical outcomes; no-prior and quota eligibility are checked before opt-in.

The initial frozen source allowed any configured stationarityStepTolerance through candidateStationary. This could extend the new route beyond the declared raw<=1e-9 slice. Root accepted restricting paired eligibility to tolerance<=1e-9 while retaining ordinary scalar behavior for looser custom budgets. Root separately identified resource-receipt admission invariants and same-epoch reentrant family callback hazards requiring evaluation generations/immutable coordinate checks. These fixes belong to the implementing agent; final source must be reviewed after refreeze.

## Qualification boundary

Generic numerical certificates do not establish callback/response binding, prior-augmented objective decrease, evaluation eligibility or whole-cohort admission by themselves. Priors remain unsupported by this slice. The DarwinJVMV15 numeric witness was obtained after quota exhaustion and cannot imply a free decoder rescue. Source-bound JVM/JS regression gates and the unchanged native Linux scientific accuracy/resource court remain separate from this review.

## Final refreeze review

The final manifest's eight source hashes match. The receipt now enforces admitted positive dimensions and checked byte totals. The compact objective invalidates current full-jet stamps on every evaluation, uses evaluation generations plus response epochs, and passes immutable ShapePoint coordinates through family callbacks; reentrant generation/epoch mismatches and changed input coordinates invalidate evidence. Paired eligibility requires no prior, positive exact/Newton quotas, at least three jets and stationarityStepTolerance<=1e-9. Looser custom budgets retain the scalar path.

PaidProfileComparison charges counters before its by-name numeric comparison; the decoder updates local exactUsed from that transaction and commits only a returned certified profile-decrease proof. State copies remain actual raw D/beta in the owned projected response frame. No additional blocking numeric/unit/profile-consumption finding remains. Targeted/full regression and native Linux scientific gates remain the implementing/root agents' qualification work. No edits, tests, publication or Mote mutations were performed by this reviewer.

import org.scalajs.linker.interface.ModuleKind
import sbtcrossproject.CrossPlugin.autoImport.*
import sbtcrossproject.CrossType
import scalajscrossproject.ScalaJSCrossPlugin.autoImport.*
ThisBuild / scalaVersion := "3.7.4"
lazy val provider = uri("https://github.com/canardlapin/neurosurf4s.git#c9b05c72e2e452d66dcff8603ea96f589d3572fd")
lazy val consumer = crossProject(JSPlatform, JVMPlatform).crossType(CrossType.Full).in(file("consumer"))
  .settings(scalacOptions ++= Seq("-deprecation", "-feature", "-unchecked", "-Werror"), Test / fork := false,
    libraryDependencies += "org.scalameta" %%% "munit" % "1.2.1" % Test)
  .jvmConfigure(_.dependsOn(ProjectRef(provider, "routingJVM")))
  .jsConfigure(_.dependsOn(ProjectRef(provider, "routingJS")))
  .jsSettings(scalaJSLinkerConfig ~= (_.withModuleKind(ModuleKind.CommonJSModule)))
lazy val root = project.in(file(".")).aggregate(consumer.jvm, consumer.js)

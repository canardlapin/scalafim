package scalafim.image

import SampleSpaces.*

import image4s.geometry.Affine
import image4s.geometry.D3
import image4s.geometry.Frame
import image4s.geometry.Grid
import ravel.NDArray as RavelArray

import scala.reflect.ClassTag
import ravel.DType

class SliceSamplingSuite extends munit.FunSuite:

  private val Tol = 1e-9

  private def volume[A: ClassTag: DType, Sem](
    dims: SpatialDims,
    affine: Option[Affine[D3]] = None,
    label: String = "test"
  )(f: (Int, Int, Int) => A)(using image4s.ValueSemantics[A, Sem]): SomeNeuroVolume[A, Sem] =
    val values =
      RavelArray.tabulate[A](dims.x, dims.y, dims.z)(f)
    SomeNeuroVolume.unsafeFromRavel[A, Sem](
      values,
      SampleSpaces(dims.toVector, affine = affine),
      label
    )

  private def gridAt(
    space: Grid[? <: Frame[D3], D3],
    anatomicalPlane: AnatomicalPlane,
    cursor: WorldPoint,
    convention: LeftRightConvention = LeftRightConvention.PatientLeftOnLeft
  ): SliceGrid =
    SliceGrid.covering(
      space,
      SlicePlane.canonical(anatomicalPlane, cursor, convention),
      PixelSpacing(1.0, 1.0)
    )

  test("linear slice sampling exactly reproduces an analytic affine field") {
    val dims = SpatialDims(10, 10, 10)
    val source = volume[Double, image4s.Continuous](dims) { (x, y, z) =>
      2.0 * x + 3.0 * y - 4.0 * z + 7.0
    }
    val grid = gridAt(source.grid, AnatomicalPlane.Axial, WorldPoint(0.0, 0.0, 4.25))
    val sampled =
      SlicePlan
        .make(source.grid, grid)
        .sample(source, SliceSampling.Linear())
        .toOption
        .get

    var row = 0
    while row < sampled.dimensions.height do
      var column = 0
      while column < sampled.dimensions.width do
        val voxel = source.grid.worldToVoxel(grid.unsafeWorldAt(column, row)).fold(error => fail(error.message), identity)
        val expected = 2.0 * voxel.x + 3.0 * voxel.y - 4.0 * voxel.z + 7.0
        assertEqualsDouble(sampled(column, row), expected, Tol)
        column += 1
      row += 1
  }

  test("nearest sampling preserves label values and the top-to-bottom row contract") {
    val dims = SpatialDims(10, 10, 10)
    val labels = volume[Int, image4s.Categorical](dims) { (x, y, z) => x + 10 * y + 100 * z }
    val grid = gridAt(labels.grid, AnatomicalPlane.Axial, WorldPoint(0.0, 0.0, 4.4))
    val sampled = SlicePlan.make(labels.grid, grid)
      .sample(labels, SliceSampling.Nearest(-1))
      .toOption
      .get

    assertEquals(sampled(0, 0), 490)
    assertEquals(sampled(9, 0), 499)
    assertEquals(sampled(0, 9), 400)
  }

  test("cubic sampling shares the kernel contract and reproduces a linear field") {
    val dims = SpatialDims(10, 10, 10)
    val source = volume[Double, image4s.Continuous](dims) { (_, _, z) => 5.0 + 2.5 * z }
    val grid = gridAt(source.grid, AnatomicalPlane.Axial, WorldPoint(0.0, 0.0, 4.25))
    val sampled =
      SlicePlan
        .make(source.grid, grid)
        .sample(source, SliceSampling.Cubic())
        .toOption
        .get

    var i = 0
    while i < sampled.values.size do
      assertEqualsDouble(sampled.valueAtCanonicalOrdinal(i), 15.625, Tol)
      i += 1
  }

  test("outside values participate explicitly in interpolation") {
    val dims = SpatialDims(4, 4, 4)
    val source = volume[Double, image4s.Continuous](dims)((_, _, _) => 8.0)
    val nearestGrid = gridAt(source.grid, AnatomicalPlane.Axial, WorldPoint(0.0, 0.0, -2.0))
    val nearest = SlicePlan.make(source.grid, nearestGrid)
      .sample(source, SliceSampling.Nearest(-3.0))
      .toOption
      .get
    assert(
      Vector
        .tabulate(nearest.values.size)(nearest.valueAtCanonicalOrdinal)
        .forall(_ == -3.0)
    )

    val linearGrid = gridAt(source.grid, AnatomicalPlane.Axial, WorldPoint(0.0, 0.0, -0.25))
    val linear = SlicePlan.make(source.grid, linearGrid)
      .sample(source, SliceSampling.Linear(0.0))
      .toOption
      .get
    assertEqualsDouble(linear(1, 1), 6.0, Tol)
  }

  test("validated sampling kernels agree with checked voxel access at every boundary") {
    val dims = SpatialDims(4, 3, 5)
    val source = volume[Double, image4s.Continuous](dims) { (x, y, z) =>
      x.toDouble + 10.0 * y.toDouble + 100.0 * z.toDouble
    }
    val outside = -1234.5

    var z = -1
    while z <= dims.z do
      var y = -1
      while y <= dims.y do
        var x = -1
        while x <= dims.x do
          val expected =
            if x >= 0 && x < dims.x && y >= 0 && y < dims.y && z >= 0 && z < dims.z then
              source(x, y, z)
            else outside
          assertEqualsDouble(
            VoxelSamplingKernel.valueOrOutside(
              source,
              dims,
              x,
              y,
              z,
              outside
            ),
            expected,
            0.0
          )
          assertEqualsDouble(
            VoxelSamplingKernel.nearest(
              source,
              dims,
              x.toDouble,
              y.toDouble,
              z.toDouble,
              outside
            ),
            expected,
            0.0
          )
          x += 1
        y += 1
      z += 1
  }

  test("display mirroring reverses pixels without changing sampled anatomy") {
    val dims = SpatialDims(6, 5, 4)
    val source = volume[Double, image4s.Continuous](dims) { (x, y, z) => x + 10.0 * y + 100.0 * z }
    val cursor = WorldPoint(0.0, 0.0, 2.0)
    val leftGrid = gridAt(
      source.grid,
      AnatomicalPlane.Axial,
      cursor,
      LeftRightConvention.PatientLeftOnLeft
    )
    val rightGrid = gridAt(
      source.grid,
      AnatomicalPlane.Axial,
      cursor,
      LeftRightConvention.PatientRightOnLeft
    )
    val left = SlicePlan.make(source.grid, leftGrid)
      .sample(source, SliceSampling.Nearest(-1.0))
      .toOption
      .get
    val right = SlicePlan.make(source.grid, rightGrid)
      .sample(source, SliceSampling.Nearest(-1.0))
      .toOption
      .get

    var row = 0
    while row < left.dimensions.height do
      var column = 0
      while column < left.dimensions.width do
        assertEqualsDouble(
          left(column, row),
          right(right.dimensions.width - 1 - column, row),
          Tol
        )
        column += 1
      row += 1
  }

  test("affine stepping agrees with direct world-to-voxel conversion") {
    val affine = ProviderSpaces.affine(
      Vector(
        Vector(0.0, -2.0, 0.25, 5.0),
        Vector(1.5, 0.0, 0.10, -4.0),
        Vector(0.0, 0.0, 3.0, 12.0),
        Vector(0.0, 0.0, 0.0, 1.0)
      )
    )
    val source = volume[Double, image4s.Continuous](SpatialDims(8, 7, 6), Some(affine)) { (x, y, z) =>
      x + 10.0 * y + 100.0 * z
    }
    val cursor = source.grid.voxelToWorld(VoxelPoint(3.5, 3.0, 2.5)).fold(error => fail(error.message), identity)
    val grid = SliceGrid.covering(
      source.grid,
      SlicePlane.canonical(AnatomicalPlane.Coronal, cursor),
      PixelSpacing(0.7, 0.9)
    )
    val plan = SlicePlan.make(source.grid, grid)
    val pixels = Vector(
      PixelCoord(0, 0),
      PixelCoord(grid.dimensions.width / 2, grid.dimensions.height / 2),
      PixelCoord(grid.dimensions.width - 1, grid.dimensions.height - 1)
    )

    pixels.foreach { pixel =>
      val direct = source.grid.worldToVoxel(grid.worldAt(pixel).toOption.get).fold(error => fail(error.message), identity)
      val planned = plan.sourceVoxelAt(pixel).toOption.get
      assertEqualsDouble(planned.x, direct.x, Tol)
      assertEqualsDouble(planned.y, direct.y, Tol)
      assertEqualsDouble(planned.z, direct.z, Tol)
    }
  }

  test("plans reject a volume from a different source space") {
    val dims = SpatialDims(3, 3, 3)
    val source = volume[Double, image4s.Continuous](dims)((x, y, z) => x + y + z)
    val shifted = volume[Double, image4s.Continuous](
      dims,
      Some(
        ProviderSpaces.affine(
          Vector(
            Vector(1.0, 0.0, 0.0, 10.0),
            Vector(0.0, 1.0, 0.0, 0.0),
            Vector(0.0, 0.0, 1.0, 0.0),
            Vector(0.0, 0.0, 0.0, 1.0)
          )
        )
      )
    )((x, y, z) => x + y + z)
    val grid = gridAt(source.grid, AnatomicalPlane.Axial, WorldPoint(0.0, 0.0, 1.0))
    val result =
      SlicePlan
        .make(source.grid, grid)
        .sample(shifted, SliceSampling.Linear())

    assert(result.isLeft)
  }

  test("mapped slice plans materialize nonlinear pullback coordinates once") {
    val dims = SpatialDims(5, 3, 1)
    val source = volume[Double, image4s.Continuous](dims) { (x, _, _) => x.toDouble }
    val grid = gridAt(source.grid, AnatomicalPlane.Axial, WorldPoint(0.0, 0.0, 0.0))
    val fieldGrid = GridSpec.fromGrid(source.grid)
    val field =
      RavelArray.tabulate[Double](
        fieldGrid.shape.x,
        fieldGrid.shape.y,
        fieldGrid.shape.z,
        3
      ) { (x, _, _, component) =>
        if component == 0 && x >= 2 then 1.0 else 0.0
      }
    val mapping = SpatialPullbacks.displacement(
      fieldGrid,
      fieldGrid,
      field,
      Resample.Method.Nearest
    ).fold(error => fail(error.message), identity)
    val plan =
      MappedSlicePlan
        .make(source.grid, grid, mapping)
        .fold(error => fail(error.message), identity)
    val sampled =
      plan
        .sample(source, SliceSampling.Nearest(-1.0))
        .toOption
        .get

    assertEqualsDouble(sampled(0, 1), 0.0, Tol)
    assertEqualsDouble(sampled(1, 1), 1.0, Tol)
    assertEqualsDouble(sampled(2, 1), 3.0, Tol)
    assertEqualsDouble(sampled(3, 1), 4.0, Tol)
    assertEqualsDouble(sampled(4, 1), -1.0, Tol)
    assertEquals(plan.sourceVoxelAt(PixelCoord(2, 1)).toOption.get, VoxelPoint(3.0, 1.0, 0.0))
    assertEquals(plan.mappingBatchCount, grid.dimensions.height)
    assert(plan.mappingBatchCount < grid.dimensions.pixelCount)
  }

  test("primitive dense-field slice mapping agrees with the typed morphism oracle") {
    val dims = SpatialDims(6, 5, 4)
    val affine = ProviderSpaces.affine(
      Vector(
        Vector(1.5, 0.10, 0.00, 4.0),
        Vector(0.0, 2.00, 0.15, -3.0),
        Vector(0.0, 0.00, 2.50, 7.0),
        Vector(0.0, 0.00, 0.00, 1.0)
      )
    )
    val source = volume[Double, image4s.Continuous](dims, Some(affine)) { (x, y, z) =>
      x.toDouble + 10.0 * y.toDouble + 100.0 * z.toDouble
    }
    val cursor = source.grid.voxelToWorld(VoxelPoint(2.4, 2.1, 1.6)).fold(error => fail(error.message), identity)
    val grid = SliceGrid.covering(
      source.grid,
      SlicePlane.canonical(AnatomicalPlane.Coronal, cursor),
      PixelSpacing(0.8, 0.9)
    )
    val fieldGrid = GridSpec.fromGrid(source.grid)
    val displacement =
      RavelArray.tabulate[Double](
        fieldGrid.shape.x,
        fieldGrid.shape.y,
        fieldGrid.shape.z,
        3
      ) { (x, y, z, component) =>
        component match
          case 0 => 0.10 * y.toDouble
          case 1 => -0.05 * x.toDouble
          case _ => 0.08 * z.toDouble
      }
    val absolute =
      RavelArray.tabulate[Double](
        fieldGrid.shape.x,
        fieldGrid.shape.y,
        fieldGrid.shape.z,
        3
      ) { (x, y, z, component) =>
        val world =
          fieldGrid
            .voxelToWorld(VoxelPoint(x.toDouble, y.toDouble, z.toDouble))
            .toOption
            .get
        component match
          case 0 => world.x + 0.10 * y.toDouble
          case 1 => world.y - 0.05 * x.toDouble
          case _ => world.z + 0.08 * z.toDouble
      }
    val mappings = Vector(
      SpatialPullbacks.displacement(fieldGrid, fieldGrid, displacement, Resample.Method.Nearest),
      SpatialPullbacks.displacement(fieldGrid, fieldGrid, displacement, Resample.Method.Linear),
      SpatialPullbacks.displacement(fieldGrid, fieldGrid, displacement, Resample.Method.Cubic),
      SpatialPullbacks.coordinates(fieldGrid, fieldGrid, absolute, Resample.Method.Nearest),
      SpatialPullbacks.coordinates(fieldGrid, fieldGrid, absolute, Resample.Method.Linear),
      SpatialPullbacks.coordinates(fieldGrid, fieldGrid, absolute, Resample.Method.Cubic)
    ).map(
      _.fold(error => fail(error.message), identity)
    )

    mappings.foreach { mapping =>
      val plan =
        MappedSlicePlan
          .make(source.grid, grid, mapping)
          .fold(error => fail(error.message), identity)
      var row = 0
      while row < grid.dimensions.height do
        var column = 0
        while column < grid.dimensions.width do
          val pixel = PixelCoord(column, row)
          val referenceWorld = grid.worldAt(pixel).toOption.get
          val mapped = SpatialPullbacks
            .transform(mapping, referenceWorld.toSpatialPoint)
            .fold(error => fail(error.message), identity)
          val mappedWorld = WorldPoint(mapped.x, mapped.y, mapped.z)
          val expected = source.grid.worldToVoxel(mappedWorld).fold(error => fail(error.message), identity)
          val actual = plan.sourceVoxelAt(pixel).toOption.get
          assertEqualsDouble(actual.x, expected.x, Tol)
          assertEqualsDouble(actual.y, expected.y, Tol)
          assertEqualsDouble(actual.z, expected.z, Tol)
          column += 1
        row += 1
    }
  }

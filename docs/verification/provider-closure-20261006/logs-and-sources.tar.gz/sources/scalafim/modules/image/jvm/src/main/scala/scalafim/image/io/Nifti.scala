package scalafim.image.io

import scalafim.image.SampleSpaces.*

import image4s.AxisKind
import image4s.Continuous
import image4s.ImageError
import image4s.SampleSpace
import image4s.Sampled
import image4s.SomeSampled
import image4s.geometry.Affine as ImageAffine
import image4s.geometry.D3
import image4s.geometry.Frame
import image4s.geometry.LengthUnit
import image4s.nifti.NiftiSpatialUnit
import image4s.nifti.DecodedNifti
import image4s.nifti.Nifti as ImageNifti
import image4s.nifti.NiftiByteOrder
import image4s.nifti.NiftiAffinePolicy
import image4s.nifti.NiftiError
import image4s.nifti.NiftiExtension
import image4s.nifti.NiftiFiles
import image4s.nifti.NiftiIoLimits
import image4s.nifti.NiftiIoStrategy
import image4s.nifti.NiftiReadOptions
import image4s.nifti.NiftiScalarWriter
import image4s.nifti.NiftiScalarStored
import image4s.nifti.NiftiTemporalUnit
import image4s.nifti.NiftiUnknownTemporalUnitPolicy
import image4s.nifti.NiftiWriteOptions
import ravel.Rank
import ravel.AnyRank
import scalafim.image.*
import scalafim.image.NeuroAffineSyntax.*
import scalafim.image.world.{SpaceError, SpaceEvidence, SpaceResolver, WorldSpace, XformCode}

import java.nio.ByteOrder
import java.nio.file.Path

/** Neuroimaging-facing view of the authoritative image4s NIfTI header.
  *
  * The provider header is retained directly. Compatibility field spellings
  * are derived views used by ScalaFIM's bounded block readers; there is no
  * second parser or separately owned header state.
  */
final class NiftiHeader private[io] (
    val native: image4s.nifti.NiftiHeader
):
  inline def dims: Vector[Int] =
    native.dimensions

  inline def pixdim: Vector[Double] =
    native.pixelDimensions

  inline def datatype: Int =
    native.datatype.code

  inline def bitpix: Int =
    native.datatype.bitsPerValue

  inline def voxOffset: Int =
    native.voxelOffset

  inline def slope: Double =
    native.slope

  inline def intercept: Double =
    native.intercept

  lazy val qoffset: Vector[Double] =
    native.qform
      .map: affine =>
        val values = affine.rowMajor
        Vector(values(3), values(7), values(11))
      .getOrElse(Vector.fill(3)(0.0))

  inline def qformCode: Int =
    native.qformCode

  lazy val qform: Option[ImageAffine[D3]] =
    native.qform

  inline def sformCode: Int =
    native.sformCode

  lazy val sform: Option[ImageAffine[D3]] =
    native.sform

  lazy val byteOrder: ByteOrder =
    native.byteOrder match
      case NiftiByteOrder.LittleEndian => ByteOrder.LITTLE_ENDIAN
      case NiftiByteOrder.BigEndian    => ByteOrder.BIG_ENDIAN

  lazy val preferredAffine: Option[ImageAffine[D3]] =
    native.sform.orElse(native.qform)

  lazy val selectedAffine: ImageAffine[D3] =
    native.sform.orElse(native.qform).getOrElse(native.fallbackAffine)

  /** Place this header's selected geometry in an asserted, resolved world. */
  def spaceIn(
    evidence: SpaceEvidence,
    options: NiftiReadOptions = NiftiReadOptions.default
  ): Either[NiftiImageReadError, SomeSampleSpace] =
    // image4s keeps selectAffine private. Match its admission gate as well as its selection;
    // a header-only read must not admit geometry the corresponding full read refuses.
    val agreement: Either[NiftiImageReadError, Unit] = options.affinePolicy match
      case NiftiAffinePolicy.RequireAgreement(tolerance) =>
        if !tolerance.isFinite || tolerance < 0.0 then
          Left(NiftiImageReadError.Provider(NiftiError.InvalidAffineAgreementTolerance(tolerance)))
        else (native.qform, native.sform) match
          case (Some(q), Some(s)) =>
            val difference = q.rowMajor.zip(s.rowMajor).map((a, b) => math.abs(a - b)).max
            if difference > tolerance then Left(NiftiImageReadError.Provider(NiftiError.AffineFormsDisagree(difference, tolerance)))
            else Right(())
          case _ => Right(())
      case _ => Right(())
    val unit = native.spatialUnit match
      case NiftiSpatialUnit.Meter => LengthUnit.Meter
      case NiftiSpatialUnit.Micrometer => LengthUnit.Micrometer
      case NiftiSpatialUnit.Millimeter => LengthUnit.Millimeter
      case NiftiSpatialUnit.Unknown => options.fallbackSpatialUnit
    for
      _ <- agreement
      _ <- Either.cond(unit == LengthUnit.Millimeter, (),
        NiftiImageReadError.Space(SpaceError.NotAWorldFrame(s"world admission requires millimetres, got $unit")))
      selection = NiftiSpaceEvidence.selectedSource(native, options.affinePolicy)
      (source, affine) = selection
      world <- Nifti.resolveWorld(native, source, evidence).left.map(NiftiImageReadError.Space.apply)
      placed <- SampleSpaces
        .inWorld(
          SampleSpaces(dims, spacing = Some(affine.neuroVoxelSizes), origin = Some(Vector(affine.matrix(0, 3), affine.matrix(1, 3), affine.matrix(2, 3))), affine = Some(affine)),
          world
        )
        .left
        .map(error => NiftiImageReadError.Image(NeuroImageError.Space(error)))
    yield placed

object NiftiHeader:
  private[io] def fromNative(
      header: image4s.nifti.NiftiHeader
  ): NiftiHeader =
    new NiftiHeader(header)

enum NiftiImageReadError derives CanEqual:
  case Provider(error: NiftiError)
  case Image(error: NeuroImageError)

  /** The file's world-space evidence, with the caller's, is unresolved or contradictory. */
  case Space(error: SpaceError)

  def message: String =
    this match
      case Provider(error) => error.message
      case Image(error)    => error.message
      case Space(error)    => error.message

/** Native NIfTI I/O over image4s streaming and Ravel-owned destinations.
  *
  * Image reads retain provider and ScalaFIM refinement failures as typed
  * causes. Other entry points return provider errors directly. All paths
  * preserve the native image4s/Ravel representation without compatibility
  * staging.
  */
object Nifti:
  type Error = NiftiError
  type ImageReadError = NiftiImageReadError
  type ReadOptions = NiftiReadOptions
  type WriteOptions = NiftiWriteOptions
  type IoLimits = NiftiIoLimits
  type StoredScalar = NiftiScalarStored

  val ReadOptions = NiftiReadOptions
  val WriteOptions = NiftiWriteOptions
  val IoLimits = NiftiIoLimits

  def ioStrategy(path: Path): NiftiIoStrategy =
    ImageNifti.ioStrategy(path)

  def readHeader(
      path: Path,
      limits: NiftiIoLimits = NiftiIoLimits.default
  ): Either[NiftiError, NiftiHeader] =
    ImageNifti.readHeader(path, limits).map(NiftiHeader.fromNative)

  def readStored(
      path: Path,
      options: NiftiReadOptions = NiftiReadOptions.default
  ): Either[NiftiError, DecodedNifti[NiftiScalarStored]] =
    ImageNifti.readScalarStored(path, options)

  /** Read a volume in the world its evidence identifies. */
  def readVolume(
      path: Path,
      evidence: SpaceEvidence,
      options: NiftiReadOptions = NiftiReadOptions.default
  ): Either[NiftiImageReadError, DecodedNifti[SomeScalarVolume[Double]]] =
    readVolumeIn(path, evidence, options)

  private def decodeVolume(
      path: Path,
      options: NiftiReadOptions
  ): Either[NiftiImageReadError, DecodedNifti[SomeScalarVolume[Double]]] =
    ImageNifti
      .readScaledDouble(path, options)
      .left
      .map(NiftiImageReadError.Provider.apply)
      .flatMap: decoded =>
        volumeFrom(decoded.image).map: volume =>
          DecodedNifti(
            volume,
            decoded.header,
            decoded.affineSelection
          )

  /** Read a volume in the world space its evidence identifies.
    *
    * The header contributes the xform code of the affine the read selected; `evidence` contributes the caller's BIDS
    * `space-` entity, native context and any assertion (its `xform` must be empty or agree with the header's).
    * `SpaceResolver.resolveKnown` decides the world space, and the decoded geometry is re-identified in it with
    * `SampleSpaces.inWorld`, keeping shape, affine and data. Unresolved or contradictory evidence is a
    * [[NiftiImageReadError.Space]], never a silent fallback to the unresolved world.
    *
    * The caller vouches for its evidence: a supplied `NativeContext` is the native space the file is asserted to be in,
    * and it is not compared with the file's own geometry (a derivative resampled into a subject's T1w space is in that
    * space without sharing the T1w grid). Use `NiftiSpaceEvidence.nativeContext` when the file is itself the reference.
    */
  def readVolumeIn(
      path: Path,
      evidence: SpaceEvidence,
      options: NiftiReadOptions = NiftiReadOptions.default
  ): Either[NiftiImageReadError, DecodedNifti[SomeScalarVolume[Double]]] =
    decodeVolume(path, options).flatMap: decoded =>
      for
        world  <- resolveWorld(decoded, evidence)
        placed <- placeIn(decoded.image.sampled, world)
      yield DecodedNifti(SomeNeuroVolume.unsafeFromSampled(placed), decoded.header, decoded.affineSelection)

  /** [[readVolumeIn]] for a 4D series; see there for how the world space is decided. */
  def readSeriesIn(
      path: Path,
      evidence: SpaceEvidence,
      options: NiftiReadOptions = Nifti.defaultSeriesReadOptions
  ): Either[NiftiImageReadError, DecodedNifti[SomeScalarSeries[Double]]] =
    decodeSeries(path, options).flatMap: decoded =>
      for
        world  <- resolveWorld(decoded, evidence)
        placed <- placeIn(decoded.image.sampled, world)
        series <- NeuroSeries.fromSampled(placed).left.map(NiftiImageReadError.Image.apply)
      yield DecodedNifti(SomeNeuroSeries.eraseSpace(series), decoded.header, decoded.affineSelection)

  /** Read a series in the world its evidence identifies. */
  def readSeries(
      path: Path,
      evidence: SpaceEvidence,
      options: NiftiReadOptions = Nifti.defaultSeriesReadOptions
  ): Either[NiftiImageReadError, DecodedNifti[SomeScalarSeries[Double]]] =
    readSeriesIn(path, evidence, options)

  private def decodeSeries(
      path: Path,
      options: NiftiReadOptions
  ): Either[NiftiImageReadError, DecodedNifti[SomeScalarSeries[Double]]] =
    ImageNifti
      .readScaledDouble(path, options)
      .left
      .map(NiftiImageReadError.Provider.apply)
      .flatMap: decoded =>
        seriesFrom(decoded.image).map: series =>
          DecodedNifti(
            series,
            decoded.header,
            decoded.affineSelection
          )

  def writeVolume(
      path: Path,
      volume: SomeScalarVolume[Double],
      options: NiftiWriteOptions = NiftiWriteOptions.default,
      extensions: Vector[NiftiExtension] = Vector.empty
  ): Either[NiftiError, NiftiFiles[Path]] =
    writeScalar(
      path,
      volume.sampled,
      options,
      extensions
    )

  def writeSeries(
      path: Path,
      series: SomeScalarSeries[Double],
      options: NiftiWriteOptions = Nifti.defaultSeriesWriteOptions,
      extensions: Vector[NiftiExtension] = Vector.empty
  ): Either[NiftiError, NiftiFiles[Path]] =
    writeScalar(
      path,
      series.sampled,
      options,
      extensions
    )

  /** Open an exclusive .nii staging file for produced scalar blocks.
    *
    * The sample space supplies the exact grid and non-spatial axes. Block indices use NIfTI first-axis-fastest spatial
    * order, not Ravel linear offsets. Header sampling, temporal units and coordinate-system codes come from `options`;
    * axis labels and scientific identities require extensions or a manifest. The caller owns close, coverage validation
    * and eventual publication.
    */
  def openScalarWriter[F <: Frame[D3]](
      path: Path,
      space: SampleSpace[F, D3],
      options: NiftiWriteOptions = NiftiWriteOptions.default,
      extensions: Vector[NiftiExtension] = Vector.empty
  ): Either[NiftiError, NiftiScalarWriter[F, Path]] =
    ImageNifti.openScalarWriter(path, space.grid, space.nonSpatialAxes, options, extensions)

  /** Scope the physical writer, including callback exceptions. A partial staging file remains caller-owned; successful
    * close does not certify a complete result.
    */
  def withScalarWriter[F <: Frame[D3], A](
      path: Path,
      space: SampleSpace[F, D3],
      options: NiftiWriteOptions = NiftiWriteOptions.default,
      extensions: Vector[NiftiExtension] = Vector.empty
  )(use: NiftiScalarWriter[F, Path] => Either[NiftiError, A]): Either[NiftiError, A] =
    ImageNifti.withScalarWriter(path, space.grid, space.nonSpatialAxes, options, extensions)(use)

  def readDisplacementField(
      path: Path,
      options: NiftiReadOptions = NiftiReadOptions.default
  ): Either[NiftiError, DisplacementField] =
    readDenseVectorFieldData(path, options).map: (grid, data) =>
      DenseVectorField.displacement(grid, data)

  def readSourceCoordinateField(
      path: Path,
      options: NiftiReadOptions = NiftiReadOptions.default
  ): Either[NiftiError, SourceCoordinateField] =
    readDenseVectorFieldData(path, options).map: (grid, data) =>
      DenseVectorField.sourceCoordinates(grid, data)

  private val defaultSeriesReadOptions: NiftiReadOptions =
    NiftiReadOptions.default.copy(
      unknownTemporalUnit = NiftiUnknownTemporalUnitPolicy.AssumeSeconds
    )

  private val defaultSeriesWriteOptions: NiftiWriteOptions =
    NiftiWriteOptions
      .create(
        datatype = image4s.nifti.NiftiDatatype.Float64,
        slope = 1.0,
        intercept = 0.0,
        nonSpatialPixelDimensions = Vector(1.0),
        temporalUnit = NiftiTemporalUnit.Second
      )
      .fold(
        error => throw new IllegalStateException(error.message),
        identity
      )

  private def volumeFrom(
      image: SomeSampled[Double, Continuous]
  ): Either[NiftiImageReadError, SomeScalarVolume[Double]] =
    image.fold(
      d2 =>
        Left(
          NiftiImageReadError.Provider(
            NiftiError.Image(
              ImageError.SpatialDimensionMismatch(3, d2.spatialRank)
            )
          )
        ),
      d3 =>
        d3.storageRank match
          case 3 =>
            d3.value
              .requireDataRank[3]
              .left
              .map(providerImageError)
              .map(SomeNeuroVolume.unsafeFromSampled)
          case 4
              if d3.value.nonSpatialAxes.size == 1 &&
                d3.value.nonSpatialAxes.values.head.extent == 1 =>
            d3.value
              .requireDataRank[4]
              .flatMap(_.selectNonSpatial(0, 0))
              .flatMap(_.requireDataRank[3])
              .left
              .map(providerImageError)
              .map(SomeNeuroVolume.unsafeFromSampled)
          case actual =>
            Left(
              NiftiImageReadError.Provider(
                NiftiError.Image(
                  ImageError.StorageRankMismatch(3, actual)
                )
              )
            )
    )

  private def seriesFrom(
      image: SomeSampled[Double, Continuous]
  ): Either[NiftiImageReadError, SomeScalarSeries[Double]] =
    image.fold(
      d2 =>
        Left(
          NiftiImageReadError.Provider(
            NiftiError.Image(
              ImageError.SpatialDimensionMismatch(3, d2.spatialRank)
            )
          )
        ),
      d3 =>
        d3.value
          .requireDataRank[4]
          .left
          .map(providerImageError)
          .flatMap: ranked =>
            val axes = ranked.nonSpatialAxes.values
            if axes.size != 1 || axes.head.kind != AxisKind.Time then
              Left(
                NiftiImageReadError.Provider(
                  NiftiError.Image(
                    ImageError.MissingNonSpatialAxisKind(AxisKind.Time)
                  )
                )
              )
            else
              NeuroSeries
                .fromSampled(ranked)
                .left
                .map(NiftiImageReadError.Image.apply)
                .map(SomeNeuroSeries.eraseSpace)
    )

  /** The world space of a completed read: the header's selected xform code plus the caller's evidence. */
  private[io] def resolveWorld(
      header: image4s.nifti.NiftiHeader,
      source: image4s.nifti.NiftiAffineSource,
      evidence: SpaceEvidence
  ): Either[SpaceError, WorldSpace] =
    for
      fromFile <- NiftiSpaceEvidence.fromSelection(header, source)
      xform <- (evidence.xform, fromFile.xform) match
        // An unknown (or scaling-fallback) header code is absence of evidence, not a contradiction.
        case (Some(claimed), Some(XformCode.Unknown)) => Right(Some(claimed))
        case (Some(claimed), Some(actual)) if claimed != actual =>
          Left(SpaceError.ConflictingEvidence(s"supplied xform code $claimed", s"header xform code $actual"))
        case (claimed, actual) => Right(actual.orElse(claimed))
      world <- SpaceResolver.resolveKnown(evidence.copy(xform = xform))
    yield world

  private def resolveWorld(
      decoded: DecodedNifti[?],
      evidence: SpaceEvidence
  ): Either[NiftiImageReadError, WorldSpace] =
    resolveWorld(decoded.header, decoded.affineSelection.source, evidence).left.map(NiftiImageReadError.Space.apply)

  /** Re-identify a decoded image's geometry in `world` without copying its data. */
  private def placeIn[A, R <: AnyRank](
      sampled: Sampled[? <: SampleSpace[?, D3], A, Continuous, R],
      world: WorldSpace
  )(using
      image4s.ValueSemantics[A, Continuous]
  ): Either[NiftiImageReadError, Sampled[? <: SampleSpace[?, D3], A, Continuous, R]] =
    for
      space <- SampleSpaces
        .inWorld(SampleSpaces.fromCanonical(sampled.sampleSpace), world)
        .flatMap(SampleSpaces.requireD3)
        .left
        .map(error => NiftiImageReadError.Image(NeuroImageError.Space(error)))
      placed <- Sampled
        .continuous(space, sampled.data, sampled.metadata)
        .left
        .map(providerImageError)
    yield placed

  private def readDenseVectorFieldData(
      path: Path,
      options: NiftiReadOptions
  ): Either[
    NiftiError,
    (GridSpec[?], ravel.NDArray[Double, Rank[4]])
  ] =
    ImageNifti
      .readScaledDouble(path, options)
      .flatMap: decoded =>
        decoded.image.fold(
          d2 =>
            Left(
              NiftiError.Image(
                ImageError.SpatialDimensionMismatch(3, d2.spatialRank)
              )
            ),
          d3 =>
            if d3.value.nonSpatialAxes.size != 1 ||
              d3.value.nonSpatialAxes.values.head.extent != 3
            then
              Left(
                NiftiError.Image(
                  ImageError.SampledShapeMismatch(
                    d3.value.grid.shape :+ 3,
                    d3.value.logicalShape
                  )
                )
              )
            else
              d3.value
                .requireDataRank[4]
                .left
                .map(NiftiError.Image.apply)
                .map: ranked =>
                  val space =
                    SampleSpaces.fromCanonical(ranked.sampleSpace).spatialSpace
                  GridSpec.fromSpace(space) -> ranked.data
        )

  private def providerImageError(error: ImageError): NiftiImageReadError =
    NiftiImageReadError.Provider(NiftiError.Image(error))

  private[scalafim] def readHeaderUnsafe(path: Path): NiftiHeader =
    readHeader(path).fold(
      error => throw new IllegalArgumentException(error.message),
      identity
    )

  private[scalafim] def writeDenseVectorField[
      Role <: DenseVectorFieldKind
  ](
      path: Path,
      field: DenseVectorField[Role]
  ): Path =
    writeScalar(
      path,
      field.sampled
    )
      .fold(
        error => throw new IllegalArgumentException(error.message),
        files =>
          files match
            case NiftiFiles.SingleFile(value) => value
            case NiftiFiles.PairFile(header, _) => header
      )

  /** Capture the existential sample-space owner before entering image4s' NIfTI
    * writer.
    *
    * `Sampled` is immutable, and `S` is already bounded by a D3 sample space.
    * Scala cannot retain the relationship between the two nested existential
    * owners when inferring image4s' separate `F` and `S` parameters, so the
    * single erased cast below restores that relationship at this format
    * boundary. No object or storage is copied or widened outside the call.
    */
  private def writeScalar[
      S <: SampleSpace[?, D3],
      R <: AnyRank
  ](
      path: Path,
      image: Sampled[S, Double, Continuous, R],
      options: NiftiWriteOptions = NiftiWriteOptions.default,
      extensions: Vector[NiftiExtension] = Vector.empty
  ): Either[NiftiError, NiftiFiles[Path]] =
    val captured = image.asInstanceOf[
      Sampled[
        SampleSpace[Frame[D3], D3],
        Double,
        Continuous,
        R
      ]
    ]
    ImageNifti.writeScalar(
      path,
      captured,
      options,
      extensions
    )

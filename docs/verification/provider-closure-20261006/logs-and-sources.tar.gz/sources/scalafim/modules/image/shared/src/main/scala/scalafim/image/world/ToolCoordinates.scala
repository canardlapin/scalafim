package scalafim.image.world

import image4s.geometry.{Affine, D3}

/** Which stored affine FSL places a volume with: the sform when its code is non-zero, else the qform when its code is
  * non-zero, else a pure pixdim scaling. This is FSL's rule (fslpy `Image.voxToWorldMat`), which can differ from the
  * policy ScalaFIM reads data with; both are kept, never merged.
  */
enum FslAffineSource derives CanEqual:
  case Sform, Qform, Scaling

/** Admission of contradictory header orientation. The compatibility policy is
  * for reproducing historical fslpy/nitransforms fixtures, not native FSL admission.
  */
enum FslHeaderPolicy derives CanEqual:
  case Strict, FslpyCompatibility

enum FslStorageOrder derives CanEqual:
  case Radiological, Neurological

/** World placement and native storage order are separate: absent forms use
  * positive world scaling but radiological storage. Opposite active q/sform
  * handedness is rejected unless historical reference compatibility is explicit.
  */
final class FslVolumeGeometry private (
    val dims: Vector[Int],
    val pixdim: Vector[Double],
    val voxelToWorld: Affine[D3],
    val selected: FslAffineSource,
    val storageOrder: FslStorageOrder
):
  def neurological: Boolean = storageOrder == FslStorageOrder.Neurological

  /** Voxel index -> FSL scaled-voxel mm: `voxel * pixdim`, with x mirrored to `(nx - 1 - i) * px` when neurological. */
  def voxelToFsl: Affine[D3] =
    val (px, py, pz) = (pixdim(0), pixdim(1), pixdim(2))
    val row0 =
      if neurological then Vector(-px, 0.0, 0.0, (dims(0) - 1) * px)
      else Vector(px, 0.0, 0.0, 0.0)
    ToolCoordinates.affine(row0 ++ Vector(0.0, py, 0.0, 0.0, 0.0, 0.0, pz, 0.0, 0.0, 0.0, 0.0, 1.0))

  /** FSL scaled-voxel mm -> RAS mm. */
  def fslToWorld: Affine[D3] =
    ToolCoordinates.compose(voxelToFsl.inverse, voxelToWorld)

object FslVolumeGeometry:
  /** Build from raw NIfTI header fields, applying FSL's affine selection. `pixdim` are the three spatial pixdims. */
  def fromHeader(
      dims: Vector[Int],
      pixdim: Vector[Double],
      qformCode: Int,
      qform: Option[Affine[D3]],
      sformCode: Int,
      sform: Option[Affine[D3]],
      policy: FslHeaderPolicy = FslHeaderPolicy.Strict
  ): Either[SpaceError, FslVolumeGeometry] =
    if dims.size < 3 || dims.take(3).exists(_ <= 0) then Left(SpaceError.InvalidGeometry(s"FSL geometry needs three positive dims, got $dims"))
    else if pixdim.size < 3 || pixdim.take(3).exists(p => !p.isFinite || p == 0.0) then
      Left(SpaceError.InvalidGeometry(s"FSL geometry needs three finite non-zero pixdims, got $pixdim"))
    else if qformCode != 0 && qform.isEmpty then Left(SpaceError.InvalidGeometry(s"qform_code $qformCode but no qform"))
    else if sformCode != 0 && sform.isEmpty then Left(SpaceError.InvalidGeometry(s"sform_code $sformCode but no sform"))
    else
      val zooms = pixdim.take(3).map(math.abs)
      val chosen =
        (sformCode, sform, qformCode, qform) match
          case (s, Some(affine), _, _) if s != 0 => Right(affine -> FslAffineSource.Sform)
          case (s, None, _, _) if s != 0         => Left(SpaceError.InvalidGeometry(s"sform_code $s but no sform"))
          case (_, _, q, Some(affine)) if q != 0 => Right(affine -> FslAffineSource.Qform)
          case (_, _, q, None) if q != 0         => Left(SpaceError.InvalidGeometry(s"qform_code $q but no qform"))
          case _ =>
            Right(ToolCoordinates.affine(Vector(zooms(0), 0, 0, 0, 0, zooms(1), 0, 0, 0, 0, zooms(2), 0, 0, 0, 0, 1)) -> FslAffineSource.Scaling)
      chosen.flatMap: (affine, source) =>
        val conflict = for
          q <- qform.filter(_ => qformCode != 0)
          s <- sform.filter(_ => sformCode != 0)
          qdet = ToolCoordinates.determinant3(q)
          sdet = ToolCoordinates.determinant3(s)
          if math.signum(qdet) != math.signum(sdet)
        yield SpaceError.FslHandednessConflict(qformCode, qdet, sformCode, sdet)
        if policy == FslHeaderPolicy.Strict && conflict.nonEmpty then Left(conflict.get)
        else
          val neurological =
            (policy == FslHeaderPolicy.FslpyCompatibility || source != FslAffineSource.Scaling) &&
              ToolCoordinates.determinant3(affine) > 0.0
          val order = if neurological then FslStorageOrder.Neurological else FslStorageOrder.Radiological
          Right(new FslVolumeGeometry(dims.take(3), zooms, affine, source, order))

/** FreeSurfer volume geometry. `norig` is the scanner vox2ras (`MRIxfmCRS2XYZ`). FreeSurfer's tkRAS vox2ras (`Torig`,
  * `MRIxfmCRS2XYZtkreg`) ignores the volume's direction cosines: it always uses the tkregister LIA axes
  * (x_r = -1, z_a = 1, y_s = -1) with the volume's voxel sizes and the volume centre at the origin. So
  * tkRAS -> scanner RAS is `Norig * inverse(Torig)`, which is a pure translation by `c_ras` only for LIA-oriented
  * (conformed) volumes; for any other orientation it also rotates. Voxel sizes are the column norms of `norig`.
  */
final case class FreeSurferVolumeGeometry(dims: Vector[Int], norig: Affine[D3]):
  require(dims.size == 3 && dims.forall(_ > 0), s"FreeSurfer geometry needs three positive dims, got $dims")

  def voxelSizes: Vector[Double] =
    val m = norig.rowMajor
    Vector.tabulate(3)(c => math.sqrt(m(c) * m(c) + m(4 + c) * m(4 + c) + m(8 + c) * m(8 + c)))

  def centerRas: Vector[Double] =
    norig(dims.map(_ / 2.0)).fold(error => throw new IllegalStateException(error.message), identity)

  def torig: Affine[D3] =
    val Vector(xs, ys, zs) = voxelSizes
    val Vector(nx, ny, nz) = dims.map(_.toDouble)
    ToolCoordinates.affine(
      Vector(-xs, 0.0, 0.0, xs * nx / 2.0, 0.0, 0.0, zs, -zs * nz / 2.0, 0.0, -ys, 0.0, ys * ny / 2.0, 0.0, 0.0, 0.0, 1.0)
    )

  /** tkRAS -> scanner RAS. */
  def tkrToScanner: Affine[D3] =
    ToolCoordinates.compose(torig.inverse, norig)

/** Toolkit coordinate systems, each decoded into canonical RAS millimetres in exactly one place. */
enum ToolCoordinates:
  /** RAS mm: nibabel, FreeSurfer scanner RAS, fMRIPrep, NIfTI world. */
  case RasMm

  /** LPS mm: ITK/ANTs physical space and AFNI's DICOM order. */
  case LpsMm

  /** FSL scaled-voxel mm of one volume (FLIRT/FNIRT). */
  case FslScaledVoxel(geometry: FslVolumeGeometry)

  /** FreeSurfer surface RAS (tkRAS) of one volume. */
  case TkRas(geometry: FreeSurferVolumeGeometry)

  /** Voxel indices of one volume (LTA VOX_TO_VOX, register.dat inputs). */
  case VoxelIndex(voxelToWorld: Affine[D3])

object ToolCoordinates:
  /** LPS <-> RAS. Self-inverse. The only definition of this flip in ScalaFIM. */
  val LpsToRas: Affine[D3] =
    affine(Vector(-1.0, 0, 0, 0, 0, -1.0, 0, 0, 0, 0, 1.0, 0, 0, 0, 0, 1.0))

  /** The affine taking coordinates in `system` to RAS millimetres. */
  def toRas(system: ToolCoordinates): Affine[D3] =
    system match
      case RasMm                      => Affine.identity[D3]
      case LpsMm                      => LpsToRas
      case FslScaledVoxel(geometry)   => geometry.fslToWorld
      case TkRas(geometry)            => geometry.tkrToScanner
      case VoxelIndex(voxelToWorld)   => voxelToWorld

  def fromRas(system: ToolCoordinates): Affine[D3] =
    toRas(system).inverse

  /** Re-express a matrix acting in `from` coordinates as one acting in `to` coordinates: `to <- from`. */
  def between(from: ToolCoordinates, to: ToolCoordinates): Affine[D3] =
    compose(toRas(from), fromRas(to))

  private[world] def affine(rowMajor: Vector[Double]): Affine[D3] =
    Affine.fromRowMajor[D3](rowMajor).fold(error => throw new IllegalArgumentException(s"invalid convention affine: ${error.message}"), identity)

  /** `first` then `second`, through the provider's checked composition. */
  private[world] def compose(first: Affine[D3], second: Affine[D3]): Affine[D3] =
    first.andThen(second).fold(error => throw new IllegalStateException(s"convention composition failed: ${error.message}"), identity)

  private[world] def determinant3(a: Affine[D3]): Double =
    val m = a.rowMajor
    m(0) * (m(5) * m(10) - m(6) * m(9)) - m(1) * (m(4) * m(10) - m(6) * m(8)) + m(2) * (m(4) * m(9) - m(5) * m(8))

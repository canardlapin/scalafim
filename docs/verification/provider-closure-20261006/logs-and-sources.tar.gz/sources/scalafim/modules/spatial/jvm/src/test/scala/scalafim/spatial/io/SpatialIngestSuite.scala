package scalafim.spatial.io

import scalafim.image.world.{SessionId, SubjectId}

import scalafim.image.{SampleSpaces, SomeSampleSpace}
import scalafim.image.SampleSpaces.*
import scalafim.spatial.*
import scalafim.transform.TransformFormat

import java.nio.file.Path

class SpatialIngestSuite extends munit.FunSuite:

  private def value[A](result: Either[SpatialError, A]): A =
    result match
      case Right(value) => value
      case Left(error) => fail(error.message)

  private def ioValue[A](result: Either[SpatialIoError, A]): A =
    result match
      case Right(value) => value
      case Left(error) => fail(error.message)

  private def domain(name: String): Domain =
    val id = value(DomainId(name))
    val subject = value(SubjectId("sub-01").asSpatial)
    val modality = value(Modality(name))
    val geometry = value(SamplingGeometry.volume(SampleSpaces(Vector(2, 1, 1), affine = Some(ProviderAffines.identity))))
    value(Domain.build(id, SpaceRef.Volume(subject, None, modality), geometry))

  test("missing inverse quality is explicit and becomes a non-geometric inverse"):
    val source = domain("func")
    val target = domain("t1w")
    val descriptor =
      ioValue(
        TransformDescriptor.build(
          id = value(MorphismId("func-to-t1w")),
          source = source.id,
          target = target.id,
          tool = TransformTool.ANTs,
          kind = TransformKind.Warp3D,
          path = Path.of("sub-01_from-bold_to-T1w_xfm.h5")
        )
      )

    val morphism = ioValue(descriptor.toMorphism)

    assertEquals(descriptor.inverseQuality, InverseQuality.Missing)
    assert(!descriptor.inverseQualityDeclared)
    assertEquals(
      descriptor.requireInverseQuality.left.toOption,
      Some(SpatialIoError.MissingInverseQuality("func-to-t1w"))
    )
    assertEquals(morphism.inverse, Inverse.None)

  test("fMRIPrep graph construction maps transform descriptors into typed spatial routes"):
    val func = domain("func")
    val t1w = domain("t1w")
    val inverseQuality = ioValue(InverseQuality.provided("xfm-sidecar", 0.8))
    val descriptor =
      ioValue(
        TransformDescriptor.build(
          id = value(MorphismId("func-to-t1w")),
          source = func.id,
          target = t1w.id,
          tool = TransformTool.FSL,
          kind = TransformKind.Affine3D,
          path = Path.of("sub-01_from-bold_to-T1w.mat"),
          inverseQuality = inverseQuality,
          coordinateMap = value(CoordinateMap.affine(func, t1w, ProviderAffines.identity))
        )
      )
    val subject = value(SubjectId("sub-01").asSpatial)
    val session = Some(value(SessionId("ses-01").asSpatial))
    val spec = ioValue(FmriprepSpatialGraph.build(subject, session, Vector(func, t1w), Vector(descriptor)))
    val graph = ioValue(spec.toSpatialGraph)

    val forward = value(graph.path(func.id, t1w.id))
    val reverse = value(graph.path(t1w.id, func.id, allowInverses = true))

    assertEquals(spec.subject, subject)
    assertEquals(spec.session, session)
    assertEquals(descriptor.tool, TransformTool.FSL)
    assertEquals(forward.ids.map(_.value), Vector("func-to-t1w"))
    assertEquals(reverse.ids.map(_.value), Vector("func-to-t1w:inverse"))
    assertEqualsDouble(reverse.pathQuality, 0.8, 1e-12)

  test("transform formats declare their tool and the morphism kind a descriptor starts from"):
    assertEquals(TransformFormat.ItkHdf5.tool, TransformTool.ANTs)
    assertEquals(TransformFormat.FslFnirtCoefficients.tool, TransformTool.FSL)
    assertEquals(TransformFormat.AfniAff12.tool, TransformTool.AFNI)
    assertEquals(TransformFormat.FreeSurferRegisterDat.tool, TransformTool.FreeSurfer)
    assertEquals(TransformFormat.X5.tool, TransformTool.X5)
    assertEquals(TransformFormat.ItkMatlab.defaultKind, TransformKind.Affine3D)
    assertEquals(TransformFormat.AntsDisplacementNifti.defaultKind, TransformKind.Warp3D)

    val func = domain("func")
    val template = domain("template")
    val descriptor =
      ioValue(
        TransformDescriptor.fromFile(
          id = value(MorphismId("func-to-template")),
          source = func.id,
          target = template.id,
          path = Path.of("sub-01_from-func_to-template_xfm.h5"),
          format = TransformFormat.ItkHdf5
        )
      )

    assertEquals(descriptor.tool, TransformTool.ANTs)
    assertEquals(descriptor.kind, TransformKind.Warp3D)

  test("inverse quality smart constructors reject invalid scores"):
    val result = InverseQuality.approximate("afni inverse", 1.1)

    result.left.toOption match
      case Some(SpatialIoError.InvalidTransformDescriptor(label, reason)) =>
        assertEquals(label, "approximate inverse")
        assert(reason.contains("quality must be in [0, 1]"))
      case other =>
        fail(s"expected invalid inverse quality, got $other")

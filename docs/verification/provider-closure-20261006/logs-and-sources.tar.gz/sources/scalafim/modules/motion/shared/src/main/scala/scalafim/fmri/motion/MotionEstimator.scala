package scalafim.fmri.motion

import scalafim.image.SampleSpaces.*

import scalafim.image.*
import gale.linalg.{CholeskyOptions, Matrix}

object MotionEstimator:
  def estimate(
      run: SomeScalarSeries[Double],
      mask: Option[SomeMaskVolume] = None,
      plan: MotionPlan = MotionPlan.default
  ): Either[MotionError, MotionEstimate] =
    plan.engine match
      case MotionEngine.RigidRobust =>
        estimateRigid(run, mask, plan)
      case MotionEngine.RigidSpline =>
        estimateSpline(run, mask, plan)

  private def estimateRigid(
      run: SomeScalarSeries[Double],
      mask: Option[SomeMaskVolume],
      plan: MotionPlan
  ): Either[MotionError, MotionEstimate] =
    for
      _ <- validateSupportedPlan(plan)
      _ <- MotionMetrics.validateMask(run, mask)
      _ <- validateFiniteRun(run)
      refIndex <- referenceIndex(run, plan.reference)
      levels <- buildPyramidLevels(run, mask, plan.control)
    yield
      val ctx = EstimatorContext(run, plan.control, refIndex, levels)
      val template = buildTemplate(run, plan.reference, refIndex)
      val first = fitRun(ctx, template)
      refreshTemplate(ctx, template, first) match
        case None => first
        case Some(refreshed) => fitRun(ctx, refreshed)

  private def estimateSpline(
      run: SomeScalarSeries[Double],
      mask: Option[SomeMaskVolume],
      plan: MotionPlan
  ): Either[MotionError, MotionEstimate] =
    for
      _ <- plan.acquisitionTiming.validateSlices(run.space.spatialDims(2))
      refIndex <- referenceIndex(run, plan.reference)
      rigid <- estimateRigid(run, mask, plan.copy(engine = MotionEngine.RigidRobust, acquisitionTiming = AcquisitionTiming.Volume))
      spline <- PoseSpline.smooth(rigid.trace)
      trace = preserveReferenceFrame(spline.trace, rigid.trace, refIndex)
    yield rigid.copy(trace = trace)

  private final case class SamplePoint(i: Int, j: Int, k: Int, ordinal: Int)

  private final case class PyramidLevel(downsample: Int, maxIterations: Int, samples: Vector[SamplePoint])

  private final case class EstimatorContext(
      run: SomeScalarSeries[Double],
      control: MotionControl,
      referenceIndex: Int,
      levels: Vector[PyramidLevel]
  ):
    val dims: Vector[Int] = run.space.spatialDims
    val nx: Int = dims(0)
    val ny: Int = dims(1)
    val nz: Int = dims(2)
    val nxyz: Int = nx * ny * nz
    val px: Double = run.space.spacing(0)
    val py: Double = run.space.spacing(1)
    val pz: Double = run.space.spacing(2)
    val diagnosticLevel: PyramidLevel = levels.last

  private final case class CostResult(cost: Double, overlap: Double)

  private final case class FitResult(pose: RigidPose, diagnostics: FrameFitDiagnostics, huber: Double)

  private final case class CaptureStart(pose: RigidPose, warmCost: CostResult, startCost: CostResult)

  private final case class SeedCost(pose: RigidPose, cost: CostResult)

  private final case class ScoredSample(sample: SamplePoint, score: Double)

  private def preserveReferenceFrame(smoothed: MotionTrace, original: MotionTrace, refIndex: Int): MotionTrace =
    if refIndex < 0 || refIndex >= smoothed.length then smoothed
    else MotionTrace.unsafe(smoothed.poses.updated(refIndex, original.unsafeFrame(refIndex)))

  private def validateSupportedPlan(plan: MotionPlan): Either[MotionError, Unit] =
    if !plan.acquisitionTiming.isVolume then Left(MotionError.NotImplemented("slice/packet-aware estimation"))
    else if plan.control.execution.policy == ExecutionPolicy.ParallelFrames && !MotionPlatform.parallelFramesSupported then
      Left(MotionError.UnsupportedControl("execution", "parallel frame estimation is not supported on this platform"))
    else if !plan.control.whitening.implemented then
      Left(
        MotionError.UnsupportedControl(
          "whitening",
          s"${plan.control.whitening.policy} requires template-mode residual whitening, which is not part of the shared estimator contract yet"
        )
      )
    else Right(())

  private def fitRun(ctx: EstimatorContext, template: Array[Double]): MotionEstimate =
    val nt = ctx.run.nVolumes
    val poses = Array.fill(nt)(RigidPose.identity)
    val diagnostics = Array.ofDim[FrameFitDiagnostics](nt)

    // Per-frame absolute Huber thresholds, fixed when each frame is fitted and reused for diagnostics.
    val huber = Array.fill(nt)(Double.NaN)
    huber(ctx.referenceIndex) = huberThreshold(ctx, template, ctx.referenceIndex, RigidPose.identity)
    val refCost = evaluate(ctx, ctx.diagnosticLevel, template, ctx.referenceIndex, RigidPose.identity, huber(ctx.referenceIndex))
    diagnostics(ctx.referenceIndex) =
      FrameFitDiagnostics(
        costInitial = refCost.cost,
        costFinal = refCost.cost,
        iterations = 0,
        overlap = refCost.overlap,
        restarted = false,
        converged = true
      )

    var t = ctx.referenceIndex + 1
    while t < nt do
      val result = fitFrame(ctx, template, t, poses(t - 1))
      poses(t) = result.pose
      diagnostics(t) = result.diagnostics
      huber(t) = result.huber
      t += 1

    t = ctx.referenceIndex - 1
    while t >= 0 do
      val result = fitFrame(ctx, template, t, poses(t + 1))
      poses(t) = result.pose
      diagnostics(t) = result.diagnostics
      huber(t) = result.huber
      t -= 1

    val outputPoses = regularizeTrace(ctx, poses)
    val outputDiagnostics =
      if outputPoses eq poses then diagnostics
      else recomputeFinalDiagnostics(ctx, template, outputPoses, diagnostics, huber)

    MotionEstimate(
      trace = MotionTrace.unsafe(outputPoses.toVector),
      diagnostics = outputDiagnostics.toVector,
      control = ctx.control
    )

  private def regularizeTrace(ctx: EstimatorContext, poses: Array[RigidPose]): Array[RigidPose] =
    ctx.control.temporal.regularization match
      case TemporalRegularizationPolicy.Disabled => poses
      case TemporalRegularizationPolicy.Enabled =>
        val out = poses.clone()
        var t = 0
        while t < poses.length do
          if t == ctx.referenceIndex then out(t) = RigidPose.identity
          else
            val left = if t > 0 then poses(t - 1) else poses(t)
            val right = if t < poses.length - 1 then poses(t + 1) else poses(t)
            out(t) =
              if t == 0 then blendPoses(poses(t), left, right, 2.0 / 3.0, 0.0, 1.0 / 3.0)
              else if t == poses.length - 1 then blendPoses(poses(t), left, right, 2.0 / 3.0, 1.0 / 3.0, 0.0)
              else blendPoses(poses(t), left, right, 0.5, 0.25, 0.25)
          t += 1
        out

  private def blendPoses(
      center: RigidPose,
      left: RigidPose,
      right: RigidPose,
      centerWeight: Double,
      leftWeight: Double,
      rightWeight: Double
  ): RigidPose =
    RigidPose.unsafe(
      center.tx * centerWeight + left.tx * leftWeight + right.tx * rightWeight,
      center.ty * centerWeight + left.ty * leftWeight + right.ty * rightWeight,
      center.tz * centerWeight + left.tz * leftWeight + right.tz * rightWeight,
      center.rx * centerWeight + left.rx * leftWeight + right.rx * rightWeight,
      center.ry * centerWeight + left.ry * leftWeight + right.ry * rightWeight,
      center.rz * centerWeight + left.rz * leftWeight + right.rz * rightWeight
    )

  private def recomputeFinalDiagnostics(
      ctx: EstimatorContext,
      template: Array[Double],
      poses: Array[RigidPose],
      diagnostics: Array[FrameFitDiagnostics],
      huber: Array[Double]
  ): Array[FrameFitDiagnostics] =
    val frameIds = Vector.tabulate(poses.length)(identity)
    val out =
      mapFrames(ctx, frameIds) { t =>
        val finalCost = evaluate(ctx, ctx.diagnosticLevel, template, t, poses(t), huber(t))
        val d = diagnostics(t)
        d.copy(
          costFinal = finalCost.cost,
          overlap = finalCost.overlap
        )
      }
    out.toArray

  private def fitFrame(
      ctx: EstimatorContext,
      template: Array[Double],
      frame: Int,
      warmStart: RigidPose
  ): FitResult =
    // The robust scale is estimated at the warm start for the coarse capture search, then
    // re-estimated once at the captured pose (residuals nearer alignment) and fixed for this
    // frame's levels and diagnostics, so one objective is minimised and costs stay comparable.
    val captureHuber = huberThreshold(ctx, template, frame, warmStart)
    val capture = captureStart(ctx, ctx.levels.head, template, frame, warmStart, captureHuber)
    val huber = huberThreshold(ctx, template, frame, capture.pose)
    var pose = capture.pose
    var lambda = math.max(1e-6, ctx.control.optimizer.lambda0)
    var totalIterations = 0
    var converged = false
    var levelIndex = 0

    while levelIndex < ctx.levels.length do
      val level = ctx.levels(levelIndex)
      var current =
        if levelIndex == 0 && huber == captureHuber then capture.startCost
        else evaluate(ctx, level, template, frame, pose, huber)
      var iter = 0
      var levelConverged = false
      var levelSolverFailed = false
      var levelStalled = false

      while iter < level.maxIterations && !levelConverged do
        val system = buildSystem(ctx, level, template, frame, pose, lambda, huber)
        solveNormal6(system.hessian, system.gradient.map(-_)) match
          case None =>
            // A singular normal system ends this level without convergence.
            levelConverged = true
            levelSolverFailed = true
          case Some(rawStep) =>
            val step = limitStep(rawStep)
            val stepNorm = poseStepNorm(step)
            if stepNorm <= ctx.control.optimizer.stepTolerance then levelConverged = true
            else
              var accepted = false
              var attempt = 0
              var trialStep = step
              while attempt < 6 && !accepted do
                val trialPose = addStep(pose, trialStep)
                val trialCost = evaluate(ctx, level, template, frame, trialPose, huber)
                if trialCost.cost < current.cost then
                  val relDrop =
                    if current.cost == 0.0 then current.cost - trialCost.cost
                    // Relative to the current cost itself: an absolute floor would
                    // declare convergence after one step on low-intensity images.
                    else (current.cost - trialCost.cost) / math.abs(current.cost)
                  pose = trialPose
                  current = trialCost
                  lambda = math.max(1e-8, lambda * 0.5)
                  accepted = true
                  if relDrop <= ctx.control.optimizer.costTolerance then levelConverged = true
                else
                  lambda *= 4.0
                  trialStep = trialStep.map(_ * 0.5)
                  attempt += 1
              // Six failed halvings end the level. That counts as convergence only
              // when the next, untried step (step / 64) is below the step tolerance;
              // a larger step that cannot reduce the cost is a stalled search.
              if !accepted then
                levelConverged = true
                if !lineSearchResolved(poseStepNorm(trialStep), ctx.control.optimizer.stepTolerance) then
                  levelStalled = true
        iter += 1

      totalIterations += iter
      converged = levelConverged && !levelSolverFailed && !levelStalled
      levelIndex += 1

    val outputPose = shrinkLowMotionPose(ctx, pose)
    val initial = evaluate(ctx, ctx.diagnosticLevel, template, frame, warmStart, huber)
    val start = evaluate(ctx, ctx.diagnosticLevel, template, frame, capture.pose, huber)
    val finalCost = evaluate(ctx, ctx.diagnosticLevel, template, frame, outputPose, huber)

    FitResult(
      pose = outputPose,
      diagnostics = FrameFitDiagnostics(
        costInitial = initial.cost,
        costFinal = finalCost.cost,
        iterations = totalIterations,
        overlap = finalCost.overlap,
        restarted = start.cost < initial.cost,
        converged = converged
      ),
      huber = huber
    )

  private final case class NormalSystem(hessian: Array[Double], gradient: Array[Double])

  private def buildSystem(
      ctx: EstimatorContext,
      level: PyramidLevel,
      template: Array[Double],
      frame: Int,
      pose: RigidPose,
      lambda: Double,
      huber: Double
  ): NormalSystem =
    val h = Array.fill(36)(0.0)
    val g = Array.fill(6)(0.0)
    val eps = Array(1e-2, 1e-2, 1e-2, 1e-4, 1e-4, 1e-4)
    val deriv = Array.ofDim[Double](6)
    val meanDeriv = Array.ofDim[Double](6)
    val centered = ctx.control.removeFrameMeanResidual
    var meanResidual = 0.0
    var meanCount = 0

    val map = MotionSampling.voxelMap(ctx.nx, ctx.ny, ctx.nz, zpad = 0, ctx.px, ctx.py, ctx.pz, pose)
    if centered then
      var s0 = 0
      while s0 < level.samples.length do
        val sample = level.samples(s0)
        val sx = MotionSampling.sourceX(map, sample.i, sample.j, sample.k)
        val sy = MotionSampling.sourceY(map, sample.i, sample.j, sample.k)
        val sz = MotionSampling.sourceZ(map, sample.i, sample.j, sample.k)
        if inBounds(ctx, sx, sy, sz) then
          val fitted =
            MotionSampling.trilinear(
              ctx.run.values,
              ctx.nx,
              ctx.ny,
              ctx.nz,
              frame,
              sx,
              sy,
              sz,
              zeroPad = false
            )
          meanResidual += fitted - template(sample.ordinal)
          var p = 0
          while p < 6 do
            val plus = addOne(pose, p, eps(p))
            val minus = addOne(pose, p, -eps(p))
            val fPlus = sampleAt(ctx, frame, plus, sample)
            val fMinus = sampleAt(ctx, frame, minus, sample)
            meanDeriv(p) += (fPlus - fMinus) / (2.0 * eps(p))
            p += 1
          meanCount += 1
        s0 += 1
      if meanCount > 0 then
        meanResidual /= meanCount.toDouble
        var p = 0
        while p < 6 do
          meanDeriv(p) /= meanCount.toDouble
          p += 1

    var s = 0
    while s < level.samples.length do
      val sample = level.samples(s)
      val sx = MotionSampling.sourceX(map, sample.i, sample.j, sample.k)
      val sy = MotionSampling.sourceY(map, sample.i, sample.j, sample.k)
      val sz = MotionSampling.sourceZ(map, sample.i, sample.j, sample.k)
      if inBounds(ctx, sx, sy, sz) then
        val fitted =
          MotionSampling.trilinear(
            ctx.run.values,
            ctx.nx,
            ctx.ny,
            ctx.nz,
            frame,
            sx,
            sy,
            sz,
            zeroPad = false
          )
        val residual =
          if centered then fitted - template(sample.ordinal) - meanResidual
          else fitted - template(sample.ordinal)
        val weight = huberWeight(residual, huber)
        var p = 0
        while p < 6 do
          val plus = addOne(pose, p, eps(p))
          val minus = addOne(pose, p, -eps(p))
          val fPlus = sampleAt(ctx, frame, plus, sample)
          val fMinus = sampleAt(ctx, frame, minus, sample)
          val rawDeriv = (fPlus - fMinus) / (2.0 * eps(p))
          deriv(p) = if centered then rawDeriv - meanDeriv(p) else rawDeriv
          p += 1

        var a = 0
        while a < 6 do
          g(a) += weight * deriv(a) * residual
          var b = 0
          while b < 6 do
            h(a * 6 + b) += weight * deriv(a) * deriv(b)
            b += 1
          a += 1
      s += 1

    // Levenberg-Marquardt damping proportional to each diagonal. The floor is
    // relative to the largest diagonal so the step does not depend on the
    // image intensity scale; a zero system stays singular.
    var maxDiag = 0.0
    var d = 0
    while d < 6 do
      maxDiag = math.max(maxDiag, math.abs(h(d * 6 + d)))
      d += 1
    d = 0
    while d < 6 do
      h(d * 6 + d) += lambda * math.max(math.abs(h(d * 6 + d)), DampingFloor * maxDiag)
      d += 1

    NormalSystem(h, g)

  private def captureStart(
      ctx: EstimatorContext,
      level: PyramidLevel,
      template: Array[Double],
      frame: Int,
      warmStart: RigidPose,
      huber: Double
  ): CaptureStart =
    val warmCost = evaluate(ctx, level, template, frame, warmStart, huber)
    if !ctx.control.capture.enabled then CaptureStart(warmStart, warmCost, warmCost)
    else
      val step = math.min(1.0, math.max(ctx.px, math.max(ctx.py, ctx.pz)))
      val maxTx = math.min(ctx.control.capture.translationHalfWidthMm, step)
      val offsets = Array(-maxTx, 0.0, maxTx)
      val rot = math.toRadians(ctx.control.capture.rotationHalfWidthDeg)
      var best = SeedCost(warmStart, warmCost)
      val translations = Vector.newBuilder[SeedCost]
      var ix = 0
      while ix < offsets.length do
        var iy = 0
        while iy < offsets.length do
          var iz = 0
          while iz < offsets.length do
            val candidate =
              RigidPose.unsafe(
                warmStart.tx + offsets(ix),
                warmStart.ty + offsets(iy),
                warmStart.tz + offsets(iz),
                warmStart.rx,
                warmStart.ry,
                warmStart.rz
              )
            val cost = evaluate(ctx, level, template, frame, candidate, huber)
            val seed = SeedCost(candidate, cost)
            translations += seed
            if cost.cost < best.cost.cost then best = seed
            iz += 1
          iy += 1
        ix += 1

      val rotations =
        Vector(
          SeedCost(warmStart, warmCost),
          rotationSeed(ctx, level, template, frame, warmStart, 3, rot, huber),
          rotationSeed(ctx, level, template, frame, warmStart, 3, -rot, huber),
          rotationSeed(ctx, level, template, frame, warmStart, 4, rot, huber),
          rotationSeed(ctx, level, template, frame, warmStart, 4, -rot, huber),
          rotationSeed(ctx, level, template, frame, warmStart, 5, rot, huber),
          rotationSeed(ctx, level, template, frame, warmStart, 5, -rot, huber)
        )
      var r = 0
      while r < rotations.length do
        if rotations(r).cost.cost < best.cost.cost then best = rotations(r)
        r += 1

      val nKeep = math.max(1, ctx.control.capture.topK)
      val topTranslations = translations.result().sortBy(_.cost.cost).take(nKeep)
      val topRotations = rotations.sortBy(_.cost.cost).take(nKeep)
      var ti = 0
      while ti < topTranslations.length do
        var ri = 0
        while ri < topRotations.length do
          val tPose = topTranslations(ti).pose
          val rPose = topRotations(ri).pose
          val candidate =
            RigidPose.unsafe(
              tPose.tx,
              tPose.ty,
              tPose.tz,
              rPose.rx,
              rPose.ry,
              rPose.rz
            )
          val cost = evaluate(ctx, level, template, frame, candidate, huber)
          if cost.cost < best.cost.cost then best = SeedCost(candidate, cost)
          ri += 1
        ti += 1

      CaptureStart(best.pose, warmCost, best.cost)

  private def rotationSeed(
      ctx: EstimatorContext,
      level: PyramidLevel,
      template: Array[Double],
      frame: Int,
      warmStart: RigidPose,
      index: Int,
      delta: Double,
      huber: Double
  ): SeedCost =
    val pose = addOne(warmStart, index, delta)
    SeedCost(pose, evaluate(ctx, level, template, frame, pose, huber))

  private def evaluate(
      ctx: EstimatorContext,
      level: PyramidLevel,
      template: Array[Double],
      frame: Int,
      pose: RigidPose,
      huber: Double
  ): CostResult =
    val map = MotionSampling.voxelMap(ctx.nx, ctx.ny, ctx.nz, zpad = 0, ctx.px, ctx.py, ctx.pz, pose)
    val centered = ctx.control.removeFrameMeanResidual
    var meanResidual = 0.0
    var meanCount = 0
    if centered then
      var s0 = 0
      while s0 < level.samples.length do
        val sample = level.samples(s0)
        val sx = MotionSampling.sourceX(map, sample.i, sample.j, sample.k)
        val sy = MotionSampling.sourceY(map, sample.i, sample.j, sample.k)
        val sz = MotionSampling.sourceZ(map, sample.i, sample.j, sample.k)
        if inBounds(ctx, sx, sy, sz) then
          val fitted =
            MotionSampling.trilinear(
              ctx.run.values,
              ctx.nx,
              ctx.ny,
              ctx.nz,
              frame,
              sx,
              sy,
              sz,
              zeroPad = false
            )
          meanResidual += fitted - template(sample.ordinal)
          meanCount += 1
        s0 += 1
      if meanCount > 0 then meanResidual /= meanCount.toDouble

    var s = 0
    var loss = 0.0
    var n = 0
    var inside = 0
    while s < level.samples.length do
      val sample = level.samples(s)
      val sx = MotionSampling.sourceX(map, sample.i, sample.j, sample.k)
      val sy = MotionSampling.sourceY(map, sample.i, sample.j, sample.k)
      val sz = MotionSampling.sourceZ(map, sample.i, sample.j, sample.k)
      if inBounds(ctx, sx, sy, sz) then
        inside += 1
        val fitted =
          MotionSampling.trilinear(
            ctx.run.values,
            ctx.nx,
            ctx.ny,
            ctx.nz,
            frame,
            sx,
            sy,
            sz,
            zeroPad = false
          )
        val residual =
          if centered then fitted - template(sample.ordinal) - meanResidual
          else fitted - template(sample.ordinal)
        loss += huberLoss(residual, huber)
        n += 1
      s += 1

    if n == 0 then CostResult(Double.PositiveInfinity, 0.0)
    else CostResult(loss / n.toDouble, inside.toDouble / level.samples.length.toDouble)

  private def sampleAt(ctx: EstimatorContext, frame: Int, pose: RigidPose, sample: SamplePoint): Double =
    val map = MotionSampling.voxelMap(ctx.nx, ctx.ny, ctx.nz, zpad = 0, ctx.px, ctx.py, ctx.pz, pose)
    val sx = MotionSampling.sourceX(map, sample.i, sample.j, sample.k)
    val sy = MotionSampling.sourceY(map, sample.i, sample.j, sample.k)
    val sz = MotionSampling.sourceZ(map, sample.i, sample.j, sample.k)
    MotionSampling.trilinear(
      ctx.run.values,
      ctx.nx,
      ctx.ny,
      ctx.nz,
      frame,
      sx,
      sy,
      sz,
      zeroPad = false
    )

  private def buildTemplate(run: SomeScalarSeries[Double], reference: ReferenceStrategy, refIndex: Int): Array[Double] =
    val nxyz = run.space.spatialDims.product
    val out = Array.ofDim[Double](nxyz)
    reference match
      case ReferenceStrategy.RobustMean =>
        var lin = 0
        while lin < nxyz do
          val voxel = run.space.indexToVoxel3D(lin)
          var t = 0
          var sum = 0.0
          while t < run.nVolumes do
            sum += run(voxel.x, voxel.y, voxel.z, t)
            t += 1
          out(lin) = sum / run.nVolumes.toDouble
          lin += 1
      case _ =>
        var lin = 0
        while lin < nxyz do
          val voxel = run.space.indexToVoxel3D(lin)
          out(lin) = run(voxel.x, voxel.y, voxel.z, refIndex)
          lin += 1
    out

  private def refreshTemplate(
      ctx: EstimatorContext,
      initial: Array[Double],
      estimate: MotionEstimate
  ): Option[Array[Double]] =
    if !ctx.control.template.robustTemplate && !ctx.control.template.refreshValidOnly then None
    else
      val included = refreshedFrameMask(ctx, estimate)
      if ctx.run.nVolumes < 3 || countIncluded(included) == 0 then None
      else
        val out = Array.ofDim[Double](ctx.nxyz)
        val counts = Array.ofDim[Int](ctx.nxyz)
        val maps = Array.ofDim[MotionSampling.VoxelMap](ctx.run.nVolumes)
        var t = 0
        while t < ctx.run.nVolumes do
          if included(t) then
            maps(t) = MotionSampling.voxelMap(
              ctx.nx,
              ctx.ny,
              ctx.nz,
              zpad = 0,
              ctx.px,
              ctx.py,
              ctx.pz,
              estimate.trace.unsafeFrame(t)
            )
          t += 1

        val frameIds = Vector.tabulate(ctx.run.nVolumes)(identity).filter(included)
        val contributions =
          mapFrames(ctx, frameIds) { frame =>
            templateContribution(ctx, maps(frame), frame)
          }
        var c = 0
        while c < contributions.length do
          val contribution = contributions(c)
          var lin = 0
          while lin < ctx.nxyz do
            out(lin) += contribution.values(lin)
            counts(lin) += contribution.counts(lin)
            lin += 1
          c += 1

        var lin = 0
        while lin < ctx.nxyz do
          if counts(lin) > 0 then out(lin) /= counts(lin).toDouble
          else out(lin) = initial(lin)
          lin += 1
        Some(out)

  private final case class TemplateContribution(values: Array[Double], counts: Array[Int])

  private def templateContribution(
      ctx: EstimatorContext,
      map: MotionSampling.VoxelMap,
      frame: Int
  ): TemplateContribution =
    val values = Array.ofDim[Double](ctx.nxyz)
    val counts = Array.ofDim[Int](ctx.nxyz)
    var lin = 0
    while lin < ctx.nxyz do
      val k = lin % ctx.nz
      val xy = lin / ctx.nz
      val j = xy % ctx.ny
      val i = xy / ctx.ny
      val sx = MotionSampling.sourceX(map, i, j, k)
      val sy = MotionSampling.sourceY(map, i, j, k)
      val sz = MotionSampling.sourceZ(map, i, j, k)
      if inBounds(ctx, sx, sy, sz) then
        values(lin) = MotionSampling.trilinear(
          ctx.run.values,
          ctx.nx,
          ctx.ny,
          ctx.nz,
          frame,
          sx,
          sy,
          sz,
          zeroPad = false
        )
        counts(lin) = 1
      lin += 1
    TemplateContribution(values, counts)

  private def mapFrames[A, B](ctx: EstimatorContext, values: Vector[A])(f: A => B): Vector[B] =
    if ctx.control.execution.policy == ExecutionPolicy.ParallelFrames then
      MotionPlatform.mapOrdered(values, ctx.control.execution.nThreads)(f)
    else values.map(f)

  private def refreshedFrameMask(ctx: EstimatorContext, estimate: MotionEstimate): Array[Boolean] =
    val out = Array.fill(ctx.run.nVolumes)(true)
    if ctx.control.template.refreshValidOnly then
      var t = 0
      while t < out.length do
        val d = estimate.diagnostics(t)
        out(t) = d.converged && d.costFinal.isFinite && d.overlap >= 0.5
        t += 1

    if ctx.control.template.robustTemplate then
      val costs = Vector.newBuilder[Double]
      var t = 0
      while t < out.length do
        val c = estimate.diagnostics(t).costFinal
        if out(t) && c.isFinite then costs += c
        t += 1
      val finite = costs.result().sorted
      if finite.nonEmpty then
        val med = MotionMetrics.quantileSorted(finite, 0.5)
        val deviations = finite.map(c => math.abs(c - med)).sorted
        val mad = MotionMetrics.quantileSorted(deviations, 0.5)
        // The MAD floor is relative to the median cost, so it is intensity-scale invariant.
        val threshold = med + 3.0 * math.max(mad, 1e-12 * math.abs(med))
        t = 0
        while t < out.length do
          out(t) = out(t) && estimate.diagnostics(t).costFinal <= threshold
          t += 1

    if !out.exists(identity) then out(ctx.referenceIndex) = true
    out

  private def countIncluded(included: Array[Boolean]): Int =
    var n = 0
    var i = 0
    while i < included.length do
      if included(i) then n += 1
      i += 1
    n

  private def referenceIndex(run: SomeScalarSeries[Double], strategy: ReferenceStrategy): Either[MotionError, Int] =
    strategy match
      case ReferenceStrategy.Middle | ReferenceStrategy.RobustMean =>
        Right(run.nVolumes / 2)
      case ReferenceStrategy.Frame(index) =>
        val i = index.value
        if i >= 0 && i < run.nVolumes then Right(i)
        else Left(MotionError.FrameIndexOutOfBounds(i, run.nVolumes))

  private def buildPyramidLevels(
      run: SomeScalarSeries[Double],
      mask: Option[SomeMaskVolume],
      control: MotionControl
  ): Either[MotionError, Vector[PyramidLevel]] =
    buildCandidateSamples(run, mask, control).map { all =>
      val pyramid = control.pyramid
      if pyramid.enabled then
        val levels = Vector.newBuilder[PyramidLevel]
        var i = 0
        while i < pyramid.downsample.length do
          val stride = pyramid.downsample(i)
          val coarse = strideSamples(all, stride)
          val candidates = if coarse.isEmpty then all else coarse
          val samples = subsample(candidates, scheduleAt(pyramid.sampleCounts, i))
          levels += PyramidLevel(stride, scheduleAt(pyramid.maxIterations, i), samples)
          i += 1
        levels.result()
      else
        Vector(
          PyramidLevel(
            downsample = 1,
            maxIterations = pyramid.maxIterations.lastOption.getOrElse(12),
            samples = subsample(all, pyramid.sampleCounts.lastOption.getOrElse(all.length))
          )
        )
    }

  private def buildCandidateSamples(
      run: SomeScalarSeries[Double],
      mask: Option[SomeMaskVolume],
      control: MotionControl
  ): Either[MotionError, Vector[SamplePoint]] =
    val dims = run.space.spatialDims
    val nx = dims(0)
    val ny = dims(1)
    val nz = dims(2)
    val edgeX = math.floor(nx.toDouble * control.template.edgeExcludeFraction).toInt
    val edgeY = math.floor(ny.toDouble * control.template.edgeExcludeFraction).toInt
    val edgeZ = math.floor(nz.toDouble * control.template.edgeExcludeFraction).toInt
    val builder = Vector.newBuilder[SamplePoint]
    var k = 0
    while k < nz do
      var j = 0
      while j < ny do
        var i = 0
        while i < nx do
          val lin = (i * ny + j) * nz + k
          val inMask = mask.forall(_(i, j, k))
          val inInterior =
            i >= edgeX && i < nx - edgeX &&
              j >= edgeY && j < ny - edgeY &&
              k >= edgeZ && k < nz - edgeZ
          if inMask && inInterior then builder += SamplePoint(i, j, k, lin)
          i += 1
        j += 1
      k += 1

    val all = builder.result()
    if all.isEmpty then Left(MotionError.ShapeMismatch("estimation mask", Vector(1), Vector(0)))
    else Right(applyStencil(run, all, control.stencil))

  private def applyStencil(
      run: SomeScalarSeries[Double],
      samples: Vector[SamplePoint],
      control: StencilControl
  ): Vector[SamplePoint] =
    control.policy match
      case StencilPolicy.Dense => samples
      case StencilPolicy.InformationContent(stencil) =>
        informationContentSamples(run, samples, stencil)

  private def informationContentSamples(
      run: SomeScalarSeries[Double],
      samples: Vector[SamplePoint],
      stencil: InformationContentStencil
  ): Vector[SamplePoint] =
    val target = math.min(samples.length, stencil.sampleCount)
    if target >= samples.length then samples
    else
      val dims = run.space.spatialDims
      val nx = dims(0)
      val ny = dims(1)
      val nz = dims(2)
      val nxyz = nx * ny * nz
      val binCount = stencil.bins.x * stencil.bins.y * stencil.bins.z
      val builders = Array.fill(binCount)(Vector.newBuilder[ScoredSample])
      val weights = Array.fill(binCount)(0.0)
      var s = 0
      while s < samples.length do
        val sample = samples(s)
        val score = informationScore(run, sample, nx, ny, nz)
        val b = stencilBin(sample, nx, ny, nz, stencil.bins)
        builders(b) += ScoredSample(sample, score)
        weights(b) += math.pow(score + 1e-12, stencil.gamma)
        s += 1

      val bins =
        Vector.tabulate(binCount) { b =>
          builders(b).result().sortBy(scored => (-scored.score, scored.sample.ordinal))
        }
      val order =
        bins.indices
          .filter(b => bins(b).nonEmpty)
          .toVector
          .sortBy(b => (-weights(b), b))
      val positions = Array.fill(binCount)(0)
      val out = Vector.newBuilder[SamplePoint]
      var emitted = 0
      var progressed = true
      while emitted < target && progressed do
        progressed = false
        var oi = 0
        while oi < order.length && emitted < target do
          val b = order(oi)
          val p = positions(b)
          if p < bins(b).length then
            out += bins(b)(p).sample
            positions(b) = p + 1
            emitted += 1
            progressed = true
          oi += 1
      out.result()

  private def informationScore(
      run: SomeScalarSeries[Double],
      sample: SamplePoint,
      nx: Int,
      ny: Int,
      nz: Int
  ): Double =
    val center = meanAt(run, sample.ordinal)
    var sum = 0.0
    var n = 0
    def addNeighbor(i: Int, j: Int, k: Int): Unit =
      val lin = (i * ny + j) * nz + k
      sum += meanAt(run, lin)
      n += 1

    if sample.i > 0 then addNeighbor(sample.i - 1, sample.j, sample.k)
    if sample.i < nx - 1 then addNeighbor(sample.i + 1, sample.j, sample.k)
    if sample.j > 0 then addNeighbor(sample.i, sample.j - 1, sample.k)
    if sample.j < ny - 1 then addNeighbor(sample.i, sample.j + 1, sample.k)
    if sample.k > 0 then addNeighbor(sample.i, sample.j, sample.k - 1)
    if sample.k < nz - 1 then addNeighbor(sample.i, sample.j, sample.k + 1)
    if n == 0 then 0.0
    else math.abs(center - sum / n.toDouble)

  private def meanAt(run: SomeScalarSeries[Double], linear: Int): Double =
    val voxel = run.space.indexToVoxel3D(linear)
    var t = 0
    var sum = 0.0
    while t < run.nVolumes do
      sum += run(voxel.x, voxel.y, voxel.z, t)
      t += 1
    sum / run.nVolumes.toDouble

  private def stencilBin(
      sample: SamplePoint,
      nx: Int,
      ny: Int,
      nz: Int,
      bins: StencilBins
  ): Int =
    val bx = math.min(bins.x - 1, (sample.i.toLong * bins.x.toLong / nx.toLong).toInt)
    val by = math.min(bins.y - 1, (sample.j.toLong * bins.y.toLong / ny.toLong).toInt)
    val bz = math.min(bins.z - 1, (sample.k.toLong * bins.z.toLong / nz.toLong).toInt)
    bx + bins.x * (by + bins.y * bz)

  private def strideSamples(samples: Vector[SamplePoint], stride: Int): Vector[SamplePoint] =
    if stride <= 1 then samples
    else
      val out = Vector.newBuilder[SamplePoint]
      var i = 0
      while i < samples.length do
        val sample = samples(i)
        if sample.i % stride == 0 && sample.j % stride == 0 && sample.k % stride == 0 then out += sample
        i += 1
      out.result()

  private def scheduleAt(values: Vector[Int], index: Int): Int =
    if values.length == 1 then values.head
    else values(math.min(index, values.length - 1))

  private def subsample(samples: Vector[SamplePoint], target: Int): Vector[SamplePoint] =
    if target <= 0 || target >= samples.length then samples
    else
      val out = Vector.newBuilder[SamplePoint]
      val step = samples.length.toDouble / target.toDouble
      var p = 0
      var last = -1
      while p < target do
        val idx = math.min(samples.length - 1, math.floor(p.toDouble * step).toInt)
        if idx != last then
          out += samples(idx)
          last = idx
        p += 1
      out.result()

  private def validateFiniteRun(run: SomeScalarSeries[Double]): Either[MotionError, Unit] =
    val dims = run.space.spatialDims
    var linear = 0
    var t = 0
    while t < run.nVolumes do
      var k = 0
      while k < dims(2) do
        var j = 0
        while j < dims(1) do
          var i = 0
          while i < dims(0) do
            if !run(i, j, k, t).isFinite then
              return Left(MotionError.NonFiniteData("run", linear))
            linear += 1
            i += 1
          j += 1
        k += 1
      t += 1
    Right(())

  private def inBounds(ctx: EstimatorContext, x: Double, y: Double, z: Double): Boolean =
    x >= 0.0 && x <= (ctx.nx - 1).toDouble &&
      y >= 0.0 && y <= (ctx.ny - 1).toDouble &&
      z >= 0.0 && z <= (ctx.nz - 1).toDouble

  /** Absolute Huber threshold for one frame against one template. With
    * `HuberScale.RobustResidual` it is `huberK * 1.4826 * MAD` of the frame's
    * residuals at `pose` over the diagnostic samples, covariant with the
    * intensity scale. A MAD at or below round-off (`1e-9` of the residual RMS)
    * means more than half the residuals are identical. The scale then falls
    * back to the MAD of the deviations above round-off
    * (exactly matching background), to the residual RMS when all residuals are
    * equal (a pure intensity offset), and for an exact match to `1e-12` of the
    * mean absolute template value. All fallbacks are covariant.
    */
  private def huberThreshold(ctx: EstimatorContext, template: Array[Double], frame: Int, pose: RigidPose): Double =
    ctx.control.optimizer.huberScale match
      case HuberScale.Absolute => ctx.control.optimizer.huberK
      case HuberScale.RobustResidual =>
        val level = ctx.diagnosticLevel
        val map = MotionSampling.voxelMap(ctx.nx, ctx.ny, ctx.nz, zpad = 0, ctx.px, ctx.py, ctx.pz, pose)
        val residuals = Array.ofDim[Double](level.samples.length)
        var count = 0
        var templateMagnitude = 0.0
        var squares = 0.0
        var s = 0
        while s < level.samples.length do
          val sample = level.samples(s)
          val sx = MotionSampling.sourceX(map, sample.i, sample.j, sample.k)
          val sy = MotionSampling.sourceY(map, sample.i, sample.j, sample.k)
          val sz = MotionSampling.sourceZ(map, sample.i, sample.j, sample.k)
          if inBounds(ctx, sx, sy, sz) then
            val fitted =
              MotionSampling.trilinear(ctx.run.values, ctx.nx, ctx.ny, ctx.nz, frame, sx, sy, sz, zeroPad = false)
            residuals(count) = fitted - template(sample.ordinal)
            squares += residuals(count) * residuals(count)
            templateMagnitude += math.abs(template(sample.ordinal))
            count += 1
          s += 1
        var scale = 0.0
        var informative = 0.0
        val rms = if count == 0 then 0.0 else math.sqrt(squares / count)
        // Scale-covariant round-off level: deviations below it are rounding noise
        // (for example (a + c) - a != c exactly), not residual spread.
        val noise = 1e-9 * rms
        if count > 0 then
          val used = java.util.Arrays.copyOf(residuals, count)
          java.util.Arrays.sort(used)
          val median = sortedMedian(used, count)
          val deviations = Array.ofDim[Double](count)
          var i = 0
          while i < count do
            deviations(i) = math.abs(used(i) - median)
            i += 1
          java.util.Arrays.sort(deviations)
          scale = 1.4826 * sortedMedian(deviations, count)
          var firstPositive = 0
          while firstPositive < count && deviations(firstPositive) <= noise do firstPositive += 1
          if firstPositive < count then
            val positive = java.util.Arrays.copyOfRange(deviations, firstPositive, count)
            informative = 1.4826 * sortedMedian(positive, count - firstPositive)
        val floor = if count == 0 then 0.0 else 1e-12 * templateMagnitude / count
        val chosen =
          if scale > noise then scale
          else if informative > noise then informative
          else if rms > 0.0 then rms
          else if floor > 0.0 then floor
          else 1.0
        ctx.control.optimizer.huberK * chosen

  private def sortedMedian(sorted: Array[Double], length: Int): Double =
    if length % 2 == 1 then sorted(length / 2) else 0.5 * (sorted(length / 2 - 1) + sorted(length / 2))

  /** A line search that exhausted its halvings is resolved when its final step
    * is already negligible. The step compared is the untried `step / 64`, so a
    * Gauss-Newton step up to 64 times `stepTolerance` still counts as resolved.
    */
  private[motion] def lineSearchResolved(finalStepNorm: Double, stepTolerance: Double): Boolean =
    finalStepNorm <= stepTolerance

  private def huberLoss(residual: Double, k: Double): Double =
    val a = math.abs(residual)
    if a <= k then 0.5 * residual * residual
    else k * (a - 0.5 * k)

  private def huberWeight(residual: Double, k: Double): Double =
    val a = math.abs(residual)
    if a <= k || a == 0.0 then 1.0 else k / a

  private def addStep(pose: RigidPose, step: Array[Double]): RigidPose =
    RigidPose.unsafe(
      pose.tx + step(0),
      pose.ty + step(1),
      pose.tz + step(2),
      pose.rx + step(3),
      pose.ry + step(4),
      pose.rz + step(5)
    )

  private def addOne(pose: RigidPose, index: Int, delta: Double): RigidPose =
    index match
      case 0 => RigidPose.unsafe(pose.tx + delta, pose.ty, pose.tz, pose.rx, pose.ry, pose.rz)
      case 1 => RigidPose.unsafe(pose.tx, pose.ty + delta, pose.tz, pose.rx, pose.ry, pose.rz)
      case 2 => RigidPose.unsafe(pose.tx, pose.ty, pose.tz + delta, pose.rx, pose.ry, pose.rz)
      case 3 => RigidPose.unsafe(pose.tx, pose.ty, pose.tz, pose.rx + delta, pose.ry, pose.rz)
      case 4 => RigidPose.unsafe(pose.tx, pose.ty, pose.tz, pose.rx, pose.ry + delta, pose.rz)
      case _ => RigidPose.unsafe(pose.tx, pose.ty, pose.tz, pose.rx, pose.ry, pose.rz + delta)

  private def limitStep(step: Array[Double]): Array[Double] =
    val out = step.clone()
    var i = 0
    while i < 3 do
      out(i) = math.max(-1.0, math.min(1.0, out(i)))
      i += 1
    while i < 6 do
      out(i) = math.max(-0.05, math.min(0.05, out(i)))
      i += 1
    out

  private def shrinkLowMotionPose(ctx: EstimatorContext, pose: RigidPose): RigidPose =
    val temporal = ctx.control.temporal
    if temporal.lowMotionPoseShrink && poseStepNorm(poseComponents(pose)) <= temporal.lowMotionThresholdMm then
      RigidPose.unsafe(
        pose.tx * temporal.lowMotionPoseScale,
        pose.ty * temporal.lowMotionPoseScale,
        pose.tz * temporal.lowMotionPoseScale,
        pose.rx * temporal.lowMotionPoseScale,
        pose.ry * temporal.lowMotionPoseScale,
        pose.rz * temporal.lowMotionPoseScale
      )
    else pose

  private def poseComponents(pose: RigidPose): Array[Double] =
    Array(pose.tx, pose.ty, pose.tz, pose.rx, pose.ry, pose.rz)

  private def poseStepNorm(step: Array[Double], radius: Double = 50.0): Double =
    math.sqrt(
      step(0) * step(0) +
        step(1) * step(1) +
        step(2) * step(2) +
        radius * radius * (step(3) * step(3) + step(4) * step(4) + step(5) * step(5))
    )

  private val DampingFloor = 1e-6
  private val RelativePivotTolerance = 1e-12

  /** Solve the damped 6x6 Gauss-Newton system `h x = rhs` by Gale's Cholesky
    * factorization of the Jacobi-scaled matrix `D^-1/2 h D^-1/2`, which has a
    * unit diagonal. The pivot tolerance is therefore relative, and the solve
    * does not depend on the image intensity scale. Returns None when `h` is not
    * numerically positive definite at that tolerance.
    */
  private[motion] def solveNormal6(h: Array[Double], rhs: Array[Double]): Option[Array[Double]] =
    val n = 6
    val scale = new Array[Double](n)
    var d = 0
    while d < n do
      val diag = h(d * n + d)
      if !(diag > 0.0 && diag.isFinite) then return None
      scale(d) = 1.0 / math.sqrt(diag)
      d += 1
    val scaled = Matrix.tabulate(n, n)((r, c) => h(r * n + c) * scale(r) * scale(c))
    val b = Matrix.tabulate(n, 1)((r, _) => rhs(r) * scale(r))
    scaled
      .cholesky(CholeskyOptions(RelativePivotTolerance))
      .flatMap(_.solve(b))
      .toOption
      .map(y => Array.tabulate(n)(r => y(r, 0) * scale(r)))
      .filter(_.forall(_.isFinite))

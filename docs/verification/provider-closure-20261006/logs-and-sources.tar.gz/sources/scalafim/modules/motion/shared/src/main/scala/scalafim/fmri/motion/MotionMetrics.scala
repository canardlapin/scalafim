package scalafim.fmri.motion

import scalafim.image.SampleSpaces.*

import image4s.geometry.Affine
import image4s.geometry.D3
import scalafim.image.*

final case class DisplacementSummary(
    median: Double,
    p95: Double,
    max: Double
)

enum DvarsPolicy:
  case Raw
  case RobustClip3xMedian

final case class FramewiseDisplacementMetric private (pair: FramePair, value: FramewiseDisplacementMm):
  def millimeters: Double = value.value

object FramewiseDisplacementMetric:
  def unsafe(pair: FramePair, value: Double): FramewiseDisplacementMetric =
    new FramewiseDisplacementMetric(pair, FramewiseDisplacementMm.unsafe(value))

final case class DvarsMetric private (pair: FramePair, value: DvarsRms):
  def rms: Double = value.value

object DvarsMetric:
  def unsafe(pair: FramePair, value: Double): DvarsMetric =
    new DvarsMetric(pair, DvarsRms.unsafe(value))

object MotionMetrics:
  def framewiseDisplacementPairs(
      trace: MotionTrace,
      radius: HeadRadius = HeadRadius.default
  ): Vector[FramewiseDisplacementMetric] =
    val out = Vector.newBuilder[FramewiseDisplacementMetric]
    var t = 1
    while t < trace.length do
      val a = trace.poses(t)
      val b = trace.poses(t - 1)
      val value =
        math.abs(a.tx - b.tx) +
          math.abs(a.ty - b.ty) +
          math.abs(a.tz - b.tz) +
          radius.value * (
            math.abs(a.rx - b.rx) +
              math.abs(a.ry - b.ry) +
              math.abs(a.rz - b.rz)
          )
      out += FramewiseDisplacementMetric.unsafe(FramePair.unsafe(t - 1, t), value)
      t += 1
    out.result()

  def framewiseDisplacement(
      trace: MotionTrace,
      radius: HeadRadius = HeadRadius.default
  ): Vector[Double] =
    val out = Array.fill(trace.length)(0.0)
    val metrics = framewiseDisplacementPairs(trace, radius)
    var i = 0
    while i < metrics.length do
      val metric = metrics(i)
      out(metric.pair.current.value) = metric.value.value
      i += 1
    out.toVector

  def dvarsPairs(
      run: SomeScalarSeries[Double],
      mask: Option[SomeMaskVolume] = None,
      policy: DvarsPolicy = DvarsPolicy.Raw
  ): Either[MotionError, Vector[DvarsMetric]] =
    validateMask(run, mask).map { maskVol =>
      val dims = run.space.spatialDims
      val nt = run.nVolumes
      val values = Array.fill(nt)(Double.NaN)
      var t = 1
      while t < nt do
        var ss = 0.0
        var n = 0
        var k = 0
        while k < dims(2) do
          var j = 0
          while j < dims(1) do
            var i = 0
            while i < dims(0) do
              val include = maskVol.forall(_(i, j, k))
              if include then
                val a = run(i, j, k, t - 1)
                val b = run(i, j, k, t)
                val d = b - a
                ss += d * d
                n += 1
              i += 1
            j += 1
          k += 1
        if n > 0 then values(t) = math.sqrt(ss / n.toDouble)
        t += 1

      val transformed =
        policy match
          case DvarsPolicy.Raw => values
          case DvarsPolicy.RobustClip3xMedian => robustClip3xMedian(values)
      val out = Vector.newBuilder[DvarsMetric]
      t = 1
      while t < nt do
        if transformed(t).isFinite then out += DvarsMetric.unsafe(FramePair.unsafe(t - 1, t), transformed(t))
        t += 1
      out.result()
    }

  def dvars(run: SomeScalarSeries[Double]): Either[MotionError, Vector[Double]] =
    dvars(run, None, DvarsPolicy.Raw)

  def dvars(run: SomeScalarSeries[Double], mask: Option[SomeMaskVolume]): Either[MotionError, Vector[Double]] =
    dvars(run, mask, DvarsPolicy.Raw)

  def dvars(run: SomeScalarSeries[Double], robust: Boolean): Either[MotionError, Vector[Double]] =
    dvars(run, None, DvarsPolicy.fromRobustBoolean(robust))

  def dvars(
      run: SomeScalarSeries[Double],
      mask: Option[SomeMaskVolume],
      robust: Boolean
  ): Either[MotionError, Vector[Double]] =
    dvars(run, mask, DvarsPolicy.fromRobustBoolean(robust))

  def dvars(
      run: SomeScalarSeries[Double],
      mask: Option[SomeMaskVolume],
      policy: DvarsPolicy
  ): Either[MotionError, Vector[Double]] =
    dvarsPairs(run, mask, policy).map { metrics =>
      val out = Array.fill(run.nVolumes)(Double.NaN)
      var i = 0
      while i < metrics.length do
        val metric = metrics(i)
        out(metric.pair.current.value) = metric.value.value
        i += 1
      out.toVector
    }

  def transformDisplacement(
      motion: RigidPose,
      radius: HeadRadius = HeadRadius.default,
      reference: Option[RigidPose] = None
  ): Double =
    val points = radiusCube(radius.value)
    val mat = motion.toAffine
    val ref = reference.map(_.toAffine)
    var i = 0
    var sum = 0.0
    while i < points.length do
      val mapped = apply3(mat, points(i))
      val target = ref.map(apply3(_, points(i))).getOrElse(points(i))
      sum += distance(mapped, target)
      i += 1
    sum / points.length.toDouble

  def maskedDisplacements(
      mask: SomeMaskVolume,
      motion: RigidPose,
      reference: Option[RigidPose] = None
  ): Vector[Double] =
    val mat = motion.toAffine
    val ref = reference.map(_.toAffine)
    val n = mask.space.spatialDims.product
    val out = Vector.newBuilder[Double]
    var lin = 0
    while lin < n do
      if mask.valueAtCanonicalOrdinal(lin) then
        val grid = mask.space.indexToGrid3D(lin).map(_.toDouble)
        val point = mask.space.indexToCoord(grid)
        val mapped = apply3(mat, point)
        val target = ref.map(apply3(_, point)).getOrElse(point)
        out += distance(mapped, target)
      lin += 1
    out.result()

  def maskedDisplacementSummary(
      mask: SomeMaskVolume,
      motion: RigidPose,
      reference: Option[RigidPose] = None
  ): Either[MotionError, DisplacementSummary] =
    val values = maskedDisplacements(mask, motion, reference).filter(_.isFinite).sorted
    if values.isEmpty then Left(MotionError.ShapeMismatch("mask", Vector(1), Vector(0)))
    else
      Right(
        DisplacementSummary(
          median = quantileSorted(values, 0.5),
          p95 = quantileSorted(values, 0.95),
          max = values.last
        )
      )

  private[motion] def validateMask(
      run: SomeScalarSeries[Double],
      mask: Option[SomeMaskVolume]
  ): Either[MotionError, Option[SomeMaskVolume]] =
    mask match
      case None => Right(None)
      case Some(m) =>
        if m.space.spatialDims != run.space.spatialDims then
          Left(MotionError.ShapeMismatch("mask", run.space.spatialDims, m.space.spatialDims))
        else Right(mask)

  private[motion] def robustClip3xMedian(values: Array[Double]): Array[Double] =
    val finite = values.filter(_.isFinite).sorted
    if finite.isEmpty then values.clone()
    else
      val med = quantileSorted(finite.toVector, 0.5)
      val cap = 3.0 * med
      val out = values.clone()
      var i = 0
      while i < out.length do
        if out(i).isFinite && out(i) > cap then out(i) = cap
        i += 1
      out

  private[motion] def quantileSorted(values: Vector[Double], p: Double): Double =
    require(values.nonEmpty, "values must be non-empty")
    if values.length == 1 then values.head
    else
      val h = (values.length - 1).toDouble * p
      val lo = math.floor(h).toInt
      val hi = math.ceil(h).toInt
      if lo == hi then values(lo)
      else
        val w = h - lo.toDouble
        values(lo) * (1.0 - w) + values(hi) * w

  private def radiusCube(radius: Double): Array[Vector[Double]] =
    Array(
      Vector(radius, radius, radius),
      Vector(radius, radius, -radius),
      Vector(radius, -radius, radius),
      Vector(radius, -radius, -radius),
      Vector(-radius, radius, radius),
      Vector(-radius, radius, -radius),
      Vector(-radius, -radius, radius),
      Vector(-radius, -radius, -radius)
    )

  private def apply3(affine: Affine[D3], point: Vector[Double]): Vector[Double] =
    affine(point).fold(
      error => throw new IllegalStateException(error.message),
      identity
    )

  private def distance(a: Vector[Double], b: Vector[Double]): Double =
    val dx = a(0) - b(0)
    val dy = a(1) - b(1)
    val dz = a(2) - b(2)
    math.sqrt(dx * dx + dy * dy + dz * dz)

object DvarsPolicy:
  def fromRobustBoolean(robust: Boolean): DvarsPolicy =
    if robust then DvarsPolicy.RobustClip3xMedian else DvarsPolicy.Raw

# scalafim-surface

`scalafim-surface` is the renderer-free surface-mesh layer for ScalaFIM. It
ports the useful data-structure and algorithmic ideas from `neurosurf` into a
Scala 3 shape: typed ids, immutable values, explicit topology views, pure
algorithms, cross-platform GIFTI ingestion, and JVM-only FreeSurfer readers.

```scala
import scalafim.surface.*
```

Platform readers live in a platform package:

```scala
import scalafim.surface.io.*
```

## Scope

The shared module cross-compiles to JVM and Scala.js and contains:

- `VertexId` and `FaceId` opaque ids over zero-based mesh indices.
- `TriangleMesh`, `Point3D` (an alias for `scalafim.image.SpatialPoint`),
  `Triangle`, and `SurfaceGeometry`.
- `Hemisphere`, `SurfaceKind`, `SurfaceSet`, and `HemispherePair`.
- `MeshTopology` derived from triangle faces: edges, neighbors, edge lengths,
  face areas, normals, Euler characteristic, and a non-retained `toGraph`
  interop value with distance-typed edges.
- Vertex-indexed containers: `SurfaceField`, `SurfaceMatrix`, `SurfaceRoi`,
  and `LabeledSurface`.
- `VolToSurfMorphism` and `SurfToSurfMorphism` wrappers for reusable
  volume-to-surface sampling plans and explicit surface-to-surface vertex maps.
- Pure algorithms for connected components, thresholded clusters, geodesic and
  spherical neighborhoods, parcel representatives, parcel distances, and parcel
  boundary contacts.
- `FramedSurface[F]`: vertex coordinates typed in a world frame `F` from
  `scalafim.image.world`, so tkRAS and scanner-RAS surfaces cannot be mixed.
  `toScanner`/`toTkRas` move FreeSurfer surfaces with `Norig * inverse(Torig)`
  of a `FreeSurferVolumeGeometry`; `transport` takes any typed reframe4s map.
- Cortical-ribbon operators on a `GridSpec[F]` in the same frame:
  `RibbonOperator` compiles neurotransform's white-to-pial trilinear ribbon
  weights `W` (vertex x voxel), with `sample` (`W v`, volume to surface),
  `adjoint` (`Wᵀ s`, surface to volume) and `project` (adjoint or weighted-mean
  ribbon fill); `RibbonMask` marks voxel centres inside the closed pial and
  outside the closed white surface.
- Sphere resampling: `SphereMesh` (`isSphere`, `withRadius`) and
  `SurfaceResampling` (barycentric on the radial ray with nearest-vertex
  fallback, or nearest vertex; `Element`/`Sum`/`None` normalisation and the
  exact adjoint).
- Stock template domains: `TemplateMesh` (fsaverage 5/6/7, fsLR 32k/59k/164k
  with their TemplateFlow counts), `TemplateSurface` (one hemisphere of one),
  and `TemplateSphere[R]`, a mesh on the registration sphere `R`
  (`SphereRegistration.FsAverage` or `FsLR`, a singleton type, so meshes on
  different spheres cannot be paired). `TemplateResampling.plan` builds
  fsaverage <-> fsLR plans through the fsLR meshes deformed onto the fsaverage
  sphere, as Workbench does; `TemplateSphereAssets` pins the 18 TemplateFlow
  sphere files by SHA-256. On the JVM, `TemplateSphereFiles` loads them from a
  local TemplateFlow cache (`TemplateFlowCache`, read-only). Against Workbench
  2.2.1 `-metric-resample BARYCENTRIC` the gated budgets are 5e-5 on smooth
  fields and on 99% of seeded values (1e-3 at most); measured maxima are 6e-7
  and 2.4e-5. These parity tests need the TemplateFlow spheres locally and are
  skipped, not failed, without them.

The platform modules add matching GIFTI APIs:

- `GiftiReader` for typed GIFTI documents, metadata, label tables,
  coordinate-system transforms, and ASCII/Base64/GZip-Base64 `DataArray`
  payloads. Decoded payloads expose `GiftiVector` and `GiftiMatrix` views so
  row-major and column-major indexing are explicit.
- `GiftiSurfaceReader` adapters from GIFTI POINTSET/TRIANGLE geometry and
  LABEL/NODE_INDEX data into `SurfaceGeometry` and `LabeledSurface`.
- JVM entry points read `Path` values synchronously, including outer
  `.gii.gz` files. Scala.js entry points read `Uint8Array` values
  asynchronously, accept raw `.gii` or gzip-wrapped bytes, and work in browser
  windows and workers through the standard `DecompressionStream` boundary.

The JVM module additionally adds:

- `FreeSurferSurfaceReader` for FreeSurfer/SUMA ASCII and binary triangle
  geometry.

## Conventions

Faces and vertices are zero-based internally. FreeSurfer ASCII, FreeSurfer
binary, and GIFTI triangle indices are preserved as zero-based indices when
loaded into `TriangleMesh`.

`TriangleMesh` stores only geometry. `MeshTopology` is a derived view over the
mesh, so graph-like queries do not become a second source of truth.
`MeshTopology.toGraph` materializes an immutable graph on demand; callers may
reuse that value, but `MeshTopology` does not retain a parallel full topology.
Thresholded components share one surface-local filtered traversal rather than
allocating induced graphs per field.

`SurfaceGeometry.surfaceToWorld` stores a 4x4 affine. Readers use identity when
the source format has no usable transform.

## Examples

Build a mesh and topology:

```scala
val mesh =
  TriangleMesh.fromRows(
    vertices = Vector(
      Vector(0.0, 0.0, 0.0),
      Vector(1.0, 0.0, 0.0),
      Vector(0.0, 1.0, 0.0)
    ),
    faces = Vector((0, 1, 2))
  )

val geometry = SurfaceGeometry(mesh, Hemisphere.Left, SurfaceKind.Pial)
val topology = MeshTopology.from(mesh)
val neighborsOfZero = topology.neighborsOf(VertexId(0))
```

Attach vertex data:

```scala
val field =
  SurfaceField.full(
    geometry,
    data = Vector(0.2, 1.5, -0.7),
    label = "activation"
  )

val roi = SurfaceRoi.fromField(field, Vector(VertexId(1), VertexId(2)), "roi")
```

Query geodesic neighborhoods:

```scala
val hits =
  SurfaceGeodesics.neighborsWithin(
    topology,
    radius = 2.0,
    sources = Vector(VertexId(0)),
    metric = DistanceMetric.Geodesic
  )
```

Work with parcels:

```scala
val labels =
  LabeledSurface.fromIndexed(
    geometry,
    indices = Vector(VertexId(0), VertexId(1), VertexId(2)),
    labels = Vector(1, 1, 2),
    table = Vector(LabelInfo(1, "A"), LabelInfo(2, "B"))
  )

val parcels = SurfaceParcels.units(labels, topology)
val contacts = SurfaceParcels.boundaryContacts(parcels, topology)
```

Load geometry on the JVM:

```scala
val fs = FreeSurferSurfaceReader.read(java.nio.file.Path.of("lh.white"))
val gii = GiftiSurfaceReader.read(java.nio.file.Path.of("sub-01_hemi-L_pial.surf.gii"))
```

Load raw GIFTI bytes in Scala.js without choosing a serialized mesh format:

```scala
import scala.scalajs.js.typedarray.Uint8Array

def decode(bytes: Uint8Array) =
  GiftiSurfaceReader.read(
    bytes,
    Hemisphere.Left,
    SurfaceKind.Pial
  )
// Future[Either[GiftiError, SurfaceGeometry]]
```

The asynchronous boundary covers gzip/zlib inflation. The returned
`SurfaceGeometry` retains the GIFTI coordinate-system transform, so the
renderer or ingestion worker can choose its own transfer rendition.

Parse GIFTI explicitly when you need provenance-like payload inspection before
building a surface value:

```scala
val doc = GiftiReader.read(java.nio.file.Path.of("lh.aparc.label.gii"))
val labels = doc.flatMap(GiftiSurfaceReader.labeledSurface(_, gii, "aparc"))
val matrix = doc.flatMap(_.pointSet.toRight(GiftiError.MissingDataArray(GiftiIntent.PointSet))).flatMap(GiftiReader.doubleMatrix)
```

Compiled runnable examples live in
[`../../examples/surface-jvm`](../../examples/surface-jvm). They cover
FreeSurfer/GIFTI IO and labeled-surface parcel workflows:

```sh
sbt surfaceExamplesJVM/test
sbt "surfaceExamplesJVM/runMain scalafim.examples.surface.inspectExampleSurfaces"
sbt "surfaceExamplesJVM/runMain scalafim.examples.surface.summarizeSurfaceParcels"
```

## Migration Stance

This is not an S4 or plotting port. The target mapping from `neurosurf` is:

- `SurfaceGeometry` style mesh metadata -> `TriangleMesh` plus
  `SurfaceGeometry`.
- neighbor/graph helpers -> `MeshTopology`.
- vertex data, ROI, and label containers -> `SurfaceField`, `SurfaceMatrix`,
  `SurfaceRoi`, and `LabeledSurface`.
- cluster, neighborhood, geodesic, and parcel operations -> pure functions over
  the typed model.
- GIFTI geometry/label readers -> JVM and Scala.js platform IO; FreeSurfer
  geometry readers -> JVM-only IO.

Non-goals for this module:

- RGL, htmlwidgets, screenshots, camera state, and interactive viewers.
- Color-map rendering classes.
- Mutable graph-library objects as public data structures.
- Volume-to-surface projection until it can reuse `scalafim-image` spaces and
  affine transforms cleanly.

## Verification

Run the surface module directly:

```sh
sbt surfaceJVM/test
sbt surfaceJS/test
```

The deterministic fixture corpus is documented in
`tools/r-parity/surface-fixtures.md`; JVM IO resources are under
`modules/surface/jvm/src/test/resources/surface/`.

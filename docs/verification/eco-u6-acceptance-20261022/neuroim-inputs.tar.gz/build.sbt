import org.scalajs.sbtplugin.ScalaJSPlugin.autoImport.*
import sbtcrossproject.CrossPlugin.autoImport.*
import sbtcrossproject.CrossType
import scalajscrossproject.ScalaJSCrossPlugin.autoImport.*
ThisBuild / scalaVersion := "3.7.4"
lazy val provider = uri("https://github.com/canardlapin/neuroim4s.git#4f75c2bf141449d032f9fe3c558ef13a22a4d59f")
lazy val common = Seq(scalacOptions ++= Seq("-deprecation", "-feature", "-unchecked"), libraryDependencies += "org.scalameta" %%% "munit" % "1.2.1" % Test)
lazy val core = crossProject(JSPlatform, JVMPlatform).crossType(CrossType.Full).in(file("core"))
  .settings(common).jvmConfigure(_.dependsOn(ProjectRef(provider, "coreJVM"))).jsConfigure(_.dependsOn(ProjectRef(provider, "coreJS")))
lazy val transform = crossProject(JSPlatform, JVMPlatform).crossType(CrossType.Full).in(file("transform"))
  .settings(common).jvmConfigure(_.dependsOn(ProjectRef(provider, "transformJVM"))).jsConfigure(_.dependsOn(ProjectRef(provider, "transformJS")))
lazy val routing = crossProject(JSPlatform, JVMPlatform).crossType(CrossType.Full).in(file("routing"))
  .settings(common).jvmConfigure(_.dependsOn(ProjectRef(provider, "routingJVM"))).jsConfigure(_.dependsOn(ProjectRef(provider, "routingJS")))
lazy val root = project.in(file(".")).aggregate(core.jvm, core.js, transform.jvm, transform.js, routing.jvm, routing.js)
  .settings(publish / skip := true)

import org.scalajs.linker.interface.ModuleKind
import sbtcrossproject.CrossPlugin.autoImport.*
import sbtcrossproject.CrossType
import scalajscrossproject.ScalaJSCrossPlugin.autoImport.*
ThisBuild / scalaVersion := "3.7.4"
lazy val provider = uri("https://github.com/canardlapin/neuroatlas4s.git#4df875d8a1cd20afd3b83ed49446422bc507e5ec")
lazy val settings = Seq(scalacOptions ++= Seq("-deprecation", "-feature", "-unchecked", "-Werror"), Test / fork := false,
  libraryDependencies += "org.scalameta" %%% "munit" % "1.2.1" % Test)
lazy val catalog = crossProject(JSPlatform, JVMPlatform).crossType(CrossType.Full).in(file("catalog"))
  .settings(settings)
  .jvmConfigure(_.dependsOn(ProjectRef(provider, "coreJVM")))
  .jsConfigure(_.dependsOn(ProjectRef(provider, "coreJS")))
  .jsSettings(scalaJSLinkerConfig ~= (_.withModuleKind(ModuleKind.CommonJSModule)))
lazy val surface = crossProject(JSPlatform, JVMPlatform).crossType(CrossType.Full).in(file("surface"))
  .settings(settings, Test / unmanagedSources += file("fixtures/SurfaceFixture.scala"))
  .jvmConfigure(_.dependsOn(ProjectRef(provider, "surfaceJVM")))
  .jsConfigure(_.dependsOn(ProjectRef(provider, "surfaceJS")))
  .jsSettings(scalaJSLinkerConfig ~= (_.withModuleKind(ModuleKind.CommonJSModule)))
lazy val routes = crossProject(JSPlatform, JVMPlatform).crossType(CrossType.Full).in(file("routes"))
  .settings(settings)
  .jvmConfigure(_.dependsOn(ProjectRef(provider, "routingJVM")))
  .jsConfigure(_.dependsOn(ProjectRef(provider, "routingJS")))
  .jsSettings(scalaJSLinkerConfig ~= (_.withModuleKind(ModuleKind.CommonJSModule)))
lazy val surfaceIo = project.in(file("surface-io"))
  .settings(settings, Test / unmanagedSources += file("fixtures/SurfaceFixture.scala"))
  .dependsOn(ProjectRef(provider, "surfaceIoJVM"))
lazy val root = project.in(file(".")).aggregate(catalog.jvm, catalog.js, surface.jvm, surface.js, routes.jvm, routes.js, surfaceIo)

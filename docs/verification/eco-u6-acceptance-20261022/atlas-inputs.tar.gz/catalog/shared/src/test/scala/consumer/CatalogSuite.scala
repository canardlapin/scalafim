package consumer
import neuroatlas4s.*

class CatalogSuite extends munit.FunSuite:
  test("catalog metadata and typed admission failures require only core"):
    val ref = Schaefer2018Surface(SchaeferParcels.P100, YeoNetworks.Seven, StandardSurface.FsAverage6).atlasRef(Confidence.Exact)
    assertEquals(ref.templateSpace, SpaceId.FsAverage6)
    assertEquals(ref.parcelVariant, Some("100Parcels_7Networks"))
    val error = AtlasRealizationError.Publication(AtlasPublicationError.AtlasProvenanceMismatch("explicit mismatch"))
    assertEquals(error.message, "atlasProvenance: explicit mismatch")

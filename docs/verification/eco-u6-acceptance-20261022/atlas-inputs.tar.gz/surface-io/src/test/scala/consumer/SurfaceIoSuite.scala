package consumer
import neuroatlas4s.*
import neuroatlas4s.io.*
import neurosurf4s.surface.{Hemisphere as H, *}
import java.nio.file.Files

class SurfaceIoSuite extends munit.FunSuite:
  test("GIFTI loading preserves labels and resolved source digests without a volume runtime"):
    def xml(id: Int): String = s"""<GIFTI Version="1.0" NumberOfDataArrays="1"><LabelTable><Label Key="$id" Red="1" Green="0" Blue="0" Alpha="1">Parcel$id</Label></LabelTable><DataArray Intent="NIFTI_INTENT_LABEL" DataType="NIFTI_TYPE_INT32" ArrayIndexingOrder="RowMajorOrder" Dimensionality="1" Dim0="3" Encoding="ASCII" Endian="LittleEndian"><Data>$id $id 0</Data></DataArray></GIFTI>"""
    val dir = Files.createTempDirectory("atlas-public-consumer-")
    val left = dir.resolve("left.label.gii")
    val right = dir.resolve("right.label.gii")
    try
      Files.writeString(left, xml(10)); Files.writeString(right, xml(20))
      val atlas = SurfaceGiftiAtlasLoader.loadFromPathsEither(SurfaceFixture.ref,
        SurfaceGiftiAtlasLoader.Geometry(SurfaceFixture.geometry(H.Left), SurfaceFixture.geometry(H.Right)),
        SurfaceGiftiAtlasLoader.Paths(left, right)).toOption.get
      assertEquals(atlas.labelIdAt(H.Left, VertexId(0)), Some(RegionId(10)))
      assertEquals(atlas.labelIdAt(H.Right, VertexId(2)), None)
      val sources = atlas.provenance.sourceArtifacts.filter(_.localPath.nonEmpty)
      assertEquals(sources.size, 2)
      for source <- sources do
        assertEquals(source.digest.map(_.value), Some(AtlasAsset.sha256(java.nio.file.Path.of(source.localPath.get))))
    finally
      Files.deleteIfExists(left); Files.deleteIfExists(right); Files.deleteIfExists(dir)

from pathlib import Path
import json,re,subprocess,hashlib,sys,importlib.util,collections
base=Path('/Volumes/My Passport for Mac/codex-work/scalafim-eco-u6-20261022')
root=base/'acceptance-clone-25';log=Path('/tmp/scalafim-eco-u6-resume-51.log');text=log.read_text() if log.exists() else ''
source='616860a2e14eb42b800462cd3d2f4fe4203f641a';prefix_source='31a42a69004c6282e01ad939c370f249fdf5e604'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==source
assert not subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True)
build_text=(root/'build.sbt').read_text()
spec=importlib.util.spec_from_file_location('inventory',root/'tools/ci/check_test_inventory.py');inventory=importlib.util.module_from_spec(spec);spec.loader.exec_module(inventory)
commands=inventory.release_batches((root/'tools/ci/full-repository-tests.sh').read_text())
def expand(target):
 if target=='ecosystemBoundaries':return [target]
 if target.endswith('/test'):return [target]
 marker='addCommandAlias("'+target+'",'
 pos=build_text.index(marker);tail=build_text[pos+len(marker):];block=tail.split('addCommandAlias(',1)[0]
 provider=re.search(r'\$\{(\w+)Build\}',block)[1]
 seq=re.search(r'Seq\(([^)]*)\)',block)
 if seq: projects=re.findall(r'"(\w+)"',seq[1])
 else:projects=re.findall(r'\}\}(\w+)/test',block)
 assert projects,(target,block)
 return [provider+':'+p+'/test' for p in projects]
expanded={name:[p for target in targets for p in expand(target)] for name,targets in commands.items()}
empty={'mvpa4s:consumerJVM/test':'Pinned examples/consumer has one main source and no test sources; compilation only, independently executed public behavior is in receipt40.', 'mvpa4s:consumerJS/test':'Same pinned pure consumer source, JS compilation/link only; no behavioral assertion.', 'neurosurf4s:spatialIoJVM/test':'No tracked test sources in pinned modules/neurosurf4s-spatial-io; platform IO capability compiled as prerequisite.'}
prefix_log=Path('/tmp/scalafim-eco-u6-full-34.log');prefix_text=prefix_log.read_text();prefix_meta=json.loads(Path(str(prefix_log)+'.meta.json').read_text());assert prefix_meta['exit_code']==1
prefix_starts=list(re.finditer(r'^\[full-repository-tests\] running (.+)$',prefix_text,re.M));assert len(prefix_starts)==18 and prefix_starts[-1][1]=='mvpa4s-imaging'
old_build=subprocess.check_output(['git','show',prefix_source+':build.sbt'],cwd=root,text=True)
old_runner=subprocess.check_output(['git','show',prefix_source+':tools/ci/full-repository-tests.sh'],cwd=root,text=True)
old_commands=inventory.release_batches(old_runner)
new_build=old_build.replace('mvpa4sImagingTestAll','scalafimMvpaImagingTestAll').replace('addCommandAlias("scalafimMvpaImagingTestAll",','// Source builds share sbt command aliases; keep this distinct from the provider alias.\naddCommandAlias("scalafimMvpaImagingTestAll",')
assert new_build==build_text
assert old_runner.replace('mvpa4sImagingTestAll','scalafimMvpaImagingTestAll')==(root/'tools/ci/full-repository-tests.sh').read_text()
changed=subprocess.check_output(['git','diff','--name-only',prefix_source,source],cwd=root,text=True).splitlines()
assert changed==['build.sbt','tools/ci/full-repository-tests.sh','tools/neuroim-composition-consumer/src/main/scala/consumer/NeuroimCompositionConsumer.scala'],changed
for name in list(commands)[:17]:assert commands[name]==old_commands[name]
resume_text=text
text=prefix_text[:prefix_starts[-1].start()]+text
expected=re.findall(r'^run_batch ([\w-]+)',(root/'tools/ci/full-repository-tests.sh').read_text(),re.M)
starts=list(re.finditer(r'^\[full-repository-tests\] running (.+)$',text,re.M));names=[m[1] for m in starts]
assert names==expected[:len(names)],(names,expected)
final='--final' in sys.argv
if final:
 meta=json.loads(Path(str(log)+'.meta.json').read_text());assert meta['exit_code']==0 and meta['reason']=='exited';assert names==expected and len(names)==37
count=len(starts) if final else max(17,len(starts)-1)
batches=[]
for i,m in enumerate(starts[:count]):
 part=text[m.end():starts[i+1].start() if i+1<len(starts) else len(text)]
 summaries=[dict(zip(['total','failed','errors','passed','skipped'],map(int,(a,b,c,d,e or 0)))) for a,b,c,d,e in re.findall(r'Passed: Total (\d+), Failed (\d+), Errors (\d+), Passed (\d+)(?:, Skipped (\d+))?',part)]
 assert all(x['failed']==x['errors']==0 and x['passed']>0 and x['total']==x['passed']+x['skipped'] for x in summaries),(m[1],summaries)
 targets=expanded[m[1]]
 expected_summaries=0 if m[1]=='ecosystem-boundaries' else sum(t not in empty for t in targets)
 assert len(summaries)==expected_summaries,(m[1],len(summaries),targets,expected_summaries)
 successes=re.findall(r'^\[success\]',part,re.M)
 assert len(successes)==len(targets),(m[1],len(successes),targets)
 assert '[error]' not in part,m[1]
 assert len(re.findall(r'^==> s .+$',part,re.M))==sum(x['skipped'] for x in summaries),(m[1],'unaccounted skip lines')
 batches.append({'source_commit':prefix_source if i<17 else source,'expanded_test_targets':targets,'expected_behavioral_summaries':expected_summaries,'success_markers':len(successes),'known_empty_targets':{t:empty[t] for t in targets if t in empty},'batch':m[1],'summaries':summaries,'passed':sum(s['passed'] for s in summaries),'skipped':sum(s['skipped'] for s in summaries),'declared_nonexecutions':re.findall(r'^==> [si] .+$',part,re.M),'no_test_messages':re.findall(r'^.*No tests to run.*$',part,re.M)})
record={'schema':'scalafim.eco-segmented-campaign.v1','status':'Pass' if final else 'Running','qualified_source_commit':source,'expected_batch_names':expected,'completed_batches':batches,'active_batch':None if final else (names[-1] if len(names)>17 else 'Awaiting mvpa4s-imaging resume'),'passed':sum(b['passed'] for b in batches),'skipped':sum(b['skipped'] for b in batches),'ignored':sum(1 for b in batches for l in b['declared_nonexecutions'] if l.startswith('==> i '))}
if final:
 prefix_record=json.loads((base/'campaign-prefix-34.json').read_text())
 assert prefix_record['source_commit']==prefix_source and prefix_record['status']=='Interrupted'
 assert prefix_record['raw_log_sha256']==hashlib.sha256(prefix_log.read_bytes()).hexdigest() and prefix_record['meta']==prefix_meta
 assert [b['batch'] for b in prefix_record['completed_batches']]==names[:17]
 for captured,observed in zip(prefix_record['completed_batches'],batches[:17]):
  assert captured['summaries']==observed['summaries'] and captured['success_markers']==observed['success_markers'] and captured['expanded_test_targets']==observed['expanded_test_targets']
 resume_inputs=json.loads((base/'resume-inputs-51.json').read_text());driver=Path('/tmp/scalafim-eco-resume-51.py')
 assert resume_inputs['source_commit']==source and resume_inputs['prefix_source_commit']==prefix_source
 assert resume_inputs['prefix_receipt_sha256']==hashlib.sha256((base/'campaign-prefix-34.json').read_bytes()).hexdigest()
 assert resume_inputs['resumed_batch_names']==names[17:] and resume_inputs['frozen_runner_sha256']==hashlib.sha256((root/'tools/ci/full-repository-tests.sh').read_bytes()).hexdigest()
 assert resume_inputs['cwd']==str(root) and resume_inputs['cache']==str(base/'acceptance-cache-25')
 assert resume_inputs['driver_sha256']==hashlib.sha256(driver.read_bytes()).hexdigest()
 intended_common=['sbt','-Djava.awt.headless=true','-Dsbt.boot.directory='+str(base/'acceptance-cache-25/boot'),'-Dsbt.global.base='+str(base/'acceptance-cache-25/global'),'-Dsbt.ivy.home='+str(base/'acceptance-cache-25/ivy'),'-Dsbt.supershell=false']
 assert resume_inputs['commands']=={name:[*intended_common,*commands[name]] for name in names[17:]}
 assert resume_inputs['controlled_JAVA_OPTS']=='-Dsbt.server.autostart=false -XX:ActiveProcessorCount=4' and resume_inputs['free_bytes_at_preflight']>=20_000_000_000
 record['segments']=[{'name':'full34 completed prefix','source_commit':prefix_source,'counted_batches':17,'raw_log_sha256':hashlib.sha256(prefix_log.read_bytes()).hexdigest(),'meta':prefix_meta,'qualification':'Interrupted at batch18 command parsing; count only completed first17. Failure retained.'},{'name':'resume51','source_commit':source,'counted_batches':20,'raw_log_sha256':hashlib.sha256(log.read_bytes()).hexdigest(),'meta':meta}]
 record['source_equivalence']={'changed_paths':changed,'compile_command_and_compile_aliases_unchanged':True,'build_delta':'Root imaging test alias renamed and callers updated; provider-qualified targets/settings/pins unchanged','standalone_delta':'Separate checked-owner repair already compiled/executed in standalone45 at f0; byte-identical tool at resumed source'}
 record['prefix_receipt_sha256']=hashlib.sha256((base/'campaign-prefix-34.json').read_bytes()).hexdigest()
 record['resume_inputs_sha256']=hashlib.sha256((base/'resume-inputs-51.json').read_bytes()).hexdigest()
 assert len(batches)==37 and sum(len(b['summaries']) for b in batches)==140 and sum(b['success_markers'] for b in batches)==144
 assert sum(len(b['summaries']) for b in batches[:17])==56 and sum(b['success_markers'] for b in batches[:17])==59
 assert sum(len(b['summaries']) for b in batches[17:])==84 and sum(b['success_markers'] for b in batches[17:])==85
 checks={
 'functional_group':('downstream', 'known effects survive public first-level fit, bridge, and fixed-effects group inference'),
 'identified_prediction':('downstream','dataset to identified prediction preserves literal values and training-only probabilities as one scenario'),
 'identified_rsa':('analysis','native scoped trial relations match independent beta-free signed distances and RSA')}
 record['existing_family_courts']={}
 for name,(batchprefix,title) in checks.items():
  courts=[]
  for suffix in ['jvm','js']:
   i=names.index(batchprefix+'-'+suffix);part=text[starts[i].end():starts[i+1].start() if i+1<len(starts) else len(text)]
   passed=re.findall(r'^\s*\+ '+re.escape(title)+r' \d[^\n]*$',part,re.M);assert len(passed)==1,(name,suffix,passed)
   courts.append({'platform':suffix,'batch':names[i],'passed_case':passed[0].strip()})
  record['existing_family_courts'][name]=courts
 scenario_lines=re.findall(r'^scenario=([^ ]+) status=(\w+)$',text,re.M)
 record['scenario_results']=[{'scenario':a,'status':b} for a,b in scenario_lines]
 for name,n in [('ecosystem-measurement-scatter',2),('gifti-freesurfer-scalar',2),('freesurfer-geometry-jvm',1),('ecosystem-linked-volume-projection',2),('ecosystem-atlas-routing',2)]:assert scenario_lines.count((name,'Pass'))==n,(name,scenario_lines)
 assert not any(b!='Pass' for _,b in scenario_lines)
 wanted=['ecosystem-measurement-scatter','gifti-freesurfer-scalar','ecosystem-linked-volume-projection','ecosystem-atlas-routing']
 for batch,extra in [('examples',['freesurfer-geometry-jvm']),('examples-js',[])]:
  i=names.index(batch);part=text[starts[i].end():starts[i+1].start() if i+1<len(starts) else len(text)]
  actual_results=re.findall(r'^scenario=([^ ]+) status=(\w+)$',part,re.M)
  assert collections.Counter(actual_results)==collections.Counter((name,'Pass') for name in wanted+extra),(batch,actual_results)
 assert len(scenario_lines)==9
 cache=base/'acceptance-cache-25';private=cache/'ivy/local'
 expected_private=json.loads((base/'acceptance-preflight-25.json').read_text())['private_artifact_inventory']
 actual={str(p.relative_to(private)):hashlib.sha256(p.read_bytes()).hexdigest() for p in private.rglob('*') if p.is_file()};assert actual==expected_private
 record['private_artifact_inventory']=actual
 pins=dict(re.findall(r'lazy val (\w+)Revision\s*=\s*"([a-f0-9]{40})"',(root/'build.sbt').read_text()))
 owners={}
 for git in sorted((cache/'global/staging').glob('*/*/.git')):
  owner=git.parent;head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=owner,text=True).strip();dirty=subprocess.check_output(['git','status','--porcelain'],cwd=owner,text=True).strip();assert not dirty,str(owner)
  if owner.name=='spatial4s':
   image=next((cache/'global/staging').glob('*/image4s/build.sbt'));pin=re.search(r'lazy val spatial4sRevision\s*=\s*"([a-f0-9]{40})"',image.read_text())[1]
  elif owner.name=='linops4s':
   alder=next((cache/'global/staging').glob('*/alder/build.sbt'),None)
   if alder is None:alder=next((cache/'global/staging').glob('*/Alder/build.sbt'))
   pin=re.search(r'lazy val linop4sRevision\s*=\s*"([a-f0-9]{40})"',alder.read_text())[1]
  else:pin=pins.get(owner.name)
  assert pin is not None,('unbound staged source',owner)
  if pin:assert head==pin,(owner,head,pin)
  owners[str(owner)]={'head':head,'expected_pin':pin,'clean':True}
 present={Path(p).name for p in owners};assert set(pins)<=present,(set(pins)-present)
 empty_proof={}
 for target in empty:
  repo=target.split(':')[0];owner=next(Path(p) for p in owners if Path(p).name==repo)
  prefix='examples/consumer' if repo=='mvpa4s' else 'modules/neurosurf4s-spatial-io'
  paths=subprocess.check_output(['git','ls-tree','-r','--name-only',owners[str(owner)]['head'],'--',prefix],cwd=owner,text=True).splitlines()
  assert paths and not any('/src/test/' in p for p in paths),(target,paths)
  empty_proof[target]={'owner':repo,'revision':owners[str(owner)]['head'],'tracked_paths':paths,'qualification':empty[target]}
 record['source_backed_empty_targets']=empty_proof
 record['staged_source_inventory']=owners
 record['source_inventory_scope']='All clean staged Git source owners at exact direct pins plus spatial4s from image4s and linops4s from Alder. This is staged-source inventory; actual classpath proofs are separate independent-receipt-40 and Compile closure evidence.' 
 record['qualification']='Segmented headless JVM/Scala.js local campaign, with failedfull34 retained and completed17+20batches at their exact source commits; native/browser evidence separately historical; no hosted CI/main merge/new scientific or performance inference.'
path=base/('campaign-receipt-52.json' if final else 'campaign-progress-52.json');path.write_text(json.dumps(record,indent=2)+'\n')
print(record['status'],len(batches),'/',len(expected),'passed',record['passed'],'skipped',record['skipped'],'ignored',record['ignored'],'active',record['active_batch'])

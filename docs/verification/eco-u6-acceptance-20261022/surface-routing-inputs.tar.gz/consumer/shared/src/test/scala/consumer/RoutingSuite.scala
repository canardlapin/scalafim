package consumer

import neurosurf4s.routing.*
import neuroim4s.image.SampleSpaces
import neuroim4s.image.SampleSpaces.*
import neuroim4s.spaces.SubjectId
import image4s.geometry.{Affine, D3}
import gale.linalg.DMat
import locus4s.{Region, Selection}

class RoutingSuite extends munit.FunSuite:
  private def admitted[E, A](value: Either[E, A]): A =
    value.fold(error => fail(error.toString), identity)

  private def domain(name: String, size: Int): Domain =
    val geometry = admitted(SamplingGeometry.volume(SampleSpaces(Vector(size, 1, 1), affine = Some(Affine.identity[D3]))))
    admitted(Domain.build(admitted(DomainId(name)), SpaceRef.Volume(admitted(SubjectId("sub-consumer")), None, admitted(Modality("bold"))), geometry))

  test("remote public anatomical route preserves sampling, selected row order and adjoint"):
    val source = domain("source", 3)
    val target = domain("target", 2)
    val affine = admitted(Affine.fromRowMajor[D3](Vector(1d, 0d, 0d, .5d, 0d, 1d, 0d, 0d, 0d, 0d, 1d, 0d, 0d, 0d, 0d, 1d)))
    val edge = admitted(Morphism.between(admitted(MorphismId("half-voxel")), source, target,
      MorphismKind.Affine3D, RouteTag.Anatomical, coordinateMap = admitted(CoordinateMap.affine(source, target, affine))))
    val graph = admitted(SpatialGraph.build(Vector(source, target), Vector(edge)))
    val request = CompileRequest.forRows(source.id, target.id, admitted(RowSelection.rows(Vector(1, 0))))
    val operator = admitted(OperatorCompiler.compile(graph, request))
    val result = admitted(operator.forward(DMat.dense(3, 1, Vector(10d, 20d, 30d))))
    assertEqualsDouble(result(0, 0), 25d, 1e-12)
    assertEqualsDouble(result(1, 0), 15d, 1e-12)
    val adjoint = admitted(operator.map.transposeApplyTo(DMat.dense(2, 1, Vector(2d, 4d))))
    assertEquals(Vector.tabulate(3)(row => adjoint(row, 0)), Vector(2d, 3d, 1d))
    assertEquals(operator.qc.coverage.rowCoverage, Vector(1d, 1d))

  test("public domain owns one fresh locus and distinguishes region and selection order"):
    val owner = domain("owned", 4).locus
    val other = domain("owned", 4).locus
    assert(owner.space.align(other.space).isLeft)
    val region = admitted(Region.fromOrdinals(owner.space, Vector(3, 1, 3)))
    val selection = admitted(Selection.fromOrdinals(owner.space, Vector(3, 1)))
    assertEquals(owner.regionRows(region), Right(Vector(1, 3)))
    assertEquals(owner.selectionRows(selection), Right(Vector(3, 1)))

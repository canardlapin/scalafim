package example

import gale.linalg.DMat
import locus4s.{Bijection, DomainRecord, DomainRegistry, PartialSurjection, Selection, TotalMap}
import locus4s.data.VectorField
import locus4s.provenance.{Provenance, ProvenanceId, SourceId}
import multivar.core.{SemanticSpace, SpaceRole, ValueId, ValueIdentity}
import mvpa4s.{AxisRef, EvidenceSource, Observations}
import mvpa4s.locus.{SpatialMeasurementFrames, SpatialMeasurementRendition, SupportWeightPolicy}
import mvpa4s.measurement.*
import mvpa4s.surface.SurfaceSupportGraphs
import neurosurf4s.surface.{TriangleMesh, VertexId}

/** Independent package using public compile-scope providers only, without ScalaFIM or testkits. */
class SurfaceConsumerSuite extends munit.FunSuite:
  private def right[E, A](value: Either[E, A]): A = value.fold(error => fail(error.toString), identity)

  test("a public surface graph preserves the explicitly selected vertex order and physical units"):
    val source = right(AxisRef.fromStableKeys("selected-vertices", SpaceRole.Observed, Vector("v1", "v0"), "vertex-order", "BOLD", "raw"))
    val mesh = TriangleMesh.fromRows(Vector(Vector(0.0, 0.0, 0.0), Vector(2.0, 0.0, 0.0), Vector(0.0, 3.0, 0.0)), Vector((0, 1, 2)))
    val graph = right(SurfaceSupportGraphs.surface(source, mesh, Vector(VertexId(1), VertexId(0)), "mm", SupportWeightPolicy.InversePhysicalLength))
    assertEquals(graph.edges.size, 1)
    assertEquals((graph.edges.head.left, graph.edges.head.right), (0, 1))
    assertEqualsDouble(graph.edges.head.weight, 0.5, 1e-12)
    assertEquals(graph.weightUnits, "1/mm")


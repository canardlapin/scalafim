package example

import neurosurf4s.surface.{Hemisphere, SurfaceGeometry, SurfaceKind}
import neurosurf4s.surface.io.GiftiSurfaceReader
import scala.concurrent.{ExecutionContext, Future}
import scala.concurrent.ExecutionContext.Implicits.global

object PlatformReader:
  def read(xml: String): Future[Either[String, SurfaceGeometry]] =
    GiftiSurfaceReader.readString(xml, Hemisphere.Left, SurfaceKind.Pial).map(_.left.map(_.message))

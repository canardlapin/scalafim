package example

import neurosurf4s.surface.*
import neuroim4s.image.*
import neuroim4s.spaces.WorldSpace

class VolumeConsumerSuite extends munit.FunSuite:
  private val space = SampleSpaces.inWorld(SampleSpaces(Vector(3, 3, 3)), WorldSpace.template("Toy").toOption.get).toOption.get
  private val volume = SomeScalarVolume.unsafeCopyFromCanonicalArray(
    Array.tabulate(27)(i => (i / 9).toDouble + 10.0 * ((i / 3) % 3) + 100.0 * (i % 3)), space, "external-ramp")
  private def surface(z: Double, kind: SurfaceKind): SurfaceGeometry =
    SurfaceGeometry(TriangleMesh.fromRows(Vector(Vector(0.0, 0.0, z), Vector(1.0, 0.0, z), Vector(0.0, 1.0, z)), Vector((0, 1, 2))), Hemisphere.Left, kind)

  test("optional volume projection retains independent scalar midpoint values and one topology owner"):
    val pair = SurfaceGeometryPair(surface(0.0, SurfaceKind.White), surface(2.0, SurfaceKind.Pial))
    assert(pair.white.mesh.topology eq pair.pial.mesh.topology)
    val sampled = VolumeSurfaceSampler(VolumeSurfaceSamplingPlan(pair, SurfaceSamplingPath.Midpoint, SurfaceSampleAggregation.Nearest)).sample(volume)
    val values = Vector.tabulate(3)(i => sampled.values.valueAt(VertexId(i)).get)
    assertEquals(values, Vector(100.0, 101.0, 110.0))
    assertEquals(Vector.tabulate(3)(i => sampled.sampleCounts.valueAt(VertexId(i)).get), Vector(1, 1, 1))

  test("public grid packaging retains the exact grid and sample-space owner"):
    val grid = GridSpec.fromSpace(space)
    val placed = GridSpec.placed(grid).toOption.get
    assert(placed.value eq grid)
    assert(placed.value.grid eq grid.grid)
    assert(placed.value.sampleSpace eq grid.sampleSpace)

import org.scalajs.linker.interface.ModuleKind
import org.scalajs.sbtplugin.ScalaJSPlugin.autoImport.*
import sbtcrossproject.CrossPlugin.autoImport.*
import sbtcrossproject.CrossType
import scalajscrossproject.ScalaJSCrossPlugin.autoImport.*
ThisBuild / scalaVersion := "3.7.4"
lazy val provider = uri("https://github.com/canardlapin/neurosurf4s.git#73a244fbe5d7b4db2f0c946d98fa2a3c00101ab7")
lazy val settings = Seq(
  scalacOptions ++= Seq("-deprecation", "-feature", "-unchecked", "-Werror"),
  Test / fork := false,
  libraryDependencies += "org.scalameta" %%% "munit" % "1.2.1" % Test
)
lazy val jsSettings = Seq(scalaJSLinkerConfig ~= (_.withModuleKind(ModuleKind.CommonJSModule)))
lazy val coreConsumer = crossProject(JSPlatform, JVMPlatform).crossType(CrossType.Full).in(file("core"))
  .settings(settings).jsSettings(jsSettings)
  .jvmConfigure(_.dependsOn(ProjectRef(provider, "coreJVM"), ProjectRef(provider, "ioJVM")))
  .jsConfigure(_.dependsOn(ProjectRef(provider, "coreJS"), ProjectRef(provider, "ioJS")))
lazy val volumeConsumer = crossProject(JSPlatform, JVMPlatform).crossType(CrossType.Full).in(file("volume"))
  .settings(settings).jsSettings(jsSettings)
  .jvmConfigure(_.dependsOn(ProjectRef(provider, "volumeJVM")))
  .jsConfigure(_.dependsOn(ProjectRef(provider, "volumeJS")))
lazy val minimalCore = crossProject(JSPlatform, JVMPlatform).crossType(CrossType.Full).in(file("minimal-core"))
  .settings(settings).jsSettings(jsSettings)
  .jvmConfigure(_.dependsOn(ProjectRef(provider, "coreJVM")))
  .jsConfigure(_.dependsOn(ProjectRef(provider, "coreJS")))
lazy val root = project.in(file(".")).aggregate(coreConsumer.jvm, coreConsumer.js, volumeConsumer.jvm, volumeConsumer.js, minimalCore.jvm, minimalCore.js)

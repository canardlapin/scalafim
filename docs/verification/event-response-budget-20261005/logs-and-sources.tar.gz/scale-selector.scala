package scalafim.fmri.hrf

class EventResponseBudgetMutationSuite extends EventResponseNormalizationSuite:
  override def munitTests(): Seq[munit.Test] =
    val names = Set(
      "basis scale allocation is bounded for preserved and unit-peak responses"
    )
    val selected = super.munitTests().filter(test => names.contains(test.name))
    assert(selected.length == names.size)
    selected

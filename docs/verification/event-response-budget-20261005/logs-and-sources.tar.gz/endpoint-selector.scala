package scalafim.fmri.hrf

class EventResponseBudgetMutationSuite extends EventResponseNormalizationSuite:
  override def munitTests(): Seq[munit.Test] =
    val names = Set(
      "reference endpoint overflow is a typed refusal before evaluation"
    )
    val selected = super.munitTests().filter(test => names.contains(test.name))
    assert(selected.length == names.size)
    selected

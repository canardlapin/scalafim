package scalafim.fmri.hrf

class EventResponseBudgetMutationSuite extends EventResponseNormalizationSuite:
  override def munitTests(): Seq[munit.Test] =
    val names = Set(
      "composed trapezoid work is refused before evaluating the kernel",
      "nested blocked, lagged and bound kernels contribute their response work",
      "exact piecewise response work includes all segments before evaluation"
    )
    val selected = super.munitTests().filter(test => names.contains(test.name))
    assert(selected.length == names.size)
    selected

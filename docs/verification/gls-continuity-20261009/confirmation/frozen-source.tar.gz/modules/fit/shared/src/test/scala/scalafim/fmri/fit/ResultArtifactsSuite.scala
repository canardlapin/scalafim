package scalafim.fmri.fit

import scalafim.image.SampleSpaces

import scalafim.dataset.DatasetShape
import scalafim.fmri.design.{DesignSchema, ModelSource}
import scalafim.fmri.hrf.design.SamplingFrame
import scalafim.fmri.hrf.linalg.Mat
import scalafim.fmri.model.{FitEngine, FitSummary}
import gale.linalg.{DVec, Matrix}

class ResultArtifactsSuite extends munit.FunSuite:

  test("runwise export preserves every aggregate status, default runs and exclusion order"):
    val statuses = VoxelFitStatus.values.toVector
    val first = statuses.flatMap(status => Vector.fill(statuses.length)(status))
    val second = Vector.fill(statuses.length)(statuses).flatten
    val source = ResultArtifactsExportFixture.runwise(first.length)
    val result = source.copy(
      runs = Vector(
        source.runs.head.copy(voxelStatuses = Some(first)),
        source.runs.last.copy(voxelStatuses = Some(second)),
        source.runs.last.copy(runIndex = 2, voxelStatuses = None)
      ),
      fitExclusions = Vector(
        VoxelInferenceExclusion(3, VoxelFitStatus.NonFinite),
        VoxelInferenceExclusion(1, VoxelFitStatus.NoObservedResponses)
      )
    )
    val precedence = Vector(
      VoxelFitStatus.NoObservedResponses,
      VoxelFitStatus.RankDeficientObservedDesign,
      VoxelFitStatus.InsufficientResidualDegreesOfFreedom,
      VoxelFitStatus.NonFinite,
      VoxelFitStatus.ZeroResidualVariance,
      VoxelFitStatus.AllZero,
      VoxelFitStatus.Constant,
      VoxelFitStatus.Estimable
    )
    val expected = result.voxelIndices.indices.map: position =>
      VoxelFitStatusRecord(
        result.voxelIndices(position),
        precedence.find(status => status == first(position) || status == second(position)).get
      )
    val provenance = AnalysisProvenance.fromResult(result, source = "runwise-export")
    assertEquals(provenance.voxelStatuses, Some(expected.toVector ++ result.fitExclusions.map(_.statusRecord)))
    assertEquals(provenance.engine, result.engine)
    assertEquals(provenance.summary, result.summary)
    assertEquals(provenance.timepoints.toVector, result.timepoints)
    assertEquals(provenance.source, "runwise-export")

  test("patterned export preserves reordered child axes, defaults and outer exclusions"):
    val source = ResultArtifactsExportFixture.runwise(3)
    val runwise = source.copy(
      voxelIndices = Vector(90, 20, 60),
      runs = Vector(
        source.runs.head.copy(voxelStatuses = Some(Vector(VoxelFitStatus.Constant, VoxelFitStatus.AllZero, VoxelFitStatus.Estimable))),
        source.runs.last.copy(voxelStatuses = Some(Vector(VoxelFitStatus.NonFinite, VoxelFitStatus.Estimable, VoxelFitStatus.Estimable)))
      )
    )
    val dense = VoxelStatusLookupFixture.dense(3).copy(
      engine = runwise.engine,
      voxelIndices = Vector(70, 10, 50),
      voxelStatuses = Some(Vector(VoxelFitStatus.ZeroResidualVariance, VoxelFitStatus.Estimable, VoxelFitStatus.RankDeficientObservedDesign))
    )
    val defaults = ResultArtifactsExportFixture.runwise(2).copy(voxelIndices = Vector(80, 30))
    val result = ResultArtifactsExportFixture.patterned(Vector(runwise, dense, defaults), Vector(30, 60, 50, 20, 10, 90, 80, 70))
      .copy(fitExclusions = Vector(VoxelInferenceExclusion(5, VoxelFitStatus.NoObservedResponses)))
    val provenance = AnalysisProvenance.fromResult(result)
    assertEquals(provenance.voxelStatuses, Some(Vector(
      VoxelFitStatusRecord(30, VoxelFitStatus.Estimable),
      VoxelFitStatusRecord(60, VoxelFitStatus.Estimable),
      VoxelFitStatusRecord(50, VoxelFitStatus.RankDeficientObservedDesign),
      VoxelFitStatusRecord(20, VoxelFitStatus.AllZero),
      VoxelFitStatusRecord(10, VoxelFitStatus.Estimable),
      VoxelFitStatusRecord(90, VoxelFitStatus.NonFinite),
      VoxelFitStatusRecord(80, VoxelFitStatus.Estimable),
      VoxelFitStatusRecord(70, VoxelFitStatus.ZeroResidualVariance),
      VoxelFitStatusRecord(5, VoxelFitStatus.NoObservedResponses)
    )))

  test("ResultManifest from dense fit preserves parameter metadata and provenance") {
    val result = denseResult().copy(
      olsDiagnostics = Some(fullRankDiagnostics),
      preparationProvenance = Some(ResponsePreparationPlan.fromConfig(scalafim.fmri.model.FitConfig()).provenance),
      voxelStatuses = Some(Vector(VoxelFitStatus.AllZero, VoxelFitStatus.Estimable))
    )
    val manifest =
      ResultManifest
        .fromDenseFit(
          result,
          shape,
          exportIntent = ResultExportIntent.NamedStem("sub-01_task-demo")
        )
        .toOption
        .get

    val coefficientMaps = manifest.parameterMaps(ParameterMapKind.Coefficient)
    val standardErrorMaps = manifest.parameterMaps(ParameterMapKind.StandardError)
    val covariance = manifest.coefficientCovariance.get

    assertEquals(manifest.provenance.engine, FitEngine.OrdinaryLeastSquares)
    assertEquals(manifest.provenance.responsePreparation, result.preparationProvenance)
    assertEquals(manifest.provenance.columnNames, Vector("task", "base_constant"))
    assertEquals(manifest.provenance.coefficientAxis, result.coefficientAxis)
    assertEquals(manifest.provenance.rankReports.length, 1)
    assertEquals(manifest.provenance.rankReports.head.numericalRank, 2)
    assertEquals(manifest.provenance.rankReports.head.aliasedColumnIds, Vector.empty)
    assertEquals(
      manifest.provenance.voxelStatuses,
      Some(
        Vector(
          VoxelFitStatusRecord(3, VoxelFitStatus.AllZero),
          VoxelFitStatusRecord(1, VoxelFitStatus.Estimable)
        )
      )
    )
    assertEquals(
      manifest.provenance.coefficientAxis.map(_.columnIds),
      result.coefficientAxis.map(_.columnIds)
    )
    assertEquals(
      manifest.provenance.coefficientInference.map(_.inferableColumnIds),
      result.coefficientAxis.map(_.columnIds)
    )
    assertEquals(manifest.provenance.timepoints.toVector, Vector(0, 1, 2, 3))
    assertEquals(coefficientMaps.map(_.parameter), Vector("task", "base_constant"))
    assertEquals(standardErrorMaps.map(_.parameter), Vector("task", "base_constant"))
    assertEquals(coefficientMaps.map(_.map.exportIntent), Vector.fill(2)(ResultExportIntent.NamedStem("sub-01_task-demo")))
    assertEquals(coefficientMaps.head.map.voxelIndices, Vector(3, 1))
    assertEquals(coefficientMaps.head.map.valueVector, Vector(2.0, -1.0))
    assertEquals(standardErrorMaps.last.map.valueVector, Vector(0.2, 0.4))
    assertEquals(covariance.scope, CoefficientCovarianceScope.Shared)
    assertEquals(covariance.parameterNames.map(_.value), Vector("task", "base_constant"))
    assertEquals(covariance.voxelIndices, Vector(3, 1))
    assertEquals(covariance.exportIntent, ResultExportIntent.NamedStem("sub-01_task-demo"))
    assertEqualsDouble(covariance.matrices.head(0, 0), 0.25, 1e-12)
  }

  test("ContrastMap preserves statistic kind and degrees of freedom") {
    val result = denseResult().copy(
      voxelStatuses = Some(Vector(VoxelFitStatus.AllZero, VoxelFitStatus.Estimable))
    )
    val provenance = AnalysisProvenance.fromResult(result)
    val t = TContrast("task", Map("task" -> 1.0)).evaluate(result).toOption.get
    val f = FContrast("task", Vector(Map("task" -> 1.0))).evaluate(result).toOption.get

    val tMaps = ContrastMap.fromTContrast(t, shape, provenance).toOption.get
    val fMaps = ContrastMap.fromFContrast(f, shape, provenance).toOption.get

    assertEquals(tMaps.map(_.statistic), Vector(ContrastMapKind.Estimate(1), ContrastMapKind.StandardError, ContrastMapKind.TStatistic))
    assertEquals(tMaps.map(_.contrast), Vector("task", "task", "task"))
    assertEquals(tMaps.map(_.map.label), Vector("task_estimate", "task_standard_error", "task_t"))
    assertEquals(tMaps.flatMap(_.degreesOfFreedom).map(_.residual.value).distinct, Vector(2))
    assertEquals(
      tMaps.map(_.excludedVoxels).distinct,
      Vector(Vector(VoxelInferenceExclusion(3, VoxelFitStatus.AllZero)))
    )
    assertEquals(fMaps.map(_.statistic), Vector(ContrastMapKind.Estimate(1), ContrastMapKind.FStatistic))
    assertEquals(fMaps.last.degreesOfFreedom.flatMap(_.numerator), Some(1))
    assertEquals(
      fMaps.map(_.excludedVoxels).distinct,
      Vector(Vector(VoxelInferenceExclusion(3, VoxelFitStatus.AllZero)))
    )

    val sourceMap = tMaps.head.map
    val withoutVoxelStatusProvenance = StatMap.unsafe(
      name = sourceMap.label,
      kind = sourceMap.kind,
      values = sourceMap.values,
      shape = sourceMap.shape,
      selectedVoxels = sourceMap.selectedVoxels,
      provenance = provenance.copy(voxelStatuses = None),
      exportIntent = sourceMap.exportIntent
    )
    interceptMessage[IllegalArgumentException]("requirement failed: contrast map exclusions must agree with voxel status provenance") {
      tMaps.head.copy(map = withoutVoxelStatusProvenance)
    }
  }

  test("StatMap rejects value and voxel-space mismatches") {
    val result = denseResult()
    val provenance = AnalysisProvenance.fromResult(result)
    val selected = SelectedVoxelIndices.unsafe(Vector(0, 1))

    val shortValues =
      StatMap.make(
        name = "bad",
        kind = StatisticKind.Custom("bad"),
        values = DVec.fromSeq(Vector(1.0)),
        shape = shape,
        selectedVoxels = selected,
        provenance = provenance
      )
    assert(shortValues.left.toOption.exists {
      case FitError.InvalidFitAxis(axis, detail) =>
        axis == "result map values" && detail.contains("selected voxels 2")
      case _ =>
        false
    })

    val outOfBounds =
      StatMap.make(
        name = "bad",
        kind = StatisticKind.Custom("bad"),
        values = DVec.fromSeq(Vector(1.0)),
        shape = shape,
        selectedVoxels = SelectedVoxelIndices.unsafe(Vector(shape.spatialSize)),
        provenance = provenance
      )
    assert(outOfBounds.left.toOption.exists {
      case FitError.InvalidFitAxis(axis, detail) =>
        axis == "result map voxel indices" && detail.contains("out of bounds")
      case _ =>
        false
    })
  }

  test("CoefficientCovarianceArtifact preserves voxelwise covariance and rejects shape mismatches") {
    val base = denseResult()
    val covariance = CoefficientCovariance.unsafeVoxelwise(
        Vector(
          scalafim.fmri.fit.GaleTestMatrix.fromRows(
            Vector(
              Vector(0.25, 0.0),
              Vector(0.0, 0.5)
            )
          ),
          scalafim.fmri.fit.GaleTestMatrix.fromRows(
            Vector(
              Vector(0.75, 0.0),
              Vector(0.0, 1.5)
            )
          )
        )
      )
    val result = base.copy(
      inference = CoefficientInference.unsafeFromExisting(
        CoefficientInferenceScope.All,
        base.standardErrors,
        covariance,
        base.inference.varianceScale,
        base.inference.residualDegreesOfFreedom
      )
    )
    val provenance = AnalysisProvenance.fromResult(result)
    val artifact =
      CoefficientCovarianceArtifact
        .fromDenseFit(result, shape, provenance, ResultExportIntent.BidsDerivative("stat"))
        .toOption
        .get

    assertEquals(artifact.scope, CoefficientCovarianceScope.Voxelwise)
    assertEquals(artifact.matrices.length, 2)
    assertEquals(artifact.parameterNames.map(_.value), Vector("task", "base_constant"))
    assertEquals(artifact.exportIntent, ResultExportIntent.BidsDerivative("stat"))
    assertEqualsDouble(artifact.matrices(1)(0, 0), 0.75, 1e-12)

    val mismatched =
      CoefficientCovarianceArtifact.make(
        parameterNames = Vector("task", "base_constant"),
        covariance = CoefficientCovariance.unsafeVoxelwise(Vector(result.normalizedCovariance)),
        shape = shape,
        selectedVoxels = result.selectedVoxels,
        provenance = provenance
      )

    assert(mismatched.left.toOption.exists {
      case FitError.InvalidFitAxis(axis, detail) =>
        axis == "voxelwise coefficient covariance" && detail.contains("expected 2")
      case _ =>
        false
    })
  }

  test("restricted inference exports only inferable standard errors and covariance") {
    val result = restrictedDenseResult()
    val manifest = ResultManifest.fromDenseFit(result, shape).toOption.get

    assertEquals(
      manifest.parameterMaps(ParameterMapKind.Coefficient).map(_.parameter),
      Vector("task", "base_constant")
    )
    assertEquals(
      manifest.parameterMaps(ParameterMapKind.StandardError).map(_.parameter),
      Vector("task")
    )
    assertEquals(
      manifest.provenance.coefficientInference.map(_.method),
      Some(CoefficientInferenceMethod.ReducedRankConditional)
    )
    assertEquals(
      manifest.provenance.coefficientInference.map(_.inferableColumns),
      Some(Vector("task"))
    )
    assertEquals(
      manifest.provenance.coefficientInference.map(_.inferableColumnIds),
      result.coefficientAxis.map(axis => Vector(axis.columnIds.head))
    )

    val covariance = manifest.coefficientCovariance.get
    assertEquals(covariance.parameterNames.map(_.value), Vector("task"))
    assertEquals(covariance.matrices.map(matrix => matrix.rows -> matrix.cols), Vector(1 -> 1))
    assertEqualsDouble(covariance.matrices.head(0, 0), 0.25, 1e-12)
  }

  private def shape: DatasetShape =
    DatasetShape.unsafe(SampleSpaces(Vector(2, 2, 1)), timepoints = 4)

  private def denseResult(): DenseFmriFitResult =
    val covariance =
      CoefficientCovariance.unsafeShared(
        scalafim.fmri.fit.GaleTestMatrix.fromRows(
          Vector(
            Vector(0.25, 0.0),
            Vector(0.0, 0.5)
          )
        )
      )
    val residualVariance = DVec.fromSeq(Vector(1.0, 2.0))
    val residualDegreesOfFreedom = ResidualDegreesOfFreedom.unsafe(2)
    DenseFmriFitResult(
      coefficients = CoefficientBlock(
        scalafim.fmri.fit.GaleTestMatrix.fromRows(
          Vector(
            Vector(2.0, -1.0),
            Vector(3.0, 4.0)
          )
        )
      ),
      inference = CoefficientInference.unsafeFromExisting(
        CoefficientInferenceScope.All,
        StandardErrorBlock(
          scalafim.fmri.fit.GaleTestMatrix.fromRows(
            Vector(
              Vector(0.1, 0.3),
              Vector(0.2, 0.4)
            )
          )
        ),
        covariance,
        residualVariance,
        residualDegreesOfFreedom
      ),
      residualVariance = residualVariance,
      residualDegreesOfFreedom = residualDegreesOfFreedom,
      columnNames = Vector("task", "base_constant"),
      voxelIndices = Vector(3, 1),
      timepoints = Vector(0, 1, 2, 3),
      engine = FitEngine.OrdinaryLeastSquares,
      summary = FitSummary(
        engine = FitEngine.OrdinaryLeastSquares,
        timepoints = 4,
        predictors = 2,
        voxels = 2,
        robust = false,
        autocorrelated = false
      ),
      coefficientAxis = Some(coefficientAxis)
    )

  private def coefficientAxis: scalafim.fmri.design.CoefficientAxis =
    DesignSchema
      .legacy(
        matrix = Mat.unsafe(4, 2, Array(1.0, 0.0, 0.0, 1.0, 1.0, 1.0, 2.0, 1.0)),
        samplingFrame = SamplingFrame(blockLens = Seq(4), tr = Seq(1.0)),
        columnNames = Vector("task", "base_constant"),
        source = ModelSource.Event
      )
      .coefficientAxis

  private def fullRankDiagnostics: OlsDiagnostics =
    val report = RankDiagnostics.fromPivotedQr(
      predictorCount = 2,
      rank = 2,
      tolerance = 1e-7,
      pivotOrder = Vector(0, 1),
      diagonalR = Vector(2.0, 1.0),
      toleranceConvention = scalafim.fmri.design.RankToleranceConvention.ScaleAware
    )
    OlsDiagnostics(
      solveMethod = OlsSolveMethod.QrRankRevealing,
      predictors = 2,
      rank = 2,
      policy = OlsSolvePolicy.Default,
      rankReport = report
    )

  private def restrictedDenseResult(): DenseFmriFitResult =
    val result = denseResult()
    val covariance =
      CoefficientCovariance.unsafeShared(
        scalafim.fmri.fit.GaleTestMatrix.fromRows(
          Vector(
            Vector(0.25, 0.0),
            Vector(0.0, 0.0)
          )
        )
      )
    result.copy(
      inference = CoefficientInference
        .fromCovariance(
          scope = CoefficientInferenceScope.unsafeOnly(Vector(0), "task coefficient"),
          covariance = covariance,
          varianceScale = DVec.fromSeq(Vector(1.0, 2.0)),
          residualDegreesOfFreedom = result.residualDegreesOfFreedom,
          method = CoefficientInferenceMethod.ReducedRankConditional
        )
        .toOption
        .get
    )

private[fit] object ResultArtifactsExportFixture:
  def runwise(voxels: Int): RunwiseFmriFitResult =
    val dense = VoxelStatusLookupFixture.dense(voxels)
    val diagnostics = Ols.prepare(DesignMatrix.unsafe(Matrix.tabulate(4, 1)((_, _) => 1.0))).toOption.get.diagnostics
    val runs = Vector.tabulate(2): run =>
      RunwiseFmriRunResult(
        runIndex = run,
        rowIndices = Vector.tabulate(4)(row => run * 4 + row),
        timepoints = Vector.tabulate(4)(row => run * 4 + row),
        coefficients = dense.coefficients,
        standardErrors = dense.standardErrors,
        normalizedCovariance = dense.normalizedCovariance,
        residualVariance = dense.residualVariance,
        residualDegreesOfFreedom = dense.residualDegreesOfFreedom,
        olsDiagnostics = diagnostics
      )
    RunwiseFmriFitResult(
      runs = runs,
      columnNames = dense.columnNames,
      voxelIndices = dense.voxelIndices,
      timepoints = Vector.tabulate(8)(identity),
      engine = FitEngine.RunwiseLeastSquares,
      summary = dense.summary.copy(engine = FitEngine.RunwiseLeastSquares, timepoints = 8)
    )

  def patterned(children: Vector[FmriFitResult], order: Vector[Int]): PatternedFmriFitResult =
    val patterns = children.zipWithIndex.map: (child, index) =>
      ObservationPatternFitResult(
        ObservationPattern.unsafe(index, child.timepoints.indices.toVector, child.timepoints, child.voxelIndices),
        child
      )
    PatternedFmriFitResult(patterns, order, Vector.tabulate(8)(identity), children.head.summary.copy(voxels = order.length))

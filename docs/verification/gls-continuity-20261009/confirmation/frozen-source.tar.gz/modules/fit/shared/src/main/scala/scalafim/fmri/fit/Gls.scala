package scalafim.fmri.fit

import scalafim.fmri.ar.{
  AcvfBias,
  ArError,
  ArEstimation,
  ArFitOptions,
  ArmaCoefficients,
  ArOrder,
  InitialConditionPolicy,
  CorrectionBudget,
  NoiseFit,
  NoiseEstimationLayout,
  NoisePooling,
  PreparedCorrection,
  RunCorrection,
  TimeSegment,
  TimeSegments,
  WhiteningMethod,
  WhiteningPlan,
  WhiteningTransform
}
import scalafim.fmri.model.{ArBiasCorrection, ArCoefficientSpec, ArInitialization, ArCensorTreatment, ArOptions, AutocorrelationConfig}
import gale.linalg.{DMat, DVec, Matrix, Vec}

final case class GlsFit(
    coefficients: CoefficientBlock,
    residualVariance: DVec,
    residualDegreesOfFreedom: ResidualDegreesOfFreedom,
    normalizedCovariance: DMat,
    standardErrors: StandardErrorBlock,
    diagnostics: ArDiagnostics,
    initialOlsDiagnostics: OlsDiagnostics,
    finalOlsDiagnostics: OlsDiagnostics,
    coefficientCovariance: CoefficientCovariance
):
  require(coefficientCovariance.predictors == coefficients.predictors, "GLS coefficient covariance must match coefficient rows")
  require(coefficientCovariance.validateVoxelCount(coefficients.voxels).isRight, "GLS coefficient covariance must be shared or match voxel count")
  def predictors: Int = coefficients.predictors
  def voxels: Int = coefficients.voxels
  def olsDiagnostics: OlsDiagnostics = finalOlsDiagnostics

private[fit] enum GlsWhitening:
  case Shared(plan: WhiteningPlan, corrections: Vector[RunCorrection] = Vector.empty)
  case Voxelwise(plans: Vector[WhiteningPlan], corrections: Vector[Vector[RunCorrection]] = Vector.empty)

final case class GlsPrepared private[fit] (
    design: DesignMatrix,
    partitions: Vector[RunPartition],
    whitening: GlsWhitening,
    diagnostics: ArDiagnostics,
    initialOlsDiagnostics: OlsDiagnostics,
    selectedVoxelIndices: Vector[Int]
):
  require(selectedVoxelIndices.nonEmpty, "GLS prepared context must contain selected voxels")

  def fit(response: ResponseBlock): Either[FitError, GlsFit] =
    Gls.fitPrepared(this, response, selectedVoxelIndices)

  def fit(response: ResponseBlock, voxelIndices: Vector[Int]): Either[FitError, GlsFit] =
    Gls.fitPrepared(this, response, voxelIndices)

object Gls:

  def fit(
      design: DesignMatrix,
      response: ResponseBlock,
      partitions: Vector[RunPartition],
      options: ArOptions
  ): Either[FitError, GlsFit] =
    fit(design, response, partitions, options, (0 until response.voxels).toVector)

  private[fit] def fit(
      design: DesignMatrix,
      response: ResponseBlock,
      partitions: Vector[RunPartition],
      options: ArOptions,
      voxelIndices: Vector[Int]
  ): Either[FitError, GlsFit] =
    prepare(design, response, partitions, options, voxelIndices).flatMap(_.fit(response, voxelIndices))

  private[fit] def prepare(
      design: DesignMatrix,
      response: ResponseBlock,
      partitions: Vector[RunPartition],
      options: ArOptions
  ): Either[FitError, GlsPrepared] =
    prepare(design, response, partitions, options, (0 until response.voxels).toVector)

  private[fit] def prepare(
      design: DesignMatrix,
      response: ResponseBlock,
      partitions: Vector[RunPartition],
      options: ArOptions,
      selectedVoxelIndices: Vector[Int]
  ): Either[FitError, GlsPrepared] =
    for
      _ <- validateVoxelIndices(response, selectedVoxelIndices)
      config <- autocorrelationConfig(options)
      _ <- validatePartitions(partitions)
      noiseLayout <- noiseEstimationLayout(partitions, options.censoredTimepoints, options.censorTreatment)
      initial <- Ols.fit(design, response)
      whiteningAndMethod <- whiteningPlan(design.value, response.value, initial.coefficients.value, noiseLayout, config)
      (whitening, method) = whiteningAndMethod
    yield GlsPrepared(
      design = design,
      partitions = partitions,
      whitening = whitening,
      diagnostics = diagnostics(whitening, partitions, method, diagnosticIterations(config), config.biasCorrection),
      initialOlsDiagnostics = initial.diagnostics,
      selectedVoxelIndices = selectedVoxelIndices
    )

  private[fit] def fitPrepared(
      prepared: GlsPrepared,
      response: ResponseBlock,
      voxelIndices: Vector[Int]
  ): Either[FitError, GlsFit] =
    validateVoxelIndices(response, voxelIndices).flatMap { _ =>
      prepared.whitening match
        case GlsWhitening.Shared(plan, _) =>
          for
            whitened <- WhiteningTransform(
              plan,
              prepared.design.value,
              response.value
            ).left.map(arToFitError)
            fit <- Ols.fit(
              DesignMatrix.unsafe(whitened.design),
              ResponseBlock.unsafe(whitened.response)
            )
          yield GlsFit(
            coefficients = fit.coefficients,
            residualVariance = fit.residualVariance,
            residualDegreesOfFreedom = fit.residualDegreesOfFreedom,
            normalizedCovariance = fit.normalizedCovariance,
            standardErrors = fit.standardErrors,
            diagnostics = prepared.diagnostics,
            initialOlsDiagnostics = prepared.initialOlsDiagnostics,
            finalOlsDiagnostics = fit.diagnostics,
            coefficientCovariance = fit.coefficientCovariance
          )

        case GlsWhitening.Voxelwise(plans, _) =>
          for
            selectedPlans <- subsetPlans(plans, prepared.diagnostics, prepared.selectedVoxelIndices, voxelIndices)
            diagnostics <- subsetDiagnostics(prepared.diagnostics, selectedPlans.positions)
            fit <- fitVoxelwise(prepared.design.value, response.value, selectedPlans.plans)
          yield GlsFit(
            coefficients = fit.coefficients,
            residualVariance = fit.residualVariance,
            residualDegreesOfFreedom = fit.residualDegreesOfFreedom,
            normalizedCovariance = fit.normalizedCovariance,
            standardErrors = fit.standardErrors,
            diagnostics = diagnostics,
            initialOlsDiagnostics = prepared.initialOlsDiagnostics,
            finalOlsDiagnostics = fit.diagnostics,
            coefficientCovariance = fit.coefficientCovariance
          )
    }

  private[fit] def initialCondition(config: AutocorrelationConfig): InitialConditionPolicy =
    initialCondition(config.initialization)

  private[fit] def initialCondition(options: ArOptions): InitialConditionPolicy =
    initialCondition(options.initialization.getOrElse(ArInitialization.fromExactFirst(options.exactFirst)))

  private def initialCondition(value: ArInitialization): InitialConditionPolicy = value match
    case ArInitialization.Identity => InitialConditionPolicy.Identity
    case ArInitialization.ExactAr1 => InitialConditionPolicy.ExactAr1
    case ArInitialization.Stationary => InitialConditionPolicy.Stationary

  private[fit] def autocorrelationConfig(options: ArOptions): Either[FitError, AutocorrelationConfig] =
    AutocorrelationConfig
      .fromLegacy(options)
      .left
      .map(error => FitError.UnsupportedAutocorrelation(error.message))

  private def validateVoxelIndices(response: ResponseBlock, voxelIndices: Vector[Int]): Either[FitError, Unit] =
    if voxelIndices.length != response.voxels then
      Left(FitError.InvalidFitAxis("voxel indices", s"expected ${response.voxels}, got ${voxelIndices.length}"))
    else SelectedVoxelIndices.fromInts(voxelIndices).map(_ => ())

  private[fit] def validatePartitions(partitions: Vector[RunPartition]): Either[FitError, Unit] =
    if partitions.isEmpty then Left(FitError.UnsupportedAutocorrelation("GLS requires at least one run partition"))
    else if partitions.exists(p => !isStrictlyIncreasing(p.timepoints)) then
      Left(FitError.UnsupportedAutocorrelation("AR GLS requires strictly increasing selected timepoints within each run"))
    else if partitions.exists(p => !isContiguous(p.rowIndices)) then
      Left(FitError.UnsupportedAutocorrelation("AR GLS requires contiguous selected rows within each run"))
    else Right(())

  private def isStrictlyIncreasing(values: Vector[Int]): Boolean =
    var i = 1
    while i < values.length do
      if values(i) <= values(i - 1) then return false
      i += 1
    true

  private def isContiguous(timepoints: Vector[Int]): Boolean =
    var i = 1
    while i < timepoints.length do
      if timepoints(i) != timepoints(i - 1) + 1 then return false
      i += 1
    true

  private[fit] def timeSegments(
      partitions: Vector[RunPartition],
      censoredTimepoints: Vector[Int]
  ): Either[FitError, Vector[TimeSegment]] =
    val base = partitions.map { partition =>
      TimeSegment(
        start = partition.rowIndices.head,
        endExclusive = partition.rowIndices.last + 1,
        runIndex = partition.runIndex
      )
    }
    val missingCensors =
      censoredTimepoints.distinct.filterNot { timepoint =>
        partitions.exists(_.timepoints.contains(timepoint))
      }
    if missingCensors.nonEmpty then
      Left(FitError.UnsupportedAutocorrelation(s"censored timepoints are not selected: ${missingCensors.mkString(", ")}"))
    else
      val explicitResetRows =
        censoredTimepoints.flatMap { timepoint =>
          partitions.iterator
            .flatMap(partition => partition.timepoints.zip(partition.rowIndices))
            .find { case (candidate, _) => candidate == timepoint }
            .map(_._2)
        }.toSet
      val gapResetRows =
        partitions.iterator.flatMap { partition =>
          partition.timepoints.zip(partition.rowIndices).sliding(2).collect {
            case Vector((leftTimepoint, leftRow), (rightTimepoint, _))
                if rightTimepoint > leftTimepoint + 1 => leftRow
          }
        }.toSet
      val segments = TimeSegments.withCensorResets(base, explicitResetRows ++ gapResetRows)
      TimeSegments.validateCoverage(segments, base.last.endExclusive).left.map(arToFitError).map(_ => segments)

  private[fit] def noiseEstimationLayout(
      partitions: Vector[RunPartition],
      censoredTimepoints: Vector[Int],
      treatment: ArCensorTreatment = ArCensorTreatment.RestartWhitening
  ): Either[FitError, NoiseEstimationLayout] =
    for
      _ <- if treatment == ArCensorTreatment.EstimateOnly && partitions.exists(_.timepoints.sliding(2).exists {
        case Vector(left, right) => right != left + 1
        case _ => false
      }) then Left(FitError.UnsupportedAutocorrelation("estimation-only continuity requires contiguous selected timepoints within each run")) else Right(())
      _ <- timeSegments(partitions, censoredTimepoints).map(_ => ())
      segments <- timeSegments(partitions, if treatment == ArCensorTreatment.EstimateOnly then Vector.empty else censoredTimepoints)
      excludedRows =
        censoredTimepoints.flatMap { timepoint =>
          partitions.iterator
            .flatMap(partition => partition.timepoints.zip(partition.rowIndices))
            .find { case (candidate, _) => candidate == timepoint }
            .map(_._2)
        }.toSet
      layout <- NoiseEstimationLayout
        .excludingRows(segments, segments.last.endExclusive, excludedRows)
        .left
        .map(arToFitError)
    yield layout

  private def whiteningPlan(
      design: DMat,
      response: DMat,
      coefficients: DMat,
      noiseLayout: NoiseEstimationLayout,
      config: AutocorrelationConfig
  ): Either[FitError, (GlsWhitening, String)] =
    config.coefficients match
      case ArCoefficientSpec.Rho(rho) =>
        WhiteningPlan
          .globalWithInitialCondition(
            ArmaCoefficients(Vector(rho)),
            noiseLayout.whiteningSegments,
            initialCondition = initialCondition(config),
            method = WhiteningMethod.Fixed
          )
          .left
          .map(arToFitError)
          .map(plan => GlsWhitening.Shared(plan) -> "fixed")

      case ArCoefficientSpec.Phi(phi) =>
        WhiteningPlan
          .globalWithInitialCondition(
            ArmaCoefficients(phi),
            noiseLayout.whiteningSegments,
            initialCondition = initialCondition(config),
            method = WhiteningMethod.Fixed
          )
          .left
          .map(arToFitError)
          .map(plan => GlsWhitening.Shared(plan) -> "fixed")

      case ArCoefficientSpec.Estimate =>
        if config.voxelwise then
          preparedCorrection(design, noiseLayout, config).flatMap { correction =>
            iterateEstimatedVoxelwiseWhitening(design, response, coefficients, noiseLayout, config, correction)
          }.map(_ -> "voxelwise-estimated")
        else preparedCorrection(design, noiseLayout, config).flatMap { correction =>
          iterateEstimatedWhitening(design, response, coefficients, noiseLayout, config, correction)
            .map((plan, statuses) => GlsWhitening.Shared(plan, statuses))
        }.map(_ -> "estimated")

  private[fit] def preparedCorrection(
      design: DMat,
      layout: NoiseEstimationLayout,
      config: AutocorrelationConfig
  ): Either[FitError, Option[PreparedCorrection]] =
    config.biasCorrection match
      case ArBiasCorrection.Raw => Right(None)
      case ArBiasCorrection.OlsDesign(ceiling) =>
        AcvfBias.prepare(design, layout, CorrectionBudget.Adaptive(ceiling.value), config.order.value)
          .left.map(arToFitError).map(Some(_))
      case ArBiasCorrection.OlsTailAnchored(maxLag) =>
        AcvfBias.prepare(design, layout, CorrectionBudget.Fixed(maxLag.value), config.order.value, scalafim.fmri.ar.AcvfCorrectionSolve.ShortMemoryTail)
          .left.map(arToFitError).map(Some(_))

  private def iterateEstimatedWhitening(
      design: DMat,
      response: DMat,
      initialCoefficients: DMat,
      noiseLayout: NoiseEstimationLayout,
      config: AutocorrelationConfig,
      correction: Option[PreparedCorrection]
  ): Either[FitError, (WhiteningPlan, Vector[RunCorrection])] =
    val pooling = if config.global then NoisePooling.Global else NoisePooling.Run
    val arOptions =
      ArFitOptions.withInitialCondition(
        order = ArOrder.Fixed(config.order.value),
        pooling = pooling,
        initialCondition = initialCondition(config)
      )

    def estimate(coefficients: DMat): Either[FitError, (WhiteningPlan, Vector[RunCorrection])] =
      val residuals = residualMatrix(design, response, coefficients)
      correction match
        case None =>
          ArEstimation.fitNoise(residuals, noiseLayout, arOptions).left.map(arToFitError)
            .map(_ -> Vector.empty)
        case Some(prepared) =>
          NoiseFit.estimate(residuals, noiseLayout, arOptions, design, prepared)
            .left.map(arToFitError).map(fit => fit.plan -> fit.corrections)

    def loop(iteration: Int, coefficients: DMat): Either[FitError, (WhiteningPlan, Vector[RunCorrection])] =
      estimate(coefficients).flatMap { estimated =>
        val (plan, _) = estimated
        if iteration >= config.iterations then Right(estimated)
        else
          for
            fit <- fitWithPlan(plan, design, response)
            finalPlan <- loop(iteration + 1, fit.coefficients.value)
          yield finalPlan
      }

    loop(iteration = 1, initialCoefficients)

  private def iterateEstimatedVoxelwiseWhitening(
      design: DMat,
      response: DMat,
      initialCoefficients: DMat,
      noiseLayout: NoiseEstimationLayout,
      config: AutocorrelationConfig,
      correction: Option[PreparedCorrection]
  ): Either[FitError, GlsWhitening] =
    val plans = Vector.newBuilder[WhiteningPlan]
    val statuses = Vector.newBuilder[Vector[RunCorrection]]
    var voxel = 0
    while voxel < response.cols do
      iterateEstimatedWhitening(
        design = design,
        response = matrixColumn(response, voxel),
        initialCoefficients = matrixColumn(initialCoefficients, voxel),
        noiseLayout = noiseLayout,
        config = config,
        correction = correction
      ) match
        case Left(error) =>
          return Left(error)
        case Right((plan, outcomes)) =>
          plans += plan
          statuses += outcomes
      voxel += 1
    Right(GlsWhitening.Voxelwise(plans.result(), if correction.isDefined then statuses.result() else Vector.empty))

  private[fit] def fitWithPlan(
      plan: WhiteningPlan,
      design: DMat,
      response: DMat
  ): Either[FitError, OlsFit] =
    for
      whitened <- WhiteningTransform(
        plan,
        design,
        response
      ).left.map(arToFitError)
      fit <- Ols.fit(
        DesignMatrix.unsafe(whitened.design),
        ResponseBlock.unsafe(whitened.response)
      )
    yield fit

  private final case class SelectedVoxelPlans(plans: Vector[WhiteningPlan], positions: Vector[Int])

  private def subsetPlans(
      plans: Vector[WhiteningPlan],
      diagnostics: ArDiagnostics,
      selectedVoxelIndices: Vector[Int],
      voxelIndices: Vector[Int]
  ): Either[FitError, SelectedVoxelPlans] =
    val selectedCount = diagnostics.runs.head.voxelwiseCoefficients.length
    if plans.length != selectedCount || plans.length != selectedVoxelIndices.length then
      Left(FitError.UnsupportedAutocorrelation("voxelwise AR plans do not match diagnostics"))
    else
      val positions = Vector.newBuilder[Int]
      val selected = Vector.newBuilder[WhiteningPlan]
      var i = 0
      while i < voxelIndices.length do
        val position = selectedVoxelIndices.indexOf(voxelIndices(i))
        if position < 0 then
          return Left(FitError.InvalidFitAxis("voxel index", s"value ${voxelIndices(i)} was not in the prepared GLS selection"))
        positions += position
        selected += plans(position)
        i += 1
      Right(SelectedVoxelPlans(selected.result(), positions.result()))

  private def subsetDiagnostics(
      diagnostics: ArDiagnostics,
      positions: Vector[Int]
  ): Either[FitError, ArDiagnostics] =
    if diagnostics.sharedNormalizedCovariance then Right(diagnostics)
    else
      val runs =
        diagnostics.runs.map { run =>
          val perVoxel = positions.map(position => run.voxelwiseCoefficients(position))
          val summary = averageCoefficients(perVoxel, diagnostics.order)
          run.copy(
            rho = summary.head,
            coefficients = summary,
            voxelwiseCoefficients = perVoxel,
            voxelwiseCorrections = if run.voxelwiseCorrections.isEmpty then Vector.empty else positions.map(run.voxelwiseCorrections)
          )
        }
      Right(diagnostics.copy(runs = runs))

  private def fitVoxelwise(
      design: DMat,
      response: DMat,
      plans: Vector[WhiteningPlan]
  ): Either[FitError, OlsFit] =
    if plans.length != response.cols then
      Left(FitError.UnsupportedAutocorrelation(s"voxelwise AR requires ${response.cols} whitening plans, got ${plans.length}"))
    else
      val coefficientData = Matrix.newBuilder(design.cols, response.cols)
      val standardErrorData = Matrix.newBuilder(design.cols, response.cols)
      val residualVarianceData = Vec.newBuilder(response.cols)
      val covarianceMatrices = Vector.newBuilder[DMat]
      var representative: Option[OlsFit] = None

      var voxel = 0
      while voxel < response.cols do
        fitWithPlan(plans(voxel), design, matrixColumn(response, voxel)) match
          case Left(error) =>
            return Left(error)
          case Right(fit) =>
            var predictor = 0
            while predictor < design.cols do
              coefficientData(predictor, voxel) = fit.coefficients(predictor, 0)
              standardErrorData(predictor, voxel) = fit.standardErrors(predictor, 0)
              predictor += 1
            residualVarianceData(voxel) = fit.residualVariance(0)
            covarianceMatrices += fit.normalizedCovariance
            if representative.isEmpty then representative = Some(fit)
        voxel += 1

      representative match
        case None => Left(FitError.EmptyResponse)
        case Some(first) =>
          Right(
            OlsFit(
              coefficients = CoefficientBlock(coefficientData.result()),
              residualVariance = residualVarianceData.result(),
              residualDegreesOfFreedom = first.residualDegreesOfFreedom,
              normalizedCovariance = first.normalizedCovariance,
              standardErrors = StandardErrorBlock(standardErrorData.result()),
              diagnostics = first.diagnostics,
              coefficientCovariance = CoefficientCovariance.unsafeVoxelwise(covarianceMatrices.result())
            )
          )

  private[fit] def residualMatrix(
      design: DMat,
      response: DMat,
      coefficients: DMat
  ): DMat =
    val out = Matrix.newBuilder(response.rows, response.cols)
    var row = 0
    while row < response.rows do
      var voxel = 0
      while voxel < response.cols do
        var fitted = 0.0
        var predictor = 0
        while predictor < design.cols do
          fitted += design(row, predictor) * coefficients(predictor, voxel)
          predictor += 1
        out(row, voxel) = response(row, voxel) - fitted
        voxel += 1
      row += 1
    out.result()

  private[fit] def diagnostics(
      whitening: GlsWhitening,
      partitions: Vector[RunPartition],
      method: String,
      iterations: Int,
      biasCorrection: ArBiasCorrection = ArBiasCorrection.Raw
  ): ArDiagnostics =
    whitening match
      case GlsWhitening.Shared(plan, corrections) =>
        ArDiagnostics(
          order = plan.arOrder,
          runs = partitions.map { partition =>
            val coefficients =
              plan.pooling match
                case NoisePooling.Global => plan.coefficients.head
                case NoisePooling.Run    => plan.coefficients(partition.runIndex)
            // IID filters have no lags; report zeros at the common diagnostic
            // order while retaining the native filter and correction outcome.
            val phi = coefficients.phi.padTo(plan.arOrder, 0.0)
            ArRunDiagnostic(
              runIndex = partition.runIndex,
              rho = phi.headOption.getOrElse(0.0),
              method = method,
              rows = partition.rowIndices.length,
              coefficients = phi,
              correction = corrections.lift(partition.runIndex)
            )
          },
          iterations = iterations,
          whitening = whiteningProvenance(plan, partitions),
          biasCorrection = biasCorrection
        )

      case GlsWhitening.Voxelwise(plans, corrections) =>
        val order = plans.map(_.arOrder).max
        ArDiagnostics(
          order = order,
          runs = partitions.map { partition =>
            val perVoxel =
              plans.map { plan =>
                val segment = plan.segments.find(_.runIndex == partition.runIndex).getOrElse(plan.segments.head)
                plan.coefficientsFor(segment).phi.padTo(order, 0.0)
              }
            val summary = averageCoefficients(perVoxel, order)
            ArRunDiagnostic(
              runIndex = partition.runIndex,
              rho = summary.headOption.getOrElse(0.0),
              method = method,
              rows = partition.rowIndices.length,
              coefficients = summary,
              voxelwiseCoefficients = perVoxel,
              voxelwiseCorrections = corrections.map(_(partition.runIndex))
            )
          },
          iterations = iterations,
          sharedNormalizedCovariance = false,
          whitening = whiteningProvenance(plans.head, partitions),
          biasCorrection = biasCorrection
        )

  private def whiteningProvenance(
      plan: WhiteningPlan,
      partitions: Vector[RunPartition]
  ): ArWhiteningProvenance =
    val segments =
      plan.segments.map { segment =>
        val partition =
          partitions.find(_.runIndex == segment.runIndex).getOrElse {
            throw new IllegalArgumentException(s"whitening segment has no run partition: ${segment.runIndex}")
          }
        val sourceTimepoints =
          partition.rowIndices.zip(partition.timepoints).collect {
            case (row, timepoint) if segment.contains(row) => timepoint
          }
        ArWhiteningSegment(
          runIndex = segment.runIndex,
          startRow = segment.start,
          endRowExclusive = segment.endExclusive,
          startTimepoint = sourceTimepoints.head,
          endTimepointExclusive = sourceTimepoints.last + 1
        )
      }
    val gaps =
      segments.sliding(2).collect {
        case Vector(left, right)
            if left.runIndex == right.runIndex && right.startTimepoint > left.endTimepointExclusive =>
          ArCensorGap(
            runIndex = left.runIndex,
            startTimepoint = left.endTimepointExclusive,
            endTimepointExclusive = right.startTimepoint
          )
      }.toVector
    ArWhiteningProvenance(
      method = plan.method,
      pooling = plan.pooling,
      initialCondition = plan.initialCondition,
      segments = segments,
      censorGaps = gaps
    )

  private[fit] def diagnosticIterations(config: AutocorrelationConfig): Int =
    config.coefficients match
      case ArCoefficientSpec.Estimate => config.iterations
      case _                          => 0

  private def matrixColumn(matrix: DMat, col: Int): DMat =
    val out = Matrix.newBuilder(matrix.rows, 1)
    var row = 0
    while row < matrix.rows do
      out(row, 0) = matrix(row, col)
      row += 1
    out.result()

  private def averageCoefficients(coefficients: Vector[Vector[Double]], order: Int): Vector[Double] =
    val out = new Array[Double](order)
    var row = 0
    while row < coefficients.length do
      var col = 0
      while col < order do
        out(col) += coefficients(row)(col)
        col += 1
      row += 1
    var col = 0
    while col < order do
      out(col) /= coefficients.length.toDouble
      col += 1
    out.toVector

  private[fit] def arToFitError(error: ArError): FitError =
    FitError.UnsupportedAutocorrelation(error.message)

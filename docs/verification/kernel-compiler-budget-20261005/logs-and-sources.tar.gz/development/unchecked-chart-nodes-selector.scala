package scalafim.fmri.design.hrf

class KernelBasisMutationSuite extends KernelBasisBudgetSuite:
  override def munitTests(): Seq[munit.Test] =
    val names = Set("finite-chart-width-with-overflowing-node-intermediate-is-refused")
    val selected = super.munitTests().filter(t => names.contains(t.name))
    require(selected.size == names.size && selected.map(_.name).toSet == names)
    selected

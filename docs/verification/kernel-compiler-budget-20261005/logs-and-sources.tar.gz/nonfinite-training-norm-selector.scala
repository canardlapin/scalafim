package scalafim.fmri.design.hrf

class KernelBasisMutationSuite extends KernelBasisBudgetSuite:
  override def munitTests(): Seq[munit.Test] =
    val names = Set("training-refuses-finite-values-with-overflowing-column-norm")
    val selected = super.munitTests().filter(t => names.contains(t.name))
    require(selected.size == names.size && selected.map(_.name).toSet == names)
    selected

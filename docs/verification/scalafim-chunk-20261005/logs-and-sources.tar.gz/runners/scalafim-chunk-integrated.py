from pathlib import Path
import os, json, subprocess, time, re, datetime, tarfile, hashlib
root = Path('/Users/bbuchsbaum/code/scala/scalafim')
logs = Path('/private/tmp/scalafim-chunk-integrated-20261005')
logs.mkdir(exist_ok=True)
env = dict(os.environ, COURSIER_REPOSITORIES='https://repo.maven.apache.org/maven2')
gates = [
 ('hrf-design', ['hrfJVM/test','hrfJS/test','designJVM/test','designJS/test']),
 ('fit', ['fitJVM/test','fitJS/test']),
 ('admission-consumers', [
  'firstLevelLawsJVM/testOnly scalafim.fmri.laws.profile.ObservedFamilyAdmissionSuite',
  'firstLevelLawsJS/testOnly scalafim.fmri.laws.profile.ObservedFamilyAdmissionSuite'])
]
results = []
for label, tasks in gates:
 command = ['python3','tools/build/sbt-warm',*tasks]
 start = time.monotonic()
 with (logs/(label+'.log')).open('w') as out:
  proc = subprocess.run(command,cwd=root,env=env,stdout=out,stderr=subprocess.STDOUT)
 content = (logs/(label+'.log')).read_text()
 summaries = [dict(total=int(m[0]), failed=int(m[1]), errors=int(m[2]), passed=int(m[3]))
  for m in re.findall(r'Passed: Total (\d+), Failed (\d+), Errors (\d+), Passed (\d+)',content)]
 row = dict(label=label,command=command,exit_code=proc.returncode,
  seconds=round(time.monotonic()-start,3),summaries=summaries,compiler_warnings='[warn]' in content)
 results.append(row)
 (logs/'runs.json').write_text(json.dumps(results,indent=2)+'\n')
 print(json.dumps(row),flush=True)
 if proc.returncode != 0:
  raise SystemExit(proc.returncode)
 assert len(summaries)==len(tasks), (label,summaries)
 assert not row['compiler_warnings'], label
 assert all(s['failed']==0 and s['errors']==0 and s['passed']>0 for s in summaries)
print('All integrated JVM/Scala.js gates passed warning-clean.',flush=True)

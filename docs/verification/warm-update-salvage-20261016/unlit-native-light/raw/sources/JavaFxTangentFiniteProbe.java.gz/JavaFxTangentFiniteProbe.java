package com.sun.prism.impl;
import com.sun.javafx.geom.Vec2f;
import com.sun.javafx.geom.Vec3f;
import com.sun.javafx.geom.Quat4f;
public final class JavaFxTangentFiniteProbe {
  public static void main(String[] args) {
    Vec3f[] p={new Vec3f(0,0,0),new Vec3f(1,0,0),new Vec3f(0,1,0),new Vec3f(0,0,1)};
    Vec3f[] n={new Vec3f(.57735026f,.57735026f,.57735026f),new Vec3f(-1,0,0),new Vec3f(0,-1,0),new Vec3f(0,0,-1)};
    int[][] faces={{0,1,2},{0,2,3},{0,3,1},{1,3,2}};
    int invalid=0;
    for(int face=0;face<4;face++) {
      int[] f=faces[face];
      float left=(4*face+.5f)/16, right=(4*face+3.5f)/16;
      Vec3f[] basis={new Vec3f(),new Vec3f(),new Vec3f()};
      MeshUtil.computeTBNNormalized(p[f[0]],p[f[1]],p[f[2]],new Vec2f(left,.875f),new Vec2f(right,.875f),new Vec2f(left,.125f),basis);
      for(int corner=0;corner<3;corner++) {
        Vec3f[] ntb={new Vec3f(n[f[corner]]),new Vec3f(basis[1]),new Vec3f(basis[2])};
        ntb[0].normalize();
        MeshUtil.fixTSpace(ntb);
        Quat4f q=new Quat4f();
        MeshUtil.buildQuat(ntb,q);
        boolean finite=Float.isFinite(q.x)&&Float.isFinite(q.y)&&Float.isFinite(q.z)&&Float.isFinite(q.w);
        if(!finite)invalid++;
        System.out.println("face="+face+" vertex="+f[corner]+" finite="+finite+" quaternion="+q.x+","+q.y+","+q.z+","+q.w);
      }
    }
    if(invalid!=6)throw new AssertionError("Expected six nonfinite face-corner quaternions, found "+invalid);
    System.out.println("REPRODUCED: six nonfinite quaternions in stock JavaFX tangent conversion; sloped face all finite.");
  }
}

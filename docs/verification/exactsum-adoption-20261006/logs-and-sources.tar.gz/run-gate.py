import json,os,subprocess,sys,time
from pathlib import Path
root=Path("/Users/bbuchsbaum/code/scala/scalafim")
out=Path(__file__).resolve().parent
env=dict(os.environ)
for name in ["JAVA_TOOL_OPTIONS","JDK_JAVA_OPTIONS","SBT_OPTS"]:
 env.pop(name,None)
env["SBT_WARM_HEAP"]="4g"
env["SBT_WARM_CPUS"]="2"
name=sys.argv[1];commands=sys.argv[2:]
assert not any("scalafim.gale.build" in command for command in commands)
started=time.time()
with (out/(name+".log")).open("w") as log:
 result=subprocess.run(["python3","tools/build/sbt-warm",*commands],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
receipt={"commands":commands,"exit_code":result.returncode,"elapsed_seconds":time.time()-started,"source_overrides":[],"requested_heap":"4g","requested_cpus":2,"jdk":subprocess.run(["java","-version"],env=env,capture_output=True,text=True).stderr.strip(),"node":subprocess.check_output(["node","--version"],env=env,text=True).strip()}
(out/(name+".json")).write_text(json.dumps(receipt,indent=2)+"\n")
print(json.dumps(receipt),flush=True)
sys.exit(result.returncode)

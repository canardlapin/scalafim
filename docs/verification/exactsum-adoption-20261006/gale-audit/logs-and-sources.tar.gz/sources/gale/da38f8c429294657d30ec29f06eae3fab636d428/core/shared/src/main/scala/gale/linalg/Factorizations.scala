package gale.linalg

import gale.backend.Backend
import gale.kernel.DoubleKernels
import gale.platform.DoubleArray
import gale.platform.DoubleArray.*
import gale.platform.PlatformMath.fma

final case class FactorizationDiagnostics(
    info: Int = 0,
    rank: Option[Int] = None,
    rankTolerance: Option[Double] = None
):
  def isSuccess: Boolean =
    info == 0

/** The row permutation produced by LU pivoting: `apply(i)` is the original row that ends up in position `i`.
  *
  * `toArray` / `toIndexSeq` are public `Int`-index accessors. P4 restricted `Double` storage to the platform-specific
  * interop doorway, but index arrays are plain `Array[Int]` and safe to expose: both accessors hand back an independent
  * copy, so callers can read or mutate the result without touching the factorization's internal state.
  */
final class PivotVector private (private val values: Array[Int]):
  def length: Int =
    values.length

  def apply(index: Int): Int =
    if index < 0 || index >= values.length then throw LinAlgError.IndexOutOfBounds(index, values.length)
    values(index)

  /** A fresh `Array[Int]` copy of the pivots; safe to mutate. */
  def toArray: Array[Int] =
    values.clone()

  /** An immutable snapshot of the pivots, for callers that want no copy to guard. */
  def toIndexSeq: IndexedSeq[Int] =
    values.toIndexedSeq

object PivotVector:
  def apply(values: Int*): PivotVector =
    new PivotVector(values.toArray)

  private[gale] def fromArray(values: Array[Int]): PivotVector =
    new PivotVector(values.clone())

enum QRPivoting:
  case Disabled
  case Column

final case class QROptions(
    pivoting: QRPivoting = QRPivoting.Disabled,
    rankTolerance: Option[Double] = None
):
  require(
    rankTolerance.forall(value => value >= 0.0 && value.isFinite),
    "QR rank tolerance must be finite and non-negative"
  )

object QROptions:
  val Default: QROptions =
    QROptions()

final case class CholeskyOptions(pivotTolerance: Double = 0.0):
  require(
    pivotTolerance >= 0.0 && pivotTolerance.isFinite,
    "Cholesky pivot tolerance must be finite and non-negative"
  )

object CholeskyOptions:
  val Default: CholeskyOptions =
    CholeskyOptions()

/** For pivoted QR, `apply(i)` is the original input column represented by factor column `i`, so
  * `Q * R == A(:, columnPermutation)`.
  */
final class ColumnPermutation private (private val values: Array[Int]):
  def length: Int =
    values.length

  def apply(index: Int): Int =
    if index < 0 || index >= values.length then throw LinAlgError.IndexOutOfBounds(index, values.length)
    values(index)

  def isIdentity: Boolean =
    var i = 0
    while i < values.length do
      if values(i) != i then return false
      i += 1
    true

  def toArray: Array[Int] =
    values.clone()

  def toIndexSeq: IndexedSeq[Int] =
    values.toIndexedSeq

object ColumnPermutation:
  def identity(size: Int): ColumnPermutation =
    require(size >= 0, "permutation size must be non-negative")
    new ColumnPermutation(Array.tabulate(size)(i => i))

  private[gale] def fromArray(values: Array[Int]): ColumnPermutation =
    new ColumnPermutation(values.clone())

final case class LU private[gale] (
    packed: DMat,
    pivots: PivotVector,
    parity: Int,
    diagnostics: FactorizationDiagnostics
) extends ExactSolveFactor:
  def size: Int = packed.rows

  def solve(b: DVec): Either[LinAlgError, DVec] =
    DenseDecompositions.solve(this, b)

  def solve(b: DMat): Either[LinAlgError, DMat] =
    DenseDecompositions.solve(this, b)

  def det: Either[LinAlgError, Double] =
    DenseDecompositions.det(this)

/** Cholesky factorization `A = L Lᵀ` of a symmetric positive-definite matrix, holding the lower factor `L`.
  *
  * The factorization reads only the '''lower triangle''' of the input (including the diagonal); the strict upper
  * triangle is never inspected, so `A` is treated as symmetric by assumption and any asymmetry in its upper triangle is
  * ignored. A non-positive pivot yields `Left(`[[LinAlgError.NotPositiveDefinite]]`)`.
  */
final case class Cholesky private[gale] (
    lower: DMat,
    diagnostics: FactorizationDiagnostics,
    options: CholeskyOptions = CholeskyOptions.Default
) extends ExactSolveFactor:
  def size: Int = lower.rows

  def solve(b: DVec): Either[LinAlgError, DVec] =
    DenseDecompositions.solve(this, b)

  def solve(b: DMat): Either[LinAlgError, DMat] =
    DenseDecompositions.solve(this, b)

/** Householder QR of an `m x n` matrix, stored compactly.
  *
  * Rather than materialising the `m x m` orthogonal factor, the factorization keeps the `min(m, n)` elementary
  * reflectors (`reflectors`, column `k` holding the length-`m` Householder vector `v_k`, zero above row `k`) and their
  * scalars (`tau`, where `tau(k) = 2 / (v_k · v_k)`), plus the upper-triangular `r`. The dense `q` is rebuilt on
  * demand; `solveLeastSquares` applies `Qᵀ` implicitly through the reflectors, so it never forms `Q`.
  */
final case class QR private[gale] (
    reflectors: DMat,
    tau: DoubleArray,
    r: DMat,
    diagnostics: FactorizationDiagnostics,
    columnPermutation: ColumnPermutation,
    options: QROptions
) extends LeastSquaresFactor:
  def observationCount: Int = reflectors.rows

  def coefficientCount: Int = r.cols

  /** The orthogonal factor `Q` (`m x m`), materialised from the stored reflectors on first access and cached
    * thereafter.
    */
  lazy val q: DMat =
    DenseDecompositions.materializeQ(this)

  def solveLeastSquares(b: DVec): Either[LinAlgError, DVec] =
    DenseDecompositions.solveLeastSquares(this, b)

  def solveLeastSquares(b: DMat): Either[LinAlgError, DMat] =
    DenseDecompositions.solveLeastSquares(this, b)

  /** Solve with caller-owned transformed-RHS scratch and an owned result. */
  def solveLeastSquaresWith(b: DVec, workspace: DenseWorkspace): Either[LinAlgError, DVec] =
    DenseDecompositions.solveLeastSquaresWith(this, b, workspace)

  /** Solve with caller-owned transformed-RHS scratch and an owned result. */
  def solveLeastSquaresWith(b: DMat, workspace: DenseWorkspace): Either[LinAlgError, DMat] =
    DenseDecompositions.solveLeastSquaresWith(this, b, workspace)

  /** Solve against `diag(scales) * b` without materializing the scaled RHS. Zero and negative finite scales are
    * algebraically supported; non-finite scales are rejected.
    */
  def solveLeastSquaresScaledRowsWith(
      b: DVec,
      scales: DVec,
      workspace: DenseWorkspace
  ): Either[LinAlgError, DVec] =
    DenseDecompositions.solveLeastSquaresScaledRowsWith(this, b, scales, workspace)

  /** Matrix-RHS form of [[solveLeastSquaresScaledRowsWith]]. */
  def solveLeastSquaresScaledRowsWith(
      b: DMat,
      scales: DVec,
      workspace: DenseWorkspace
  ): Either[LinAlgError, DMat] =
    DenseDecompositions.solveLeastSquaresScaledRowsWith(this, b, scales, workspace)

  def applyQ(b: DMat): Either[LinAlgError, DMat] =
    DenseDecompositions.applyQ(this, b, transpose = false)

  def applyQT(b: DMat): Either[LinAlgError, DMat] =
    DenseDecompositions.applyQ(this, b, transpose = true)

  def residualize(b: DMat): Either[LinAlgError, DMat] =
    DenseDecompositions.residualize(this, b)

  def normalizedCovariance: Either[LinAlgError, DMat] =
    DenseDecompositions.normalizedCovariance(this)

object DenseDecompositions:
  def lu(A: DMat): Either[LinAlgError, LU] =
    if A.rows != A.cols then Left(LinAlgError.NonSquareMatrix(A.shape))
    else
      val n = A.rows
      val packed = A.toDoubleArrayCopyRowMajor
      val pivots = new Array[Int](n)
      var i = 0
      while i < n do
        pivots(i) = i
        i += 1

      var parity = 1
      var k = 0
      while k < n do
        var pivot = k
        var maxAbs = math.abs(packed(k * n + k))
        i = k + 1
        while i < n do
          val candidate = math.abs(packed(i * n + k))
          if candidate > maxAbs then
            maxAbs = candidate
            pivot = i
          i += 1

        if maxAbs == 0.0 || maxAbs.isNaN then return Left(LinAlgError.SingularMatrix(k))

        if pivot != k then
          swapRows(packed, n, k, pivot)
          val tmpPivot = pivots(k)
          pivots(k) = pivots(pivot)
          pivots(pivot) = tmpPivot
          parity = -parity

        val pivotValue = packed(k * n + k)
        i = k + 1
        while i < n do
          val ik = i * n + k
          packed(ik) = packed(ik) / pivotValue
          val multiplier = packed(ik)
          var j = k + 1
          while j < n do
            packed(i * n + j) = packed(i * n + j) - multiplier * packed(k * n + j)
            j += 1
          i += 1
        k += 1

      Right(
        LU(
          packed = DMat.fromDoubleArrayOwned(n, n, packed),
          pivots = PivotVector.fromArray(pivots),
          parity = parity,
          diagnostics = FactorizationDiagnostics(info = 0)
        )
      )

  def cholesky(A: DMat): Either[LinAlgError, Cholesky] =
    cholesky(A, CholeskyOptions.Default)

  def cholesky(A: DMat, options: CholeskyOptions): Either[LinAlgError, Cholesky] =
    if A.rows != A.cols then Left(LinAlgError.NonSquareMatrix(A.shape))
    else
      val n = A.rows
      val lower = DoubleArray.alloc(n * n)
      var i = 0
      while i < n do
        var j = 0
        while j <= i do
          var sum = A(i, j)
          var k = 0
          while k < j do
            sum -= lower(i * n + k) * lower(j * n + k)
            k += 1
          if i == j then
            if sum <= options.pivotTolerance || sum.isNaN then return Left(LinAlgError.NotPositiveDefinite(i))
            lower(i * n + j) = math.sqrt(sum)
          else lower(i * n + j) = sum / lower(j * n + j)
          j += 1
        i += 1
      Right(
        Cholesky(
          lower = DMat.fromDoubleArrayOwned(n, n, lower),
          diagnostics = FactorizationDiagnostics(info = 0),
          options = options
        )
      )

  def qr(A: DMat)(using Backend): QR =
    qr(A, QROptions.Default, DenseWorkspace.forQR(A.rows, A.cols))

  def qr(A: DMat, options: QROptions)(using Backend): QR =
    qr(A, options, DenseWorkspace.forQR(A.rows, A.cols, options))

  def qr(A: DMat, workspace: DenseWorkspace)(using backend: Backend): QR =
    qr(A, QROptions.Default, workspace)

  def qr(A: DMat, options: QROptions, workspace: DenseWorkspace)(using backend: Backend): QR =
    qrOwned(A.rows, A.cols, A.toDoubleArrayCopyRowMajor, options, workspace)

  private[gale] def qrOwned(
      m: Int,
      n: Int,
      r: DoubleArray,
      options: QROptions,
      workspace: DenseWorkspace
  )(using backend: Backend): QR =
    val limit = math.min(m, n)
    // Compact storage: reflectors column k holds v_k (length m, zero above row k),
    // tau(k) = 2 / (v_k · v_k). No m x m Q is formed here; it is rebuilt on demand.
    val reflectors = DoubleArray.alloc(m * limit)
    val tau = DoubleArray.alloc(limit)
    val requirement = DenseWorkspace.qrRequirement(m, n, options) match
      case Left(error)  => throw error
      case Right(value) => value
    val scratch = workspace.doubles(requirement)
    val permutation = Array.tabulate(n)(i => i)

    if options.pivoting == QRPivoting.Column then factorPivotedQR(r, m, n, reflectors, limit, tau, scratch, permutation)
    else if DenseWorkspace.usesBlockedQR(m, n) then factorBlockedQR(r, m, n, reflectors, limit, tau, scratch)
    else factorUnblockedQR(r, m, n, reflectors, limit, tau, scratch)

    val rankTolerance = options.rankTolerance.getOrElse(rankToleranceFromUpperTriangular(r, m, n))
    val rank = rankFromUpperTriangular(r, m, n, rankTolerance)
    QR(
      reflectors = DMat.fromDoubleArrayOwned(m, limit, reflectors),
      tau = tau,
      r = DMat.fromDoubleArrayOwned(m, n, r),
      diagnostics = FactorizationDiagnostics(
        info = 0,
        rank = Some(rank),
        rankTolerance = Some(rankTolerance)
      ),
      columnPermutation = ColumnPermutation.fromArray(permutation),
      options = options
    )

  def qrScaledRows(
      A: DMat,
      scales: DVec,
      options: QROptions,
      workspace: DenseWorkspace
  )(using Backend): Either[LinAlgError, QR] =
    validateRowScales(scales, A.rows) match
      case Left(error) => Left(error)
      case Right(_)    =>
        val m = A.rows
        val n = A.cols
        val r = DoubleArray.alloc(m * n)
        var row = 0
        while row < m do
          val scale = scales.data(scales.offset.value + row * scales.stride.value)
          var source = A.offset.value + row * A.rowStride.value
          var col = 0
          while col < n do
            r(row * n + col) = scale * A.data(source)
            source += A.colStride.value
            col += 1
          row += 1
        Right(qrOwned(m, n, r, options, workspace))

  /** Rank-revealing unblocked QR with exact column-pivot selection.
    *
    * Both widths select the pivot from exact `dnrm2` values in ascending column order under the same strict-improvement
    * rule; they differ only in how the scans that cannot win are avoided. The default unpivoted path retains the
    * blocked fast kernel.
    */
  private def factorPivotedQR(
      r: DoubleArray,
      m: Int,
      n: Int,
      reflectors: DoubleArray,
      limit: Int,
      tau: DoubleArray,
      scratch: DoubleArray,
      permutation: Array[Int]
  ): Unit =
    // Scalar-local row-first norms are admitted for compact statistical
    // designs, where the accumulator pairs stay in registers. Wider designs
    // screen with downdated norms instead; the scratch-array row-first
    // candidate did not clear the benchmark court at those widths.
    if n <= 8 then factorPivotedQRRowFirst(r, m, n, reflectors, limit, tau, scratch, permutation)
    else factorPivotedQRScreened(r, m, n, reflectors, limit, tau, scratch, permutation)

  /** Compact-width pivoted QR: every trailing column norm is recomputed before each pivot decision, but all columns
    * share one row-contiguous matrix pass with the scaled accumulation and row order of `dnrm2` held in locals.
    */
  private def factorPivotedQRRowFirst(
      r: DoubleArray,
      m: Int,
      n: Int,
      reflectors: DoubleArray,
      limit: Int,
      tau: DoubleArray,
      scratch: DoubleArray,
      permutation: Array[Int]
  ): Unit =
    var k = 0
    while k < limit do
      exactTrailingColumnNormsScalarRowMajor(r, m, n, k, scratch)
      var pivot = k
      var bestNorm = -1.0
      var col = k
      while col < n do
        val norm = scratch(col) * math.sqrt(scratch(n + col))
        if norm > bestNorm then
          bestNorm = norm
          pivot = col
        col += 1
      // Read the chosen column's actual accumulator so Householder sees exactly
      // the value a fresh `dnrm2` would have produced, including when every
      // norm is NaN and `bestNorm` remains the scan sentinel.
      val selectedNorm = scratch(pivot) * math.sqrt(scratch(n + pivot))
      if pivot != k then
        swapColumns(r, m, n, k, pivot)
        val original = permutation(k)
        permutation(k) = permutation(pivot)
        permutation(pivot) = original
      factorHouseholder(r, m, n, reflectors, limit, tau, k, selectedNorm)
      applyReflectorToColumns(r, m, n, reflectors, limit, tau(k), k, k + 1, n, scratch, 0)
      k += 1

  /** Wide-width pivoted QR that measures only the columns which can still hold the largest norm.
    *
    * Applying the step-`k` reflector is orthogonal on rows `k..m-1`, so `‖A(k+1:m, j)‖² = ‖A(k:m, j)‖² - R(k, j)²`
    * holds exactly in real arithmetic. This path carries that downdate for every trailing column alongside a running
    * bound on the rounding error the downdate has accumulated, which makes `[estimate - bound, estimate + bound]` an
    * enclosure of the squared norm a fresh `dnrm2` scan would report.
    *
    * The enclosure is used only to discard columns that provably cannot hold the maximum. Every surviving column is
    * then measured by the same `dnrm2` scan, in the same ascending order, under the same strict-improvement rule as
    * recomputing all of them, so the pivot index, the tie choice, the rank decision, and the `selectedNorm` handed to
    * `factorHouseholder` are unchanged. Only discarded scans are saved: a step costs one scan rather than one per
    * trailing column whenever the columns are separated, and falls back to measuring all of them when they are not.
    */
  private def factorPivotedQRScreened(
      r: DoubleArray,
      m: Int,
      n: Int,
      reflectors: DoubleArray,
      limit: Int,
      tau: DoubleArray,
      scratch: DoubleArray,
      permutation: Array[Int]
  ): Unit =
    // The reflector update owns `scratch(0 until n)`, so both per-column
    // regions live past it and survive across steps.
    val estimates = n
    val bounds = 2 * n
    var col = 0
    while col < n do
      val norm = DoubleKernels.dnrm2(m, r, col, n)
      val square = norm * norm
      scratch(estimates + col) = square
      scratch(bounds + col) = pivotScreenMeasuredBound(square, m)
      col += 1

    var k = 0
    while k < limit do
      // The largest lower bound any trailing column can claim. A column whose
      // enclosure lies entirely below it cannot hold the maximum.
      var screen = Double.NegativeInfinity
      col = k
      while col < n do
        val lower = scratch(estimates + col) - scratch(bounds + col)
        if lower > screen then screen = lower
        col += 1

      var pivot = k
      var bestNorm = -1.0
      col = k
      while col < n do
        // Negated so a NaN enclosure stays in the measured set and reaches the
        // same comparison it would have reached under full recomputation.
        if !(scratch(estimates + col) + scratch(bounds + col) < screen) then
          val norm = DoubleKernels.dnrm2(m - k, r, k * n + col, n)
          val square = norm * norm
          scratch(estimates + col) = square
          scratch(bounds + col) = pivotScreenMeasuredBound(square, m - k)
          if norm > bestNorm then
            bestNorm = norm
            pivot = col
        col += 1

      // `bestNorm` deliberately remains the scan sentinel when every measured
      // norm is NaN. Read the chosen column's actual accumulator so Householder
      // sees exactly the non-finite value a fresh `dnrm2` would have produced.
      val selectedNorm =
        if bestNorm >= 0.0 then bestNorm
        else DoubleKernels.dnrm2(m - k, r, k * n + pivot, n)

      if pivot != k then
        swapColumns(r, m, n, k, pivot)
        val original = permutation(k)
        permutation(k) = permutation(pivot)
        permutation(pivot) = original
        val movedEstimate = scratch(estimates + k)
        scratch(estimates + k) = scratch(estimates + pivot)
        scratch(estimates + pivot) = movedEstimate
        val movedBound = scratch(bounds + k)
        scratch(bounds + k) = scratch(bounds + pivot)
        scratch(bounds + pivot) = movedBound

      factorHouseholder(r, m, n, reflectors, limit, tau, k, selectedNorm)
      applyReflectorToColumns(r, m, n, reflectors, limit, tau(k), k, k + 1, n, scratch, 0)

      // Downdate past the row the reflector just resolved, then widen each
      // bound by the rounding the square and the subtraction introduced.
      col = k + 1
      while col < n do
        val resolved = r(k * n + col)
        val resolvedSquare = resolved * resolved
        val updated = scratch(estimates + col) - resolvedSquare
        scratch(estimates + col) = updated
        scratch(bounds + col) = scratch(bounds + col) +
          (resolvedSquare + math.abs(updated)) * PivotScreenStepRounding
        col += 1
      k += 1

  /** IEEE machine epsilon for `Double` (2^-52), the pivot-screen bound scale. */
  private inline val PivotScreenEpsilon = 2.220446049250313e-16

  /** Rounding admitted by one downdate: the square, and the subtraction that consumes it. Two epsilons carry both with
    * slack.
    */
  private inline val PivotScreenStepRounding = 2.0 * PivotScreenEpsilon

  /** Bound on how far a squared norm measured now can sit from the value a later `dnrm2` scan reports for the same
    * column.
    *
    * `dnrm2` admits one scaled update per scanned row, so its relative error grows with the scan length; squaring
    * doubles that, and the constant term carries the final rounding of the square itself with slack. A bound that is
    * too wide only costs scans that the screen then declines to discard.
    */
  private def pivotScreenMeasuredBound(square: Double, length: Int): Double =
    math.abs(square) * ((2.0 * length.toDouble + 8.0) * PivotScreenEpsilon)

  /** Small-width row-first norm pass with accumulator pairs held in locals. Predictable width guards avoid scratch
    * traffic inside the matrix scan and cover the compact statistical-design regime directly.
    */
  private def exactTrailingColumnNormsScalarRowMajor(
      r: DoubleArray,
      m: Int,
      n: Int,
      k: Int,
      scratch: DoubleArray
  ): Unit =
    val width = n - k
    var scale0, scale1, scale2, scale3 = 0.0
    var scale4, scale5, scale6, scale7 = 0.0
    var ssq0, ssq1, ssq2, ssq3 = 1.0
    var ssq4, ssq5, ssq6, ssq7 = 1.0
    var row = k
    while row < m do
      val offset = row * n + k
      var value = r(offset)
      if value != 0.0 then
        val abs = math.abs(value)
        if scale0 < abs then
          val ratio = scale0 / abs
          ssq0 = 1.0 + ssq0 * ratio * ratio
          scale0 = abs
        else
          val ratio = abs / scale0
          ssq0 += ratio * ratio
      if width > 1 then
        value = r(offset + 1)
        if value != 0.0 then
          val abs = math.abs(value)
          if scale1 < abs then
            val ratio = scale1 / abs
            ssq1 = 1.0 + ssq1 * ratio * ratio
            scale1 = abs
          else
            val ratio = abs / scale1
            ssq1 += ratio * ratio
      if width > 2 then
        value = r(offset + 2)
        if value != 0.0 then
          val abs = math.abs(value)
          if scale2 < abs then
            val ratio = scale2 / abs
            ssq2 = 1.0 + ssq2 * ratio * ratio
            scale2 = abs
          else
            val ratio = abs / scale2
            ssq2 += ratio * ratio
      if width > 3 then
        value = r(offset + 3)
        if value != 0.0 then
          val abs = math.abs(value)
          if scale3 < abs then
            val ratio = scale3 / abs
            ssq3 = 1.0 + ssq3 * ratio * ratio
            scale3 = abs
          else
            val ratio = abs / scale3
            ssq3 += ratio * ratio
      if width > 4 then
        value = r(offset + 4)
        if value != 0.0 then
          val abs = math.abs(value)
          if scale4 < abs then
            val ratio = scale4 / abs
            ssq4 = 1.0 + ssq4 * ratio * ratio
            scale4 = abs
          else
            val ratio = abs / scale4
            ssq4 += ratio * ratio
      if width > 5 then
        value = r(offset + 5)
        if value != 0.0 then
          val abs = math.abs(value)
          if scale5 < abs then
            val ratio = scale5 / abs
            ssq5 = 1.0 + ssq5 * ratio * ratio
            scale5 = abs
          else
            val ratio = abs / scale5
            ssq5 += ratio * ratio
      if width > 6 then
        value = r(offset + 6)
        if value != 0.0 then
          val abs = math.abs(value)
          if scale6 < abs then
            val ratio = scale6 / abs
            ssq6 = 1.0 + ssq6 * ratio * ratio
            scale6 = abs
          else
            val ratio = abs / scale6
            ssq6 += ratio * ratio
      if width > 7 then
        value = r(offset + 7)
        if value != 0.0 then
          val abs = math.abs(value)
          if scale7 < abs then
            val ratio = scale7 / abs
            ssq7 = 1.0 + ssq7 * ratio * ratio
            scale7 = abs
          else
            val ratio = abs / scale7
            ssq7 += ratio * ratio
      row += 1

    scratch(k) = scale0
    scratch(n + k) = ssq0
    if width > 1 then
      scratch(k + 1) = scale1
      scratch(n + k + 1) = ssq1
    if width > 2 then
      scratch(k + 2) = scale2
      scratch(n + k + 2) = ssq2
    if width > 3 then
      scratch(k + 3) = scale3
      scratch(n + k + 3) = ssq3
    if width > 4 then
      scratch(k + 4) = scale4
      scratch(n + k + 4) = ssq4
    if width > 5 then
      scratch(k + 5) = scale5
      scratch(n + k + 5) = ssq5
    if width > 6 then
      scratch(k + 6) = scale6
      scratch(n + k + 6) = ssq6
    if width > 7 then
      scratch(k + 7) = scale7
      scratch(n + k + 7) = ssq7

  /** Small-shape QR: scalar Householder generation with row-major rank-1 updates. Keeping this path avoids compact-WY
    * setup overhead where Gale is already ahead of Breeze.
    */
  private def factorUnblockedQR(
      r: DoubleArray,
      m: Int,
      n: Int,
      reflectors: DoubleArray,
      limit: Int,
      tau: DoubleArray,
      scratch: DoubleArray
  ): Unit =
    var k = 0
    while k < limit do
      factorHouseholder(r, m, n, reflectors, limit, tau, k)
      applyReflectorToColumns(r, m, n, reflectors, limit, tau(k), k, k + 1, n, scratch, 0)
      k += 1

  /** Large-shape QR using compact WY panels. Each panel is factored with the unblocked kernel, but its reflectors are
    * aggregated as `H = I - V T Vᵀ`; the trailing matrix receives `Hᵀ` through two GEMMs.
    */
  private def factorBlockedQR(
      r: DoubleArray,
      m: Int,
      n: Int,
      reflectors: DoubleArray,
      limit: Int,
      tau: DoubleArray,
      scratch: DoubleArray
  )(using backend: Backend): Unit =
    val block = DenseWorkspace.QrBlockSize
    val vtOffset = 0
    val wOffset = block * m
    val tOffset = wOffset + block * n
    var panelStart = 0
    while panelStart < limit do
      val panelEnd = math.min(panelStart + block, limit)
      var k = panelStart
      while k < panelEnd do
        factorHouseholder(r, m, n, reflectors, limit, tau, k)
        applyReflectorToColumns(r, m, n, reflectors, limit, tau(k), k, k + 1, panelEnd, scratch, wOffset)
        k += 1

      if panelEnd < n then
        val panelWidth = panelEnd - panelStart
        formCompactWY(reflectors, m, limit, tau, panelStart, panelWidth, scratch, tOffset, wOffset, block)
        applyCompactWYTranspose(
          r,
          m,
          n,
          reflectors,
          limit,
          panelStart,
          panelEnd,
          panelWidth,
          scratch,
          vtOffset,
          wOffset,
          tOffset,
          block
        )
      panelStart = panelEnd

  /** Build one normalized Householder reflector with a scaled `dnrm2` norm. The stored vector has `v(k)=1`;
    * `tau=2/(vᵀv)` and the transformed diagonal is written directly to `R`. This is the stable `dlarfg` convention.
    */
  private def factorHouseholder(
      r: DoubleArray,
      m: Int,
      n: Int,
      reflectors: DoubleArray,
      limit: Int,
      tau: DoubleArray,
      k: Int
  ): Unit =
    val diagIndex = k * n + k
    val norm = DoubleKernels.dnrm2(m - k, r, diagIndex, n)
    factorHouseholder(r, m, n, reflectors, limit, tau, k, norm)

  /** Build a Householder reflector from an already exact norm. Pivoted QR uses this overload to avoid rescanning the
    * selected strided column.
    */
  private def factorHouseholder(
      r: DoubleArray,
      m: Int,
      n: Int,
      reflectors: DoubleArray,
      limit: Int,
      tau: DoubleArray,
      k: Int,
      norm: Double
  ): Unit =
    val diagIndex = k * n + k
    val x0 = r(diagIndex)
    reflectors(k * limit + k) = 1.0
    if norm > 0.0 then
      val beta = if x0 >= 0.0 then -norm else norm
      // Compute through ratios: x0-beta can overflow even when x0, beta, and
      // every input are finite (for example x0 ~= -beta ~= 1e308).
      val x0OverBeta = x0 / beta
      val denominatorOverBeta = x0OverBeta - 1.0
      val tauK = 1.0 - x0OverBeta
      tau(k) = tauK
      r(diagIndex) = beta
      var i = k + 1
      while i < m do
        val idx = i * n + k
        reflectors(i * limit + k) = (r(idx) / beta) / denominatorOverBeta
        r(idx) = 0.0
        i += 1
    else
      tau(k) = 0.0
      var i = k + 1
      while i < m do
        r(i * n + k) = 0.0
        i += 1

  /** Apply `I - tau*v*vᵀ` to a contiguous row-major column interval. The dot vector is accumulated row-first so the
    * matrix traversal stays unit-stride.
    */
  private def applyReflectorToColumns(
      r: DoubleArray,
      m: Int,
      n: Int,
      reflectors: DoubleArray,
      limit: Int,
      tauK: Double,
      k: Int,
      colFrom: Int,
      colUntil: Int,
      scratch: DoubleArray,
      scratchOffset: Int
  ): Unit =
    val width = colUntil - colFrom
    if tauK != 0.0 && width > 0 then
      var j = 0
      while j < width do
        scratch(scratchOffset + j) = 0.0
        j += 1
      var i = k
      while i < m do
        val vi = reflectors(i * limit + k)
        val rRow = i * n + colFrom
        j = 0
        while j < width do
          val wj = scratchOffset + j
          scratch(wj) = fma(vi, r(rRow + j), scratch(wj))
          j += 1
        i += 1
      j = 0
      while j < width do
        scratch(scratchOffset + j) = tauK * scratch(scratchOffset + j)
        j += 1
      i = k
      while i < m do
        val vi = reflectors(i * limit + k)
        val rRow = i * n + colFrom
        j = 0
        while j < width do
          r(rRow + j) = fma(-vi, scratch(scratchOffset + j), r(rRow + j))
          j += 1
        i += 1

  /** Form the upper-triangular compact-WY factor `T` for one reflector panel. */
  private def formCompactWY(
      reflectors: DoubleArray,
      m: Int,
      limit: Int,
      tau: DoubleArray,
      panelStart: Int,
      panelWidth: Int,
      scratch: DoubleArray,
      tOffset: Int,
      tempOffset: Int,
      tStride: Int
  )(using backend: Backend): Unit =
    var i = 0
    var j = 0
    while i < panelWidth do
      j = 0
      while j < panelWidth do
        scratch(tOffset + i * tStride + j) = 0.0
        j += 1
      i += 1

    i = 0
    while i < panelWidth do
      val globalI = panelStart + i
      val tauI = tau(globalI)
      if tauI != 0.0 then
        j = 0
        while j < i do
          var dot = 0.0
          var row = globalI
          while row < m do
            dot = fma(
              reflectors(row * limit + panelStart + j),
              reflectors(row * limit + globalI),
              dot
            )
            row += 1
          scratch(tempOffset + j) = -tauI * dot
          j += 1

        j = 0
        while j < i do
          var sum = 0.0
          var l = j
          while l < i do
            sum = fma(
              scratch(tOffset + j * tStride + l),
              scratch(tempOffset + l),
              sum
            )
            l += 1
          scratch(tOffset + j * tStride + i) = sum
          j += 1
      scratch(tOffset + i * tStride + i) = tauI
      i += 1

  /** Apply the panel product `Hᵀ = I - V Tᵀ Vᵀ` to the trailing matrix. */
  private def applyCompactWYTranspose(
      r: DoubleArray,
      m: Int,
      n: Int,
      reflectors: DoubleArray,
      limit: Int,
      panelStart: Int,
      panelEnd: Int,
      panelWidth: Int,
      scratch: DoubleArray,
      vtOffset: Int,
      wOffset: Int,
      tOffset: Int,
      tStride: Int
  )(using backend: Backend): Unit =
    val rowsRemaining = m - panelStart
    val trailingCols = n - panelEnd

    // Pack V^T row-major; V itself stays row-major in `reflectors` and feeds the
    // second GEMM without a copy.
    var j = 0
    while j < panelWidth do
      var row = 0
      while row < rowsRemaining do
        scratch(vtOffset + j * rowsRemaining + row) = reflectors((panelStart + row) * limit + panelStart + j)
        row += 1
      j += 1

    // W := V^T C.
    dispatchGemm(
      panelWidth,
      trailingCols,
      rowsRemaining,
      1.0,
      scratch,
      vtOffset,
      rowsRemaining,
      1,
      r,
      panelStart * n + panelEnd,
      n,
      1,
      0.0,
      scratch,
      wOffset,
      trailingCols,
      1
    )

    // W := T^T W. Descending rows make the triangular multiply safe in place.
    var col = 0
    while col < trailingCols do
      var i = panelWidth - 1
      while i >= 0 do
        var sum = 0.0
        var l = 0
        while l <= i do
          sum = fma(
            scratch(tOffset + l * tStride + i),
            scratch(wOffset + l * trailingCols + col),
            sum
          )
          l += 1
        scratch(wOffset + i * trailingCols + col) = sum
        i -= 1
      col += 1

    // C := C - V W.
    dispatchGemm(
      rowsRemaining,
      trailingCols,
      panelWidth,
      -1.0,
      reflectors,
      panelStart * limit + panelStart,
      limit,
      1,
      scratch,
      wOffset,
      trailingCols,
      1,
      1.0,
      r,
      panelStart * n + panelEnd,
      n,
      1
    )

  private def dispatchGemm(
      rows: Int,
      cols: Int,
      shared: Int,
      alpha: Double,
      a: DoubleArray,
      aOffset: Int,
      aRowStride: Int,
      aColStride: Int,
      b: DoubleArray,
      bOffset: Int,
      bRowStride: Int,
      bColStride: Int,
      beta: Double,
      c: DoubleArray,
      cOffset: Int,
      cRowStride: Int,
      cColStride: Int
  )(using backend: Backend): Unit =
    if backend.routesGemm(rows, cols, shared) then
      backend.denseDouble.gemm(
        rows,
        cols,
        shared,
        alpha,
        a,
        aOffset,
        aRowStride,
        aColStride,
        b,
        bOffset,
        bRowStride,
        bColStride,
        beta,
        c,
        cOffset,
        cRowStride,
        cColStride
      )
    else
      DoubleKernels.dgemm(
        rows,
        cols,
        shared,
        alpha,
        a,
        aOffset,
        aRowStride,
        aColStride,
        b,
        bOffset,
        bRowStride,
        bColStride,
        beta,
        c,
        cOffset,
        cRowStride,
        cColStride
      )

  /** Rebuild the dense `m x m` orthogonal factor from the stored reflectors.
    *
    * `Q = H_0 H_1 ... H_{limit-1}` with `H_k = I - tau_k v_k v_kᵀ`. Starting from the identity and right-multiplying by
    * each `H_k` in order accumulates `Q`.
    */
  private[gale] def materializeQ(qr: QR): DMat =
    val reflectors = qr.reflectors
    val m = reflectors.rows
    val limit = reflectors.cols
    val tau = qr.tau
    // reflectors and q are both contiguous row-major with offset 0.
    val vData = reflectors.data
    val q = identityArray(m)
    var k = 0
    while k < limit do
      val beta = tau(k)
      if beta != 0.0 then
        var row = 0
        while row < m do
          var dot = 0.0
          var i = k
          while i < m do
            dot = fma(q(row * m + i), vData(i * limit + k), dot)
            i += 1
          dot *= beta
          i = k
          while i < m do
            q(row * m + i) = fma(-dot, vData(i * limit + k), q(row * m + i))
            i += 1
          row += 1
      k += 1
    DMat.fromDoubleArrayOwned(m, m, q)

  def solve(A: DMat, b: DVec): Either[LinAlgError, DVec] =
    lu(A).flatMap(_.solve(b))

  def rankEstimate(A: DMat)(using Backend): Int =
    // QR always populates rank, so a single factorization suffices. The ambient
    // backend is threaded through so the internal blocked-QR gemms route exactly
    // as they do under the `DMat.qr` facade's pure path — one dispatch policy,
    // one numerical answer.
    qr(A).diagnostics.rank.get

  /** 1-norm condition number estimate `||A||_1 * ||A^{-1}||_1`.
    *
    * `||A^{-1}||_1` is estimated by Hager's algorithm (Higham's refinement): a handful of matvecs with `A^{-1}` and
    * `A^{-T}` locate a large column of the inverse without forming it. Each matvec is one LU back/forward solve, so the
    * total cost is two LU factorizations (of `A` and `Aᵀ`) plus O(5) solves — not the `n` solves a full inverse would
    * need. The estimate is a lower bound on the true 1-norm, so the returned condition number never exceeds the exact
    * one.
    */
  def conditionEstimate(A: DMat): Either[LinAlgError, Double] =
    if A.rows != A.cols then Left(LinAlgError.NonSquareMatrix(A.shape))
    else
      lu(A) match
        case Left(_: LinAlgError.SingularMatrix) =>
          Right(Double.PositiveInfinity)
        case Left(error) =>
          Left(error)
        case Right(luA) =>
          lu(A.t) match
            case Left(_: LinAlgError.SingularMatrix) =>
              Right(Double.PositiveInfinity)
            case Left(error) =>
              Left(error)
            case Right(luAt) =>
              hagerInverseOneNorm(A.rows, luA, luAt) match
                case Left(error)        => Left(error)
                case Right(inverseNorm) => Right(norm1(A) * inverseNorm)

  /** Hager/Higham estimate of `||A^{-1}||_1` given LU factors of `A` and `Aᵀ`.
    *
    * `luA` solves `A y = x` (applies `A^{-1}`); `luAt` solves `Aᵀ z = ξ` (applies `A^{-T}`). Iterates the standard
    * column-search recurrence for at most five steps, stopping when the search index repeats or the local optimality
    * test `||z||_inf <= zᵀx` holds.
    */
  private def hagerInverseOneNorm(n: Int, luA: LU, luAt: LU): Either[LinAlgError, Double] =
    if n == 0 then Right(0.0)
    else
      // Platform scratch reused across iterations: `xVec` / `xiVec` are stable
      // views over `x` / `xi`, re-solved after each in-place update, and the
      // solve results are read straight from their backing storage. No plain
      // Array or fromArray/toArray round-trips, so JS stays typed-array clean.
      val x = DoubleArray.alloc(n)
      val xi = DoubleArray.alloc(n)
      val xVec = new DVec(x, Offset.unsafe(0), Length.unsafe(n), Stride.unsafe(1))
      val xiVec = new DVec(xi, Offset.unsafe(0), Length.unsafe(n), Stride.unsafe(1))
      val start = 1.0 / n
      var i = 0
      while i < n do
        x(i) = start
        i += 1
      var est = 0.0
      var jOld = -1
      var iter = 0
      var converged = false
      while iter < 5 && !converged do
        solve(luA, xVec) match
          case Left(error) =>
            return Left(error)
          case Right(yVec) =>
            val yData = yVec.data
            val yOff = yVec.offset.value
            val yStep = yVec.stride.value
            est = 0.0
            i = 0
            while i < n do
              val yi = yData(yOff + i * yStep)
              est += math.abs(yi)
              xi(i) = if yi >= 0.0 then 1.0 else -1.0
              i += 1
            solve(luAt, xiVec) match
              case Left(error) =>
                return Left(error)
              case Right(zVec) =>
                val zData = zVec.data
                val zOff = zVec.offset.value
                val zStep = zVec.stride.value
                var zMax = 0.0
                var j = 0
                var zdotx = 0.0
                i = 0
                while i < n do
                  val zi = zData(zOff + i * zStep)
                  zdotx += zi * x(i)
                  val az = math.abs(zi)
                  if az > zMax then
                    zMax = az
                    j = i
                  i += 1
                if zMax <= zdotx || j == jOld then converged = true
                else
                  jOld = j
                  i = 0
                  while i < n do
                    x(i) = 0.0
                    i += 1
                  x(j) = 1.0
        iter += 1
      Right(est)

  def solve(lu: LU, b: DVec): Either[LinAlgError, DVec] =
    val n = lu.packed.rows
    if lu.packed.cols != n then Left(LinAlgError.NonSquareMatrix(lu.packed.shape))
    else if b.length != n then
      Left(LinAlgError.DimensionMismatch(Shape(Rows(n), Cols(1)), Shape(Rows(b.length), Cols(1))))
    else
      // Hoist the packed matrix's raw storage once and drive the shared
      // triangular-solve kernel: gather the permuted right-hand side, then a
      // unit-lower forward sweep and a non-unit-upper back sweep in place.
      val pData = lu.packed.data
      val pOff = lu.packed.offset.value
      val pRowStep = lu.packed.rowStride.value
      val pColStep = lu.packed.colStride.value
      val bData = b.data
      val bOff = b.offset.value
      val bStep = b.stride.value
      val pivots = lu.pivots
      // Platform scratch throughout, so JS keeps typed-array storage and the
      // result vector owns `x` directly (no Array round-trip).
      val x = DoubleArray.alloc(n)
      var i = 0
      while i < n do
        x(i) = bData(bOff + pivots(i) * bStep)
        i += 1
      // L y = Pb: unit lower diagonal, so the guard never trips here.
      DoubleKernels.dtrsv(n, lower = true, unit = true, 0.0, pData, pOff, pRowStep, pColStep, x, 0, 1)
      // U x = y: a successful LU has nonzero pivots, but guard exact zeros anyway.
      val info = DoubleKernels.dtrsv(n, lower = false, unit = false, 0.0, pData, pOff, pRowStep, pColStep, x, 0, 1)
      if info >= 0 then Left(LinAlgError.SingularMatrix(info))
      else Right(DVec.fromDoubleArrayOwned(x))

  def solve(lu: LU, b: DMat): Either[LinAlgError, DMat] =
    val n = lu.packed.rows
    if lu.packed.cols != n then Left(LinAlgError.NonSquareMatrix(lu.packed.shape))
    else if b.rows != n then
      Left(
        LinAlgError.DimensionMismatch(
          Shape(Rows(n), Cols(b.cols)),
          b.shape
        )
      )
    else
      val rhsCols = b.cols
      val packed = lu.packed
      val packedData = packed.data
      val packedOffset = packed.offset.value
      val packedRowStride = packed.rowStride.value
      val packedColStride = packed.colStride.value
      val values = DoubleArray.alloc(n * rhsCols)
      var row = 0
      while row < n do
        val sourceRow = lu.pivots(row)
        var rhs = 0
        while rhs < rhsCols do
          values(row * rhsCols + rhs) = b(sourceRow, rhs)
          rhs += 1
        row += 1

      var rhs = 0
      while rhs < rhsCols do
        DoubleKernels.dtrsv(
          n,
          lower = true,
          unit = true,
          0.0,
          packedData,
          packedOffset,
          packedRowStride,
          packedColStride,
          values,
          rhs,
          rhsCols
        )
        val info = DoubleKernels.dtrsv(
          n,
          lower = false,
          unit = false,
          0.0,
          packedData,
          packedOffset,
          packedRowStride,
          packedColStride,
          values,
          rhs,
          rhsCols
        )
        if info >= 0 then return Left(LinAlgError.SingularMatrix(info))
        rhs += 1
      Right(DMat.fromDoubleArrayOwned(n, rhsCols, values))

  def solve(cholesky: Cholesky, b: DVec): Either[LinAlgError, DVec] =
    val n = cholesky.lower.rows
    if cholesky.lower.cols != n then Left(LinAlgError.NonSquareMatrix(cholesky.lower.shape))
    else if b.length != n then
      Left(LinAlgError.DimensionMismatch(Shape(Rows(n), Cols(1)), Shape(Rows(b.length), Cols(1))))
    else
      // Hoist the lower factor's raw storage once and drive the shared triangular
      // kernel twice: `L y = b` (non-unit lower), then `Lᵀ x = y`. The transpose
      // is the same storage with row/column strides swapped, so no copy is made.
      val lData = cholesky.lower.data
      val lOff = cholesky.lower.offset.value
      val lRowStep = cholesky.lower.rowStride.value
      val lColStep = cholesky.lower.colStride.value
      // Owned contiguous copy of b, mutated in place into the solution.
      val x = b.toDoubleArrayOwnedCopy
      val forward = DoubleKernels.dtrsv(n, lower = true, unit = false, 0.0, lData, lOff, lRowStep, lColStep, x, 0, 1)
      if forward >= 0 then Left(LinAlgError.NotPositiveDefinite(forward))
      else
        val back = DoubleKernels.dtrsv(n, lower = false, unit = false, 0.0, lData, lOff, lColStep, lRowStep, x, 0, 1)
        if back >= 0 then Left(LinAlgError.NotPositiveDefinite(back))
        else Right(DVec.fromDoubleArrayOwned(x))

  def solve(cholesky: Cholesky, b: DMat): Either[LinAlgError, DMat] =
    val n = cholesky.lower.rows
    if cholesky.lower.cols != n then Left(LinAlgError.NonSquareMatrix(cholesky.lower.shape))
    else if b.rows != n then
      Left(
        LinAlgError.DimensionMismatch(
          Shape(Rows(n), Cols(b.cols)),
          b.shape
        )
      )
    else
      val rhsCols = b.cols
      val x = b.toDoubleArrayCopyRowMajor
      val lower = cholesky.lower
      var row = 0
      while row < n do
        val diagonal = lower(row, row)
        var rhs = 0
        while rhs < rhsCols do
          var value = x(row * rhsCols + rhs)
          var k = 0
          while k < row do
            value -= lower(row, k) * x(k * rhsCols + rhs)
            k += 1
          x(row * rhsCols + rhs) = value / diagonal
          rhs += 1
        row += 1
      row = n - 1
      while row >= 0 do
        val diagonal = lower(row, row)
        var rhs = 0
        while rhs < rhsCols do
          var value = x(row * rhsCols + rhs)
          var k = row + 1
          while k < n do
            value -= lower(k, row) * x(k * rhsCols + rhs)
            k += 1
          x(row * rhsCols + rhs) = value / diagonal
          rhs += 1
        row -= 1
      Right(DMat.fromDoubleArrayOwned(n, rhsCols, x))

  def solveLeastSquares(qr: QR, b: DVec): Either[LinAlgError, DVec] =
    val m = qr.reflectors.rows
    val n = qr.r.cols
    if qr.r.rows != m then Left(LinAlgError.DimensionMismatch(Shape(Rows(m), Cols(n)), qr.r.shape))
    else if b.length != m then
      Left(LinAlgError.DimensionMismatch(Shape(Rows(m), Cols(1)), Shape(Rows(b.length), Cols(1))))
    else if m < n then Left(LinAlgError.UnsupportedOperation("underdetermined least squares"))
    else
      val rank = qr.diagnostics.rank.getOrElse(rankFromMatrix(qr.r))
      if rank < n then Left(LinAlgError.RankDeficient(rank, n))
      else
        // y := Qᵀ b, applied implicitly as H_{limit-1} ... H_0 b through the
        // stored reflectors — no m x m Q is ever formed. Order matters: apply
        // H_0 first (the reflectors were applied to R in ascending k).
        val limit = qr.reflectors.cols
        val vData = qr.reflectors.data
        val tau = qr.tau
        // Owned platform copy of b: mutated in place as Qᵀ is applied.
        val y = b.toDoubleArrayOwnedCopy
        var k = 0
        while k < limit do
          val beta = tau(k)
          if beta != 0.0 then
            var dot = 0.0
            var i = k
            while i < m do
              dot = fma(vData(i * limit + k), y(i), dot)
              i += 1
            dot *= beta
            i = k
            while i < m do
              y(i) = fma(-dot, vData(i * limit + k), y(i))
              i += 1
          k += 1

        // Back-substitute the upper-triangular n x n leading block of R through
        // the shared kernel. `y` holds Qᵀb over its first n entries; copy those
        // into an owned length-n buffer and solve in place. A diagonal at or below
        // the rank tolerance marks rank deficiency at that column.
        val tolerance = qr.diagnostics.rankTolerance.getOrElse(rankToleranceFromMatrix(qr.r))
        val rData = qr.r.data
        val rOff = qr.r.offset.value
        val rRowStep = qr.r.rowStride.value
        val rColStep = qr.r.colStride.value
        val x = DoubleArray.alloc(n)
        DoubleKernels.dcopy(n, y, 0, 1, x, 0, 1)
        val info =
          DoubleKernels.dtrsv(n, lower = false, unit = false, tolerance, rData, rOff, rRowStep, rColStep, x, 0, 1)
        if info >= 0 then Left(LinAlgError.RankDeficient(rank, n))
        else if qr.columnPermutation.isIdentity then Right(DVec.fromDoubleArrayOwned(x))
        else
          val unpermuted = DoubleArray.alloc(n)
          var pivoted = 0
          while pivoted < n do
            unpermuted(qr.columnPermutation(pivoted)) = x(pivoted)
            pivoted += 1
          Right(DVec.fromDoubleArrayOwned(unpermuted))

  def solveLeastSquares(qr: QR, b: DMat): Either[LinAlgError, DMat] =
    val m = qr.reflectors.rows
    val n = qr.r.cols
    if qr.r.rows != m then Left(LinAlgError.DimensionMismatch(Shape(Rows(m), Cols(n)), qr.r.shape))
    else if b.rows != m then Left(LinAlgError.DimensionMismatch(Shape(Rows(m), Cols(b.cols)), b.shape))
    else if m < n then Left(LinAlgError.UnsupportedOperation("underdetermined least squares"))
    else
      val rank = qr.diagnostics.rank.getOrElse(rankFromMatrix(qr.r))
      if rank < n then Left(LinAlgError.RankDeficient(rank, n))
      else
        val rhsCols = b.cols
        val transformed = b.toDoubleArrayCopyRowMajor
        applyReflectorsLeft(qr, transformed, rhsCols, transpose = true)
        val tolerance = qr.diagnostics.rankTolerance.getOrElse(rankToleranceFromMatrix(qr.r))
        val rData = qr.r.data
        val rOff = qr.r.offset.value
        val rRowStep = qr.r.rowStride.value
        val rColStep = qr.r.colStride.value
        var rhs = 0
        while rhs < rhsCols do
          val info = DoubleKernels.dtrsv(
            n,
            lower = false,
            unit = false,
            tolerance,
            rData,
            rOff,
            rRowStep,
            rColStep,
            transformed,
            rhs,
            rhsCols
          )
          if info >= 0 then return Left(LinAlgError.RankDeficient(rank, n))
          rhs += 1

        val coefficients = DoubleArray.alloc(n * rhsCols)
        var pivoted = 0
        while pivoted < n do
          val original = qr.columnPermutation(pivoted)
          rhs = 0
          while rhs < rhsCols do
            coefficients(original * rhsCols + rhs) = transformed(pivoted * rhsCols + rhs)
            rhs += 1
          pivoted += 1
        Right(DMat.fromDoubleArrayOwned(n, rhsCols, coefficients))

  def solveLeastSquaresWith(
      qr: QR,
      b: DVec,
      workspace: DenseWorkspace
  ): Either[LinAlgError, DVec] =
    val m = qr.reflectors.rows
    val n = qr.r.cols
    if qr.r.rows != m then Left(LinAlgError.DimensionMismatch(Shape(Rows(m), Cols(n)), qr.r.shape))
    else if b.length != m then
      Left(LinAlgError.DimensionMismatch(Shape(Rows(m), Cols(1)), Shape(Rows(b.length), Cols(1))))
    else if m < n then Left(LinAlgError.UnsupportedOperation("underdetermined least squares"))
    else
      val rank = qr.diagnostics.rank.getOrElse(rankFromMatrix(qr.r))
      if rank < n then Left(LinAlgError.RankDeficient(rank, n))
      else
        val requirement = DenseWorkspace.qrSolveRequirement(m) match
          case Left(error)  => return Left(error)
          case Right(value) => value
        val transformed = workspace.doubles(requirement)
        DoubleKernels.dcopy(m, b.data, b.offset.value, b.stride.value, transformed, 0, 1)
        finishLeastSquaresVectorInScratch(qr, transformed, rank)

  def solveLeastSquaresWith(
      qr: QR,
      b: DMat,
      workspace: DenseWorkspace
  ): Either[LinAlgError, DMat] =
    val m = qr.reflectors.rows
    val n = qr.r.cols
    if qr.r.rows != m then Left(LinAlgError.DimensionMismatch(Shape(Rows(m), Cols(n)), qr.r.shape))
    else if b.rows != m then Left(LinAlgError.DimensionMismatch(Shape(Rows(m), Cols(b.cols)), b.shape))
    else if m < n then Left(LinAlgError.UnsupportedOperation("underdetermined least squares"))
    else
      val rank = qr.diagnostics.rank.getOrElse(rankFromMatrix(qr.r))
      if rank < n then Left(LinAlgError.RankDeficient(rank, n))
      else
        val rhsCols = b.cols
        val requirement = DenseWorkspace.qrSolveRequirement(m, rhsCols) match
          case Left(error)  => return Left(error)
          case Right(value) => value
        val transformed = workspace.doubles(requirement)
        var row = 0
        while row < m do
          DoubleKernels.dcopy(
            rhsCols,
            b.data,
            b.offset.value + row * b.rowStride.value,
            b.colStride.value,
            transformed,
            row * rhsCols,
            1
          )
          row += 1
        finishLeastSquaresMatrixInScratch(qr, transformed, rhsCols, rank)

  def solveLeastSquaresScaledRowsWith(
      qr: QR,
      b: DVec,
      scales: DVec,
      workspace: DenseWorkspace
  ): Either[LinAlgError, DVec] =
    val m = qr.reflectors.rows
    val n = qr.r.cols
    if qr.r.rows != m then Left(LinAlgError.DimensionMismatch(Shape(Rows(m), Cols(n)), qr.r.shape))
    else if b.length != m then
      Left(LinAlgError.DimensionMismatch(Shape(Rows(m), Cols(1)), Shape(Rows(b.length), Cols(1))))
    else if m < n then Left(LinAlgError.UnsupportedOperation("underdetermined least squares"))
    else
      val rank = qr.diagnostics.rank.getOrElse(rankFromMatrix(qr.r))
      if rank < n then Left(LinAlgError.RankDeficient(rank, n))
      else
        validateRowScales(scales, m) match
          case Left(error) => Left(error)
          case Right(_)    =>
            val requirement = DenseWorkspace.qrSolveRequirement(m) match
              case Left(error)  => return Left(error)
              case Right(value) => value
            val transformed = workspace.doubles(requirement)
            var row = 0
            var bi = b.offset.value
            var si = scales.offset.value
            while row < m do
              transformed(row) = scales.data(si) * b.data(bi)
              bi += b.stride.value
              si += scales.stride.value
              row += 1
            finishLeastSquaresVectorInScratch(qr, transformed, rank)

  def solveLeastSquaresScaledRowsWith(
      qr: QR,
      b: DMat,
      scales: DVec,
      workspace: DenseWorkspace
  ): Either[LinAlgError, DMat] =
    val m = qr.reflectors.rows
    val n = qr.r.cols
    if qr.r.rows != m then Left(LinAlgError.DimensionMismatch(Shape(Rows(m), Cols(n)), qr.r.shape))
    else if b.rows != m then Left(LinAlgError.DimensionMismatch(Shape(Rows(m), Cols(b.cols)), b.shape))
    else if m < n then Left(LinAlgError.UnsupportedOperation("underdetermined least squares"))
    else
      val rank = qr.diagnostics.rank.getOrElse(rankFromMatrix(qr.r))
      if rank < n then Left(LinAlgError.RankDeficient(rank, n))
      else
        validateRowScales(scales, m) match
          case Left(error) => Left(error)
          case Right(_)    =>
            val rhsCols = b.cols
            val requirement = DenseWorkspace.qrSolveRequirement(m, rhsCols) match
              case Left(error)  => return Left(error)
              case Right(value) => value
            val transformed = workspace.doubles(requirement)
            var row = 0
            var si = scales.offset.value
            while row < m do
              val scale = scales.data(si)
              var source = b.offset.value + row * b.rowStride.value
              var col = 0
              while col < rhsCols do
                transformed(row * rhsCols + col) = scale * b.data(source)
                source += b.colStride.value
                col += 1
              si += scales.stride.value
              row += 1
            finishLeastSquaresMatrixInScratch(qr, transformed, rhsCols, rank)

  private def finishLeastSquaresVectorInScratch(
      qr: QR,
      transformed: DoubleArray,
      rank: Int
  ): Either[LinAlgError, DVec] =
    val m = qr.reflectors.rows
    val n = qr.r.cols
    val limit = qr.reflectors.cols
    val vData = qr.reflectors.data
    val tau = qr.tau
    var k = 0
    while k < limit do
      val beta = tau(k)
      if beta != 0.0 then
        var dot = 0.0
        var row = k
        while row < m do
          dot = fma(vData(row * limit + k), transformed(row), dot)
          row += 1
        dot *= beta
        row = k
        while row < m do
          transformed(row) = fma(-dot, vData(row * limit + k), transformed(row))
          row += 1
      k += 1

    val tolerance = qr.diagnostics.rankTolerance.getOrElse(rankToleranceFromMatrix(qr.r))
    val info = DoubleKernels.dtrsv(
      n,
      lower = false,
      unit = false,
      tolerance,
      qr.r.data,
      qr.r.offset.value,
      qr.r.rowStride.value,
      qr.r.colStride.value,
      transformed,
      0,
      1
    )
    if info >= 0 then Left(LinAlgError.RankDeficient(rank, n))
    else
      val coefficients = DoubleArray.alloc(n)
      if qr.columnPermutation.isIdentity then DoubleKernels.dcopy(n, transformed, 0, 1, coefficients, 0, 1)
      else
        var pivoted = 0
        while pivoted < n do
          coefficients(qr.columnPermutation(pivoted)) = transformed(pivoted)
          pivoted += 1
      Right(DVec.fromDoubleArrayOwned(coefficients))

  private def finishLeastSquaresMatrixInScratch(
      qr: QR,
      transformed: DoubleArray,
      rhsCols: Int,
      rank: Int
  ): Either[LinAlgError, DMat] =
    val n = qr.r.cols
    applyReflectorsLeft(qr, transformed, rhsCols, transpose = true)
    val tolerance = qr.diagnostics.rankTolerance.getOrElse(rankToleranceFromMatrix(qr.r))
    var rhs = 0
    while rhs < rhsCols do
      val info = DoubleKernels.dtrsv(
        n,
        lower = false,
        unit = false,
        tolerance,
        qr.r.data,
        qr.r.offset.value,
        qr.r.rowStride.value,
        qr.r.colStride.value,
        transformed,
        rhs,
        rhsCols
      )
      if info >= 0 then return Left(LinAlgError.RankDeficient(rank, n))
      rhs += 1

    val coefficients = DoubleArray.alloc(n * rhsCols)
    var pivoted = 0
    while pivoted < n do
      val original = qr.columnPermutation(pivoted)
      DoubleKernels.dcopy(
        rhsCols,
        transformed,
        pivoted * rhsCols,
        1,
        coefficients,
        original * rhsCols,
        1
      )
      pivoted += 1
    Right(DMat.fromDoubleArrayOwned(n, rhsCols, coefficients))

  private def validateRowScales(scales: DVec, rows: Int): Either[LinAlgError, Unit] =
    if scales.length != rows then
      Left(LinAlgError.DimensionMismatch(Shape(Rows(rows), Cols(1)), Shape(Rows(scales.length), Cols(1))))
    else
      var row = 0
      var index = scales.offset.value
      while row < rows do
        val scale = scales.data(index)
        if !scale.isFinite then
          return Left(LinAlgError.InvalidArgument(s"row scale at index $row must be finite, got $scale"))
        index += scales.stride.value
        row += 1
      Right(())

  def applyQ(qr: QR, b: DMat, transpose: Boolean): Either[LinAlgError, DMat] =
    val m = qr.reflectors.rows
    if b.rows != m then Left(LinAlgError.DimensionMismatch(Shape(Rows(m), Cols(b.cols)), b.shape))
    else
      val out = b.toDoubleArrayCopyRowMajor
      applyReflectorsLeft(qr, out, b.cols, transpose)
      Right(DMat.fromDoubleArrayOwned(b.rows, b.cols, out))

  def residualize(qr: QR, b: DMat): Either[LinAlgError, DMat] =
    val m = qr.reflectors.rows
    if b.rows != m then Left(LinAlgError.DimensionMismatch(Shape(Rows(m), Cols(b.cols)), b.shape))
    else
      val out = b.toDoubleArrayCopyRowMajor
      applyReflectorsLeft(qr, out, b.cols, transpose = true)
      val rank = qr.diagnostics.rank.getOrElse(rankFromMatrix(qr.r))
      var row = 0
      while row < rank do
        var col = 0
        while col < b.cols do
          out(row * b.cols + col) = 0.0
          col += 1
        row += 1
      applyReflectorsLeft(qr, out, b.cols, transpose = false)
      Right(DMat.fromDoubleArrayOwned(b.rows, b.cols, out))

  def normalizedCovariance(qr: QR): Either[LinAlgError, DMat] =
    val n = qr.r.cols
    val rank = qr.diagnostics.rank.getOrElse(rankFromMatrix(qr.r))
    if qr.r.rows < n then Left(LinAlgError.UnsupportedOperation("normalized covariance requires rows >= columns"))
    else if rank < n then Left(LinAlgError.RankDeficient(rank, n))
    else
      val invR = DoubleArray.alloc(n * n)
      var rhs = 0
      while rhs < n do
        var row = n - 1
        while row >= 0 do
          var value = if row == rhs then 1.0 else 0.0
          var col = row + 1
          while col < n do
            value -= qr.r(row, col) * invR(col * n + rhs)
            col += 1
          invR(row * n + rhs) = value / qr.r(row, row)
          row -= 1
        rhs += 1

      val covariance = DoubleArray.alloc(n * n)
      var pivotedRow = 0
      while pivotedRow < n do
        var pivotedCol = 0
        while pivotedCol < n do
          var value = 0.0
          var k = 0
          while k < n do
            value = fma(invR(pivotedRow * n + k), invR(pivotedCol * n + k), value)
            k += 1
          val originalRow = qr.columnPermutation(pivotedRow)
          val originalCol = qr.columnPermutation(pivotedCol)
          covariance(originalRow * n + originalCol) = value
          pivotedCol += 1
        pivotedRow += 1
      Right(DMat.fromDoubleArrayOwned(n, n, covariance))

  private def applyReflectorsLeft(
      qr: QR,
      values: DoubleArray,
      valueCols: Int,
      transpose: Boolean
  ): Unit =
    if valueCols < 8 then applyReflectorsLeftScalar(qr, values, valueCols, transpose)
    else applyReflectorsLeftBlocked(qr, values, valueCols, transpose)

  /** Preserve the original column-first traversal for narrow right-hand sides. In particular, q=1 remains the compact
    * scalar control rather than paying the compilation and branch footprint of the wide matrix kernel.
    */
  private def applyReflectorsLeftScalar(
      qr: QR,
      values: DoubleArray,
      valueCols: Int,
      transpose: Boolean
  ): Unit =
    val m = qr.reflectors.rows
    val limit = qr.reflectors.cols
    val reflectors = qr.reflectors.data
    val tau = qr.tau
    var k = if transpose then 0 else limit - 1
    val end = if transpose then limit else -1
    val step = if transpose then 1 else -1
    while k != end do
      val beta = tau(k)
      if beta != 0.0 then
        var col = 0
        while col < valueCols do
          var dot = 0.0
          var row = k
          while row < m do
            dot = fma(reflectors(row * limit + k), values(row * valueCols + col), dot)
            row += 1
          dot *= beta
          row = k
          while row < m do
            val index = row * valueCols + col
            values(index) = fma(-dot, reflectors(row * limit + k), values(index))
            row += 1
          col += 1
      k += step

  /** Matrix RHS values are owned row-major storage. Work eight columns at a time so both dot accumulation and the
    * rank-1 update traverse each row contiguously while keeping partial sums in scalar locals. The scalar tail handles
    * widths that are not multiples of eight without scratch storage.
    */
  private def applyReflectorsLeftBlocked(
      qr: QR,
      values: DoubleArray,
      valueCols: Int,
      transpose: Boolean
  ): Unit =
    val m = qr.reflectors.rows
    val limit = qr.reflectors.cols
    val reflectors = qr.reflectors.data
    val tau = qr.tau
    var k = if transpose then 0 else limit - 1
    val end = if transpose then limit else -1
    val step = if transpose then 1 else -1
    while k != end do
      val beta = tau(k)
      if beta != 0.0 then
        var col = 0
        while col + 7 < valueCols do
          var dot0 = 0.0
          var dot1 = 0.0
          var dot2 = 0.0
          var dot3 = 0.0
          var dot4 = 0.0
          var dot5 = 0.0
          var dot6 = 0.0
          var dot7 = 0.0
          var row = k
          while row < m do
            val vi = reflectors(row * limit + k)
            val index = row * valueCols + col
            dot0 = fma(vi, values(index), dot0)
            dot1 = fma(vi, values(index + 1), dot1)
            dot2 = fma(vi, values(index + 2), dot2)
            dot3 = fma(vi, values(index + 3), dot3)
            dot4 = fma(vi, values(index + 4), dot4)
            dot5 = fma(vi, values(index + 5), dot5)
            dot6 = fma(vi, values(index + 6), dot6)
            dot7 = fma(vi, values(index + 7), dot7)
            row += 1
          dot0 *= beta
          dot1 *= beta
          dot2 *= beta
          dot3 *= beta
          dot4 *= beta
          dot5 *= beta
          dot6 *= beta
          dot7 *= beta
          row = k
          while row < m do
            val vi = reflectors(row * limit + k)
            val index = row * valueCols + col
            values(index) = fma(-dot0, vi, values(index))
            values(index + 1) = fma(-dot1, vi, values(index + 1))
            values(index + 2) = fma(-dot2, vi, values(index + 2))
            values(index + 3) = fma(-dot3, vi, values(index + 3))
            values(index + 4) = fma(-dot4, vi, values(index + 4))
            values(index + 5) = fma(-dot5, vi, values(index + 5))
            values(index + 6) = fma(-dot6, vi, values(index + 6))
            values(index + 7) = fma(-dot7, vi, values(index + 7))
            row += 1
          col += 8
        while col < valueCols do
          var dot = 0.0
          var row = k
          while row < m do
            dot = fma(reflectors(row * limit + k), values(row * valueCols + col), dot)
            row += 1
          dot *= beta
          row = k
          while row < m do
            val index = row * valueCols + col
            values(index) = fma(-dot, reflectors(row * limit + k), values(index))
            row += 1
          col += 1
      k += step

  def det(lu: LU): Either[LinAlgError, Double] =
    val n = lu.packed.rows
    if lu.packed.cols != n then Left(LinAlgError.NonSquareMatrix(lu.packed.shape))
    else
      var out = lu.parity.toDouble
      var i = 0
      while i < n do
        out *= lu.packed(i, i)
        i += 1
      Right(out)

  private def swapRows(values: DoubleArray, cols: Int, r1: Int, r2: Int): Unit =
    var col = 0
    while col < cols do
      val i = r1 * cols + col
      val j = r2 * cols + col
      val tmp = values(i)
      values(i) = values(j)
      values(j) = tmp
      col += 1

  private def swapColumns(
      values: DoubleArray,
      rows: Int,
      cols: Int,
      c1: Int,
      c2: Int
  ): Unit =
    var row = 0
    while row < rows do
      val i = row * cols + c1
      val j = row * cols + c2
      val tmp = values(i)
      values(i) = values(j)
      values(j) = tmp
      row += 1

  private def identityArray(size: Int): DoubleArray =
    val out = DoubleArray.alloc(size * size)
    var i = 0
    while i < size do
      out(i * size + i) = 1.0
      i += 1
    out

  private[gale] def rankFromMatrix(A: DMat): Int =
    rankFromUpperTriangular(A.toDoubleArrayCopyRowMajor, A.rows, A.cols)

  private def rankFromUpperTriangular(values: DoubleArray, rows: Int, cols: Int): Int =
    val tolerance = rankToleranceFromUpperTriangular(values, rows, cols)
    rankFromUpperTriangular(values, rows, cols, tolerance)

  private def rankFromUpperTriangular(
      values: DoubleArray,
      rows: Int,
      cols: Int,
      tolerance: Double
  ): Int =
    val limit = math.min(rows, cols)
    var rank = 0
    var i = 0
    while i < limit do
      if math.abs(values(i * cols + i)) > tolerance then rank += 1
      i += 1
    rank

  private[gale] def rankToleranceFromMatrix(A: DMat): Double =
    rankToleranceFromUpperTriangular(A.toDoubleArrayCopyRowMajor, A.rows, A.cols)

  private def rankToleranceFromUpperTriangular(values: DoubleArray, rows: Int, cols: Int): Double =
    val limit = math.min(rows, cols)
    var maxDiag = 0.0
    var i = 0
    while i < limit do
      maxDiag = math.max(maxDiag, math.abs(values(i * cols + i)))
      i += 1
    // Tolerance scales with the matrix magnitude; a hard floor at 1.0 would
    // wrongly rank uniformly tiny (but well-conditioned) matrices as deficient.
    // An all-zero matrix yields maxDiag == 0, hence tolerance 0, hence rank 0.
    // Two guards the final diagonal against the pair of rounded Householder
    // reductions that can leave an exactly dependent column a few ulps above the
    // textbook `max(m,n)*eps` cutoff.
    2.0 * math.max(rows, cols).toDouble * 2.220446049250313e-16 * maxDiag

  /** Matrix 1-norm: the maximum absolute column sum. */
  private def norm1(A: DMat): Double =
    val data = A.data
    val base = A.offset.value
    val rowStep = A.rowStride.value
    val colStep = A.colStride.value
    var out = 0.0
    var j = 0
    while j < A.cols do
      var sum = 0.0
      var i = 0
      var idx = base + j * colStep
      while i < A.rows do
        sum += math.abs(data(idx))
        idx += rowStep
        i += 1
      out = math.max(out, sum)
      j += 1
    out

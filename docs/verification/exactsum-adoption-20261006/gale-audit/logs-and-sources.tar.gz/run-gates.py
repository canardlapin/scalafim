from pathlib import Path
import os,sys,subprocess,json,time,hashlib
work=Path('/Users/bbuchsbaum/code/scala/scalafim');out=Path(__file__).resolve().parent
env=dict(os.environ)
cleared=['JAVA_TOOL_OPTIONS','JDK_JAVA_OPTIONS','_JAVA_OPTIONS','JAVA_OPTS','SBT_OPTS','SBT_ARGS','JVM_OPTS']
for name in cleared:env.pop(name,None)
env['JAVA_HOME']='/Users/bbuchsbaum/Library/Java/JavaVirtualMachines/temurin-21.0.12.1+1.jdk/Contents/Home'
env['PATH']=env['JAVA_HOME']+'/bin:'+env.get('PATH','')
env['SBT_WARM_HEAP']='4g';env['SBT_WARM_CPUS']='4'
files=['build.sbt','modules/design/shared/src/main/scala/scalafim/fmri/design/hrf/KernelBasis.scala','modules/design/shared/src/main/scala/scalafim/fmri/design/hrf/KernelBasisBudget.scala','modules/design/shared/src/test/scala/scalafim/fmri/design/hrf/KernelBasisBudgetSuite.scala','modules/design/shared/src/test/scala/scalafim/fmri/design/HrfKernelBasisSuite.scala','tools/build/sbt-warm','project/build.properties','project/plugins.sbt']
source={f:hashlib.sha256((work/f).read_bytes()).hexdigest()for f in files}
manifest={'root_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=work,text=True).strip(),'source_sha256':source,'cleared_env_names':cleared,'requested_heap':'4g','requested_cpus':'4','local_provider_overrides':False}
(out/'source-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
runs=[]
for label,command in zip(sys.argv[1::2],sys.argv[2::2]):
 print('BEGIN',label,command,flush=True);start=time.time();log=out/(label+'.log')
 with log.open('w')as stream:code=subprocess.run(['python3','tools/build/sbt-warm',command],cwd=work,env=env,stdout=stream,stderr=subprocess.STDOUT).returncode
 for f,digest in source.items():assert hashlib.sha256((work/f).read_bytes()).hexdigest()==digest,f
 runs.append({'label':label,'command':command,'exit':code,'elapsed_seconds':round(time.time()-start,3),'log':log.name,'sha256':hashlib.sha256(log.read_bytes()).hexdigest()});(out/'runs.json').write_text(json.dumps(runs,indent=2)+'\n')
 print('END',label,code,runs[-1]['elapsed_seconds'],flush=True)
 if code:
  print(log.read_text()[-16000:],flush=True);sys.exit(code)

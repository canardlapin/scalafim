#!/usr/bin/env node
/*
 * P0/P1 browser capture runner. Run it only as the owning task: it starts one
 * Vite child and one Playwright Chromium browser/context, and closes both in
 * finally. No system Chrome profile is used.
 */
import { spawn, spawnSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { mkdir, readFile, writeFile, stat } from 'node:fs/promises';
import { basename, dirname, resolve } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const here = dirname(fileURLToPath(import.meta.url));
const repo = resolve(here, '../../..');
const reference = '/Users/bbuchsbaum/code/jscode/surfviewjs';
const guard = resolve(process.env.HOME ?? '', '.local/share/agent-policy/browser-automation-guard.mjs');
const manifestPath = resolve(here, 'manifest.json');

function fail(message) { throw new Error(message); }
function argument(name) {
  const index = process.argv.indexOf(name);
  return index < 0 ? null : process.argv[index + 1] ?? null;
}
const scalarModule = argument('--scalafim-module');
const output = resolve(argument('--out') ?? '/private/tmp/scalafim-surfview-parity-artifacts');
if (!scalarModule) fail('missing --scalafim-module (a Scala.js module exposing mountScalafimSurfaceParityBaseline)');
await stat(scalarModule).catch(() => fail(`Scala.js module does not exist: ${scalarModule}`));
await stat(reference).catch(() => fail(`pinned SurfViewJS checkout is unavailable: ${reference}`));

function commandText(command, args, cwd) {
  const result = spawnSync(command, args, { cwd, encoding: 'utf8' });
  if (result.status !== 0) fail(`${command} ${args.join(' ')} failed: ${result.stderr || result.stdout}`);
  return result.stdout.trim();
}
function audit(label) {
  const result = spawnSync(process.execPath, [guard, '--audit'], { encoding: 'utf8' });
  if (result.status !== 0) fail(`browser ownership audit (${label}) failed:\n${result.stdout}${result.stderr}`);
  return result.stdout.trim();
}
function sha(value) { return createHash('sha256').update(value).digest('hex'); }
async function text(path) { return readFile(path, 'utf8'); }
async function json(path) { return JSON.parse(await text(path)); }
async function writeJson(path, value) { await writeFile(path, `${JSON.stringify(value, null, 2)}\n`); }
async function dataUrlToFile(url, path) {
  const comma = url.indexOf(',');
  if (comma < 0) fail(`invalid PNG data URL for ${path}`);
  await writeFile(path, Buffer.from(url.slice(comma + 1), 'base64'));
}
function viteUrl(path) { return `/@fs/${resolve(path).replaceAll('\\', '/')}`; }
async function waitForServer(url, child) {
  for (let attempt = 0; attempt < 80; attempt += 1) {
    if (child.exitCode !== null) fail(`Vite exited before serving capture page (${child.exitCode})`);
    try { if ((await fetch(url)).ok) return; } catch { /* wait */ }
    await new Promise(resolve => setTimeout(resolve, 100));
  }
  fail(`Vite did not serve ${url}`);
}

const manifest = await json(manifestPath);
const sourceCommit = commandText('git', ['rev-parse', 'HEAD'], reference);
if (sourceCommit !== manifest.reference.commit) fail(`SurfViewJS is ${sourceCommit}, expected ${manifest.reference.commit}`);
const provenance = {
  schema: 'scalafim.surface-view-parity-provenance.v1',
  candidateCommit: commandText('git', ['rev-parse', 'HEAD'], repo),
  referenceCommit: sourceCommit,
  referencePackageLockSha256: sha(await readFile(resolve(reference, 'package-lock.json'))),
  referencePackage: JSON.parse(await text(resolve(reference, 'package.json'))),
  threeVersion: JSON.parse(await text(resolve(reference, 'node_modules/three/package.json'))).version,
  playwrightVersion: JSON.parse(await text(resolve(reference, 'node_modules/playwright/package.json'))).version,
  scalaModule: resolve(scalarModule),
  scalaModuleSha256: sha(await readFile(scalarModule)),
  auditBefore: audit('before')
};
await mkdir(output, { recursive: true });
await writeJson(resolve(output, 'provenance.json'), provenance);

const vite = spawn(process.execPath, [resolve(reference, 'node_modules/vite/bin/vite.js'), '--host', '127.0.0.1', '--port', '4179', '--strictPort'], {
  cwd: here,
  stdio: ['ignore', 'pipe', 'pipe']
});
let browser;
try {
  await waitForServer('http://127.0.0.1:4179/', vite);
  const { chromium } = await import(pathToFileURL(resolve(reference, 'node_modules/playwright/index.mjs')).href);
  browser = await chromium.launch({ headless: true });
  const context = await browser.newContext({ viewport: { width: 640, height: 480 }, deviceScaleFactor: 1 });
  const page = await context.newPage();
  const browserInfo = await page.evaluate(() => ({ userAgent: navigator.userAgent, platform: navigator.platform }));
  await writeJson(resolve(output, 'environment.json'), { ...browserInfo, node: process.version, os: process.platform });
  for (const entry of manifest.requiredCases) {
    const caseDir = resolve(output, entry.id);
    await mkdir(caseDir, { recursive: true });
    if (!entry.implemented) {
      await writeJson(resolve(caseDir, 'failure.json'), { case: entry.id, status: 'fail', reason: 'no P1 public adapter implemented' });
      continue;
    }
    const result = await captureCase(page, entry.id, scalarModule);
    const canvases = page.locator('canvas');
    const referencePng = await canvases.nth(0).screenshot();
    const candidatePng = await canvases.nth(1).screenshot();
    await writeFile(resolve(caseDir, 'surfviewjs.png'), referencePng);
    await writeFile(resolve(caseDir, 'scalafim-three.png'), candidatePng);
    result.comparison = await comparePng(page, referencePng, candidatePng);
    await dataUrlToFile(result.comparison.sideBySide, resolve(caseDir, 'side-by-side.png'));
    await dataUrlToFile(result.comparison.heatmap, resolve(caseDir, 'error-heatmap.png'));
    await writeJson(resolve(caseDir, 'semantic.json'), result.semantic);
    await writeJson(resolve(caseDir, 'comparison.json'), result.comparison.metrics);
    await writeJson(resolve(caseDir, 'mutation.json'), result.mutation);
    await page.evaluate(() => {
      globalThis.__surfaceParityViewer?.dispose();
      globalThis.disposeScalafimSurfaceParityBaseline?.();
    });
    if (!result.mutation.smallElementRejected || !result.mutation.cameraShiftRejected)
      fail(`${entry.id}: comparator mutation test accepted a removed small element or shifted camera`);
  }
  await context.close();
} finally {
  if (browser) await browser.close();
  vite.kill('SIGTERM');
  await new Promise(resolve => vite.once('exit', resolve));
  provenance.auditAfter = audit('after');
  await writeJson(resolve(output, 'provenance.json'), provenance);
}

const requiredFailures = manifest.requiredCases.filter(row => !row.implemented).map(row => row.id);
if (requiredFailures.length) {
  console.error(`baseline intentionally incomplete: ${requiredFailures.join(', ')}`);
  process.exitCode = 1;
}

async function captureCase(page, caseId, modulePath) {
  const url = `http://127.0.0.1:4179/?case=${encodeURIComponent(caseId)}&scalafim=${encodeURIComponent(viteUrl(modulePath))}`;
  await page.goto(url, { waitUntil: 'networkidle' });
  return page.evaluate(async ({ caseId }) => {
    const ref = await import('/@fs//Users/bbuchsbaum/code/jscode/surfviewjs/src/index.ts');
    const three = await import('/@fs//Users/bbuchsbaum/code/jscode/surfviewjs/node_modules/three/build/three.module.js');
    const query = new URLSearchParams(location.search);
    const scalar = await import(query.get('scalafim'));
    const mount = globalThis.mountScalafimSurfaceParityBaseline ?? scalar.mountScalafimSurfaceParityBaseline;
    if (typeof mount !== 'function') throw new Error('ScalaFIM module does not export mountScalafimSurfaceParityBaseline');
    const vertices = new Float32Array([0, 0, 0, 1.4, .1, .2, -.2, 1.1, .35, .15, -.35, 1.3]);
    const faces = new Uint32Array([0, 1, 2, 0, 3, 1, 0, 2, 3, 1, 3, 2]);
    const curvature = new Float32Array([-.8, .25, .7, -.15]);
    const scalars = new Float32Array([-2.5, -2.5, 2.5, 2.5]);
    const root = document.createElement('div'); root.style.cssText = 'width:640px;height:480px'; document.body.append(root);
    const viewer = new ref.NeuroSurfaceViewer(root, 512, 512, { backgroundColor: 0xffffff, useShaders: false, initialZoom: 4 }, 'left_dorsal');
    if (viewer.initializationFailed) throw new Error('SurfViewJS viewer could not initialize WebGL');
    const geometry = new ref.SurfaceGeometry(vertices, faces, 'left', curvature, false);
    const surface = new ref.MultiLayerNeuroSurface(geometry, { curvature, showCurvature: caseId !== 'C02' });
    const lut = new ref.ColorMap([[0, 0, 1], [1, 0, 0]], { range: [-2.5, 2.5], threshold: [-.35, .35] });
    if (caseId !== 'C01') surface.addLayer(new ref.DataLayer('scalar', scalars, null, lut, { range: [-2.5, 2.5], threshold: [-.35, .35], opacity: .85 }));
    if (caseId === 'C03') surface.addLayer(new ref.DataLayer('scalar-2', new Float32Array([1, 1, -1, -1]), null, new ref.ColorMap([[0, 0, 1], [1, 0, 0]], { range: [-1, 1] }), { range: [-1, 1], opacity: .35, blendMode: 'additive' }));
    viewer.addSurface(surface, 'left'); viewer.setViewpoint('left_dorsal');
    // These are documented public viewer/camera fields. The baseline has no
    // arbitrary-up constructor seam, so use the fixed dorsal convention and
    // record its resulting matrices rather than modifying renderer internals.
    viewer.camera.fov = 35; viewer.camera.aspect = 1; viewer.camera.near = .01; viewer.camera.far = 1000;
    viewer.camera.position.set(.6, .375, 4.65); viewer.camera.up.set(0, 1, 0); viewer.camera.lookAt(.6, .375, .65);
    viewer.cameraControls.target.set(.6, .375, .65); viewer.cameraControls.update(); viewer.camera.updateMatrixWorld(); viewer.camera.updateProjectionMatrix();
    await new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve)));
    const referenceCanvas = viewer.renderer.domElement;
    const candidateCanvas = document.createElement('canvas'); candidateCanvas.width = 512; candidateCanvas.height = 512; document.body.append(candidateCanvas);
    const semantic = mount(three, candidateCanvas, caseId);
    await new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve)));
    const compare = (left, right) => {
      const canvas = document.createElement('canvas'); canvas.width = 1280; canvas.height = 480;
      const c = canvas.getContext('2d', { willReadFrequently: true }); c.drawImage(left, 0, 0); c.drawImage(right, 640, 0);
      const a = c.getImageData(0, 0, 640, 480).data; const b = c.getImageData(640, 0, 640, 480).data;
      const heat = document.createElement('canvas'); heat.width = 640; heat.height = 480; const h = heat.getContext('2d'); const out = h.createImageData(640, 480);
      let equal = 0, foregroundA = 0, foregroundB = 0, intersect = 0, max = 0, total = 0;
      for (let i = 0; i < a.length; i += 4) { const d = Math.max(Math.abs(a[i]-b[i]), Math.abs(a[i+1]-b[i+1]), Math.abs(a[i+2]-b[i+2])); max = Math.max(max,d); total += d; if (d <= 2) equal++; const fa = a[i+3] > 0 && (a[i] < 250 || a[i+1] < 250 || a[i+2] < 250); const fb = b[i+3] > 0 && (b[i] < 250 || b[i+1] < 250 || b[i+2] < 250); if (fa) foregroundA++; if (fb) foregroundB++; if (fa && fb) intersect++; out.data[i]=d; out.data[i+1]=0; out.data[i+2]=0; out.data[i+3]=255; }
      h.putImageData(out,0,0); const union = foregroundA + foregroundB - intersect;
      return { sideBySide: canvas.toDataURL('image/png'), heatmap: heat.toDataURL('image/png'), metrics: { width:640, height:480, matchingPixels:equal, maxChannelError:max, meanMaximumChannelError:total/(a.length/4), foregroundIoU: union ? intersect/union : 1 } };
    };
    const comparison = compare(referenceCanvas, candidateCanvas);
    const small = document.createElement('canvas'); small.width=64; small.height=64; const smallC=small.getContext('2d'); smallC.fillStyle='#000'; smallC.fillRect(31,31,2,2);
    const missingSmall = document.createElement('canvas'); missingSmall.width=64; missingSmall.height=64;
    const shifted = document.createElement('canvas'); shifted.width=640; shifted.height=480; shifted.getContext('2d').drawImage(candidateCanvas,3,0);
    const smallDiff = compare(small, missingSmall).metrics.maxChannelError > 0;
    const shiftDiff = compare(candidateCanvas, shifted).metrics.maxChannelError > 0;
    const gpu = viewer.renderer.getContext().getParameter(viewer.renderer.getContext().RENDERER);
    globalThis.__surfaceParityViewer = viewer;
    return { semantic: { caseId, surfviewjs: { vertices:4, faces:4, renderer:String(gpu), viewMatrix:Array.from(viewer.camera.matrixWorldInverse.elements), projectionMatrix:Array.from(viewer.camera.projectionMatrix.elements), up:[viewer.camera.up.x, viewer.camera.up.y, viewer.camera.up.z] }, scalafim: semantic }, comparison, mutation: { smallElementRejected: smallDiff, cameraShiftRejected: shiftDiff } };
  }, { caseId });
}

async function comparePng(page, left, right) {
  const value = await page.evaluate(async ({ left, right }) => {
    const image = value => new Promise((resolve, reject) => { const node = new Image(); node.onload = () => resolve(node); node.onerror = reject; node.src = `data:image/png;base64,${value}`; });
    const [a, b] = await Promise.all([image(left), image(right)]);
    const side = document.createElement('canvas'); side.width = a.width + b.width; side.height = Math.max(a.height, b.height); const c = side.getContext('2d', { willReadFrequently: true }); c.drawImage(a, 0, 0); c.drawImage(b, a.width, 0);
    const p = c.getImageData(0, 0, a.width, a.height).data; const q = c.getImageData(a.width, 0, b.width, b.height).data;
    const heat = document.createElement('canvas'); heat.width = a.width; heat.height = a.height; const h = heat.getContext('2d'); const out = h.createImageData(a.width, a.height);
    let max = 0, total = 0, matching = 0, foregroundA = 0, foregroundB = 0, intersect = 0;
      for (let i = 0; i < p.length; i += 4) { const d = Math.max(Math.abs(p[i]-q[i]), Math.abs(p[i+1]-q[i+1]), Math.abs(p[i+2]-q[i+2]), Math.abs(p[i+3]-q[i+3])); max=Math.max(max,d); total+=d; if(d<=2)matching++; const fa=p[i+3]>0&&(p[i]<250||p[i+1]<250||p[i+2]<250), fb=q[i+3]>0&&(q[i]<250||q[i+1]<250||q[i+2]<250); if(fa)foregroundA++; if(fb)foregroundB++; if(fa&&fb)intersect++; out.data[i]=d;out.data[i+3]=255; }
    h.putImageData(out,0,0); const union=foregroundA+foregroundB-intersect;
    const metrics = { width:a.width,height:a.height,matchingPixels:matching,maxChannelError:max,meanMaximumChannelError:total/(p.length/4),foregroundIoU:union?intersect/union:1 };
    const pass = metrics.foregroundIoU >= .995 && metrics.maxChannelError <= 2;
    return { sideBySide: side.toDataURL('image/png'), heatmap: heat.toDataURL('image/png'), metrics, verdict: { pass, failures: pass ? [] : [`foregroundIoU=${metrics.foregroundIoU}`, `maxChannelError=${metrics.maxChannelError}`] } };
  }, { left: left.toString('base64'), right: right.toString('base64') });
  return value;
}


package scalafim.fmri.laws.profile

import gale.linalg.DMat
import scalafim.dataset.{
  DataSelection,
  DatasetError,
  DatasetId,
  DatasetSeriesReader,
  FmriDataset,
  FmriSeries,
  InMemoryDatasetBackend,
  SynchronousFmriDataset
}
import scalafim.fmri.design.baseline.{BaselineBasis, BaselineModel, Intercept}
import scalafim.fmri.design.event.{Event, EventModel, EventTerm}
import scalafim.fmri.design.hrf.{ExpandedConditionDesign, HrfKernelBasis, KernelBasisSpec}
import scalafim.fmri.fit.profile.*
import scalafim.fmri.hrf.{PositiveSeconds, Seconds}
import scalafim.fmri.hrf.design.SamplingFrame
import scalafim.fmri.hrf.family.{GaussianFamily, JetLayout, NormalizationRule, ShapePoint}
import scalafim.fmri.model.{FitPlan, FmriModel}
import scalafim.image.SampleSpaces

/** PHRF-12: the condition profile fit composed over a real `FitPlan`, checked against the compact runtime on the same
  * data and against a direct oracle.
  */
class ConditionProfileFitSuite extends munit.FunSuite:

  private val family = GaussianFamily.Default
  private val step = PositiveSeconds(0.1).fold(e => fail(e.message), identity)
  private val precision = Seconds(0.1)
  private val rows = 200
  private val voxels = 20
  private val frame = SamplingFrame(blockLens = Seq(rows), tr = Seq(1.0))
  private val rng0 = new scala.util.Random(4040L)
  private val events = 30
  private val onsets = Vector.fill(events)(rng0.nextInt(1800) / 10.0).sorted.map(Seconds(_))
  private val conditions = Vector.tabulate(events)(i => Vector("A", "B", "C")(i % 3))
  private val term = EventTerm(
    events = Vector(Event.factor(conditions, "cond")),
    onsets = onsets,
    blockIds = Vector.fill(events)(0),
    termTag = Some("cond")
  )
  private lazy val basis = HrfKernelBasis
    .compile(KernelBasisSpec(family, step, Vector(26, 21), tolerance = 1e-4, maxRank = 40))
    .fold(e => fail(e.message), identity)
  private lazy val convolved = term.convolve(basis.kernel, frame, precision = precision)
  private lazy val eventModel = EventModel.build(Vector(convolved), frame)
  private lazy val baseline =
    BaselineModel.build(samplingFrame = frame, basis = BaselineBasis.Poly, degree = 2, intercept = Intercept.Global)

  private lazy val truth: (Array[Double], Array[Double], Array[Double]) =
    val rng = new scala.util.Random(99L)
    val tau = Array.fill(voxels)(3.5 + 4.0 * rng.nextDouble())
    val logSd = Array.fill(voxels)(math.log(1.0) + rng.nextDouble() * (math.log(2.5) - math.log(1.0)))
    val beta = Array.fill(voxels * 3)((if rng.nextBoolean() then 1.0 else -1.0) * (0.5 + 1.5 * rng.nextDouble()))
    (tau, logSd, beta)

  /** Time-major rows x voxels data: family signal + white noise at SNR 1 + drift. */
  private lazy val data: Array[Double] =
    val (tau, logSd, beta) = truth
    val rng = new scala.util.Random(7L)
    val out = new Array[Double](rows * voxels)
    val scale = new Array[Double](family.jetComponents)
    var v = 0
    while v < voxels do
      val point = ShapePoint.unsafe(Vector(tau(v), logSd(v)))
      family.scaleJetInto(family.libraryNormalization, point, scale)
      val design = term.convolve(family.toHrf(point), frame, precision = precision).data
      val signal = new Array[Double](rows)
      var sum = 0.0
      var sum2 = 0.0
      var t = 0
      while t < rows do
        var acc = 0.0
        var j = 0
        while j < 3 do
          acc += design.data(t * 3 + j) / scale(JetLayout.Value) * beta(v * 3 + j)
          j += 1
        signal(t) = acc
        sum += acc
        sum2 += acc * acc
        t += 1
      val sd = math.sqrt(math.max(1e-12, sum2 / rows - (sum / rows) * (sum / rows)))
      t = 0
      while t < rows do
        val drift = 10.0 * sd + 0.3 * sd * (t.toDouble / rows - 0.5) + 0.2 * sd * math.pow(t.toDouble / rows - 0.5, 2)
        out(t * voxels + v) = signal(t) + rng.nextGaussian() * sd + drift
        t += 1
      v += 1
    out

  private lazy val dataset: SynchronousFmriDataset =
    val b = DMat.newBuilder(rows, voxels)
    var i = 0
    while i < data.length do
      b.writeLinear(i, data(i))
      i += 1
    FmriDataset.unsafe(
      InMemoryDatasetBackend(DatasetId("phrf12"), b.result(), SampleSpaces(Vector(voxels, 1, 1))),
      frame
    )

  private lazy val plan: FitPlan = FitPlan(FmriModel(eventModel, baseline, dataset))

  private lazy val nuisance: DMat =
    val taskNames = convolved.columnNames.toSet
    val indices = plan.model.columnNames.indices.filterNot(i => taskNames.contains(plan.model.columnNames(i))).toVector
    DMat.tabulate(rows, indices.length)((t, j) => plan.model.designMatrix(t, indices(j)))

  private lazy val admission: ObservedFamilyAdmission =
    val structure = ConditionProfileFit.structureFor(plan, convolved).fold(e => fail(e.message), identity)
    val expanded = ExpandedConditionDesign.lower(term, frame, basis, precision).fold(e => fail(e.message), identity)
    val points = Vector((4.0, math.log(1.2)), (6.0, math.log(2.0))).map { case (tau, logSd) =>
      family.chart.point(tau, logSd).fold(e => fail(e.message), identity)
    }
    ObservedFamilyCertification
      .admitForCondition(
        plan,
        structure,
        expanded,
        term,
        frame,
        precision,
        None,
        Some(nuisance),
        points,
        ObservedFamilyRequirements(1e-2, 1e8, 1e-6)
      )
      .fold(e => fail(e.message), identity)

  private def policy(output: OutputRequest): ConditionProfilePolicy =
    val structure = ConditionProfileFit.structureFor(plan, convolved).fold(e => fail(e.message), identity)
    ConditionProfilePolicy(
      basis,
      structure,
      Vector(15, 15),
      DecodeBudget(
        coarseStride = 2,
        maxNewtonSteps = 6,
        maxJets = 8,
        maxExactEvaluations = 2,
        weakSdLimit = Vector(0.5, 1.0)
      ),
      None,
      1.0,
      output,
      admission,
      blockSize = 8
    )

  private final class CollectingSink extends BlockSink[ConditionProfileBlock, ConditionProfileReceipt]:
    val blocks = Vector.newBuilder[ConditionProfileBlock]
    def accept(block: VoxelBlock, payload: ConditionProfileBlock): Either[String, ConditionProfileReceipt] =
      blocks += payload
      Right(
        ConditionProfileReceipt(
          payload.ordinal,
          payload.results.length,
          payload.results.count(_.status == DecodeStatus.Accepted)
        )
      )

  test("cancellation before read, during read and after delivery never returns successful completion"):
    val prep = ConditionProfileFit
      .prepare(plan, policy(OutputRequest.ConditionAmplitudes(NormalizationRule.Unnormalised)))
      .fold(e => fail(e.message), identity)
    for mode <- Vector("before", "during", "after") do
      var stopped = mode == "before"
      var reads = 0
      var deliveries = 0
      val reader = new DatasetSeriesReader:
        val dataset: FmriDataset = ConditionProfileFitSuite.this.dataset
        def seriesEither(selection: DataSelection): Either[DatasetError, FmriSeries] =
          reads += 1
          val result = ConditionProfileFitSuite.this.dataset.seriesEither(selection)
          if mode == "during" then stopped = true
          result
      val sink = new BlockSink[ConditionProfileBlock, ConditionProfileReceipt]:
        def accept(block: VoxelBlock, payload: ConditionProfileBlock): Either[String, ConditionProfileReceipt] =
          deliveries += 1
          if mode == "after" then stopped = true
          Right(ConditionProfileReceipt(payload.ordinal, payload.results.length, 0))
      val result = prep.run(reader, sink, () => stopped)
      assert(result.isLeft, s"mode=$mode returned $result")
      assertEquals(reads, if mode == "before" then 0 else 1, mode)
      assertEquals(deliveries, if mode == "after" then 1 else 0, mode)
      val expectedCounts = if mode == "after" then "1 chunks / 8 voxels" else "0 chunks / 0 voxels"
      assert(result.left.exists(_.message.contains(expectedCounts)), s"mode=$mode: $result")

  test("the structure maps the plan's task columns by condition and basis"):
    val structure = ConditionProfileFit.structureFor(plan, convolved).fold(e => fail(e.message), identity)
    assertEquals(structure.conditionCount, 3)
    assertEquals(structure.basisSize, basis.rank)

  test("admission refuses a different compiled-plan nuisance geometry before preparation"):
    val alteredBaseline =
      BaselineModel.build(samplingFrame = frame, basis = BaselineBasis.Poly, degree = 1, intercept = Intercept.Global)
    val alteredPlan = FitPlan(FmriModel(eventModel, alteredBaseline, dataset))
    val structure = ConditionProfileFit.structureFor(alteredPlan, convolved).fold(e => fail(e.message), identity)
    val expanded = ExpandedConditionDesign.lower(term, frame, basis, precision).fold(e => fail(e.message), identity)
    val points = Vector((4.0, math.log(1.2))).map { case (tau, logSd) =>
      family.chart.point(tau, logSd).fold(e => fail(e.message), identity)
    }
    val result = ObservedFamilyCertification.admitForCondition(
      alteredPlan,
      structure,
      expanded,
      term,
      frame,
      precision,
      None,
      Some(nuisance),
      points,
      ObservedFamilyRequirements(1e-2, 1e8, 1e-6)
    )
    assert(result.isLeft)

  test("admission refuses same-shaped shifted task and nuisance geometry, and OLS whitening"):
    val shifted = term.copy(onsets = term.onsets.updated(0, Seconds(term.onsets.head.value + 0.2)))
    val shiftedConvolved = shifted.convolve(basis.kernel, frame, precision = precision)
    val shiftedModel = EventModel.build(Vector(shiftedConvolved), frame)
    val shiftedPlan = FitPlan(FmriModel(shiftedModel, baseline, dataset))
    val shiftedStructure =
      ConditionProfileFit.structureFor(shiftedPlan, shiftedConvolved).fold(e => fail(e.message), identity)
    val expanded = ExpandedConditionDesign.lower(term, frame, basis, precision).fold(e => fail(e.message), identity)
    val points = Vector(family.chart.point(4.0, math.log(1.2)).fold(e => fail(e.message), identity))
    val shiftedResult = ObservedFamilyCertification.admitForCondition(
      shiftedPlan,
      shiftedStructure,
      expanded,
      term,
      frame,
      precision,
      None,
      Some(nuisance),
      points,
      ObservedFamilyRequirements(1e-2, 1e8, 1e-6)
    )
    assert(shiftedResult.isLeft)
    val changedNuisance = DMat.tabulate(rows, nuisance.cols)((row, column) =>
      nuisance(row, column) + (if row == 0 && column == 0 then 1e-8 else 0.0)
    )
    val structure = ConditionProfileFit.structureFor(plan, convolved).fold(e => fail(e.message), identity)
    val nuisanceResult = ObservedFamilyCertification.admitForCondition(
      plan,
      structure,
      expanded,
      term,
      frame,
      precision,
      None,
      Some(changedNuisance),
      points,
      ObservedFamilyRequirements(1e-2, 1e8, 1e-6)
    )
    assert(nuisanceResult.isLeft)
    val whitenedResult = ObservedFamilyCertification.admitForCondition(
      plan,
      structure,
      expanded,
      term,
      frame,
      precision,
      Some(
        scalafim.fmri.ar.WhiteningPlan
          .global(scalafim.fmri.ar.ArmaCoefficients.ar(0.2), Vector(scalafim.fmri.ar.TimeSegment(0, rows, 0)))
      ),
      Some(nuisance),
      points,
      ObservedFamilyRequirements(1e-2, 1e8, 1e-6)
    )
    assert(whitenedResult.isLeft)

  test("the Gram route agrees with the compact route and the direct oracle, streaming blocks in order"):
    val queries = Vector(SignedQuery.make("A-B", Vector(1.0, -1.0, 0.0), 1e-6).fold(e => fail(e.message), identity))
    val prep = ConditionProfileFit
      .prepare(plan, policy(OutputRequest.ConditionQueries(queries, NormalizationRule.Unnormalised)))
      .fold(e => fail(e.message), identity)
    val sink = new CollectingSink
    val (receipts, counters) = prep.run(dataset, sink).fold(e => fail(e.message), identity)
    val blocks = sink.blocks.result()
    assertEquals(blocks.map(_.ordinal), blocks.indices.toVector)
    assertEquals(receipts.map(_.voxels).sum, voxels)
    val results = blocks.flatMap(_.results).sortBy(_.voxel)
    assertEquals(results.map(_.voxel), (0 until voxels).toVector)
    assert(counters.perVoxel(counters.jets) <= prep.policy.budget.maxJets.toDouble + 1e-9)
    assert(counters.perVoxel(counters.exactEvaluations) <= prep.policy.budget.maxExactEvaluations.toDouble + 1e-9)
    assert(counters.perVoxel(counters.nodeScores) <= 90.0)

    // Compact route on the same data: nuisance = the plan's baseline columns, no whitening.
    val expanded = ExpandedConditionDesign.lower(term, frame, basis, precision).fold(e => fail(e.message), identity)
    val compactPrep =
      CompactConditionPreparation
        .prepare(expanded, admission, None, Some(nuisance), term, frame, precision)
        .fold(e => fail(e.message), identity)
    val runtime = new CompactConditionRuntime(
      compactPrep,
      NodeGrid(family.chart, Vector(15, 15)),
      prep.policy.budget,
      None,
      1.0,
      NormalizationRule.Unnormalised
    )
    val column = new Array[Double](rows)
    val (tau, _, _) = truth
    var accepted = 0
    var v = 0
    while v < voxels do
      var t = 0
      while t < rows do
        column(t) = data(t * voxels + v)
        t += 1
      val compact = runtime.fit(column, 0, new DecoderCounters)
      val gramRoute = results(v)
      assertEqualsDouble(gramRoute.coordinates(0), compact.decode.coordinates(0), 1e-6, s"tau voxel $v")
      assertEqualsDouble(gramRoute.coordinates(1), compact.decode.coordinates(1), 1e-6, s"logSd voxel $v")
      var j = 0
      while j < 3 do
        assertEqualsDouble(
          gramRoute.amplitudes(j).value,
          compact.amplitudes(j),
          1e-6 * math.max(1.0, math.abs(compact.amplitudes(j))),
          s"amplitude $j voxel $v"
        )
        j += 1
      assertEqualsDouble(
        gramRoute.queries.head.value,
        gramRoute.amplitudes(0).value - gramRoute.amplitudes(1).value,
        1e-12
      )
      if gramRoute.status == DecodeStatus.Accepted then
        accepted += 1
        assert(
          math.abs(gramRoute.coordinates(0) - tau(v)) < 0.6,
          s"voxel $v latency ${gramRoute.coordinates(0)} vs truth ${tau(v)}"
        )
      v += 1
    assert(accepted >= 0.8 * voxels, s"accepted $accepted of $voxels")

  test("prepared provenance carries the policy's typed prior, output and the retained preparation"):
    val queries =
      Vector(SignedQuery.make("a_minus_b", Vector(1.0, -1.0, 0.0), 1e-6).fold(e => fail(e.message), identity))
    val output = OutputRequest.ConditionQueries(queries, NormalizationRule.Unnormalised)
    val prior = Some(ShapePrior(Vector(5.0, 0.1), Vector(0.1, 0.0, 0.0, 0.1)))
    val prep =
      ConditionProfileFit.prepare(plan, policy(output).copy(prior = prior)).fold(e => fail(e.message), identity)
    assertEquals(prep.provenance.output, output)
    assertEquals(prep.provenance.prior, prior)
    assertEquals(prep.provenance.preparation, prep.retention.preparation)
    assertEquals(prep.provenance.noiseVariance, 1.0)
    val canonical = prep.provenance.canonical
    assert(canonical.startsWith("condition-profile/v2|basis="), canonical)
    assert(canonical.contains("|prior=some("), canonical)
    assert(!canonical.contains("@"), canonical)
    val baseline = ConditionProfileFit.prepare(plan, policy(output)).fold(e => fail(e.message), identity)
    assertNotEquals(baseline.provenance.canonical, canonical)

  test("trial outputs and mismatched structures are refused before any response is read"):
    val trial = ConditionProfileFit.prepare(plan, policy(OutputRequest.TrialAmplitudes(NormalizationRule.Density)))
    assert(trial.isLeft)
    val wrongRank = policy(OutputRequest.ConditionAmplitudes(NormalizationRule.Density)).copy(basis = basis)
    val badStructure = wrongRank.copy(structure =
      scalafim.fmri.fit.TaskBasisStructure
        .make(Vector(Vector(plan.structuralColumns.head.id)))
        .fold(e => fail(e.message), identity)
    )
    assert(ConditionProfileFit.prepare(plan, badStructure).isLeft)
    assert(
      ConditionProfileFit
        .prepare(plan, policy(OutputRequest.ConditionAmplitudes(NormalizationRule.UnitIntegral)))
        .isLeft
    )

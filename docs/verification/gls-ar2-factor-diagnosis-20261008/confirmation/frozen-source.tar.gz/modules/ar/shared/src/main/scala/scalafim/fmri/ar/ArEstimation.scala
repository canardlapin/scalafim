package scalafim.fmri.ar

import gale.linalg.{CholeskyOptions, DMat, Matrix}
import gale.numeric.{ExactSum, ExactSumError}

enum ArOrder:
  case Fixed(order: ArOrderValue)
  case Auto(maxOrder: ArOrderValue)

  def maxRequested: Int =
    this match
      case Fixed(order)  => order.value
      case Auto(maxOrder) => maxOrder.value

  def maxRequestedOrder: ArOrderValue =
    this match
      case Fixed(order)  => order
      case Auto(maxOrder) => maxOrder

object ArOrder:
  def Fixed(order: Int): ArOrder =
    Fixed(ArOrderValue.unsafe(order))

  def Auto(maxOrder: Int): ArOrder =
    Auto(ArOrderValue.unsafe(maxOrder))

final case class ArFitOptions private (
    order: ArOrder,
    pooling: NoisePooling,
    initialCondition: InitialConditionPolicy,
    stationarity: StationarityBound
):
  def exactFirstAr1: Boolean = initialCondition == InitialConditionPolicy.ExactAr1
  def stationarityBound: Double = stationarity.value

object ArFitOptions:

  def apply(
      order: ArOrder = ArOrder.Auto(6),
      pooling: NoisePooling = NoisePooling.Global,
      exactFirstAr1: Boolean = true,
      stationarityBound: Double = 0.99
  ): ArFitOptions =
    new ArFitOptions(
      order = order,
      pooling = pooling,
      initialCondition = InitialConditionPolicy.fromExactFirstAr1(exactFirstAr1),
      stationarity = StationarityBound.unsafe(stationarityBound)
    )

  def withInitialCondition(
      order: ArOrder = ArOrder.Auto(6),
      pooling: NoisePooling = NoisePooling.Global,
      initialCondition: InitialConditionPolicy = InitialConditionPolicy.ExactAr1,
      stationarity: StationarityBound = StationarityBound.Default
  ): ArFitOptions =
    new ArFitOptions(order, pooling, initialCondition, stationarity)

final case class YuleWalkerEstimate(
    coefficients: ArmaCoefficients,
    innovationVariance: Double
):
  require(innovationVariance >= 0.0 && innovationVariance.isFinite, "innovation variance must be non-negative and finite")

/** Immutable raw spatial-block statistics. Lag products remain unregularized
  * until every block for this complete temporal layout has been merged.
  *
  * Lag sums are held exactly (see [[ExactSum]]), so merging is associative and
  * commutative: any partition of the voxels into spatial blocks, merged in any
  * order, finalizes to the same doubles as the whole-volume estimator.
  */
final class ArNoiseSummary private (
    val layout: NoiseEstimationLayout,
    val maxOrder: ArOrderValue,
    private val exactSumsByRun: Vector[Vector[ExactSum]],
    private[ar] val sumsByRun: Vector[Vector[Double]],
    private[ar] val countsByRun: Vector[Vector[Long]],
    private[ar] val correction: PreparedCorrection
):
  require(sumsByRun.length == layout.runCount, "noise-summary sums must cover every run")
  require(countsByRun.length == layout.runCount, "noise-summary counts must cover every run")
  require(sumsByRun.zip(countsByRun).forall { (sums, counts) =>
    sums.length == maxOrder.value + 1 && counts.length == maxOrder.value + 1
  }, "noise-summary lag dimensions must match the requested order")
  require(sumsByRun.flatten.forall(_.isFinite), "noise-summary sums must be finite")
  require(countsByRun.flatten.forall(_ >= 0L), "noise-summary pair counts must be non-negative")

  private[ar] def exactSum(run: Int, lag: Int): ExactSum = exactSumsByRun(run)(lag)

  def lagSumsByRun: Vector[Vector[Double]] = sumsByRun
  def pairCountsByRun: Vector[Vector[Long]] = countsByRun

  def merge(other: ArNoiseSummary): Either[ArError, ArNoiseSummary] =
    ArNoiseSummary.merge(this, other)

private object ArNoiseSummary:
  def make(
      layout: NoiseEstimationLayout,
      maxOrder: ArOrderValue,
      exactSumsByRun: Vector[Vector[ExactSum]],
      countsByRun: Vector[Vector[Long]],
      correction: PreparedCorrection
  ): Either[ArError, ArNoiseSummary] =
    // Round each exact total once; the summary keeps both forms so later merges stay exact.
    val sumsByRun = exactSumsByRun.map(_.map(_.value))
    var run = 0
    while run < sumsByRun.length do
      var lag = 0
      while lag < sumsByRun(run).length do
        val total = sumsByRun(run)(lag)
        if !total.isFinite then return Left(ArError.NonFiniteNoiseSummary(run, ArLag.unsafe(lag), total))
        lag += 1
      run += 1
    Right(new ArNoiseSummary(layout, maxOrder, exactSumsByRun, sumsByRun, countsByRun, correction))

  def merge(left: ArNoiseSummary, right: ArNoiseSummary): Either[ArError, ArNoiseSummary] =
    if left.layout != right.layout then
      Left(ArError.IncompatibleNoiseSummaries("layouts differ"))
    else if left.maxOrder != right.maxOrder then
      Left(ArError.IncompatibleNoiseSummaries("maximum requested orders differ"))
    else if left.correction.binding.map(b => (b.fingerprint, b.budget, b.targetOrder)) !=
        right.correction.binding.map(b => (b.fingerprint, b.budget, b.targetOrder)) then
      Left(ArError.IncompatibleNoiseSummaries("residual-bias correction bindings differ"))
    else
      val sums = Vector.newBuilder[Vector[ExactSum]]
      val counts = Vector.newBuilder[Vector[Long]]
      var run = 0
      while run < left.layout.runCount do
        val mergedSums = Vector.newBuilder[ExactSum]
        val mergedCounts = Array.ofDim[Long](left.maxOrder.value + 1)
        var lag = 0
        while lag <= left.maxOrder.value do
          if Long.MaxValue - left.countsByRun(run)(lag) < right.countsByRun(run)(lag) then
            return Left(ArError.NoiseSummaryCountOverflow(run, ArLag.unsafe(lag)))
          val sum = left.exactSum(run, lag).copy()
          sum.addAll(right.exactSum(run, lag)) match
            case Left(ExactSumError.CapacityExceeded(current, incoming)) =>
              return Left(ArError.NoiseSumCapacityExceeded(ArLag.unsafe(lag), current, incoming))
            case Right(_) => ()
          mergedSums += sum
          mergedCounts(lag) = left.countsByRun(run)(lag) + right.countsByRun(run)(lag)
          lag += 1
        sums += mergedSums.result()
        counts += mergedCounts.toVector
        run += 1
      make(left.layout, left.maxOrder, sums.result(), counts.result(), left.correction)

object ArEstimation:

  private val RelativePositiveDefiniteMargin = 1e-6

  private[ar] final case class PooledAutocovariance(
      sums: Array[Double],
      pairCounts: Array[Long],
      correction: Option[DMat] = None
  ):
    require(sums.length == pairCounts.length, "autocovariance sums and pair counts must align")
    require(sums.nonEmpty, "pooled autocovariance must contain lag zero")

    def maxLag: ArLag =
      var lag = pairCounts.length - 1
      while lag > 0 && pairCounts(lag) == 0L do lag -= 1
      ArLag.unsafe(lag)

    /** Pair-count autocovariances over every lag that has pairs, with the design-bias system solved over that
      * full budget when a correction matrix is present. Correcting before truncating matters: the correction at
      * length L assumes gamma beyond L is zero, so correcting a short vector discards what makes it work.
      */
    private lazy val correctedFull: (Vector[Double], Option[CorrectionFallback]) =
      correction match
        case None => (Vector.empty, None)
        case Some(matrix) =>
          var available = 0
          while available < pairCounts.length && pairCounts(available) > 0L do available += 1
          val raw = Vector.tabulate(available)(lag => sums(lag) / pairCounts(lag).toDouble)
          AcvfBias.correct(raw, matrix) match
            case Right(corrected) => (corrected, None)
            case Left(reason)     => (raw, Some(reason))

    /** Whether a correction was requested and actually used; `false` after a fallback to the raw estimate. */
    def correctionApplied: Boolean = correction.isDefined && correctedFull._2.isEmpty

    /** Why a requested correction fell back to the raw estimate, if it did. */
    def correctionFallback: Option[CorrectionFallback] = correctedFull._2

    def through(order: ArOrderValue): Either[ArError, Autocovariances] =
      val required = order.value + 1
      if required > sums.length then Left(ArError.InsufficientAutocovariances(required, sums.length))
      else
        var lag = 0
        while lag < required do
          if pairCounts(lag) == 0L then
            return Left(ArError.InsufficientAutocovariances(required, lag))
          lag += 1
        val values =
          if correction.isDefined then correctedFull._1.take(required)
          else Vector.tabulate(required)(lag => sums(lag) / pairCounts(lag).toDouble)
        Autocovariances(values).map(stabilizeAutocovariances)

  private final case class RunEstimate(
      coefficients: ArmaCoefficients,
      observations: Int
  ):
    require(observations >= 0, "run estimate observations must be non-negative")

  /** Summarize one spatial residual block against the complete temporal layout.
    * Means are per voxel and run over all retained rows, while lag products do
    * not cross censored/reset segment boundaries.
    */
  def summarizeNoise(
      residuals: DMat,
      layout: NoiseEstimationLayout,
      maxOrder: ArOrderValue
  ): Either[ArError, ArNoiseSummary] =
    for
      _ <- layout.coveredSegments.validateRows(residuals.rows)
      _ <- validateFinite(residuals)
      _ <- if residuals.cols > 0 then Right(()) else Left(ArError.EmptySpatialNoiseBlock)
      _ <- if layout.retainedRows > 0 then Right(()) else Left(ArError.NoEstimableRows)
      summary <- summarizeNoiseUnchecked(residuals, layout, maxOrder, uncorrected(layout))
    yield summary

  /** Validate each OLS residual block against a prepared design, then retain raw
    * lag statistics over the complete correction budget. Correction is applied
    * once after merging spatial blocks, preserving exact pooling determinism.
    */
  def summarizeNoise(
      residuals: DMat,
      layout: NoiseEstimationLayout,
      maxOrder: ArOrderValue,
      design: DMat,
      prepared: PreparedCorrection
  ): Either[ArError, ArNoiseSummary] =
    for
      _ <- validateInputs(residuals, layout)
      _ <- if residuals.cols > 0 then Right(()) else Left(ArError.EmptySpatialNoiseBlock)
      bound <- AcvfBias.bind(residuals, layout, design, maxOrder.value, prepared)
      accumulated = ArOrderValue.unsafe(math.max(maxOrder.value, bound.matrices.lag))
      summary <- summarizeNoiseUnchecked(residuals, layout, accumulated, bound)
    yield summary

  /** Finalize merged noise statistics, applying their bound correction once. */
  def fitNoise(
      summary: ArNoiseSummary,
      options: ArFitOptions
  ): Either[ArError, WhiteningPlan] =
    if options.order.maxRequested > summary.maxOrder.value then
      Left(ArError.ArOrderNotEstimable(options.order.maxRequestedOrder, ArLag.unsafe(summary.maxOrder.value)))
    else if summary.correction.binding.exists(_.targetOrder != options.order.maxRequested) then
      Left(ArError.PreparedCorrectionOrderMismatch(summary.correction.binding.get.targetOrder, options.order.maxRequested))
    else
      options.pooling match
        case NoisePooling.Global =>
          for
            estimates <- estimateByRun(summary, options)
            coefficients <- poolRunCoefficients(estimates, options.stationarity)
            plan <- WhiteningPlan.globalWithInitialCondition(
              coefficients,
              summary.layout.whiteningSegments,
              initialCondition = options.initialCondition,
              method = WhiteningMethod.Estimated
            )
          yield plan
        case NoisePooling.Run =>
          estimateByRun(summary, options).flatMap { estimates =>
            WhiteningPlan.byRunWithInitialCondition(
              estimates.map(_.coefficients),
              summary.layout.whiteningSegments,
              initialCondition = options.initialCondition,
              method = WhiteningMethod.Estimated
            )
          }

  def fitNoise(
      residuals: DMat,
      segments: Vector[TimeSegment],
      options: ArFitOptions = ArFitOptions()
  ): Either[ArError, WhiteningPlan] =
    fitNoise(residuals, segments, options, EstimationPolicy.Raw)

  def fitNoise(
      residuals: DMat,
      segments: Vector[TimeSegment],
      options: ArFitOptions,
      policy: EstimationPolicy
  ): Either[ArError, WhiteningPlan] =
    NoiseEstimationLayout
      .allRows(segments, residuals.rows)
      .flatMap(layout => fitNoise(residuals, layout, options, policy))

  def fitNoise(
      residuals: DMat,
      layout: NoiseEstimationLayout,
      options: ArFitOptions
  ): Either[ArError, WhiteningPlan] =
    fitNoise(residuals, layout, options, EstimationPolicy.Raw)

  def fitNoise(
      residuals: DMat,
      layout: NoiseEstimationLayout,
      options: ArFitOptions,
      policy: EstimationPolicy
  ): Either[ArError, WhiteningPlan] =
    for
      _ <- validateInputs(residuals, layout)
      correction <- resolveCorrection(residuals, layout, options.order.maxRequested, policy)
      plan <- fitNoisePrepared(residuals, layout, options, correction)
    yield plan

  /** Fit against a correction prepared once by [[AcvfBias.prepare]]. Results are bit-identical to
    * `EstimationPolicy.DesignCorrected` with the same design, budget and order; the prepared value is checked
    * against this residual set's row count and layout, and the residuals against the design's orthogonality.
    */
  def fitNoise(
      residuals: DMat,
      layout: NoiseEstimationLayout,
      options: ArFitOptions,
      design: DMat,
      prepared: PreparedCorrection
  ): Either[ArError, WhiteningPlan] =
    for
      _ <- validateInputs(residuals, layout)
      correction <- AcvfBias.bind(residuals, layout, design, options.order.maxRequested, prepared)
      plan <- fitNoisePrepared(residuals, layout, options, correction)
    yield plan

  private[ar] def validateInputs(residuals: DMat, layout: NoiseEstimationLayout): Either[ArError, Unit] =
    for
      _ <- layout.coveredSegments.validateRows(residuals.rows)
      _ <- validateFinite(residuals)
      _ <- if layout.retainedRows > 0 then Right(()) else Left(ArError.NoEstimableRows)
    yield ()

  /** Fit with bias matrices that were already built, so a caller needing both the plan and the matrices builds
    * them once. Inputs are assumed validated by the public entry points.
    */
  private[ar] def fitNoisePrepared(
      residuals: DMat,
      layout: NoiseEstimationLayout,
      options: ArFitOptions,
      correction: PreparedCorrection
  ): Either[ArError, WhiteningPlan] =
    for
      plan <-
        options.pooling match
          case NoisePooling.Global =>
            for
              estimates <- estimateByRun(residuals, layout, options, correction)
              coefficients <- poolRunCoefficients(estimates, options.stationarity)
              plan <-
                WhiteningPlan.globalWithInitialCondition(
                  coefficients,
                  layout.whiteningSegments,
                  initialCondition = options.initialCondition,
                  method = WhiteningMethod.Estimated
                )
            yield plan

          case NoisePooling.Run =>
            estimateByRun(residuals, layout, options, correction).flatMap { estimates =>
              WhiteningPlan.byRunWithInitialCondition(
                estimates.map(_.coefficients),
                layout.whiteningSegments,
                initialCondition = options.initialCondition,
                method = WhiteningMethod.Estimated
              )
            }
    yield plan

  /** Per-run bias matrices for the policy; `None` leaves a run on the raw estimator. */
  private[ar] def resolveCorrection(
      residuals: DMat,
      layout: NoiseEstimationLayout,
      targetOrder: Int,
      policy: EstimationPolicy
  ): Either[ArError, PreparedCorrection] =
    policy match
      case EstimationPolicy.Raw =>
        Right(uncorrected(layout))
      case EstimationPolicy.DesignCorrected(design, budget) =>
        if design.rows != residuals.rows then Left(ArError.DesignRowMismatch(design.rows, residuals.rows))
        else AcvfBias.prepareChecked(design, layout, budget, targetOrder, Some(residuals))

  private[ar] def uncorrected(layout: NoiseEstimationLayout): PreparedCorrection =
    PreparedCorrection(
      AcvfBiasMatrices(0, 0, 0, Vector.empty),
      Vector.fill(layout.runCount)(RunCorrection.Uncorrected),
      layout,
      None
    )

  private def estimateByRun(
      residuals: DMat,
      layout: NoiseEstimationLayout,
      options: ArFitOptions,
      correction: PreparedCorrection
  ): Either[ArError, Vector[RunEstimate]] =
    val estimates = Vector.newBuilder[RunEstimate]
    var run = 0
    while run < layout.runCount do
      val segments = layout.segmentsForRun(run)
      val observations = effectiveObservations(segments)
      if observations <= 1 then
        estimates += RunEstimate(ArmaCoefficients.Iid, observations)
      else
        estimateForSegmentsUnchecked(residuals, segments, options, correction.usable(run)) match
          case Left(error) => return Left(error)
          case Right(estimate) =>
            estimates += RunEstimate(estimate.coefficients, observations)
      run += 1
    Right(estimates.result())

  private def estimateByRun(
      summary: ArNoiseSummary,
      options: ArFitOptions
  ): Either[ArError, Vector[RunEstimate]] =
    val estimates = Vector.newBuilder[RunEstimate]
    var run = 0
    while run < summary.layout.runCount do
      val observations = effectiveObservations(summary.layout.segmentsForRun(run))
      if observations <= 1 then
        estimates += RunEstimate(ArmaCoefficients.Iid, observations)
      else
        estimateForSummaryRun(summary, run, observations, options) match
          case Left(error) => return Left(error)
          case Right(estimate) => estimates += RunEstimate(estimate.coefficients, observations)
      run += 1
    Right(estimates.result())

  private def estimateForSummaryRun(
      summary: ArNoiseSummary,
      run: Int,
      observations: Int,
      options: ArFitOptions
  ): Either[ArError, YuleWalkerEstimate] =
    val pooled = PooledAutocovariance(
      summary.sumsByRun(run).toArray,
      summary.countsByRun(run).toArray,
      summary.correction.usable(run)
    )
    val maxLag = ArLag.unsafe(math.min(options.order.maxRequested, pooled.maxLag.value))
    options.order match
      case ArOrder.Fixed(order) =>
        if order.value > maxLag.value then Left(ArError.ArOrderNotEstimable(order, maxLag))
        else pooled.through(order).flatMap(yuleWalker(_, order, options.stationarity))
      case ArOrder.Auto(_) =>
        selectByBic(pooled, observations, maxLag, options.stationarity)

  private def poolRunCoefficients(
      estimates: Vector[RunEstimate],
      stationarityBound: StationarityBound
  ): Either[ArError, ArmaCoefficients] =
    val observations = estimates.map(_.observations).sum
    if observations <= 0 then Left(ArError.NoEstimableRows)
    else
      val order = estimates.map(_.coefficients.arOrder).maxOption.getOrElse(0)
      if order == 0 then Right(ArmaCoefficients.Iid)
      else
        val pooled = Array.fill(order)(0.0)
        estimates.foreach { estimate =>
          val weight = estimate.observations.toDouble / observations.toDouble
          var lag = 0
          while lag < estimate.coefficients.arOrder do
            pooled(lag) += weight * estimate.coefficients.phi(lag)
            lag += 1
        }
        Pacf
          .enforceStationaryChecked(pooled.toVector, stationarityBound)
          .map(phi => ArmaCoefficients.ar(phi*))

  def estimateForSegments(
      residuals: DMat,
      segments: Vector[TimeSegment],
      options: ArFitOptions
  ): Either[ArError, YuleWalkerEstimate] =
    for
      layout <- NoiseEstimationLayout.allRows(segments, residuals.rows)
      _ <- validateFinite(residuals)
      estimate <- estimateForSegmentsUnchecked(residuals, layout.estimationSegments, options)
    yield estimate

  private def estimateForSegmentsUnchecked(
      residuals: DMat,
      segments: Vector[TimeSegment],
      options: ArFitOptions,
      correction: Option[DMat] = None
  ): Either[ArError, YuleWalkerEstimate] =
    val observations = effectiveObservations(segments)
    if observations <= 1 then
      Right(YuleWalkerEstimate(ArmaCoefficients.Iid, 0.0))
    else
      // Solving the bias system needs a wider tail than the order being fitted, so accumulate through the
      // correction budget and then truncate to the requested order.
      val requested = options.order.maxRequestedOrder
      val accumulate =
        correction.fold(requested)(matrix => ArOrderValue.unsafe(math.max(requested.value, matrix.rows - 1)))
      pooledAutocovariance(residuals, segments, accumulate, correction).flatMap { pooled =>
        val maxLag = ArLag.unsafe(math.min(options.order.maxRequested, pooled.maxLag.value))
        options.order match
          case ArOrder.Fixed(order) =>
            if order.value > maxLag.value then
              Left(ArError.ArOrderNotEstimable(order, maxLag))
            else
              pooled.through(order).flatMap(yuleWalker(_, order, options.stationarity))

          case ArOrder.Auto(_) =>
            selectByBic(pooled, observations, maxLag, options.stationarity)
      }

  def autocovariance(
      residuals: DMat,
      segments: Vector[TimeSegment],
      maxLag: Int
  ): Either[ArError, Vector[Double]] =
    ArLag(maxLag).flatMap(autocovariances(residuals, segments, _)).map(_.toVector)

  def autocovariances(
      residuals: DMat,
      segments: Vector[TimeSegment],
      maxLag: ArLag
  ): Either[ArError, Autocovariances] =
    for
      layout <- NoiseEstimationLayout.allRows(segments, residuals.rows)
      _ <- validateFinite(residuals)
      pooled <- pooledAutocovariance(residuals, layout.estimationSegments, ArOrderValue.unsafe(maxLag.value))
      _ <-
        if maxLag.value <= pooled.maxLag.value then Right(())
        else Left(ArError.ArOrderNotEstimable(ArOrderValue.unsafe(maxLag.value), pooled.maxLag))
      gamma <- pooled.through(ArOrderValue.unsafe(maxLag.value))
    yield gamma

  def yuleWalker(
      gamma: Vector[Double],
      order: Int,
      stationarityBound: Double = 0.99
  ): Either[ArError, YuleWalkerEstimate] =
    for
      typedOrder <- ArOrderValue(order)
      typedGamma <- Autocovariances(gamma)
      bound <- StationarityBound(stationarityBound)
      estimate <- yuleWalker(typedGamma, typedOrder, bound)
    yield estimate

  def yuleWalker(
      gamma: Autocovariances,
      order: ArOrderValue,
      stationarityBound: StationarityBound
  ): Either[ArError, YuleWalkerEstimate] =
    gamma.takeThrough(order).flatMap { scopedGamma =>
      if order.value == 0 then
        Right(YuleWalkerEstimate(ArmaCoefficients.Iid, math.max(0.0, scopedGamma.lagZero)))
      else if scopedGamma.lagZero <= 0.0 || !scopedGamma.lagZero.isFinite then
        Right(YuleWalkerEstimate(ArmaCoefficients.ar(Vector.fill(order.value)(0.0)*), 0.0))
      else
        yuleWalkerNonZero(stabilizeAutocovariances(scopedGamma), order, stationarityBound)
    }

  private def yuleWalkerNonZero(
      gamma: Autocovariances,
      order: ArOrderValue,
      stationarityBound: StationarityBound
  ): Either[ArError, YuleWalkerEstimate] =
    if gamma.lagZero <= 0.0 || !gamma.lagZero.isFinite then
      Right(YuleWalkerEstimate(ArmaCoefficients.ar(Vector.fill(order.value)(0.0)*), 0.0))
    else
      var sigma2 = gamma.lagZero
      var previous = Array.empty[Double]
      var m = 1
      while m <= order.value do
        var acc = gamma.at(ArLag.unsafe(m))
        var j = 1
        while j <= m - 1 do
          acc -= previous(j - 1) * gamma.at(ArLag.unsafe(m - j))
          j += 1

        val kappa =
          if sigma2 <= 0.0 || !sigma2.isFinite then 0.0
          else acc / sigma2

        val current = new Array[Double](m)
        j = 1
        while j <= m - 1 do
          current(j - 1) = previous(j - 1) - kappa * previous((m - j) - 1)
          j += 1
        current(m - 1) = kappa
        sigma2 = math.max(0.0, sigma2 * (1.0 - kappa * kappa))
        previous = current
        m += 1

      Pacf.enforceStationaryChecked(previous.toVector, stationarityBound).map { stable =>
        var innovationVariance = gamma.lagZero
        var lag = 0
        while lag < stable.length do
          innovationVariance -= stable(lag) * gamma.at(ArLag.unsafe(lag + 1))
          lag += 1
        val boundedVariance = math.min(gamma.lagZero, math.max(1e-12, innovationVariance))
        YuleWalkerEstimate(ArmaCoefficients.ar(stable*), boundedVariance)
      }

  private def selectByBic(
      pooled: PooledAutocovariance,
      observations: Int,
      maxOrder: ArLag,
      stationarityBound: StationarityBound
  ): Either[ArError, YuleWalkerEstimate] =
    var best: Option[(Double, YuleWalkerEstimate)] = None
    var order = 0
    val selectionLimit = math.min(maxOrder.value, observations / 5)
    while order <= selectionLimit do
      val estimate =
        pooled
          .through(ArOrderValue.unsafe(order))
          .flatMap(yuleWalker(_, ArOrderValue.unsafe(order), stationarityBound))
      estimate match
        case Left(error) => return Left(error)
        case Right(estimate) =>
          val sigma2 = math.max(estimate.innovationVariance, 1e-12)
          val bic =
            2.0 * observations.toDouble * math.log(sigma2) +
              (order + 1).toDouble * math.log(observations.toDouble)
          best match
            case None => best = Some(bic -> estimate)
            case Some((current, _)) if bic < current => best = Some(bic -> estimate)
            case _ => ()
      order += 1

    best.map(_._2).toRight(ArError.UnableToEstimateArModel)

  private def effectiveObservations(segments: Vector[TimeSegment]): Int =
    segments.map(_.length).sum

  private def summarizeNoiseUnchecked(
      residuals: DMat,
      layout: NoiseEstimationLayout,
      maxOrder: ArOrderValue,
      correction: PreparedCorrection
  ): Either[ArError, ArNoiseSummary] =
    val lags = maxOrder.value + 1
    val sums = Array.fill(layout.runCount, lags)(ExactSum.zero())
    val counts = Array.fill(layout.runCount, lags)(0L)
    var run = 0
    while run < layout.runCount do
      val segments = layout.segmentsForRun(run)
      val retainedRows = effectiveObservations(segments)
      val segmentMeans = new Array[Double](segments.length)
      var column = 0
      while column < residuals.cols do
        var total = 0.0
        var segmentIndex = 0
        while segmentIndex < segments.length do
          val segment = segments(segmentIndex)
          var row = segment.start
          while row < segment.endExclusive do
            total += residuals(row, column)
            row += 1
          segmentIndex += 1
        java.util.Arrays.fill(segmentMeans, total / retainedRows.toDouble)
        var lag = 0
        while lag < lags do
          val partial = columnLagProductSum(residuals, column, lag, segments, segmentMeans)
          if !partial.isFinite then
            return Left(ArError.NonFiniteNoiseSummary(run, ArLag.unsafe(lag), partial))
          val pairs = lagPairCount(segments, lag)
          if Long.MaxValue - counts(run)(lag) < pairs then
            return Left(ArError.NoiseSummaryCountOverflow(run, ArLag.unsafe(lag)))
          sums(run)(lag).add(partial) match
            case Left(ExactSumError.CapacityExceeded(current, incoming)) =>
              return Left(ArError.NoiseSumCapacityExceeded(ArLag.unsafe(lag), current, incoming))
            case Right(_) => ()
          counts(run)(lag) += pairs
          lag += 1
        column += 1
      run += 1
    ArNoiseSummary.make(
      layout,
      maxOrder,
      sums.iterator.map(_.toVector).toVector,
      counts.iterator.map(_.toVector).toVector,
      correction
    )

  /** Canonical per-voxel lag-product sum: segments in order, rows in order, from zero. Both the whole-volume
    * estimator and spatial-block summaries reduce exactly this value per voxel, then combine voxels with
    * [[ExactSum]], so the pooled statistic does not depend on how voxels were partitioned.
    */
  private def columnLagProductSum(
      residuals: DMat,
      column: Int,
      lag: Int,
      segments: Vector[TimeSegment],
      segmentMeans: Array[Double]
  ): Double =
    var partial = 0.0
    var segmentIndex = 0
    while segmentIndex < segments.length do
      val segment = segments(segmentIndex)
      val mean = segmentMeans(segmentIndex)
      var row = segment.start + lag
      while row < segment.endExclusive do
        partial += (residuals(row, column) - mean) * (residuals(row - lag, column) - mean)
        row += 1
      segmentIndex += 1
    partial

  private def lagPairCount(segments: Vector[TimeSegment], lag: Int): Long =
    var pairs = 0L
    var segmentIndex = 0
    while segmentIndex < segments.length do
      pairs += math.max(0, segments(segmentIndex).length - lag).toLong
      segmentIndex += 1
    pairs

  private[ar] def pooledAutocovariance(
      residuals: DMat,
      segments: Vector[TimeSegment],
      maxOrder: ArOrderValue,
      correction: Option[DMat] = None
  ): Either[ArError, PooledAutocovariance] =
    if segments.isEmpty then Left(ArError.NoEstimableRows)
    else
      val maxRun = segments.map(_.runIndex).max
      val runRows = Array.fill(maxRun + 1)(0)
      val runSums = Array.fill((maxRun + 1) * residuals.cols)(0.0)
      segments.foreach { segment =>
        var row = segment.start
        while row < segment.endExclusive do
          runRows(segment.runIndex) += 1
          var col = 0
          while col < residuals.cols do
            runSums(segment.runIndex * residuals.cols + col) += residuals(row, col)
            col += 1
          row += 1
      }

      val lags = maxOrder.value + 1
      val segmentMeans = new Array[Double](segments.length)
      def loadMeans(col: Int): Unit =
        var segmentIndex = 0
        while segmentIndex < segments.length do
          val runIndex = segments(segmentIndex).runIndex
          segmentMeans(segmentIndex) = runSums(runIndex * residuals.cols + col) / runRows(runIndex).toDouble
          segmentIndex += 1
      val sums = new Array[Double](lags)
      if residuals.cols == 1 then
        // One voxel contributes one term per lag, and the exact sum of one term is that term (ExactSum also
        // reports a signed zero as +0.0), so this skips the accumulator and stays bit-identical to it.
        loadMeans(0)
        var lag = 0
        while lag < lags do
          val partial = columnLagProductSum(residuals, 0, lag, segments, segmentMeans)
          sums(lag) = if partial == 0.0 then 0.0 else partial
          lag += 1
      else if residuals.cols > 1 then
        val exact = Array.fill(lags)(ExactSum.zero())
        var col = 0
        while col < residuals.cols do
          loadMeans(col)
          var lag = 0
          while lag < lags do
            exact(lag).add(columnLagProductSum(residuals, col, lag, segments, segmentMeans)) match
              case Left(ExactSumError.CapacityExceeded(current, incoming)) =>
                return Left(ArError.NoiseSumCapacityExceeded(ArLag.unsafe(lag), current, incoming))
              case Right(_) => ()
            lag += 1
          col += 1
        var lag = 0
        while lag < lags do
          sums(lag) = exact(lag).value
          lag += 1
      val pairCounts = Array.tabulate(lags)(lag => residuals.cols.toLong * lagPairCount(segments, lag))
      Right(PooledAutocovariance(sums, pairCounts, correction))

  private[ar] def validateFinite(residuals: DMat): Either[ArError, Unit] =
    var row = 0
    while row < residuals.rows do
      var col = 0
      while col < residuals.cols do
        val value = residuals(row, col)
        if !value.isFinite then return Left(ArError.NonFiniteResidual(row, col, value))
        col += 1
      row += 1
    Right(())

  private[ar] def stabilizeAutocovariances(
      gamma: Autocovariances
  ): Autocovariances =
    if gamma.lagZero <= 0.0 || gamma.length <= 1 || isStrictlyPositiveDefinite(gamma.toVector) then gamma
    else
      var lower = 0.0
      var upper = 1.0
      var iteration = 0
      while iteration < 50 do
        val scale = 0.5 * (lower + upper)
        val candidate = gamma.toVector.zipWithIndex.map { case (value, lag) =>
          if lag == 0 then value else value * scale
        }
        if isStrictlyPositiveDefinite(candidate) then lower = scale
        else upper = scale
        iteration += 1
      Autocovariances.unsafe(
        gamma.toVector.zipWithIndex.map { case (value, lag) =>
          if lag == 0 then value else value * lower
        }
      )

  private[ar] def isStrictlyPositiveDefinite(values: Vector[Double]): Boolean =
    if values.isEmpty || !values.forall(_.isFinite) || values.head <= 0.0 then false
    else
      val margin = RelativePositiveDefiniteMargin * values.head
      val toeplitz = Matrix.newBuilder(values.length, values.length)
      var row = 0
      while row < values.length do
        var col = 0
        while col < values.length do
          toeplitz(row, col) = values(math.abs(row - col)) - (if row == col then margin else 0.0)
          col += 1
        row += 1
      toeplitz.result().cholesky(CholeskyOptions(0.0)).isRight

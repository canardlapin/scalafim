package scalafim.fmri.fit.profile

import gale.linalg.{BandedCholesky, DMat, DMatBuilder}
import scalafim.fmri.ar.{WhiteningPlan, WhiteningTransform}
import scalafim.fmri.design.hrf.{HrfKernelBasis, TrialBasisDesign, TrialDesignLowering, TrialMembership}
import scalafim.fmri.hrf.family.{JetLayout, ShapePoint}

/** Bounds preparation-owned numeric storage, counting Int entries as Doubles
  * conservatively. Excludes the caller's source, basis, whitening metadata,
  * convolution/whitening scratch and later node-bank/worker allocations.
  */
final case class TrialPreparationPolicy(
    lowering: TrialDesignLowering = TrialDesignLowering.Dense,
    maxRetainedValues: Long = 16000000L):
  require(maxRetainedValues > 0L && maxRetainedValues <= Int.MaxValue.toLong,
    "trial preparation limit must be positive and fit an array index")

enum TrialBandedError:
  case Lowering(detail: String)
  case StorageLimit(required: Long, limit: Long)
  case InvalidLambda(value: Double)
  case NuisanceRows(expected: Int, actual: Int)
  case ResponseLength(expectedAtLeast: Int, actual: Int)
  case UnobservedTrial(trial: Int)
  case Whitening(detail: String)
  case Factorisation(detail: String)
  case ReleaseRank(node: Option[Int], columns: Int)
  case InvalidNode(node: Int, count: Int)
  case ReadoutRhs(expected: Int, actual: Int)
  case ReadoutOutput(expected: Int, actual: Int)
  case NonFiniteReadoutRhs(index: Int, value: Double)

  def message: String =
    this match
      case Lowering(detail) => s"trial lowering failed: $detail"
      case StorageLimit(required, limit) => s"trial preparation needs $required retained numeric values; limit is $limit"
      case InvalidLambda(value) => s"lambda must be finite and > 0, got $value"
      case NuisanceRows(expected, actual) => s"nuisance has $actual rows; expected $expected"
      case ResponseLength(expected, actual) => s"response storage has $actual entries; expected at least $expected"
      case UnobservedTrial(trial) => s"trial ${trial + 1} has no observed support after whitening"
      case Whitening(detail) => s"whitening failed: $detail"
      case Factorisation(detail) => s"banded trial factorisation failed: $detail"
      case ReleaseRank(node, columns) =>
        val where = node.fold("continuous shape")(n => s"reference node $n")
        s"the $where nuisance/condition release is rank deficient ($columns columns)"
      case InvalidNode(node, count) => s"reference node $node is outside 0 until $count"
      case ReadoutRhs(expected, actual) => s"trial readout RHS has length $actual; expected $expected"
      case ReadoutOutput(expected, actual) => s"trial readout output has length $actual; expected $expected"
      case NonFiniteReadoutRhs(index, value) => s"trial readout RHS entry $index must be finite, got $value"

/** Response-independent accounting for the packed trial geometry. */
final case class TrialBandedPreparationReceipt(
    rows: Int,
    trials: Int,
    basisRank: Int,
    conditions: Int,
    nuisanceColumns: Int,
    bandwidth: Int,
    gramBlocks: Int,
    retainedDoubles: Long,
    loweredBlocks: Int,
    maxLoweredBlockValues: Long):
  def estimatedBytes: Long = retainedDoubles * 8L

/** Per-worker counters. Shared node factors are preparation, while continuous
  * and exact-readout factors are charged where they occur.
  */
final case class TrialBandedWorkSnapshot(
    voxels: Long,
    trialBasisScores: Long,
    bankValueEvaluations: Long,
    jetEvaluations: Long,
    amplitudeCorrections: Long,
    bandedSolveCalls: Long,
    bandedRightHandSides: Long,
    continuousFactors: Long,
    exactReadoutFactors: Long,
    attempted: TrialBandedAttemptedWorkSnapshot)

/** Bounded reference-build and banded-work accounting for immutable node-bank
  * setup or one worker. Legacy counters retain their original increment semantics.
  *
  * `factorAttempts` and `factorFailures` count reference-build Cholesky calls:
  * the banded ridge, dense release and dense constrained-determinant factors.
  * Solve and RHS counters cover banded calls and their requested RHS columns only.
  * `releaseFailures` counts references returning `ReleaseRank`, including the
  * constrained determinant. `partialReferenceFailures` currently equals
  * `referenceFailures`; it does not imply a solve succeeded before refusal.
  * Exact-readout factor attempts count exact-reference requests, including a
  * coordinate-dimension refusal before numerical factorisation.
  * Conditional requests, reference inverses and residual corrections have
  * separate counters; they do not change legacy readout/amplitude counters.
  *
  * First-order search requests/failures are separate from full-jet counters.
  * Reconstructed bands count omitted derivative components contracted on demand;
  * reconstructedBandProducts counts their scalar weight-times-Gram additions.
  * These do not add inverse/factor attempts or include coefficient-weight assembly.
  * Small release solves, profile reduction and curvature checks are excluded.
  * Failed bank construction returns an error without exposing its setup receipt.
  */
final case class TrialBandedAttemptedWorkSnapshot(
    referenceAttempts: Long,
    referenceFailures: Long,
    partialReferenceFailures: Long,
    releaseFailures: Long,
    factorAttempts: Long,
    factorFailures: Long,
    solveAttempts: Long,
    solveFailures: Long,
    rightHandSideAttempts: Long,
    rightHandSideFailures: Long,
    jetAttempts: Long,
    jetFailures: Long,
    readoutAttempts: Long,
    readoutFailures: Long,
    exactReadoutFactorAttempts: Long,
    exactReadoutFactorFailures: Long,
    conditionalReadoutAttempts: Long,
    conditionalReadoutFailures: Long,
    conditionalInverseAttempts: Long,
    conditionalInverseFailures: Long,
    conditionalCorrectionAttempts: Long,
    conditionalCorrectionFailures: Long,
    firstOrderAttempts: Long = 0L,
    firstOrderFailures: Long = 0L,
    reconstructedBands: Long = 0L,
    reconstructedBandProducts: Long = 0L)

final class TrialBandedWork private[profile] ():
  private[profile] var voxels: Long = 0L
  private[profile] var trialBasisScores: Long = 0L
  private[profile] var bankValueEvaluations: Long = 0L
  private[profile] var jetEvaluations: Long = 0L
  private[profile] var amplitudeCorrections: Long = 0L
  private[profile] var bandedSolveCalls: Long = 0L
  private[profile] var bandedRightHandSides: Long = 0L
  private[profile] var continuousFactors: Long = 0L
  private[profile] var exactReadoutFactors: Long = 0L
  private[profile] var referenceAttempts: Long = 0L
  private[profile] var referenceFailures: Long = 0L
  private[profile] var partialReferenceFailures: Long = 0L
  private[profile] var releaseFailures: Long = 0L
  private[profile] var factorAttempts: Long = 0L
  private[profile] var factorFailures: Long = 0L
  private[profile] var solveAttempts: Long = 0L
  private[profile] var solveFailures: Long = 0L
  private[profile] var rightHandSideAttempts: Long = 0L
  private[profile] var rightHandSideFailures: Long = 0L
  private[profile] var jetAttempts: Long = 0L
  private[profile] var jetFailures: Long = 0L
  private[profile] var readoutAttempts: Long = 0L
  private[profile] var readoutFailures: Long = 0L
  private[profile] var exactReadoutFactorAttempts: Long = 0L
  private[profile] var exactReadoutFactorFailures: Long = 0L
  private[profile] var conditionalReadoutAttempts: Long = 0L
  private[profile] var conditionalReadoutFailures: Long = 0L
  private[profile] var conditionalInverseAttempts: Long = 0L
  private[profile] var conditionalInverseFailures: Long = 0L
  private[profile] var conditionalCorrectionAttempts: Long = 0L
  private[profile] var conditionalCorrectionFailures: Long = 0L
  private[profile] var firstOrderAttempts: Long = 0L
  private[profile] var firstOrderFailures: Long = 0L
  private[profile] var reconstructedBands: Long = 0L
  private[profile] var reconstructedBandProducts: Long = 0L
  // Additional ML accounting outside the attempted snapshot:
  // N-sized accepted-band factorisations within `factorAttempts`, and legacy scalar
  // constrained-determinant membership RHS columns within `rightHandSideAttempts`.
  private[profile] var bandFactorAttempts: Long = 0L
  private[profile] var bandFactorFailures: Long = 0L
  private[profile] var membershipRightHandSides: Long = 0L
  // Determinant-helper work charged where the helper runs, so no caller can hide it.
  private[profile] var helperSolveAttempts: Long = 0L
  private[profile] var helperRightHandSides: Long = 0L
  private[profile] var helperMembershipRightHandSides: Long = 0L
  private[profile] var helperConditionFactorAttempts: Long = 0L
  private[profile] var helperLogDetJetAttempts: Long = 0L

  private[profile] def referenceFailed(release: Boolean): Unit =
    referenceFailures += 1L
    partialReferenceFailures += 1L
    if release then releaseFailures += 1L

  private[profile] def solveAttempt(rightHandSides: Int): Unit =
    solveAttempts += 1L
    rightHandSideAttempts += rightHandSides.toLong

  private[profile] def solveFailed(rightHandSides: Int): Unit =
    solveFailures += 1L
    rightHandSideFailures += rightHandSides.toLong

  private def attemptedSnapshot: TrialBandedAttemptedWorkSnapshot =
    TrialBandedAttemptedWorkSnapshot(
      referenceAttempts,
      referenceFailures,
      partialReferenceFailures,
      releaseFailures,
      factorAttempts,
      factorFailures,
      solveAttempts,
      solveFailures,
      rightHandSideAttempts,
      rightHandSideFailures,
      jetAttempts,
      jetFailures,
      readoutAttempts,
      readoutFailures,
      exactReadoutFactorAttempts,
      exactReadoutFactorFailures,
      conditionalReadoutAttempts,
      conditionalReadoutFailures,
      conditionalInverseAttempts,
      conditionalInverseFailures,
      conditionalCorrectionAttempts,
      conditionalCorrectionFailures,
      firstOrderAttempts,
      firstOrderFailures,
      reconstructedBands,
      reconstructedBandProducts)

  def snapshot: TrialBandedWorkSnapshot =
    TrialBandedWorkSnapshot(voxels, trialBasisScores, bankValueEvaluations, jetEvaluations, amplitudeCorrections,
      bandedSolveCalls, bandedRightHandSides, continuousFactors, exactReadoutFactors, attemptedSnapshot)

/** Immutable work performed while building the shared node bank. Each worker
  * reports only its own mutable response work through [[TrialBandedWork]].
  */
final case class TrialBandedSetupReceipt(
    nodeReferenceAttempts: Long,
    work: TrialBandedAttemptedWorkSnapshot)

/** Encoded response in the sufficient statistics consumed by TrialBanded.
  * Construction is tied to one preparation so incompatible geometries cannot
  * be pointed at an objective accidentally.
  */
final class TrialBandedResponse private[profile] (
    private[profile] val owner: TrialBandedPreparation,
    private[profile] val trialBasisScores: Array[Double],
    private[profile] val nuisanceScores: Array[Double],
    private[profile] var energyValue: Double):
  def responseEnergy: Double = energyValue

enum TrialReadoutFactorMode:
  case PreparedNode(node: Int)
  case ExactShape(coordinates: Vector[Double])

final case class TrialBandedReadout(
    penalizedEnergy: Double,
    conditionMeans: Vector[Double],
    trialAmplitudes: Vector[Double],
    factorMode: TrialReadoutFactorMode)

/** Shared, response-independent trial geometry. The `m(m+1)/2` blocks store
  * lower symmetric bands directly; no dense `N x N` Gram is constructed.
  * The caller's expanded source and basis remain referenced for identity and
  * readout for this preparation's lifetime (including its banks and workers).
  * Source storage is shared, not copied or counted once per worker.
  */
final class TrialBandedPreparation private[profile] (
    val source: TrialBasisDesign,
    val basis: HrfKernelBasis,
    val membership: TrialMembership,
    val rows: Int,
    val whitening: Option[WhiteningPlan],
    val lambda: Double,
    val bandwidth: Int,
    private[profile] val sparseDesign: Array[Double],
    private[profile] val trialOffsets: Array[Int],
    private[profile] val whitenedNuisance: Array[Double],
    private[profile] val gramBlocksData: Array[Double],
    private[profile] val basisNuisanceCross: Array[Double],
    private[profile] val nuisanceGram: Array[Double],
    private[profile] val starts: Array[Int],
    private[profile] val ends: Array[Int],
    maxLoweredBlockValues: Long):

  val trials: Int = membership.trials
  val basisRank: Int = basis.rank
  val conditions: Int = membership.conditionCount
  val nuisanceColumns: Int = if rows == 0 then 0 else whitenedNuisance.length / rows
  val bandWidth: Int = bandwidth + 1
  val packedBandSize: Int = trials * bandWidth
  val gramBlockCount: Int = basisRank * (basisRank + 1) / 2

  /** Actual retained source-design Double data length: T*N*m for dense sources,
    * zero for schedule-backed blocked sources.
    * This scoped count excludes the source's basis, membership, event row maps,
    * convolved-term metadata and object/collection overhead. It is separate
    * from receipt/engine estimates; it is not total source storage.
    */
  val retainedSourceDesignDataValues: Long = source.retainedDesignDataValues
  val retainedSourceDesignDataBytes: Long = 8L * retainedSourceDesignDataValues

  /** Preparation-owned packed/sparse array estimate, excluding the retained
    * caller source, basis, membership and whitening plan.
    */
  val receipt: TrialBandedPreparationReceipt =
    TrialBandedPreparationReceipt(
      rows,
      trials,
      basisRank,
      conditions,
      nuisanceColumns,
      bandwidth,
      gramBlockCount,
      gramBlocksData.length.toLong + sparseDesign.length + whitenedNuisance.length +
        basisNuisanceCross.length + nuisanceGram.length + trialOffsets.length + starts.length + ends.length,
      source.blockCount,
      maxLoweredBlockValues
    )

  /** Copy one cross-basis Gram block as `bands(i,d)=B(i,i-d)`. */
  def gramBlock(basisA: Int, basisB: Int): DMat =
    require(basisA >= 0 && basisA < basisRank && basisB >= 0 && basisB < basisRank)
    val index = TrialBandedPreparation.pairIndex(math.min(basisA, basisB), math.max(basisA, basisB))
    val out = DMatBuilder.zeros(trials, bandWidth)
    val offset = index * packedBandSize
    var i = 0
    while i < packedBandSize do
      out.writeLinear(i, gramBlocksData(offset + i))
      i += 1
    out.result()

  /** Apply the preparation's shared whitening to a row-major response block. */
  def whitenResponses(columns: Int, rowMajor: Array[Double]): Either[TrialBandedError, Array[Double]] =
    if rowMajor.length != rows * columns then Left(TrialBandedError.ResponseLength(rows * columns, rowMajor.length))
    else
      whitening match
        case None => Right(java.util.Arrays.copyOf(rowMajor, rowMajor.length))
        case Some(plan) =>
          WhiteningTransform.matrix(plan, TrialBandedPreparation.toDMat(rows, columns, rowMajor)) match
            case Left(error) => Left(TrialBandedError.Whitening(error.toString))
            case Right(matrix) =>
              val out = new Array[Double](rowMajor.length)
              matrix.copyRowMajorTo(out)
              Right(out)

  /** Encode one already-whitened response column. The output contains exactly
    * `N*m` trial-basis scores, `F'y`, and `y'y`.
    */
  def encodeWhitened(response: Array[Double], offset: Int = 0): Either[TrialBandedError, TrialBandedResponse] =
    encodeWhitenedInto(response, offset, newResponseBuffer)

  /** Allocate one reusable response buffer for a worker. */
  def newResponseBuffer: TrialBandedResponse =
    new TrialBandedResponse(this, new Array[Double](trials * basisRank), new Array[Double](nuisanceColumns), 0.0)

  /** Allocation-free response encoding after [[newResponseBuffer]]. */
  def encodeWhitenedInto(
      response: Array[Double],
      offset: Int,
      out: TrialBandedResponse
  ): Either[TrialBandedError, TrialBandedResponse] =
    if offset < 0 || response.length - offset < rows then Left(TrialBandedError.ResponseLength(offset + rows, response.length))
    else
      require(out.owner eq this, "response buffer belongs to a different TrialBanded preparation")
      java.util.Arrays.fill(out.trialBasisScores, 0.0)
      java.util.Arrays.fill(out.nuisanceScores, 0.0)
      var energy = 0.0
      var t = 0
      while t < rows do
        val y = response(offset + t)
        energy += y * y
        var f = 0
        while f < nuisanceColumns do
          out.nuisanceScores(f) += whitenedNuisance(t * nuisanceColumns + f) * y
          f += 1
        t += 1
      var trial = 0
      while trial < trials do
        t = starts(trial)
        while t <= ends(trial) do
          val base = trialOffsets(trial) + (t - starts(trial)) * basisRank
          var p = 0
          while p < basisRank do
            out.trialBasisScores(p * trials + trial) += sparseDesign(base + p) * response(offset + t)
            p += 1
          t += 1
        trial += 1
      out.energyValue = energy
      Right(out)

  def objective(grid: NodeGrid, storage: TrialReferenceStorage = TrialReferenceStorage.FullJets): Either[TrialBandedError, TrialBandedObjective] =
    TrialBandedObjective.make(this, grid, storage)

  /** Explicit readout/curvature references, independent of the decoder grid. */
  def referenceBank(points: TrialReferencePoints,
      storage: TrialReferenceStorage = TrialReferenceStorage.FullJets): Either[TrialBandedError, TrialReferenceBank] =
    TrialBandedObjective.buildBank(this, points, storage).map: (references, receipt) =>
      new TrialReferenceBank(this, points, storage, references, receipt)

object TrialBandedPreparation:

  def prepare(
      expanded: TrialBasisDesign,
      whitening: Option[WhiteningPlan],
      nuisance: Option[DMat],
      lambda: Double,
      maxRetainedValues: Long = TrialPreparationPolicy().maxRetainedValues
  ): Either[TrialBandedError, TrialBandedPreparation] =
    require(maxRetainedValues > 0L && maxRetainedValues <= Int.MaxValue.toLong,
      "trial preparation limit must be positive and fit an array index")
    if !(lambda > 0.0 && lambda.isFinite) then return Left(TrialBandedError.InvalidLambda(lambda))
    if nuisance.exists(_.rows != expanded.rows) then
      return Left(TrialBandedError.NuisanceRows(expanded.rows, nuisance.map(_.rows).getOrElse(0)))
    val rows = expanded.rows
    val n = expanded.trials
    val m = expanded.rank
    val f = nuisance.map(_.cols).getOrElse(0)
    val fixedCount = 3.0 * n + 1.0 + rows.toDouble * f + m.toDouble * n * f + f.toDouble * f
    if fixedCount > maxRetainedValues then return Left(TrialBandedError.StorageLimit(fixedCount.toLong, maxRetainedValues))
    val fixedValues = fixedCount.toLong
    def whiten(cols: Int, values: Array[Double]): Either[TrialBandedError, Array[Double]] =
      if cols == 0 then Right(Array.emptyDoubleArray)
      else whitening match
        case None => Right(values)
        case Some(plan) =>
          WhiteningTransform.matrix(plan, toDMat(rows, cols, values)) match
            case Left(error) => Left(TrialBandedError.Whitening(error.toString))
            case Right(matrix) =>
              val out = new Array[Double](values.length)
              matrix.copyRowMajorTo(out)
              Right(out)
    val rawNuisance = new Array[Double](rows * f)
    nuisance.foreach(_.copyRowMajorTo(rawNuisance))
    val nuisanceData = whiten(f, rawNuisance) match
      case Left(error) => return Left(error)
      case Right(values) => values
    val starts = Array.fill(n)(rows)
    val ends = Array.fill(n)(-1)
    val offsets = new Array[Int](n + 1)
    val chunks = Array.fill(n)(Array.emptyDoubleArray)
    var packedValues = 0L
    var largestBlock = 0L
    var block = 0
    while block < expanded.blockCount do
      val raw = expanded.block(block) match
        case Left(error) => return Left(TrialBandedError.Lowering(error.message))
        case Right(matrix) => matrix
      largestBlock = math.max(largestBlock, raw.data.length.toLong)
      val x = whiten(raw.cols, raw.data) match
        case Left(error) => return Left(error)
        case Right(values) => values
      val count = expanded.trialsInBlock(block)
      var local = 0
      while local < count do
        val trial = block * expanded.trialsPerBlock + local
        var t = 0
        while t < rows do
          var p = 0
          while p < m do
            if x(t * raw.cols + p * count + local) != 0.0 then
              starts(trial) = math.min(starts(trial), t)
              ends(trial) = t
            p += 1
          t += 1
        if ends(trial) < 0 then return Left(TrialBandedError.UnobservedTrial(trial))
        val values = (ends(trial) - starts(trial) + 1).toLong * m
        packedValues += values
        if fixedValues + packedValues > maxRetainedValues then
          return Left(TrialBandedError.StorageLimit(fixedValues + packedValues, maxRetainedValues))
        val chunk = new Array[Double](values.toInt)
        t = starts(trial)
        while t <= ends(trial) do
          var p = 0
          while p < m do
            chunk((t - starts(trial)) * m + p) = x(t * raw.cols + p * count + local)
            p += 1
          t += 1
        chunks(trial) = chunk
        offsets(trial + 1) = packedValues.toInt
        local += 1
      block += 1
    build(expanded, whitening, lambda, chunks, offsets, starts, ends, nuisanceData,
      fixedValues, maxRetainedValues, largestBlock)

  private def build(
      expanded: TrialBasisDesign,
      whitening: Option[WhiteningPlan],
      lambda: Double,
      chunks: Array[Array[Double]],
      offsets: Array[Int],
      starts: Array[Int],
      ends: Array[Int],
      nuisance: Array[Double],
      fixedValues: Long,
      maxRetainedValues: Long,
      largestBlock: Long): Either[TrialBandedError, TrialBandedPreparation] =
    val rows = expanded.rows
    val n = expanded.trials
    val m = expanded.rank
    val f = if rows == 0 then 0 else nuisance.length / rows
    var t = 0
    var bandwidth = 0
    var i = 0
    while i < n do
      var j = 0
      while j < i do
        if starts(i) <= ends(j) && starts(j) <= ends(i) then bandwidth = math.max(bandwidth, i - j)
        j += 1
      i += 1
    val width = bandwidth + 1
    val blockCountLong = m.toLong * (m + 1L) / 2L
    // Check in Double before narrowing: hostile dimensions must not wrap Long
    // products. Every admitted count is <= Int.MaxValue and exactly represented.
    val gramCount = blockCountLong.toDouble * n * width
    val retainedCount = fixedValues.toDouble + offsets(n) + gramCount
    if retainedCount > maxRetainedValues then
      return Left(TrialBandedError.StorageLimit(retainedCount.toLong, maxRetainedValues))
    val gramValues = gramCount.toInt
    val bandSize = n * width
    val sparse = new Array[Double](offsets(n))
    var trial = 0
    while trial < n do
      System.arraycopy(chunks(trial), 0, sparse, offsets(trial), chunks(trial).length)
      chunks(trial) = Array.emptyDoubleArray
      trial += 1
    val blocks = new Array[Double](gramValues)
    var q = 0
    while q < m do
      var p = 0
      while p <= q do
        val blockOffset = pairIndex(p, q) * bandSize
        i = 0
        while i < n do
          var delta = 0
          while delta <= math.min(i, bandwidth) do
            val other = i - delta
            val from = math.max(starts(i), starts(other))
            val until = math.min(ends(i), ends(other))
            var sum = 0.0
            t = from
            while t <= until do
              val row = offsets(i) + (t - starts(i)) * m
              val otherRow = offsets(other) + (t - starts(other)) * m
              if p == q then sum += sparse(row + p) * sparse(otherRow + p)
              else
                sum += sparse(row + p) * sparse(otherRow + q) +
                  sparse(row + q) * sparse(otherRow + p)
              t += 1
            blocks(blockOffset + i * width + delta) = sum
            delta += 1
          i += 1
        p += 1
      q += 1
    val xf = new Array[Double](m * n * f)
    var p = 0
    while p < m do
      i = 0
      while i < n do
        var nuisanceCol = 0
        while nuisanceCol < f do
          var sum = 0.0
          t = starts(i)
          while t <= ends(i) do
            sum += sparse(offsets(i) + (t - starts(i)) * m + p) * nuisance(t * f + nuisanceCol)
            t += 1
          xf((p * n + i) * f + nuisanceCol) = sum
          nuisanceCol += 1
        i += 1
      p += 1
    val ff = new Array[Double](f * f)
    i = 0
    while i < f do
      var j = 0
      while j <= i do
        var sum = 0.0
        t = 0
        while t < rows do
          sum += nuisance(t * f + i) * nuisance(t * f + j)
          t += 1
        ff(i * f + j) = sum
        ff(j * f + i) = sum
        j += 1
      i += 1
    Right(new TrialBandedPreparation(expanded, expanded.basis, expanded.membership, rows, whitening, lambda,
      bandwidth, sparse, offsets, nuisance, blocks, xf, ff, starts, ends, largestBlock))

  private[profile] def pairIndex(p: Int, q: Int): Int = q * (q + 1) / 2 + p

  private[profile] def toDMat(rows: Int, cols: Int, values: Array[Double]): DMat =
    val out = DMatBuilder.zeros(rows, cols)
    var i = 0
    while i < values.length do
      out.writeLinear(i, values(i))
      i += 1
    out.result()

/** `accepted` is the stamped bundle: its factor is the Gale factor of exactly
  * its own frozen copy of the value band, so energy and determinant share it.
  */
/** Native ML retains an owned response and evaluates residuals before squaring.
  * Rounded sufficient statistics cannot recover small residual energies by subtraction.
  * The encoded-only public objective keeps its existing storage and ownership contract.
  */
private[profile] final class TrialMlResidualEnergy(val preparation: TrialBandedPreparation):
  val response = new Array[Double](preparation.rows)
  val residual = new Array[Double](preparation.rows)
  val amplitudes = new Array[Double](preparation.trials)
  val conditionSums = new Array[Double](preparation.conditions)
  val scratchValues: Int = response.length + residual.length + amplitudes.length + conditionSums.length
  var evaluations = 0L
  var responseCopies = 0L
  var residualRows = 0L
  var sourceValues = 0L
  var coefficientProducts = 0L
  var nuisanceValues = 0L
  private var pointed = false

  def invalidate(): Unit = pointed = false

  def pointAt(values: Array[Double]): Unit =
    require(values.length == response.length, "native ML response length differs from preparation")
    System.arraycopy(values, 0, response, 0, response.length)
    responseCopies += response.length
    pointed = true

  def begin(): Unit =
    require(pointed, "native ML residual energy needs a successful response epoch")
    evaluations += 1L
    System.arraycopy(response, 0, residual, 0, response.length)
    java.util.Arrays.fill(conditionSums, 0.0)

private[profile] final case class TrialBandedReference(
    coefficients: Array[Double],
    accepted: TrialAcceptedTrialBand,
    aJets: Array[Double],
    cJets: Array[Double],
    wcJets: Array[Double],
    hJets: Array[Double],
    releaseLower: Array[Double],
    logDetK: Double):
  def factor: BandedCholesky = accepted.factor

/** Trial-sized profile objective. Its node factors and releases are immutable
  * and shared; each worker owns only response statistics and primitive scratch.
  */
sealed class TrialReferenceBank private[profile] (
    val preparation: TrialBandedPreparation,
    val points: TrialReferencePoints,
    val storage: TrialReferenceStorage,
    private val references: Vector[TrialBandedReference],
    val setupReceipt: TrialBandedSetupReceipt):

  private val n = preparation.trials
  private val m = preparation.basisRank
  private val c = preparation.conditions
  private val f = preparation.nuisanceColumns
  private val k = f + c
  private val d = preparation.basis.family.dimension
  private val comps = JetLayout.components(d)
  private val bandSize = preparation.packedBandSize
  private val reconstructionCapacity =
    if storage == TrialReferenceStorage.ReconstructSecondBands then bandSize else 0
  // A readout-only worker never uses derivative bands. Capacity is still charged
  // in its worker estimate, but the buffer is retained only after curvature work.
  private var reconstructedBandData: Array[Double] = Array.emptyDoubleArray
  private def reconstructedBand: Array[Double] =
    if reconstructedBandData.length != reconstructionCapacity then
      reconstructedBandData = new Array[Double](reconstructionCapacity)
    reconstructedBandData

  def retainedReconstructionScratchBytes: Long = 8L * reconstructedBandData.length
  private val responseB = new Array[Double](comps * n)
  private val zTy = new Array[Double](comps * k)
  private val wbJets = new Array[Double](comps * n)
  private val s = new Array[Double](comps)
  private val b = new Array[Double](comps * k)
  private val g = new Array[Double](comps * k * k)
  private val scoreBuilder = DMatBuilder.zeros(n, 1)
  private val readoutBuilder = DMatBuilder.zeros(n, 1)
  private val jetSolveBuilder = DMatBuilder.zeros(n, 1)
  private val scoreRelease = new Array[Double](k)
  private val scoreSolved = new Array[Double](k)
  private val conditionalRelease = new Array[Double](k)
  private val releaseReduction = new ProfileReduction(d, k)
  private val releaseOut = new ProfileJetBuffer(d, k)
  private val kernelScratch = new Array[Double](comps * preparation.basis.fineCount)
  private val coefficients = new Array[Double](comps * m)
  private var response: TrialBandedResponse | Null = null
  val work: TrialBandedWork = new TrialBandedWork

  /** Scoped array estimates for reference factors and the listed objective
    * arrays, not total retained engine memory or peak memory. They exclude the
    * retained caller source (its dense data is counted separately on preparation),
    * basis, membership, whitening plan, grid, encoded response, reduction
    * workspace, conditional solver/wrapper arrays, transient build/whitening
    * storage, caller/result buffers and VM/object/collection overhead.
    */
  private def referenceDoubles(components: Int): Long =
    components.toLong * m + components.toLong * bandSize + 2L * components * n * k +
      components.toLong * k * k + 2L * bandSize + k.toLong * k

  val estimatedFullReferenceBytes: Long = 8L * referenceDoubles(comps)
  val estimatedReferenceBytes: Long = estimatedFullReferenceBytes -
    (if storage == TrialReferenceStorage.ReconstructSecondBands then 8L * (comps - 1 - d) * bandSize else 0L)
  /** Largest derivative reconstruction buffer retained by each worker. */
  val reconstructionScratchBytes: Long = 8L * reconstructionCapacity
  /** Hypothetical lower-order references, not the compact full-jet storage. */
  val estimatedFirstOrderReferenceBytes: Long = 8L * referenceDoubles(1 + d)
  val estimatedValueReferenceBytes: Long = 8L * referenceDoubles(1)
  val estimatedValueBuildBytes: Long = estimatedValueReferenceBytes + 8L * n * (k + c)

  /** Preparation-kernel and node-reference estimate; excludes retained source
    * and basis. Add preparation.retainedSourceDesignDataBytes once to count
    * its dense design data, without claiming all shared storage is covered.
    */
  val estimatedSharedBytes: Long =
    preparation.receipt.estimatedBytes + references.length * estimatedReferenceBytes

  /** Listed objective arrays only; exclusions are stated above. */
  val estimatedWorkerBytes: Long =
    val worker = responseB.length.toLong + zTy.length + wbJets.length +
      s.length + b.length + g.length + n.toLong + n.toLong + n.toLong +
      scoreRelease.length + scoreSolved.length + conditionalRelease.length +
      comps.toLong * preparation.basis.fineCount + coefficients.length + reconstructionCapacity
    8L * worker

  /** Scoped shared estimate plus one listed objective-array estimate. */
  val estimatedEngineBytes: Long = estimatedSharedBytes + estimatedWorkerBytes

  /** A new mutable worker over the same immutable preparation and reference
    * factors. No Gram block, factor or response-independent jet is rebuilt.
    */
  def newWorker(): TrialReferenceBank = new TrialReferenceBank(preparation, points, storage, references, setupReceipt)

  def amplitudeCount: Int = c

  def pointAt(encoded: TrialBandedResponse): Unit =
    require(encoded.owner eq preparation, "response statistics belong to a different TrialBanded preparation")
    response = encoded
    work.voxels += 1
    work.trialBasisScores += n.toLong * m

  private def currentResponse: TrialBandedResponse =
    if response == null then throw new IllegalStateException("pointAt must be called before scoring")
    response.nn

  def scoreNode(node: Int): Double =
    if node < 0 || node >= references.length then Double.PositiveInfinity
    else
      work.bankValueEvaluations += 1
      scoreReference(references(node), currentResponse, null)

  def jetAtNode(node: Int, out: ProfileJetBuffer): Boolean =
    work.jetAttempts += 1L
    if node < 0 || node >= references.length then
      work.jetFailures += 1L
      false
    else
      work.jetEvaluations += 1
      val completed = fullJet(references(node), currentResponse, out)
      if !completed then work.jetFailures += 1L
      completed

  def jetAt(coordinates: Array[Double], out: ProfileJetBuffer): Boolean =
    work.jetAttempts += 1L
    buildReference(coordinates, comps, None) match
      case Left(_) =>
        work.jetFailures += 1L
        false
      case Right(reference) =>
        work.continuousFactors += 1
        work.jetEvaluations += 1
        val completed = fullJet(reference, currentResponse, out)
        if !completed then work.jetFailures += 1L
        completed

  /** Search-only envelope gradient. At the conditional optimum, coefficient
    * derivatives cancel: dE = a' d(X'X) a + 2 a' d(X'F) gamma - 2 a' d(X'y).
    * One value reference and one response solve suffice. The basis-pair
    * quadratics are contracted once and shared by all shape coordinates.
    * Full jets remain mandatory for terminal curvature admission.
    */
  def gradientAt(coordinates: Array[Double], out: ProfileGradientBuffer): Boolean =
    work.firstOrderAttempts += 1L
    val completed = buildReference(coordinates, 1, None) match
      case Left(_) => false
      case Right(reference) =>
        work.continuousFactors += 1L
        envelopeGradient(reference, coordinates, currentResponse, out)
    if !completed then work.firstOrderFailures += 1L
    completed

  private def envelopeGradient(ref: TrialBandedReference, coordinates: Array[Double],
      encoded: TrialBandedResponse, out: ProfileGradientBuffer): Boolean =
    out.energy = scoreReference(ref, encoded, null)
    if !out.energy.isFinite then return false
    preparation.basis.coefficientJetInto(ShapePoint.unsafe(coordinates.toVector),
      kernelScratch, coefficients, 1 + d)
    java.util.Arrays.fill(out.gradient, 0.0)
    var trial = 0
    while trial < n do
      var amplitude = scoreBuilder(trial, 0) + scoreSolved(f + preparation.membership.conditionOfTrial(trial))
      var col = 0
      while col < k do
        amplitude -= ref.wcJets(trial * k + col) * scoreSolved(col)
        col += 1
      // Reuse the full-jet solve buffer; no coefficient vector is retained.
      jetSolveBuilder.writeLinear(trial, amplitude)
      trial += 1
    var q = 0
    while q < m do
      var p = 0
      while p <= q do
        val block = TrialBandedPreparation.pairIndex(p, q) * bandSize
        var quadratic = 0.0
        trial = 0
        while trial < n do
          val amplitude = jetSolveBuilder(trial, 0)
          var delta = 0
          while delta <= math.min(trial, preparation.bandwidth) do
            val product = amplitude * preparation.gramBlocksData(block + trial * preparation.bandWidth + delta) *
              jetSolveBuilder(trial - delta, 0)
            quadratic += (if delta == 0 then product else 2.0 * product)
            delta += 1
          trial += 1
        var axis = 0
        while axis < d do
          val derivative = JetLayout.first(axis) * m
          out.gradient(axis) += quadratic *
            (coefficients(derivative + p) * coefficients(q) + coefficients(p) * coefficients(derivative + q))
          axis += 1
        p += 1
      q += 1
    var p = 0
    while p < m do
      var cross = 0.0
      trial = 0
      while trial < n do
        var residualScore = -encoded.trialBasisScores(p * n + trial)
        var col = 0
        while col < f do
          residualScore += preparation.basisNuisanceCross((p * n + trial) * f + col) * scoreSolved(col)
          col += 1
        cross += jetSolveBuilder(trial, 0) * residualScore
        trial += 1
      var axis = 0
      while axis < d do
        out.gradient(axis) += 2.0 * coefficients(JetLayout.first(axis) * m + p) * cross
        axis += 1
      p += 1
    var condition = 0
    while condition < c do
      out.amplitudes(condition) = scoreSolved(f + condition)
      condition += 1
    out.gradient.forall(_.isFinite) && out.amplitudes.forall(_.isFinite)

  def energyAt(coordinates: Array[Double], out: ProfileJetBuffer): Double =
    buildReference(coordinates, 1, None) match
      case Left(_) =>
        out.energy = Double.PositiveInfinity
        out.curvature = CurvatureStatus.GramNotPositiveDefinite
        Double.PositiveInfinity
      case Right(reference) =>
        work.continuousFactors += 1
        scoreReference(reference, currentResponse, out)

  def logDetAtNode(node: Int): Either[TrialBandedError, Double] =
    if node < 0 || node >= references.length then Left(TrialBandedError.InvalidNode(node, references.length))
    else Right(references(node).logDetK)

  def logDetAt(coordinates: Array[Double]): Either[TrialBandedError, Double] =
    buildReference(coordinates, 1, None).map { reference =>
      work.continuousFactors += 1
      reference.logDetK
    }

  // ----- Native ML hooks. Each returns raw energy and the determinant from ONE
  // reference, whose stamped bundle factor both use; they never pair public
  // jetAt with logDetAt. Raw energy/amplitudes are written to `out`.

  /** Node value from the shared node reference; its determinant is cached by the caller. */
  private[profile] def mlValueAtNode(node: Int, out: ProfileJetBuffer, energy: TrialMlResidualEnergy): Either[TrialBandedError, Double] =
    if node < 0 || node >= references.length then Left(TrialBandedError.InvalidNode(node, references.length))
    else
      work.bankValueEvaluations += 1
      Right(mlResidualEnergy(references(node), energy, out))

  /** Node raw full jet from the shared node reference. */
  private[profile] def mlJetAtNode(node: Int, out: ProfileJetBuffer, energy: TrialMlResidualEnergy): Either[TrialBandedError, Boolean] =
    work.jetAttempts += 1L
    if node < 0 || node >= references.length then
      work.jetFailures += 1L
      Left(TrialBandedError.InvalidNode(node, references.length))
    else
      work.jetEvaluations += 1
      val completed = fullJet(references(node), currentResponse, out)
      if !completed then work.jetFailures += 1L
      else mlResidualEnergy(references(node), energy, out)
      Right(completed)

  /** Response-independent determinant jet of a node reference, for setup caching. */
  private[profile] def mlNodeDeterminant(node: Int): Either[TrialBandedError, TrialDeterminantAttempt] =
    if node < 0 || node >= references.length then Left(TrialBandedError.InvalidNode(node, references.length))
    else Right(determinantJet(references(node)))

  /** One value-only reference: raw energy into `out` and the scalar constrained
    * determinant of the same factor. No determinant derivatives are formed.
    */
  private[profile] def mlValueAt(coordinates: Array[Double], out: ProfileJetBuffer, energy: TrialMlResidualEnergy): Either[TrialBandedError, (Double, Double)] =
    buildReference(coordinates, 1, None).map { reference =>
      work.continuousFactors += 1
      (mlResidualEnergy(reference, energy, out), reference.logDetK)
    }

  /** One full reference: raw full jet into `out` and the determinant jet of the
    * same bundle. The reference and its derivative bands are released on return.
    */
  private[profile] def mlJetAt(coordinates: Array[Double], out: ProfileJetBuffer, energy: TrialMlResidualEnergy)
      : Either[TrialBandedError, (Boolean, TrialDeterminantAttempt)] =
    work.jetAttempts += 1L
    buildReference(coordinates, comps, None) match
      case Left(error) =>
        work.jetFailures += 1L
        Left(error)
      case Right(reference) =>
        work.continuousFactors += 1
        work.jetEvaluations += 1
        val completed = fullJet(reference, currentResponse, out)
        if !completed then work.jetFailures += 1L
        else mlResidualEnergy(reference, energy, out)
        Right((completed, determinantJet(reference)))

  /** Helper input made only from this reference's stamped bundle plus its own
    * derivative bands (row-packed ScalaFIM second order); no separate factor.
    */
  private def determinantJet(reference: TrialBandedReference): TrialDeterminantAttempt =
    val width = preparation.bandWidth
    def band(component: Int): DMat =
      val out = DMatBuilder.zeros(n, width)
      val (bands, base) = derivativeBand(reference, component)
      var i = 0
      while i < bandSize do
        out.writeLinear(i, bands(base + i))
        i += 1
      out.result()
    val first = Vector.tabulate(d)(axis => band(JetLayout.first(axis)))
    val second = Vector.tabulate(comps - 1 - d)(index => band(1 + d + index))
    val attempt = TrialDeterminantInput(reference.accepted, first, second) match
      case Left(error) =>
        TrialDeterminantAttempt(Left(error), TrialDeterminantWork(0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L))
      case Right(input) => TrialConstrainedLogDetJet.evaluate(input, TrialDeterminantNumerics.Default)
    val h = attempt.work
    work.helperSolveAttempts += h.bandedSolveAttempts
    work.helperRightHandSides += h.rightHandSideAttempts
    if h.bandedSolveAttempts > 0L then work.helperMembershipRightHandSides += c
    work.helperConditionFactorAttempts += h.conditionFactorAttempts
    work.helperLogDetJetAttempts += h.logDetJetAttempts
    attempt

  /** Solve the trial ridge system for later conditional readout. Exact-shape
    * factorisation is deliberately named and counted; PHRF-11 owns the final
    * amplitude/query contract.
    */
  def solveReadoutSystem(mode: TrialReadoutFactorMode, rhs: Array[Double]): Either[TrialBandedError, Vector[Double]] =
    work.readoutAttempts += 1L
    if rhs.length != n then
      work.readoutFailures += 1L
      Left(TrialBandedError.ReadoutRhs(n, rhs.length))
    else
      val reference =
        mode match
          case TrialReadoutFactorMode.PreparedNode(node) =>
            if node < 0 || node >= references.length then Left(TrialBandedError.InvalidNode(node, references.length))
            else Right(references(node))
          case TrialReadoutFactorMode.ExactShape(coords) =>
            work.exactReadoutFactorAttempts += 1L
            if coords.length != d then
              work.exactReadoutFactorFailures += 1L
              Left(TrialBandedError.Factorisation(s"${coords.length} coordinates for dimension $d"))
            else
              buildReference(coords.toArray, 1, None) match
                case Left(error) =>
                  work.exactReadoutFactorFailures += 1L
                  Left(error)
                case Right(reference) =>
                  work.exactReadoutFactors += 1
                  Right(reference)
      reference match
        case Left(error) =>
          work.readoutFailures += 1L
          Left(error)
        case Right(ref) =>
          val builder = DMatBuilder.zeros(n, 1)
          var i = 0
          while i < n do
            builder.writeLinear(i, rhs(i))
            i += 1
          work.solveAttempt(1)
          ref.factor.solveInPlace(builder) match
            case Left(error) =>
              work.solveFailed(1)
              work.readoutFailures += 1L
              Left(TrialBandedError.Factorisation(error.getMessage))
            case Right(_) =>
              work.bandedSolveCalls += 1
              work.bandedRightHandSides += 1
              Right(Vector.tabulate(n)(i => builder(i, 0)))

  /** Apply the original condition-centred trial normal inverse at a prepared
    * node to an arbitrary `(trial, nuisance)` RHS. The augmented coordinates
    * are `(v, gamma, beta)` with `a = v + M beta`; the lifted RHS is
    * `(r_a, r_gamma, M' r_a)`. The reference's ridge factor and release are
    * reused without constructing another factor or a dense trial inverse.
    */
  private[profile] def solveConditionalReference(
      node: Int,
      rhs: Array[Double],
      out: Array[Double]
  ): Either[TrialBandedError, Unit] =
    work.conditionalInverseAttempts += 1L
    if node < 0 || node >= references.length then
      work.conditionalInverseFailures += 1L
      Left(TrialBandedError.InvalidNode(node, references.length))
    else
      validateConditionalInput(rhs, out) match
        case Left(error) =>
          work.conditionalInverseFailures += 1L
          Left(error)
        case Right(_) => solveConditionalAgainst(references(node), rhs, out)

  /** An exact actual-shape factor is an explicit, separately charged request.
    * It never replaces the prepared-node inverses used by corrected mode.
    */
  private[profile] def solveConditionalExact(
      coordinates: Vector[Double],
      rhs: Array[Double],
      out: Array[Double]
  ): Either[TrialBandedError, Unit] =
    work.conditionalInverseAttempts += 1L
    validateConditionalInput(rhs, out) match
      case Left(error) =>
        work.conditionalInverseFailures += 1L
        Left(error)
      case Right(_) =>
        work.exactReadoutFactorAttempts += 1L
        preparation.basis.family.chart.point(coordinates) match
          case Left(error) =>
            work.exactReadoutFactorFailures += 1L
            work.conditionalInverseFailures += 1L
            Left(TrialBandedError.Factorisation(error.message))
          case Right(_) =>
            buildReference(coordinates.toArray, 1, None) match
              case Left(error) =>
                work.exactReadoutFactorFailures += 1L
                work.conditionalInverseFailures += 1L
                Left(error)
              case Right(reference) =>
                work.exactReadoutFactors += 1L
                solveConditionalAgainst(reference, rhs, out)

  private def validateConditionalInput(rhs: Array[Double], out: Array[Double]): Either[TrialBandedError, Unit] =
    if rhs.length != n + f then Left(TrialBandedError.ReadoutRhs(n + f, rhs.length))
    else if out.length != n + f then Left(TrialBandedError.ReadoutOutput(n + f, out.length))
    else
      var bad = 0
      while bad < rhs.length do
        if !rhs(bad).isFinite then return Left(TrialBandedError.NonFiniteReadoutRhs(bad, rhs(bad)))
        bad += 1
      Right(())

  private def solveConditionalAgainst(
      ref: TrialBandedReference,
      rhs: Array[Double],
      out: Array[Double]
  ): Either[TrialBandedError, Unit] =
    var i = 0
    while i < n do
      readoutBuilder.writeLinear(i, rhs(i))
      i += 1
    work.solveAttempt(1)
    ref.factor.solveInPlace(readoutBuilder) match
      case Left(error) =>
        work.solveFailed(1)
        work.conditionalInverseFailures += 1L
        Left(TrialBandedError.Factorisation(error.getMessage))
      case Right(_) =>
        work.bandedSolveCalls += 1L
        work.bandedRightHandSides += 1L
        var col = 0
        while col < f do
          var value = rhs(n + col)
          i = 0
          while i < n do
            value -= ref.cJets(i * k + col) * readoutBuilder(i, 0)
            i += 1
          conditionalRelease(col) = value
          col += 1
        col = 0
        while col < c do
          var value = 0.0
          i = 0
          while i < n do
            if preparation.membership.conditionOfTrial(i) == col then value += rhs(i)
            value -= ref.cJets(i * k + f + col) * readoutBuilder(i, 0)
            i += 1
          conditionalRelease(f + col) = value
          col += 1
        SmallCholesky.solveInPlace(k, ref.releaseLower, conditionalRelease)
        i = 0
        while i < n do
          var value = readoutBuilder(i, 0) + conditionalRelease(f + preparation.membership.conditionOfTrial(i))
          col = 0
          while col < k do
            value -= ref.wcJets(i * k + col) * conditionalRelease(col)
            col += 1
          out(i) = value
          i += 1
        col = 0
        while col < f do
          out(n + col) = conditionalRelease(col)
          col += 1
        Right(())

  /** Unnormalised conditional trial readout for this backend. The public
    * normalization/query surface remains PHRF-11; this method closes the
    * backend equation and makes exact-per-voxel factor work measurable.
    */
  def readout(mode: TrialReadoutFactorMode): Either[TrialBandedError, TrialBandedReadout] =
    val amplitudes = new Array[Double](n)
    readoutInto(mode, amplitudes).map { energy =>
      TrialBandedReadout(energy, Vector.tabulate(c)(i => scoreSolved(f + i)), amplitudes.toVector, mode)
    }

  /** Conditional readout into a caller-owned trial array. Prepared-node mode
    * reuses all numerical storage; exact-shape mode deliberately constructs
    * and counts one value-only reference factor.
    */
  def readoutInto(mode: TrialReadoutFactorMode, trialAmplitudes: Array[Double]): Either[TrialBandedError, Double] =
    readoutCoefficientsInto(mode, trialAmplitudes, includeNuisance = false)

  /** Same exact readout body, with the already solved nuisance block copied
    * only after the band solve succeeds. The N+F scratch stays caller-owned.
    */
  private[profile] def exactSolvedReadoutInto(coordinates: Vector[Double],
      coefficients: Array[Double], energy: Option[TrialMlResidualEnergy] = None): Either[TrialBandedError, TrialBandedReadout] =
    val mode = TrialReadoutFactorMode.ExactShape(coordinates)
    readoutCoefficientsInto(mode, coefficients, includeNuisance = true, nativeEnergy = energy).map: energy =>
      TrialBandedReadout(energy, Vector.tabulate(c)(i => scoreSolved(f + i)),
        Vector.tabulate(n)(coefficients(_)), mode)

  private def readoutCoefficientsInto(mode: TrialReadoutFactorMode,
      trialAmplitudes: Array[Double], includeNuisance: Boolean,
      nativeEnergy: Option[TrialMlResidualEnergy] = None): Either[TrialBandedError, Double] =
    work.readoutAttempts += 1L
    val expected = if includeNuisance then n + f else n
    if trialAmplitudes.length != expected then
      work.readoutFailures += 1L
      Left(TrialBandedError.ReadoutRhs(expected, trialAmplitudes.length))
    else
      work.amplitudeCorrections += 1
      val reference =
        mode match
          case TrialReadoutFactorMode.PreparedNode(node) =>
            if node < 0 || node >= references.length then Left(TrialBandedError.InvalidNode(node, references.length))
            else Right(references(node))
          case TrialReadoutFactorMode.ExactShape(coords) =>
            work.exactReadoutFactorAttempts += 1L
            if coords.length != d then
              work.exactReadoutFactorFailures += 1L
              Left(TrialBandedError.Factorisation(s"${coords.length} coordinates for dimension $d"))
            else
              buildReference(coords.toArray, 1, None) match
                case Left(error) =>
                  work.exactReadoutFactorFailures += 1L
                  Left(error)
                case Right(reference) =>
                  work.exactReadoutFactors += 1
                  Right(reference)
      reference match
        case Left(error) =>
          work.readoutFailures += 1L
          Left(error)
        case Right(ref) =>
          val energy = scoreReference(ref, currentResponse, null)
          if !energy.isFinite then
            work.readoutFailures += 1L
            Left(TrialBandedError.Factorisation("nonfinite profiled energy during readout"))
          else
            var i = 0
            while i < n do
              var value = responseB(i)
              var j = 0
              while j < k do
                value -= ref.cJets(i * k + j) * scoreSolved(j)
                j += 1
              readoutBuilder.writeLinear(i, value)
              i += 1
            work.solveAttempt(1)
            ref.factor.solveInPlace(readoutBuilder) match
              case Left(error) =>
                work.solveFailed(1)
                work.readoutFailures += 1L
                Left(TrialBandedError.Factorisation(error.getMessage))
              case Right(_) =>
                work.bandedSolveCalls += 1
                work.bandedRightHandSides += 1
                i = 0
                while i < n do
                  trialAmplitudes(i) = scoreSolved(f + preparation.membership.conditionOfTrial(i)) + readoutBuilder(i, 0)
                  i += 1
                if includeNuisance then System.arraycopy(scoreSolved, 0, trialAmplitudes, n, f)
                val returnedEnergy = nativeEnergy.fold(energy)(workspace =>
                  residualEnergy(ref, workspace, trialAmplitudes, trialAmplitudes, n))
                Right(returnedEnergy)

  private def buildReference(coordinates: Array[Double], activeComponents: Int, node: Option[Int]): Either[TrialBandedError, TrialBandedReference] =
    preparation.basis.coefficientJetInto(ShapePoint.unsafe(coordinates.toVector), kernelScratch, coefficients, activeComponents)
    TrialBandedObjective.reference(preparation, coordinates.toVector, java.util.Arrays.copyOf(coefficients, activeComponents * m),
      activeComponents, node, work).map { reference =>
      work.bandedSolveCalls += activeComponents + 1L
      work.bandedRightHandSides += activeComponents.toLong * k + c
      reference
    }

  private def contractResponse(ref: TrialBandedReference, encoded: TrialBandedResponse, activeComponents: Int): Unit =
    java.util.Arrays.fill(responseB, 0.0)
    java.util.Arrays.fill(zTy, 0.0)
    var comp = 0
    while comp < activeComponents do
      var trial = 0
      while trial < n do
        var sum = 0.0
        var p = 0
        while p < m do
          sum += ref.coefficients(comp * m + p) * encoded.trialBasisScores(p * n + trial)
          p += 1
        responseB(comp * n + trial) = sum
        trial += 1
      var nuisanceCol = 0
      while nuisanceCol < f do
        if comp == JetLayout.Value then zTy(nuisanceCol) = encoded.nuisanceScores(nuisanceCol)
        nuisanceCol += 1
      trial = 0
      while trial < n do
        val condition = preparation.membership.conditionOfTrial(trial)
        zTy(comp * k + f + condition) += responseB(comp * n + trial)
        trial += 1
      comp += 1

  private def scoreReference(ref: TrialBandedReference, encoded: TrialBandedResponse, out: ProfileJetBuffer | Null): Double =
    contractResponse(ref, encoded, 1)
    var i = 0
    while i < n do
      scoreBuilder.writeLinear(i, responseB(i))
      i += 1
    work.solveAttempt(1)
    ref.factor.solveInPlace(scoreBuilder) match
      case Left(_) =>
        work.solveFailed(1)
        Double.PositiveInfinity
      case Right(_) =>
        work.bandedSolveCalls += 1
        work.bandedRightHandSides += 1
        var ridgeFit = 0.0
        i = 0
        while i < n do
          ridgeFit += responseB(i) * scoreBuilder(i, 0)
          i += 1
        var j = 0
        while j < k do
          var correction = 0.0
          i = 0
          while i < n do
            correction += ref.cJets(i * k + j) * scoreBuilder(i, 0)
            i += 1
          scoreRelease(j) = zTy(j) - correction
          j += 1
        System.arraycopy(scoreRelease, 0, scoreSolved, 0, k)
        SmallCholesky.solveInPlace(k, ref.releaseLower, scoreSolved)
        var releasedFit = 0.0
        j = 0
        while j < k do
          releasedFit += scoreRelease(j) * scoreSolved(j)
          j += 1
        val energy = encoded.responseEnergy - ridgeFit - releasedFit
        if out != null then
          out.nn.energy = energy
          java.util.Arrays.fill(out.nn.gradient, 0.0)
          java.util.Arrays.fill(out.nn.hessian, 0.0)
          j = 0
          while j < c do
            out.nn.amplitudes(j) = scoreSolved(f + j)
            j += 1
          out.nn.curvature = CurvatureStatus.Indefinite
        energy

  /** Recover coefficients with this evaluation's factor and release, then use
    * ||y-Xa-Fgamma||² + lambda ||P a||². The extra response solve is charged by
    * scoreReference; residual traversal and response storage are reported by ML.
    * Both value and full calls use this same value path without replacing derivatives.
    */
  private def mlResidualEnergy(ref: TrialBandedReference, energy: TrialMlResidualEnergy,
      out: ProfileJetBuffer): Double =
    require(energy.preparation eq preparation, "ML energy workspace belongs to a different preparation")
    val scored = scoreReference(ref, currentResponse, null)
    if !scored.isFinite then
      out.energy = Double.PositiveInfinity
      return out.energy
    var i = 0
    while i < n do
      var amplitude = scoreBuilder(i, 0) + scoreSolved(f + preparation.membership.conditionOfTrial(i))
      var col = 0
      while col < k do
        amplitude -= ref.wcJets(i * k + col) * scoreSolved(col)
        col += 1
      energy.amplitudes(i) = amplitude
      i += 1
    energy.coefficientProducts += n.toLong * k
    out.energy = residualEnergy(ref, energy, energy.amplitudes, scoreSolved, 0)
    var condition = 0
    while condition < c do
      out.amplitudes(condition) = scoreSolved(f + condition)
      condition += 1
    out.energy

  /** Evaluate the energy of these actual coefficients using the same reference's
    * basis coefficients. Native readout supplies its independently solved N+F vector.
    */
  private def residualEnergy(ref: TrialBandedReference, energy: TrialMlResidualEnergy,
      amplitudes: Array[Double], nuisance: Array[Double], nuisanceOffset: Int): Double =
    energy.begin()
    var i = 0
    while i < n do
      val condition = preparation.membership.conditionOfTrial(i)
      val amplitude = amplitudes(i)
      energy.conditionSums(condition) += amplitude
      var row = preparation.starts(i)
      while row <= preparation.ends(i) do
        val source = preparation.trialOffsets(i) + (row - preparation.starts(i)) * m
        var x = 0.0
        var p = 0
        while p < m do
          x += preparation.sparseDesign(source + p) * ref.coefficients(p)
          p += 1
        energy.residual(row) -= x * amplitude
        energy.sourceValues += m
        row += 1
      i += 1
    var result = 0.0
    var row = 0
    while row < preparation.rows do
      var col = 0
      while col < f do
        energy.residual(row) -= preparation.whitenedNuisance(row * f + col) * nuisance(nuisanceOffset + col)
        col += 1
      result += energy.residual(row) * energy.residual(row)
      row += 1
    energy.residualRows += preparation.rows
    energy.nuisanceValues += preparation.rows.toLong * f
    var condition = 0
    while condition < c do
      energy.conditionSums(condition) /= preparation.membership.trialsOf(condition).length
      condition += 1
    i = 0
    while i < n do
      val centered = amplitudes(i) - energy.conditionSums(preparation.membership.conditionOfTrial(i))
      result += preparation.lambda * centered * centered
      i += 1
    result

  private def fullJet(ref: TrialBandedReference, encoded: TrialBandedResponse, out: ProfileJetBuffer): Boolean =
    reducedJet(ref, encoded, out, full = true)

  private def reducedJet(ref: TrialBandedReference, encoded: TrialBandedResponse,
      out: ProfileGradientBuffer, full: Boolean): Boolean =
    val active = if full then comps else 1 + d
    contractResponse(ref, encoded, active)
    java.util.Arrays.fill(wbJets, 0.0)
    if !solveResponseComponent(ref, JetLayout.Value, -1, -1) then return false
    var p = 0
    while p < d do
      if !solveResponseComponent(ref, JetLayout.first(p), p, -1) then return false
      p += 1
    p = 0
    while full && p < d do
      var q = p
      while q < d do
        if !solveResponseComponent(ref, JetLayout.second(d, p, q), p, q) then return false
        q += 1
      p += 1
    java.util.Arrays.fill(s, 0.0)
    java.util.Arrays.fill(b, 0.0)
    System.arraycopy(ref.hJets, 0, g, 0, active * k * k)
    assembleReducedComponent(ref, encoded, JetLayout.Value, 1,
      JetLayout.Value, JetLayout.Value, 0, 0, 0, 0, 0, 0)
    p = 0
    while p < d do
      assembleReducedComponent(ref, encoded, JetLayout.first(p), 2,
        JetLayout.first(p), JetLayout.Value,
        JetLayout.Value, JetLayout.first(p),
        0, 0, 0, 0)
      p += 1
    p = 0
    while full && p < d do
      var q = p
      while q < d do
        assembleReducedComponent(ref, encoded, JetLayout.second(d, p, q), 4,
          JetLayout.second(d, p, q), JetLayout.Value,
          JetLayout.first(p), JetLayout.first(q),
          JetLayout.first(q), JetLayout.first(p),
          JetLayout.Value, JetLayout.second(d, p, q))
        q += 1
      p += 1
    val completed =
      if full then releaseReduction.reduce(s, b, g, releaseOut)
      else releaseReduction.reduceGradient(s, b, g, releaseOut)
    if !completed then
      out.energy = Double.PositiveInfinity
      out match
        case jet: ProfileJetBuffer => jet.curvature = CurvatureStatus.GramNotPositiveDefinite
        case _ => ()
      false
    else
      out.energy = releaseOut.energy
      System.arraycopy(releaseOut.gradient, 0, out.gradient, 0, d)
      var i = 0
      while i < c do
        out.amplitudes(i) = releaseOut.amplitudes(f + i)
        i += 1
      out match
        case jet: ProfileJetBuffer if full =>
          System.arraycopy(releaseOut.hessian, 0, jet.hessian, 0, d * d)
          jet.curvature = releaseOut.curvature
        case _ => ()
      true

  /** Solve the differentiated `A w = b` system for one response RHS. */
  private def solveResponseComponent(ref: TrialBandedReference, comp: Int, axisP: Int, axisQ: Int): Boolean =
    val target = comp * n
    val (bands, bandOffset) = derivativeBand(ref, comp)
    var i = 0
    while i < n do
      var value = responseB(target + i)
      if comp != JetLayout.Value then
        value -= bandVectorProduct(bands, bandOffset / bandSize, wbJets, 0, i)
        if axisQ >= 0 then
          value -= bandVectorProduct(ref.aJets, JetLayout.first(axisP), wbJets, JetLayout.first(axisQ) * n, i)
          value -= bandVectorProduct(ref.aJets, JetLayout.first(axisQ), wbJets, JetLayout.first(axisP) * n, i)
      jetSolveBuilder.writeLinear(i, value)
      i += 1
    work.solveAttempt(1)
    ref.factor.solveInPlace(jetSolveBuilder) match
      case Left(_) =>
        work.solveFailed(1)
        false
      case Right(_) =>
        work.bandedSolveCalls += 1
        work.bandedRightHandSides += 1
        i = 0
        while i < n do
          wbJets(target + i) = jetSolveBuilder(i, 0)
          i += 1
        true

  /** Same basis-pair contraction and summation order as setup; only the second
    * bands are omitted from immutable storage. One buffer is reused between
    * components, with no additional inverse or factorisation.
    */
  private def derivativeBand(ref: TrialBandedReference, component: Int): (Array[Double], Int) =
    if (component + 1) * bandSize <= ref.aJets.length then (ref.aJets, component * bandSize)
    else
      val scratch = reconstructedBand
      require(scratch.length == bandSize)
      java.util.Arrays.fill(scratch, 0.0)
      var axisP = 0
      var axisQ = 0
      var p = 0
      while p < d do
        var q = p
        while q < d do
          if JetLayout.second(d, p, q) == component then
            axisP = p
            axisQ = q
          q += 1
        p += 1
      val coefficients = ref.coefficients
      var q = 0
      while q < m do
        p = 0
        while p <= q do
          val weight = coefficients(component * m + p) * coefficients(q) +
            coefficients(JetLayout.first(axisP) * m + p) * coefficients(JetLayout.first(axisQ) * m + q) +
            coefficients(JetLayout.first(axisQ) * m + p) * coefficients(JetLayout.first(axisP) * m + q) +
            coefficients(p) * coefficients(component * m + q)
          if weight != 0.0 then
            val block = TrialBandedPreparation.pairIndex(p, q) * bandSize
            var i = 0
            while i < bandSize do
              scratch(i) += weight * preparation.gramBlocksData(block + i)
              i += 1
            work.reconstructedBandProducts += bandSize.toLong
          p += 1
        q += 1
      work.reconstructedBands += 1L
      (scratch, 0)

  private def bandVectorProduct(bands: Array[Double], comp: Int, vector: Array[Double], vectorOffset: Int, row: Int): Double =
    val width = preparation.bandWidth
    val from = math.max(0, row - preparation.bandwidth)
    val until = math.min(n - 1, row + preparation.bandwidth)
    var sum = 0.0
    var j = from
    while j <= until do
      val high = math.max(row, j)
      val delta = math.abs(row - j)
      sum += bands(comp * bandSize + high * width + delta) * vector(vectorOffset + j)
      j += 1
    sum

  /** Assemble one component of `s = y'y - b'A^-1b` and
    * `b_release = Z'y - b'A^-1C`. The product rule has one, two or four
    * terms for value, first and second derivatives respectively.
    */
  private def assembleReducedComponent(
      ref: TrialBandedReference,
      encoded: TrialBandedResponse,
      outComponent: Int,
      termCount: Int,
      b0: Int,
      w0: Int,
      b1: Int,
      w1: Int,
      b2: Int,
      w2: Int,
      b3: Int,
      w3: Int
  ): Unit =
    var quadratic = responseSolutionDot(b0, w0)
    if termCount > 1 then quadratic += responseSolutionDot(b1, w1)
    if termCount > 2 then
      quadratic += responseSolutionDot(b2, w2)
      quadratic += responseSolutionDot(b3, w3)
    s(outComponent) = (if outComponent == JetLayout.Value then encoded.responseEnergy else 0.0) - quadratic
    var col = 0
    while col < k do
      var cross = responseReleaseDot(ref, b0, w0, col)
      if termCount > 1 then cross += responseReleaseDot(ref, b1, w1, col)
      if termCount > 2 then
        cross += responseReleaseDot(ref, b2, w2, col)
        cross += responseReleaseDot(ref, b3, w3, col)
      b(outComponent * k + col) = zTy(outComponent * k + col) - cross
      col += 1

  private def responseSolutionDot(bComponent: Int, wComponent: Int): Double =
    val bBase = bComponent * n
    val wBase = wComponent * n
    var sum = 0.0
    var i = 0
    while i < n do
      sum += responseB(bBase + i) * wbJets(wBase + i)
      i += 1
    sum

  private def responseReleaseDot(ref: TrialBandedReference, bComponent: Int, wComponent: Int, col: Int): Double =
    val bBase = bComponent * n
    val wBase = wComponent * n * k
    var sum = 0.0
    var i = 0
    while i < n do
      sum += responseB(bBase + i) * ref.wcJets(wBase + i * k + col)
      i += 1
    sum

/** Regular-grid decoder objective. Explicit point banks do not implement
  * ShapeObjective and therefore cannot accidentally masquerade as a grid.
  */
final class TrialBandedObjective private (
    preparation: TrialBandedPreparation,
    val grid: NodeGrid,
    storage: TrialReferenceStorage,
    references: Vector[TrialBandedReference],
    receipt: TrialBandedSetupReceipt)
    extends TrialReferenceBank(preparation, TrialReferencePoints.fromGrid(grid), storage, references, receipt)
    with FirstOrderShapeObjective:
  override def newWorker(): TrialBandedObjective =
    new TrialBandedObjective(preparation, grid, storage, references, receipt)

object TrialBandedObjective:

  def make(preparation: TrialBandedPreparation, grid: NodeGrid,
      storage: TrialReferenceStorage = TrialReferenceStorage.FullJets): Either[TrialBandedError, TrialBandedObjective] =
    buildBank(preparation, TrialReferencePoints.fromGrid(grid), storage).map: (references, receipt) =>
      new TrialBandedObjective(preparation, grid, storage, references, receipt)

  private[profile] def buildBank(preparation: TrialBandedPreparation, points: TrialReferencePoints,
      storage: TrialReferenceStorage): Either[TrialBandedError, (Vector[TrialBandedReference], TrialBandedSetupReceipt)] =
    val basis = preparation.basis
    if points.chart.dimension != basis.family.dimension || points.coordinates.exists(p => basis.family.chart.point(p).isLeft) then
      Left(TrialBandedError.Factorisation("reference coordinates must lie inside the family chart"))
    else
      val comps = basis.family.jetComponents
      val scratch = new Array[Double](comps * basis.fineCount)
      val coefficients = new Array[Double](comps * basis.rank)
      val refs = Vector.newBuilder[TrialBandedReference]
      val setupWork = new TrialBandedWork
      var node = 0
      while node < points.count do
        val coords = points.coordinates(node)
        basis.coefficientJetInto(ShapePoint.unsafe(coords), scratch, coefficients, comps)
        reference(preparation, coords, java.util.Arrays.copyOf(coefficients, coefficients.length), comps, Some(node),
          setupWork) match
          case Left(error) => return Left(error)
          case Right(ref) =>
            val retained = if storage == TrialReferenceStorage.FullJets then ref else
              ref.copy(aJets = java.util.Arrays.copyOf(ref.aJets, (1 + basis.family.dimension) * preparation.packedBandSize))
            refs += retained
        node += 1
      val setup = setupWork.snapshot.attempted
      Right((refs.result(), TrialBandedSetupReceipt(setup.referenceAttempts, setup)))

  private[profile] def reference(
      prep: TrialBandedPreparation,
      coordinates: Vector[Double],
      coefficients: Array[Double],
      activeComponents: Int,
      node: Option[Int],
      work: TrialBandedWork): Either[TrialBandedError, TrialBandedReference] =
    work.referenceAttempts += 1L
    val n = prep.trials
    val m = prep.basisRank
    val c = prep.conditions
    val f = prep.nuisanceColumns
    val k = f + c
    val d = prep.basis.family.dimension
    val width = prep.bandWidth
    val bandSize = prep.packedBandSize
    val aJets = new Array[Double](activeComponents * bandSize)
    def addBlock(component: Int, p: Int, q: Int, weight: Double): Unit =
      if weight != 0.0 then
        val block = TrialBandedPreparation.pairIndex(math.min(p, q), math.max(p, q)) * bandSize
        val target = component * bandSize
        var i = 0
        while i < bandSize do
          aJets(target + i) += weight * prep.gramBlocksData(block + i)
          i += 1
    var q = 0
    while q < m do
      var p = 0
      while p <= q do
        val c0p = coefficients(p)
        val c0q = coefficients(q)
        addBlock(JetLayout.Value, p, q, c0p * c0q)
        var axis = 0
        while axis < d && JetLayout.first(axis) < activeComponents do
          val cp = coefficients(JetLayout.first(axis) * m + p)
          val cq = coefficients(JetLayout.first(axis) * m + q)
          addBlock(JetLayout.first(axis), p, q, cp * c0q + c0p * cq)
          axis += 1
        axis = 0
        while axis < d do
          var axisQ = axis
          while axisQ < d do
            val component = JetLayout.second(d, axis, axisQ)
            if component < activeComponents then
              val c2p = coefficients(component * m + p)
              val c2q = coefficients(component * m + q)
              val c1pp = coefficients(JetLayout.first(axis) * m + p)
              val c1pq = coefficients(JetLayout.first(axisQ) * m + p)
              val c1qp = coefficients(JetLayout.first(axis) * m + q)
              val c1qq = coefficients(JetLayout.first(axisQ) * m + q)
              addBlock(component, p, q, c2p * c0q + c1pp * c1qq + c1pq * c1qp + c0p * c2q)
            axisQ += 1
          axis += 1
        p += 1
      q += 1
    var i = 0
    while i < n do
      aJets(i * width) += prep.lambda
      i += 1
    val valueBand = DMatBuilder.zeros(n, width)
    i = 0
    while i < bandSize do
      valueBand.writeLinear(i, aJets(i))
      i += 1
    // At most one N-sized factorisation, of the bundle's own frozen canonical copy. Charge the
    // factory's actual receipt: a pre-factor construction refusal attempts no Gale factorisation.
    val bundle = TrialAcceptedTrialBand.atPreparationLambda(prep, coordinates, valueBand.result())
    work.factorAttempts += bundle.work.factorAttempts
    work.bandFactorAttempts += bundle.work.factorAttempts
    work.factorFailures += bundle.work.factorFailures
    work.bandFactorFailures += bundle.work.factorFailures
    bundle.outcome match
      case Left(error) =>
        work.referenceFailed(release = false)
        Left(TrialBandedError.Factorisation(error.message))
      case Right(accepted) =>
        val factor = accepted.factor
        val cJets = new Array[Double](activeComponents * n * k)
        val dJets = new Array[Double](activeComponents * k * k)
        var comp = 0
        while comp < activeComponents do
          i = 0
          while i < n do
            var nuisanceCol = 0
            while nuisanceCol < f do
              var sum = 0.0
              var basisIx = 0
              while basisIx < m do
                sum += coefficients(comp * m + basisIx) * prep.basisNuisanceCross((basisIx * n + i) * f + nuisanceCol)
                basisIx += 1
              cJets(comp * n * k + i * k + nuisanceCol) = sum
              nuisanceCol += 1
            var j = math.max(0, i - prep.bandwidth)
            while j <= math.min(n - 1, i + prep.bandwidth) do
              val high = math.max(i, j)
              val delta = math.abs(i - j)
              var value = aJets(comp * bandSize + high * width + delta)
              if comp == JetLayout.Value && i == j then value -= prep.lambda
              val condition = prep.membership.conditionOfTrial(j)
              cJets(comp * n * k + i * k + f + condition) += value
              j += 1
            i += 1
          if comp == JetLayout.Value then
            i = 0
            while i < f do
              var j = 0
              while j < f do
                dJets(i * k + j) = prep.nuisanceGram(i * f + j)
                j += 1
              i += 1
          i = 0
          while i < n do
            val condition = prep.membership.conditionOfTrial(i)
            var nuisanceCol = 0
            while nuisanceCol < f do
              val value = cJets(comp * n * k + i * k + nuisanceCol)
              dJets(comp * k * k + nuisanceCol * k + f + condition) += value
              dJets(comp * k * k + (f + condition) * k + nuisanceCol) += value
              nuisanceCol += 1
            var conditionCol = 0
            while conditionCol < c do
              dJets(comp * k * k + (f + condition) * k + f + conditionCol) +=
                cJets(comp * n * k + i * k + f + conditionCol)
              conditionCol += 1
            i += 1
          comp += 1
        val wcJets = new Array[Double](activeComponents * n * k)
        val solveC = DMatBuilder.zeros(n, k)
        def bandMatrixProduct(component: Int, solutionComponent: Int, row: Int, col: Int): Double =
          val from = math.max(0, row - prep.bandwidth)
          val until = math.min(n - 1, row + prep.bandwidth)
          val solutionBase = solutionComponent * n * k
          var sum = 0.0
          var trial = from
          while trial <= until do
            val high = math.max(row, trial)
            val delta = math.abs(row - trial)
            sum += aJets(component * bandSize + high * width + delta) * wcJets(solutionBase + trial * k + col)
            trial += 1
          sum
        def solveCComponent(component: Int, axisP: Int, axisQ: Int): Either[TrialBandedError, Unit] =
          val target = component * n * k
          var row = 0
          while row < n do
            var col = 0
            while col < k do
              var value = cJets(target + row * k + col)
              if component != JetLayout.Value then
                value -= bandMatrixProduct(component, JetLayout.Value, row, col)
                if axisQ >= 0 then
                  value -= bandMatrixProduct(JetLayout.first(axisP), JetLayout.first(axisQ), row, col)
                  value -= bandMatrixProduct(JetLayout.first(axisQ), JetLayout.first(axisP), row, col)
              solveC.writeLinear(row * k + col, value)
              col += 1
            row += 1
          work.solveAttempt(k)
          factor.solveInPlace(solveC) match
            case Left(error) =>
              work.solveFailed(k)
              Left(TrialBandedError.Factorisation(error.getMessage))
            case Right(_) =>
              row = 0
              while row < n do
                var col = 0
                while col < k do
                  wcJets(target + row * k + col) = solveC(row, col)
                  col += 1
                row += 1
              Right(())
        var solveFailure: TrialBandedError | Null = null
        solveCComponent(JetLayout.Value, -1, -1) match
          case Left(error) => solveFailure = error
          case Right(_) => ()
        var axis = 0
        while axis < d && solveFailure == null && JetLayout.first(axis) < activeComponents do
          solveCComponent(JetLayout.first(axis), axis, -1) match
            case Left(error) => solveFailure = error
            case Right(_) => ()
          axis += 1
        axis = 0
        while axis < d && solveFailure == null do
          var axisQ = axis
          while axisQ < d && solveFailure == null do
            val component = JetLayout.second(d, axis, axisQ)
            if component < activeComponents then
              solveCComponent(component, axis, axisQ) match
                case Left(error) => solveFailure = error
                case Right(_) => ()
            axisQ += 1
          axis += 1
        if solveFailure != null then
          work.referenceFailed(release = false)
          Left(solveFailure.nn)
        else
          val hJets = java.util.Arrays.copyOf(dJets, dJets.length)
          def subtractCross(outComponent: Int, cComponent: Int, wComponent: Int): Unit =
            val outBase = outComponent * k * k
            val cBase = cComponent * n * k
            val wBase = wComponent * n * k
            var row = 0
            while row < k do
              var col = 0
              while col < k do
                var correction = 0.0
                var trial = 0
                while trial < n do
                  correction += cJets(cBase + trial * k + row) * wcJets(wBase + trial * k + col)
                  trial += 1
                hJets(outBase + row * k + col) -= correction
                col += 1
              row += 1
          def symmetrise(component: Int): Unit =
            val base = component * k * k
            var row = 0
            while row < k do
              var col = 0
              while col < row do
                val mean = 0.5 * (hJets(base + row * k + col) + hJets(base + col * k + row))
                hJets(base + row * k + col) = mean
                hJets(base + col * k + row) = mean
                col += 1
              row += 1
          subtractCross(JetLayout.Value, JetLayout.Value, JetLayout.Value)
          symmetrise(JetLayout.Value)
          axis = 0
          while axis < d && JetLayout.first(axis) < activeComponents do
            val first = JetLayout.first(axis)
            subtractCross(first, first, JetLayout.Value)
            subtractCross(first, JetLayout.Value, first)
            symmetrise(first)
            axis += 1
          axis = 0
          while axis < d do
            var axisQ = axis
            while axisQ < d do
              val second = JetLayout.second(d, axis, axisQ)
              if second < activeComponents then
                subtractCross(second, second, JetLayout.Value)
                subtractCross(second, JetLayout.first(axis), JetLayout.first(axisQ))
                subtractCross(second, JetLayout.first(axisQ), JetLayout.first(axis))
                subtractCross(second, JetLayout.Value, second)
                symmetrise(second)
              axisQ += 1
            axis += 1
          val release = java.util.Arrays.copyOf(hJets, k * k)
          denseLower(release, k, work) match
            case None =>
              work.referenceFailed(release = true)
              Left(TrialBandedError.ReleaseRank(node, k))
            case Some((releaseLower, _)) =>
              constrainedLogDet(prep, factor, work) match
                case Left(error) =>
                  val releaseFailure = error match
                    case TrialBandedError.ReleaseRank(_, _) => true
                    case _ => false
                  work.referenceFailed(releaseFailure)
                  Left(error)
                case Right(logDet) =>
                  Right(TrialBandedReference(coefficients, accepted, aJets, cJets, wcJets, hJets, releaseLower, logDet))

  private def constrainedLogDet(prep: TrialBandedPreparation, factor: BandedCholesky, work: TrialBandedWork): Either[TrialBandedError, Double] =
    val n = prep.trials
    val c = prep.conditions
    val mSolve = DMatBuilder.zeros(n, c)
    var i = 0
    while i < n do
      mSolve(i, prep.membership.conditionOfTrial(i)) = 1.0
      i += 1
    work.solveAttempt(c)
    work.membershipRightHandSides += c
    factor.solveInPlace(mSolve) match
      case Left(error) =>
        work.solveFailed(c)
        Left(TrialBandedError.Factorisation(error.getMessage))
      case Right(_) =>
        val small = new Array[Double](c * c)
        i = 0
        while i < n do
          val row = prep.membership.conditionOfTrial(i)
          var j = 0
          while j < c do
            small(row * c + j) += mSolve(i, j)
            j += 1
          i += 1
        denseLower(small, c, work) match
          case None => Left(TrialBandedError.ReleaseRank(None, c))
          case Some((_, smallLogDet)) =>
            val membershipLogDet = (0 until c).map(cond => math.log(prep.membership.trialsOf(cond).length.toDouble)).sum
            Right(factor.logDet - (n - c) * math.log(prep.lambda) + smallLogDet - membershipLogDet)

  /** Gale performs the rank decision; the copied lower triangle feeds the
    * allocation-free small release solve used for every voxel.
    */
  private def denseLower(matrix: Array[Double], size: Int, work: TrialBandedWork): Option[(Array[Double], Double)] =
    work.factorAttempts += 1L
    TrialBandedPreparation.toDMat(size, size, matrix).cholesky.toOption match
      case None =>
        work.factorFailures += 1L
        None
      case Some(factor) =>
        val lower = new Array[Double](size * size)
        factor.lower.copyRowMajorTo(lower)
        var logDet = 0.0
        var i = 0
        while i < size do
          logDet += 2.0 * math.log(lower(i * size + i))
          i += 1
        Some((lower, logDet))

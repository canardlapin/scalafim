package scalafim.fmri.fit

import scalafim.dataset.{
  DataSelection,
  DatasetSeriesReader,
  FmriSeries,
  SynchronousFmriDataset
}
import scalafim.fmri.design.event.{ConvolvedTerm, EventTermColumnRole}
import scalafim.fmri.design.{RunCoefficientProjection, RunIndex as DesignRunIndex, ScanIndex}
import scalafim.fmri.model.{FitPlan, MissingDataPolicy}

import scala.concurrent.{ExecutionContext, Future}

object FitPlanExecutor:
  /** Synchronous compatibility overload. */
  def fit(
      plan: FitPlan
  ): Either[FitError, FmriFitResult] =
    fit(plan, DataSelection.All)

  /** Synchronous compatibility overload. */
  def fit(
      plan: FitPlan,
      selection: DataSelection
  ): Either[FitError, FmriFitResult] =
    legacyReader(plan).flatMap(fit(_, plan, selection))

  def fit(
      reader: DatasetSeriesReader,
      plan: FitPlan,
      selection: DataSelection = DataSelection.All
  ): Either[FitError, FmriFitResult] =
    for
      _ <-
        if reader.dataset.id == plan.model.dataset.id then Right(())
        else
          Left(FitError.InvalidFitAxis(
            "dataset reader",
            s"reader dataset '${reader.dataset.id.value}' does not match model dataset '${plan.model.dataset.id.value}'"
          ))
      interpreter <- FitInterpreters.forPlan(plan)
      series <- reader
        .seriesEither(selection)
        .left
        .map(FitChunkPlan.mapDatasetError)
      result <-
        plan.config.missingData match
          case MissingDataPolicy.OmitRowsPerVoxel => MaskedResponseExecutor.fit(plan, series)
          case _                                  => interpreter.fit(plan, series)
    yield result

  /** Execute a plan whose result is required for coefficient-level inference.
    *
    * The method uses the same executor as [[fit]] and reports a typed error when
    * the selected engine returns a runwise, fixed-effects, or trialwise result.
    */
  def fitDense(
      plan: FitPlan
  ): Either[FitError, DenseFmriFitResult] =
    fitDense(plan, DataSelection.All)

  def fitDense(
      plan: FitPlan,
      selection: DataSelection
  ): Either[FitError, DenseFmriFitResult] =
    fit(plan, selection).flatMap(requireDense)

  def fitDense(
      reader: DatasetSeriesReader,
      plan: FitPlan,
      selection: DataSelection = DataSelection.All
  ): Either[FitError, DenseFmriFitResult] =
    fit(reader, plan, selection).flatMap(requireDense)

  def unsafeFit(
      reader: DatasetSeriesReader,
      plan: FitPlan,
      selection: DataSelection = DataSelection.All
  ): FmriFitResult =
    fit(reader, plan, selection)
      .fold(error => throw new IllegalArgumentException(error.message), identity)

  /** Synchronous compatibility overload. */
  def unsafeFit(
      plan: FitPlan
  ): FmriFitResult =
    unsafeFit(plan, DataSelection.All)

  /** Synchronous compatibility overload. */
  def unsafeFit(
      plan: FitPlan,
      selection: DataSelection
  ): FmriFitResult =
    fit(plan, selection)
      .fold(error => throw new IllegalArgumentException(error.message), identity)

  /** Synchronous compatibility overload. */
  def fitChunked(
      plan: FitPlan
  ): Either[FitError, FmriFitResult] =
    fitChunked(
      plan,
      DataSelection.All,
      FitChunkingStrategy.WholeSelection
    )

  /** Synchronous compatibility overload. */
  def fitChunked(
      plan: FitPlan,
      selection: DataSelection
  ): Either[FitError, FmriFitResult] =
    fitChunked(plan, selection, FitChunkingStrategy.WholeSelection)

  /** Synchronous compatibility overload. */
  def fitChunked(
      plan: FitPlan,
      chunking: FitChunkingStrategy
  ): Either[FitError, FmriFitResult] =
    fitChunked(plan, DataSelection.All, chunking)

  /** Synchronous compatibility overload. */
  def fitChunked(
      plan: FitPlan,
      selection: DataSelection,
      chunking: FitChunkingStrategy
  ): Either[FitError, FmriFitResult] =
    legacyReader(plan).flatMap(fitChunked(_, plan, selection, chunking))

  def fitChunked(
      reader: DatasetSeriesReader,
      plan: FitPlan,
      selection: DataSelection = DataSelection.All,
      chunking: FitChunkingStrategy = FitChunkingStrategy.WholeSelection
  ): Either[FitError, FmriFitResult] =
    ChunkedFitExecutor.fit(reader, plan, selection, chunking)

  def fitChunkedFuture(
      reader: DatasetSeriesReader,
      plan: FitPlan,
      selection: DataSelection = DataSelection.All,
      chunking: FitChunkingStrategy = FitChunkingStrategy.WholeSelection,
      parallelism: FitParallelism = FitParallelism.unbounded
  )(using ExecutionContext): Future[Either[FitError, FmriFitResult]] =
    FutureChunkedFitExecutor.fit(
      reader,
      plan,
      selection,
      chunking,
      parallelism
    )

  /** Synchronous compatibility overload. */
  def fitChunkedFuture(
      plan: FitPlan
  )(using ExecutionContext): Future[Either[FitError, FmriFitResult]] =
    fitChunkedFuture(
      plan,
      DataSelection.All,
      FitChunkingStrategy.WholeSelection,
      FitParallelism.unbounded
    )

  /** Synchronous compatibility overload. */
  def fitChunkedFuture(
      plan: FitPlan,
      selection: DataSelection
  )(using ExecutionContext): Future[Either[FitError, FmriFitResult]] =
    fitChunkedFuture(
      plan,
      selection,
      FitChunkingStrategy.WholeSelection,
      FitParallelism.unbounded
    )

  /** Synchronous compatibility overload. */
  def fitChunkedFuture(
      plan: FitPlan,
      selection: DataSelection,
      chunking: FitChunkingStrategy
  )(using ExecutionContext): Future[Either[FitError, FmriFitResult]] =
    fitChunkedFuture(
      plan,
      selection,
      chunking,
      FitParallelism.unbounded
    )

  /** Synchronous compatibility overload. */
  def fitChunkedFuture(
      plan: FitPlan,
      selection: DataSelection,
      chunking: FitChunkingStrategy,
      parallelism: FitParallelism
  )(using ExecutionContext): Future[Either[FitError, FmriFitResult]] =
    legacyReader(plan) match
      case Left(error) =>
        Future.successful(Left(error))
      case Right(reader) =>
        fitChunkedFuture(reader, plan, selection, chunking, parallelism)

  private def legacyReader(
      plan: FitPlan
  ): Either[FitError, SynchronousFmriDataset] =
    SynchronousFmriDataset
      .readerFor(plan.model.dataset)
      .left
      .map(error =>
        FitError.InvalidFitAxis("dataset reader", error.message)
      )

  private def requireDense(result: FmriFitResult): Either[FitError, DenseFmriFitResult] =
    result match
      case dense: DenseFmriFitResult => Right(dense)
      case _: PatternedFmriFitResult =>
        Left(FitError.UnsupportedMissingDataPolicy(
          "voxel-specific observed-row patterns do not share one dense inference geometry; use fit and inspect patternResults"
        ))
      case other                     => Left(FitError.NonDenseFitResult(other.engine))

  private[fit] def fitBlockInput(
      plan: FitPlan,
      series: FmriSeries,
      partitions: Vector[RunPartition] = Vector.empty,
      lssDesign: Option[Either[FitError, LssBlockDesign]] = None
  ): Either[FitError, FitBlockInput] =
    preparedFitBlockInput(plan, series, partitions, lssDesign).map(_.input)

  private[fit] def fitBlockInput(
      plan: FitPlan,
      series: FmriSeries,
      partitions: Vector[RunPartition],
      preparation: ResolvedResponsePreparation
  ): Either[FitError, FitBlockInput] =
    preparedFitBlockInput(
      plan = plan,
      series = series,
      partitions = partitions,
      lssDesign = None,
      resolvedPreparation = Some(preparation)
    ).map(_.input)

  private[fit] def rawFitBlockInput(
      plan: FitPlan,
      series: FmriSeries,
      partitions: Vector[RunPartition] = Vector.empty,
      lssDesign: Option[Either[FitError, LssBlockDesign]] = None
  ): Either[FitError, FitBlockInput] =
    for
      design <- MatrixAdapters.designMatrix(plan.model, series.timepoints)
      adaptedResponse <- MatrixAdapters.responseBlock(series, plan.config.missingData)
      runwiseProjections <- runwiseProjections(plan, series.timepoints, partitions)
      lss <- lssDesign match
        case None        => Right(None)
        case Some(value) => value.map(design => Some(design): Option[LssBlockDesign])
    yield FitBlockInput(
      design = design,
      response = adaptedResponse.response,
      voxelIndices = adaptedResponse.voxelIndices,
      timepoints = series.timepoints,
      partitions = partitions,
      lssDesign = lss,
      coefficientAxis = plan.coefficientAxis,
      runwiseProjections = runwiseProjections,
      voxelStatuses = Some(VoxelFitStatus.classify(adaptedResponse.response)),
      fitExclusions = adaptedResponse.fitExclusions
    )

  private[fit] def preparedFitBlockInput(
      plan: FitPlan,
      series: FmriSeries,
      partitions: Vector[RunPartition] = Vector.empty,
      lssDesign: Option[Either[FitError, LssBlockDesign]] = None,
      resolvedPreparation: Option[ResolvedResponsePreparation] = None
  ): Either[FitError, PreparedFitBlockInput] =
    for
      input <- rawFitBlockInput(plan, series, partitions, lssDesign)
      prepared <- resolvedPreparation match
        case Some(value) => value.prepare(input)
        case None        => ResponsePreparationPlan.fromPlan(plan).prepare(input)
    yield prepared

  private def runwiseProjections(
      plan: FitPlan,
      timepoints: IndexedSeq[Int],
      partitions: Vector[RunPartition]
  ): Either[FitError, Vector[RunCoefficientProjection]] =
    plan.strategy match
      case scalafim.fmri.model.FitStrategy.RunwiseLeastSquares(_) |
          scalafim.fmri.model.FitStrategy.RunwiseGeneralizedLeastSquares(_, _) |
          scalafim.fmri.model.FitStrategy.SeparateRunsThenFixedEffects(_) =>
        plan.model.designSchema match
          case None => Right(Vector.empty)
          case Some(schema) if schema.columns.exists(_.origin.isInstanceOf[scalafim.fmri.design.StructuralColumnOrigin.Legacy]) =>
            // Pre-schema models retain the old common-axis runwise behavior.
            Right(Vector.empty)
          case Some(schema) =>
            val selectedRows = timepoints.map { timepoint => ScanIndex.unsafeOneBased(timepoint + 1) }.toVector
            val out = Vector.newBuilder[RunCoefficientProjection]
            var index = 0
            while index < partitions.length do
              val partition = partitions(index)
              val run = DesignRunIndex.unsafeOneBased(partition.runIndex + 1)
              schema.runwiseProjection(run, selectedRows) match
                case Left(error) =>
                  return Left(FitError.InvalidFitAxis("runwise coefficient projection", error.message))
                case Right(projection) => out += projection
              index += 1
            Right(out.result())
      case _ => Right(Vector.empty)

  private[fit] def denseResult(plan: FitPlan, block: DenseFitBlockResult): DenseFmriFitResult =
    DenseFmriFitResult(
      coefficients = block.coefficients,
      inference = block.inference,
      residualVariance = block.residualVariance,
      residualDegreesOfFreedom = block.residualDegreesOfFreedom,
      columnNames = plan.model.columnNames,
      voxelIndices = block.voxelIndices,
      timepoints = block.timepoints,
      engine = block.engine,
      summary = plan.summary,
      olsDiagnostics = block.olsDiagnostics,
      autocorrelation = block.autocorrelation,
      robustDiagnostics = block.robustDiagnostics,
      coefficientAxis = block.coefficientAxis,
      preparationProvenance = block.preparationProvenance,
      voxelStatuses = Some(block.resolvedVoxelStatuses),
      fitExclusions = block.fitExclusions
    )

  private[fit] def lssExecutionDesign(plan: FitPlan, timepoints: Vector[Int]): Either[FitError, LssBlockDesign] =
    for
      trialTerm <- selectTrialwiseTerm(plan)
      termCols <- trialColumns(plan, trialTerm)
      trialMatrix <- LssTrialDesign.fromMatrix(
        MatrixAdapters.designColumns(plan.model, timepoints, termCols.trials),
        termCols.trials.map(plan.model.eventModel.columnNames)
      )
      fixed <- fixedDesign(plan, timepoints, excludedEventCols = termCols.trials ++ termCols.aggregates)
      prepared <- LeastSquaresSeparate.prepare(
        trials = trialMatrix,
        fixed = fixed,
        options = LssOptions(eps = plan.config.lss.eps, rankTol = plan.config.lss.rankTol)
      )
    yield LssBlockDesign(prepared, trialColumns = termCols.trials)

  private final case class TrialwiseTerm(key: String, index: Int, term: ConvolvedTerm)
  private final case class TrialColumnSelection(trials: Vector[Int], aggregates: Vector[Int])

  private def selectTrialwiseTerm(plan: FitPlan): Either[FitError, TrialwiseTerm] =
    val trialwiseTerms =
      plan.model.eventModel.terms.zipWithIndex.collect {
        case ((key, term: ConvolvedTerm), index) if term.isTrialwise =>
          TrialwiseTerm(key, index, term)
      }

    plan.config.lss.trialTerm match
      case Some(requested) =>
        trialwiseTerms.find(_.key == requested).toRight(FitError.UnknownLssTrialTerm(requested))
      case None =>
        trialwiseTerms match
          case Vector()       => Left(FitError.MissingLssTrialTerm)
          case Vector(single) => Right(single)
          case many           => Left(FitError.AmbiguousLssTrialTerms(many.map(_.key)))

  private def trialColumns(plan: FitPlan, selected: TrialwiseTerm): Either[FitError, TrialColumnSelection] =
    if selected.term.hrf.nbasis != 1 then
      Left(FitError.UnsupportedLssDesign(s"trialwise term '${selected.key}' has ${selected.term.hrf.nbasis} HRF basis columns; core LSS supports scalar trial regressors only"))
    else
      val nTrials = selected.term.term.onsets.length
      if nTrials <= 0 then Left(FitError.EmptyDesign)
      else
        val (start, endExcl) = plan.model.eventModel.termSpans(selected.index)
        val spanCols = (start until endExcl).toVector
        val roles = selected.term.resolvedColumnRoles
        if roles.length != spanCols.length then
          Left(
            FitError.UnsupportedLssDesign(
              s"trialwise term '${selected.key}' metadata has ${roles.length} roles for ${spanCols.length} design columns"
            )
          )
        else
          val trialCols = roles.zip(spanCols).collect {
            case (EventTermColumnRole.Trial, col) => col
          }
          val aggregateCols = roles.zip(spanCols).collect {
            case (EventTermColumnRole.TrialAggregate, col) => col
          }
          if trialCols.length != nTrials then
            Left(
              FitError.UnsupportedLssDesign(
                s"trialwise term '${selected.key}' exposes ${trialCols.length} trial columns for $nTrials events"
              )
            )
          else Right(TrialColumnSelection(trials = trialCols, aggregates = aggregateCols))

  private def fixedDesign(plan: FitPlan, timepoints: Vector[Int], excludedEventCols: Vector[Int]): Either[FitError, LssFixedDesign] =
    val excludedSet = excludedEventCols.toSet
    val eventFixedCols =
      plan.model.eventModel.columnNames.indices.filterNot(excludedSet.contains).toVector

    val baselineCols = (plan.model.eventModel.columnNames.length until plan.model.nPredictors).toVector
    val fixedCols = eventFixedCols ++ baselineCols
    val fixedMatrix = MatrixAdapters.designColumns(plan.model, timepoints, fixedCols)
    val fixedNames = fixedCols.map(plan.model.columnNames)

    if fixedMatrix.cols == 0 then Right(LssFixedDesign.empty(timepoints.length))
    else LssFixedDesign.fromMatrix(fixedMatrix, fixedNames)

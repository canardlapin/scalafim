package scalafim.fmri.fit

import scalafim.dataset.FmriSeries
import scalafim.fmri.model.{
  ArOptions,
  DesignColumnSource,
  FitConfig,
  FitEngine,
  FitPlan,
  FitStrategy,
  LatentSketchConfig,
  ReducedRankGlsConfig
}

trait FitInterpreter:
  type Prepared
  type Block <: FitBlockResult
  type Result <: FmriFitResult

  def engine: FitEngine

  def fit(plan: FitPlan, series: FmriSeries): Either[FitError, Result]

  def prepare(plan: FitPlan, series: FmriSeries): Either[FitError, Prepared]

  def fitChunk(
      plan: FitPlan,
      series: FmriSeries,
      prepared: Prepared
  ): Either[FitError, Block]

  def merge(
      plan: FitPlan,
      chunks: IndexedSeq[Block]
  ): Either[FitError, Result]

  /** None means preparation needs the selected responses. Implementations may
    * opt in only when selected timepoints and the plan fully determine Prepared.
    * In particular, pooled noise or response-weight estimation must not opt in.
    */
  private[fit] def prepareFromTimepoints(
      plan: FitPlan,
      timepoints: Vector[Int]
  ): Option[Either[FitError, Prepared]] = None

  private[fit] final def prepareContext(
      plan: FitPlan,
      timepoints: Vector[Int],
      loadResponses: => Either[FitError, FmriSeries]
  ): Either[FitError, PreparedFitContext] =
    val preparation = prepareFromTimepoints(plan, timepoints)
      .getOrElse(loadResponses.flatMap(series => prepare(plan, series)))
    preparation.map(prepared => new InterpreterFitContext(this)(plan, prepared))

  private[fit] final def mergeAny(
      plan: FitPlan,
      chunks: IndexedSeq[FitBlockResult]
  ): Either[FitError, FmriFitResult] =
    val fittedBlocks = chunks.filter {
      case _: ExcludedFitBlockResult => false
      case _                         => true
    }
    for
      excluded <- VoxelInferenceExclusions.combine(chunks.iterator.flatMap(_.fitExclusions))
      result <-
        if fittedBlocks.isEmpty then Left(FitError.AllVoxelsExcluded(excluded))
        else collect(fittedBlocks).flatMap(typed => merge(plan, typed))
      withExclusions <- FmriFitResults.mergeFitExclusions(result, excluded)
    yield withExclusions

  protected def collect(chunks: IndexedSeq[FitBlockResult]): Either[FitError, IndexedSeq[Block]]

/** Runtime state only. Persist FitWorkDescriptor, then bind interpreter capabilities. */
private[fit] sealed trait PreparedFitContext:
  def engine: FitEngine
  protected def execute(series: FmriSeries): Either[FitError, FitBlockResult]
  def merge(chunks: IndexedSeq[FitBlockResult]): Either[FitError, FmriFitResult]

  final def fitChunk(series: FmriSeries): Either[FitError, FitBlockResult] =
    execute(series) match
      case Left(FitError.AllVoxelsExcluded(exclusions)) =>
        Right(ExcludedFitBlockResult(exclusions.map(_.voxelIndex), series.timepoints, engine, exclusions))
      case other => other

private[fit] final class InterpreterFitContext(val interpreter: FitInterpreter)(
    plan: FitPlan,
    prepared: interpreter.Prepared
) extends PreparedFitContext:
  def engine: FitEngine = interpreter.engine
  protected def execute(series: FmriSeries): Either[FitError, FitBlockResult] =
    interpreter.fitChunk(plan, series, prepared)
  def merge(chunks: IndexedSeq[FitBlockResult]): Either[FitError, FmriFitResult] =
    interpreter.mergeAny(plan, chunks)

private[fit] final class BlockLocalFitContext(
    interpreter: FitInterpreter,
    plan: FitPlan
) extends PreparedFitContext:
  def engine: FitEngine = interpreter.engine
  protected def execute(series: FmriSeries): Either[FitError, FitBlockResult] =
    interpreter.prepare(plan, series).flatMap(interpreter.fitChunk(plan, series, _))
  def merge(chunks: IndexedSeq[FitBlockResult]): Either[FitError, FmriFitResult] =
    interpreter.mergeAny(plan, chunks)

private[fit] trait PreparedSpatialReduction:
  def engine: FitEngine
  def fit(series: FmriSeries): Either[FitError, FitBlockResult]

private[fit] final class SpatialReductionFitContext(
    plan: FitPlan,
    prepared: PreparedSpatialReduction
) extends PreparedFitContext:
  def engine: FitEngine = prepared.engine
  protected def execute(series: FmriSeries): Either[FitError, FitBlockResult] = prepared.fit(series)
  def merge(chunks: IndexedSeq[FitBlockResult]): Either[FitError, FmriFitResult] =
    FitInterpreters.forPlan(plan).flatMap(_.mergeAny(plan, chunks))

/** Guards a context prepared from a completed voxel population, such as pooled AR whitening. Every block must
  * present exactly the finite voxels that preparation retained from it. Otherwise a voxel that contributed to the
  * shared estimate could later vanish (or a new one appear) without trace, so a change is a typed refusal.
  */
private[fit] final class RetainedMembershipFitContext(
    inner: PreparedFitContext,
    retained: Set[Int],
    missingData: scalafim.fmri.model.MissingDataPolicy
) extends PreparedFitContext:
  def engine: FitEngine = inner.engine
  protected def execute(series: FmriSeries): Either[FitError, FitBlockResult] =
    RetainedMembershipFitContext.finiteMembership(series, missingData).flatMap { observed =>
      val expected = series.voxelIndices.filter(retained)
      if observed == expected then inner.fitChunk(series)
      else Left(FitError.PreparationReplayMismatch(
        s"retained voxel membership changed: prepared ${expected.mkString("[", ",", "]")}, read ${observed.mkString("[", ",", "]")}"
      ))
    }
  def merge(chunks: IndexedSeq[FitBlockResult]): Either[FitError, FmriFitResult] =
    inner.merge(chunks)

private[fit] object RetainedMembershipFitContext:
  /** Voxels of one block that the missing-data policy admits to fitting; empty when all are excluded. */
  def finiteMembership(
      series: FmriSeries,
      missingData: scalafim.fmri.model.MissingDataPolicy
  ): Either[FitError, Vector[Int]] =
    MatrixAdapters.responseBlock(series, missingData) match
      case Left(FitError.AllVoxelsExcluded(_)) => Right(Vector.empty)
      case Left(error)                         => Left(error)
      case Right(value)                        => Right(value.voxelIndices)

private[fit] final case class OlsExecutionPrepared(
    solver: OlsPrepared,
    responsePreparation: ResolvedResponsePreparation,
    partitions: Vector[RunPartition]
)

object FitInterpreters:
  private[fit] def olsContext(plan: FitPlan, prepared: OlsExecutionPrepared): PreparedFitContext =
    new InterpreterFitContext(OrdinaryLeastSquares)(plan, prepared)

  private[fit] def glsContext(plan: FitPlan, prepared: GlsPrepared): PreparedFitContext =
    new InterpreterFitContext(GeneralizedLeastSquares)(plan, prepared)

  private[fit] def runwiseGlsContext(plan: FitPlan, prepared: RunwiseGlsPrepared): PreparedFitContext =
    new InterpreterFitContext(RunwiseGeneralizedLeastSquares)(plan, prepared)

  private def bindRankFailure(input: FitBlockInput, error: FitError): FitError =
    input.coefficientAxis match
      case Some(axis) => FitKernel.bindRankFailure(error, axis)
      case None       => error

  def forPlan(plan: FitPlan): Either[FitError, FitInterpreter] =
    plan.strategy match
      case FitStrategy.RunwiseGeneralizedLeastSquares(_, _) => Right(RunwiseGeneralizedLeastSquares)
      case _                                                => forEngine(plan.engine)

  def forEngine(engine: FitEngine): Either[FitError, FitInterpreter] =
    engine match
      case FitEngine.OrdinaryLeastSquares    => Right(OrdinaryLeastSquares)
      case FitEngine.GeneralizedLeastSquares => Right(GeneralizedLeastSquares)
      case FitEngine.RobustLeastSquares      => Right(RobustLeastSquares)
      case FitEngine.RunwiseLeastSquares     => Right(RunwiseLeastSquares)
      case FitEngine.FixedEffects            => Right(SeparateRunsThenFixedEffects)
      case FitEngine.LeastSquaresSeparate    => Right(LeastSquaresSeparate)
      case FitEngine.LatentSketch            => Right(LatentSketch)
      case FitEngine.ReducedRankGls          => Right(ReducedRankGls)

  private def robustAutocorrelation(config: FitConfig): Option[ArOptions] =
    if config.robust.reestimateAutocorrelation then Some(config.autocorrelation) else None

  private def latentSketchConfig(plan: FitPlan): Either[FitError, LatentSketchConfig] =
    plan.strategy match
      case FitStrategy.LatentSketch(sketch, _) => Right(sketch)
      case _ => Left(FitError.UnsupportedEngine(s"${plan.engine} plan does not carry a latent sketch config"))

  private[fit] def reducedRankGlsConfig(plan: FitPlan): Either[FitError, ReducedRankGlsConfig] =
    plan.strategy match
      case FitStrategy.ReducedRankGls(lowRank, _) => Right(lowRank)
      case _ => Left(FitError.UnsupportedEngine(s"${plan.engine} plan does not carry a reduced-rank GLS config"))

  private[fit] def reducedRankDesignPartition(plan: FitPlan): Either[FitError, ReducedRankDesignPartition] =
    val targets = Vector.newBuilder[Int]
    val nuisance = Vector.newBuilder[Int]
    plan.model.designBlock.columns.zipWithIndex.foreach { case (column, index) =>
      column.source match
        case DesignColumnSource.Event =>
          targets += index
        case DesignColumnSource.Baseline =>
          nuisance += index
    }
    ReducedRankDesignPartition.fromColumns(plan.model.nPredictors, targets.result(), nuisance.result())

  private object OrdinaryLeastSquares extends FitInterpreter:
    type Prepared = OlsExecutionPrepared
    type Block = DenseFitBlockResult
    type Result = DenseFmriFitResult

    val engine: FitEngine = FitEngine.OrdinaryLeastSquares

    override private[fit] def prepareFromTimepoints(
        plan: FitPlan,
        timepoints: Vector[Int]
    ): Option[Either[FitError, OlsExecutionPrepared]] =
      plan.config.volumeWeighting match
        case scalafim.fmri.model.VolumeWeighting.Estimated(_) => None
        case _ => Some(FitPreparation.ols(plan, timepoints))

    def fit(plan: FitPlan, series: FmriSeries): Either[FitError, DenseFmriFitResult] =
      val partitions = RunPartition.fromSamplingFrame(plan.model.dataset.samplingFrame, series.timepoints)
      for
        input <- FitPlanExecutor.fitBlockInput(plan, series, partitions = partitions)
        dense <- FitKernel.fitDense(input, engine, plan.config)
      yield FitPlanExecutor.denseResult(plan, dense)

    def prepare(plan: FitPlan, series: FmriSeries): Either[FitError, OlsExecutionPrepared] =
      val partitions = RunPartition.fromSamplingFrame(plan.model.dataset.samplingFrame, series.timepoints)
      for
        raw <- FitPlanExecutor.rawFitBlockInput(plan, series, partitions = partitions)
        responsePreparation <- ResponsePreparationPlan.fromPlan(plan).resolve(raw)
        prepared <- responsePreparation.prepare(raw)
        solver <- Ols.prepare(prepared.input.design).left.map(error => bindRankFailure(prepared.input, error))
      yield OlsExecutionPrepared(solver, responsePreparation, partitions)

    def fitChunk(
        plan: FitPlan,
        series: FmriSeries,
        prepared: OlsExecutionPrepared
    ): Either[FitError, DenseFitBlockResult] =
      for
        input <- FitPlanExecutor.fitBlockInput(
          plan,
          series,
          prepared.partitions,
          prepared.responsePreparation
        )
        fit <- prepared.solver.fit(input.response)
      yield DenseFitBlockResult.fromOls(input, fit, engine)

    def merge(
        plan: FitPlan,
        chunks: IndexedSeq[DenseFitBlockResult]
    ): Either[FitError, DenseFmriFitResult] =
      DenseFitBlockResult.merge(chunks).map(FitPlanExecutor.denseResult(plan, _))

    protected def collect(chunks: IndexedSeq[FitBlockResult]): Either[FitError, IndexedSeq[DenseFitBlockResult]] =
      FitBlockCollectors.dense(chunks)

  private object GeneralizedLeastSquares extends FitInterpreter:
    type Prepared = GlsPrepared
    type Block = DenseFitBlockResult
    type Result = DenseFmriFitResult

    val engine: FitEngine = FitEngine.GeneralizedLeastSquares

    override private[fit] def prepareFromTimepoints(
        plan: FitPlan,
        timepoints: Vector[Int]
    ): Option[Either[FitError, GlsPrepared]] =
      if FitPreparation.fixedAr(plan.config.autocorrelation) then
        Some(FitPreparation.designSeries(plan, timepoints).flatMap(prepare(plan, _)))
      else None

    def fit(plan: FitPlan, series: FmriSeries): Either[FitError, DenseFmriFitResult] =
      val partitions = RunPartition.fromSamplingFrame(plan.model.dataset.samplingFrame, series.timepoints)
      for
        input <- FitPlanExecutor.fitBlockInput(plan, series, partitions = partitions)
        dense <- FitKernel.fitDense(input, engine, plan.config)
      yield FitPlanExecutor.denseResult(plan, dense)

    def prepare(plan: FitPlan, series: FmriSeries): Either[FitError, GlsPrepared] =
      val partitions = RunPartition.fromSamplingFrame(plan.model.dataset.samplingFrame, series.timepoints)
      for
        input <- FitPlanExecutor.fitBlockInput(plan, series, partitions = partitions)
        prepared <- Gls
          .prepare(input.design, input.response, partitions, plan.config.autocorrelation, input.voxelIndices)
          .left
          .map(error => bindRankFailure(input, error))
      yield prepared

    def fitChunk(
        plan: FitPlan,
        series: FmriSeries,
        prepared: GlsPrepared
    ): Either[FitError, DenseFitBlockResult] =
      for
        input <- FitPlanExecutor.fitBlockInput(plan, series, partitions = prepared.partitions)
        fit <- prepared.fit(input.response, input.voxelIndices)
      yield DenseFitBlockResult.fromGls(input, fit)

    def merge(
        plan: FitPlan,
        chunks: IndexedSeq[DenseFitBlockResult]
    ): Either[FitError, DenseFmriFitResult] =
      DenseFitBlockResult.merge(chunks).map(FitPlanExecutor.denseResult(plan, _))

    protected def collect(chunks: IndexedSeq[FitBlockResult]): Either[FitError, IndexedSeq[DenseFitBlockResult]] =
      FitBlockCollectors.dense(chunks)

  private object RunwiseLeastSquares extends FitInterpreter:
    type Prepared = Vector[RunPartition]
    type Block = RunwiseFitBlockResult
    type Result = RunwiseFmriFitResult

    val engine: FitEngine = FitEngine.RunwiseLeastSquares

    def fit(plan: FitPlan, series: FmriSeries): Either[FitError, RunwiseFmriFitResult] =
      val partitions = RunPartition.fromSamplingFrame(plan.model.dataset.samplingFrame, series.timepoints)
      for
        input <- FitPlanExecutor.fitBlockInput(plan, series, partitions = partitions)
        runwise <- FitKernel.fitRunwise(input)
      yield RunwiseFmriFitResult(
        runs = runwise.runs,
        columnNames = plan.model.columnNames,
        voxelIndices = runwise.voxelIndices,
        timepoints = runwise.timepoints,
        engine = engine,
        summary = plan.summary,
        coefficientAxis = runwise.coefficientAxis,
        preparationProvenance = runwise.preparationProvenance,
        fitExclusions = runwise.fitExclusions
      )

    def prepare(plan: FitPlan, series: FmriSeries): Either[FitError, Vector[RunPartition]] =
      Right(RunPartition.fromSamplingFrame(plan.model.dataset.samplingFrame, series.timepoints))

    override private[fit] def prepareFromTimepoints(
        plan: FitPlan,
        timepoints: Vector[Int]
    ): Option[Either[FitError, Vector[RunPartition]]] =
      Some(Right(RunPartition.fromSamplingFrame(plan.model.dataset.samplingFrame, timepoints)))

    def fitChunk(
        plan: FitPlan,
        series: FmriSeries,
        prepared: Vector[RunPartition]
    ): Either[FitError, RunwiseFitBlockResult] =
      for
        input <- FitPlanExecutor.fitBlockInput(plan, series, partitions = prepared)
        runwise <- FitKernel.fitRunwise(input)
      yield runwise

    def merge(
        plan: FitPlan,
        chunks: IndexedSeq[RunwiseFitBlockResult]
    ): Either[FitError, RunwiseFmriFitResult] =
      RunwiseFitBlockResult.merge(chunks).map { merged =>
        RunwiseFmriFitResult(
          runs = merged.runs,
          columnNames = plan.model.columnNames,
          voxelIndices = merged.voxelIndices,
          timepoints = merged.timepoints,
          engine = engine,
          summary = plan.summary,
          coefficientAxis = merged.coefficientAxis,
          preparationProvenance = merged.preparationProvenance,
          fitExclusions = merged.fitExclusions
        )
      }

    protected def collect(chunks: IndexedSeq[FitBlockResult]): Either[FitError, IndexedSeq[RunwiseFitBlockResult]] =
      FitBlockCollectors.runwise(chunks)

  /** Reuse the native GLS preparation and solve independently within every
    * structural run projection. The result remains run-specific even though
    * the numerical engine is GLS.
    */
  private object RunwiseGeneralizedLeastSquares extends FitInterpreter:
    type Prepared = RunwiseGlsPrepared
    type Block = RunwiseFitBlockResult
    type Result = RunwiseFmriFitResult

    val engine: FitEngine = FitEngine.GeneralizedLeastSquares

    override private[fit] def prepareFromTimepoints(
        plan: FitPlan,
        timepoints: Vector[Int]
    ): Option[Either[FitError, RunwiseGlsPrepared]] =
      if FitPreparation.fixedAr(plan.config.autocorrelation) then
        Some(FitPreparation.designSeries(plan, timepoints).flatMap(prepare(plan, _)))
      else None

    def fit(plan: FitPlan, series: FmriSeries): Either[FitError, RunwiseFmriFitResult] =
      val partitions = RunPartition.fromSamplingFrame(plan.model.dataset.samplingFrame, series.timepoints)
      for
        input <- FitPlanExecutor.fitBlockInput(plan, series, partitions = partitions)
        runwise <- RunwiseGls.fit(
          input.design,
          input.response,
          partitions,
          plan.config.autocorrelation,
          input.runwiseProjections
        )
        block = RunwiseFitBlockResult.fromRunwiseGls(input, runwise)
      yield result(plan, block)

    def prepare(plan: FitPlan, series: FmriSeries): Either[FitError, RunwiseGlsPrepared] =
      val partitions = RunPartition.fromSamplingFrame(plan.model.dataset.samplingFrame, series.timepoints)
      for
        input <- FitPlanExecutor.fitBlockInput(plan, series, partitions = partitions)
        prepared <- RunwiseGls.prepare(
          input.design,
          input.response,
          partitions,
          plan.config.autocorrelation,
          input.runwiseProjections,
          input.voxelIndices
        )
      yield prepared

    def fitChunk(
        plan: FitPlan,
        series: FmriSeries,
        prepared: RunwiseGlsPrepared
    ): Either[FitError, RunwiseFitBlockResult] =
      val partitions = RunPartition.fromSamplingFrame(plan.model.dataset.samplingFrame, series.timepoints)
      for
        input <- FitPlanExecutor.fitBlockInput(plan, series, partitions = partitions)
        runwise <- prepared.fit(input.response, input.voxelIndices)
      yield RunwiseFitBlockResult.fromRunwiseGls(input, runwise)

    def merge(
        plan: FitPlan,
        chunks: IndexedSeq[RunwiseFitBlockResult]
    ): Either[FitError, RunwiseFmriFitResult] =
      RunwiseFitBlockResult.merge(chunks).map(result(plan, _))

    protected def collect(chunks: IndexedSeq[FitBlockResult]): Either[FitError, IndexedSeq[RunwiseFitBlockResult]] =
      FitBlockCollectors.runwise(chunks)

    private def result(plan: FitPlan, block: RunwiseFitBlockResult): RunwiseFmriFitResult =
      RunwiseFmriFitResult(
        runs = block.runs,
        columnNames = plan.model.columnNames,
        voxelIndices = block.voxelIndices,
        timepoints = block.timepoints,
        engine = engine,
        summary = plan.summary,
        coefficientAxis = block.coefficientAxis,
        preparationProvenance = block.preparationProvenance,
        fitExclusions = block.fitExclusions
      )

  /** Fit each run with the existing runwise OLS kernel, then combine the
    * resulting coefficient covariances as a fixed-effects estimand.  Keeping
    * the runwise block path here means chunking and multi-response execution
    * reuse the same numerical and boundary checks as RunwiseLeastSquares.
    */
  private object SeparateRunsThenFixedEffects extends FitInterpreter:
    type Prepared = Vector[RunPartition]
    type Block = RunwiseFitBlockResult
    type Result = FixedEffectsFmriFitResult

    val engine: FitEngine = FitEngine.FixedEffects

    def fit(plan: FitPlan, series: FmriSeries): Either[FitError, FixedEffectsFmriFitResult] =
      val partitions = RunPartition.fromSamplingFrame(plan.model.dataset.samplingFrame, series.timepoints)
      for
        input <- FitPlanExecutor.fitBlockInput(plan, series, partitions = partitions)
        runwise <- FitKernel.fitRunwise(input)
        runwiseResult = RunwiseFmriFitResult(
          runs = runwise.runs,
          columnNames = plan.model.columnNames,
          voxelIndices = runwise.voxelIndices,
          timepoints = runwise.timepoints,
          engine = FitEngine.RunwiseLeastSquares,
          summary = plan.summary,
          coefficientAxis = runwise.coefficientAxis,
          preparationProvenance = runwise.preparationProvenance,
          fitExclusions = runwise.fitExclusions
        )
        fixed <- FixedEffects.combine(runwiseResult)
      yield fixed

    def prepare(plan: FitPlan, series: FmriSeries): Either[FitError, Vector[RunPartition]] =
      Right(RunPartition.fromSamplingFrame(plan.model.dataset.samplingFrame, series.timepoints))

    override private[fit] def prepareFromTimepoints(
        plan: FitPlan,
        timepoints: Vector[Int]
    ): Option[Either[FitError, Vector[RunPartition]]] =
      Some(Right(RunPartition.fromSamplingFrame(plan.model.dataset.samplingFrame, timepoints)))

    def fitChunk(
        plan: FitPlan,
        series: FmriSeries,
        prepared: Vector[RunPartition]
    ): Either[FitError, RunwiseFitBlockResult] =
      for
        input <- FitPlanExecutor.fitBlockInput(plan, series, partitions = prepared)
        runwise <- FitKernel.fitRunwise(input)
      yield runwise

    def merge(
        plan: FitPlan,
        chunks: IndexedSeq[RunwiseFitBlockResult]
    ): Either[FitError, FixedEffectsFmriFitResult] =
      for
        merged <- RunwiseFitBlockResult.merge(chunks)
        runwise = RunwiseFmriFitResult(
          runs = merged.runs,
          columnNames = plan.model.columnNames,
          voxelIndices = merged.voxelIndices,
          timepoints = merged.timepoints,
          engine = FitEngine.RunwiseLeastSquares,
          summary = plan.summary,
          coefficientAxis = merged.coefficientAxis,
          preparationProvenance = merged.preparationProvenance,
          fitExclusions = merged.fitExclusions
        )
        fixed <- FixedEffects.combine(runwise)
      yield fixed

    protected def collect(chunks: IndexedSeq[FitBlockResult]): Either[FitError, IndexedSeq[RunwiseFitBlockResult]] =
      FitBlockCollectors.runwise(chunks)

  private object RobustLeastSquares extends FitInterpreter:
    type Prepared = RobustPrepared
    type Block = DenseFitBlockResult
    type Result = DenseFmriFitResult

    val engine: FitEngine = FitEngine.RobustLeastSquares

    def fit(plan: FitPlan, series: FmriSeries): Either[FitError, DenseFmriFitResult] =
      val partitions = RunPartition.fromSamplingFrame(plan.model.dataset.samplingFrame, series.timepoints)
      for
        input <- FitPlanExecutor.fitBlockInput(plan, series, partitions = partitions)
        dense <- FitKernel.fitDense(input, engine, plan.config)
      yield FitPlanExecutor.denseResult(plan, dense)

    def prepare(plan: FitPlan, series: FmriSeries): Either[FitError, RobustPrepared] =
      val partitions = RunPartition.fromSamplingFrame(plan.model.dataset.samplingFrame, series.timepoints)
      for
        input <- FitPlanExecutor.fitBlockInput(plan, series, partitions = partitions)
        prepared <- Robust
          .prepare(input.design, input.response, input.partitions, input.voxelIndices, plan.config.robust, robustAutocorrelation(plan.config))
          .left
          .map(error => bindRankFailure(input, error))
      yield prepared

    def fitChunk(
        plan: FitPlan,
        series: FmriSeries,
        prepared: RobustPrepared
    ): Either[FitError, DenseFitBlockResult] =
      for
        input <- FitPlanExecutor.fitBlockInput(plan, series, partitions = prepared.partitions)
        fit <- Robust.fitPrepared(prepared, input.response, input.voxelIndices)
      yield DenseFitBlockResult.fromRobust(input, fit)

    def merge(
        plan: FitPlan,
        chunks: IndexedSeq[DenseFitBlockResult]
    ): Either[FitError, DenseFmriFitResult] =
      DenseFitBlockResult.merge(chunks).map(FitPlanExecutor.denseResult(plan, _))

    protected def collect(chunks: IndexedSeq[FitBlockResult]): Either[FitError, IndexedSeq[DenseFitBlockResult]] =
      FitBlockCollectors.dense(chunks)

  private object LeastSquaresSeparate extends FitInterpreter:
    type Prepared = LssBlockDesign
    type Block = LssFitBlockResult
    type Result = LssFmriFitResult

    val engine: FitEngine = FitEngine.LeastSquaresSeparate

    def fit(plan: FitPlan, series: FmriSeries): Either[FitError, LssFmriFitResult] =
      for
        input <- FitPlanExecutor.fitBlockInput(plan, series, lssDesign = Some(FitPlanExecutor.lssExecutionDesign(plan, series.timepoints)))
        lss <- FitKernel.fitLss(input)
      yield LssFmriFitResult(
        coefficients = lss.coefficients,
        trialNames = lss.trialNames,
        lssDiagnostics = lss.diagnostics,
        voxelIndices = lss.voxelIndices,
        timepoints = lss.timepoints,
        engine = engine,
        summary = plan.summary,
        coefficientAxis = lss.coefficientAxis,
        preparationProvenance = input.preparationProvenance,
        fitExclusions = input.fitExclusions
      )

    def prepare(plan: FitPlan, series: FmriSeries): Either[FitError, LssBlockDesign] =
      FitPlanExecutor.lssExecutionDesign(plan, series.timepoints)

    override private[fit] def prepareFromTimepoints(
        plan: FitPlan,
        timepoints: Vector[Int]
    ): Option[Either[FitError, LssBlockDesign]] =
      Some(FitPlanExecutor.lssExecutionDesign(plan, timepoints))

    def fitChunk(
        plan: FitPlan,
        series: FmriSeries,
        prepared: LssBlockDesign
    ): Either[FitError, LssFitBlockResult] =
      for
        input <- FitPlanExecutor.fitBlockInput(plan, series, lssDesign = Some(Right(prepared)))
        lss <- FitKernel.fitLss(input)
      yield lss

    def merge(
        plan: FitPlan,
        chunks: IndexedSeq[LssFitBlockResult]
    ): Either[FitError, LssFmriFitResult] =
      LssFitBlockResult.merge(chunks).map { merged =>
        LssFmriFitResult(
          coefficients = merged.coefficients,
          trialNames = merged.trialNames,
          lssDiagnostics = merged.diagnostics,
          voxelIndices = merged.voxelIndices,
          timepoints = merged.timepoints,
          engine = engine,
          summary = plan.summary,
          coefficientAxis = merged.coefficientAxis,
          preparationProvenance = merged.preparationProvenance,
          fitExclusions = merged.fitExclusions
        )
      }

    protected def collect(chunks: IndexedSeq[FitBlockResult]): Either[FitError, IndexedSeq[LssFitBlockResult]] =
      FitBlockCollectors.lss(chunks)

  private object LatentSketch extends FitInterpreter:
    type Prepared = LatentSketchPrepared
    type Block = DenseFitBlockResult
    type Result = DenseFmriFitResult

    val engine: FitEngine = FitEngine.LatentSketch

    def fit(plan: FitPlan, series: FmriSeries): Either[FitError, DenseFmriFitResult] =
      for
        prepared <- prepare(plan, series)
        block <- fitChunk(plan, series, prepared)
      yield FitPlanExecutor.denseResult(plan, block)

    def prepare(plan: FitPlan, series: FmriSeries): Either[FitError, LatentSketchPrepared] =
      for
        sketch <- latentSketchConfig(plan)
        input <- FitPlanExecutor.fitBlockInput(plan, series)
        prepared <- LatentSketchPrepared.prepare(input.design, input.response, input.voxelIndices, sketch)
      yield prepared

    def fitChunk(
        plan: FitPlan,
        series: FmriSeries,
        prepared: LatentSketchPrepared
    ): Either[FitError, DenseFitBlockResult] =
      for
        input <- FitPlanExecutor.fitBlockInput(plan, series)
        fit <- prepared.fitBlock(input)
      yield fit

    def merge(
        plan: FitPlan,
        chunks: IndexedSeq[DenseFitBlockResult]
    ): Either[FitError, DenseFmriFitResult] =
      DenseFitBlockResult.merge(chunks).map(FitPlanExecutor.denseResult(plan, _))

    protected def collect(chunks: IndexedSeq[FitBlockResult]): Either[FitError, IndexedSeq[DenseFitBlockResult]] =
      FitBlockCollectors.dense(chunks)

  private object ReducedRankGls extends FitInterpreter:
    type Prepared = ReducedRankGlsPrepared
    type Block = DenseFitBlockResult
    type Result = DenseFmriFitResult

    val engine: FitEngine = FitEngine.ReducedRankGls

    def fit(plan: FitPlan, series: FmriSeries): Either[FitError, DenseFmriFitResult] =
      for
        prepared <- prepare(plan, series)
        block <- fitChunk(plan, series, prepared)
      yield FitPlanExecutor.denseResult(plan, block)

    def prepare(plan: FitPlan, series: FmriSeries): Either[FitError, ReducedRankGlsPrepared] =
      val partitions = RunPartition.fromSamplingFrame(plan.model.dataset.samplingFrame, series.timepoints)
      for
        config <- reducedRankGlsConfig(plan)
        input <- FitPlanExecutor.fitBlockInput(plan, series, partitions = partitions)
        designPartition <- reducedRankDesignPartition(plan)
        prepared <- ReducedRankGlsPrepared.prepare(input.design, input.response, input.partitions, config, input.voxelIndices, designPartition)
      yield prepared

    def fitChunk(
        plan: FitPlan,
        series: FmriSeries,
        prepared: ReducedRankGlsPrepared
    ): Either[FitError, DenseFitBlockResult] =
      for
        input <- FitPlanExecutor.fitBlockInput(plan, series, partitions = prepared.partitions)
        fit <- prepared.fitBlock(input)
      yield fit

    def merge(
        plan: FitPlan,
        chunks: IndexedSeq[DenseFitBlockResult]
    ): Either[FitError, DenseFmriFitResult] =
      DenseFitBlockResult.merge(chunks).map(FitPlanExecutor.denseResult(plan, _))

    protected def collect(chunks: IndexedSeq[FitBlockResult]): Either[FitError, IndexedSeq[DenseFitBlockResult]] =
      FitBlockCollectors.dense(chunks)

private[fit] object FitBlockCollectors:
  def dense(chunks: IndexedSeq[FitBlockResult]): Either[FitError, Vector[DenseFitBlockResult]] =
    val out = Vector.newBuilder[DenseFitBlockResult]
    var i = 0
    while i < chunks.length do
      chunks(i) match
        case dense: DenseFitBlockResult => out += dense
        case other => return Left(FitError.IncompatibleFitBlocks(s"expected dense fit chunk but got ${other.engine}"))
      i += 1
    Right(out.result())

  def lss(chunks: IndexedSeq[FitBlockResult]): Either[FitError, Vector[LssFitBlockResult]] =
    val out = Vector.newBuilder[LssFitBlockResult]
    var i = 0
    while i < chunks.length do
      chunks(i) match
        case lss: LssFitBlockResult => out += lss
        case other => return Left(FitError.IncompatibleFitBlocks(s"expected LSS fit chunk but got ${other.engine}"))
      i += 1
    Right(out.result())

  def runwise(chunks: IndexedSeq[FitBlockResult]): Either[FitError, Vector[RunwiseFitBlockResult]] =
    val out = Vector.newBuilder[RunwiseFitBlockResult]
    var i = 0
    while i < chunks.length do
      chunks(i) match
        case runwise: RunwiseFitBlockResult => out += runwise
        case other => return Left(FitError.IncompatibleFitBlocks(s"expected runwise fit chunk but got ${other.engine}"))
      i += 1
    Right(out.result())

package scalafim.fmri.hrf

import scalafim.fmri.hrf.{Hrf, Seconds, s}
import scalafim.fmri.hrf.linalg.Mat

object Deriv:

  def apply(
      hrf: Hrf,
      times: Seq[Lag],
      eps: Seconds = 1e-4.s
  ): Mat =
    val nb = hrf.nbasis
    if times.isEmpty then return Mat.zeros(0, nb)

    hrf.descriptor.derivative match
      case DerivativePolicy.Spmg(params, columns) if columns.value == nb =>
        spmg(params, columns, times)
      case _ =>
        numeric(hrf, times, eps)

  private def spmg(params: SpmgParams, columns: BasisCount, times: Seq[Lag]): Mat =
    val nb = columns.value
    if nb == 1 then
      val out = times.map(t => HrfFunctions.spmg1Deriv(t, params.p1, params.p2, params.a1)).toArray
      Mat.unsafe(out.length, 1, out)
    else if nb == 2 then
      val out = new Array[Double](times.length * 2)
      var i = 0
      while i < times.length do
        val t = times(i)
        out(i * 2) = HrfFunctions.spmg1Deriv(t, params.p1, params.p2, params.a1)
        out(i * 2 + 1) = HrfFunctions.spmg1SecondDeriv(t, params.p1, params.p2, params.a1)
        i += 1
      Mat.unsafe(times.length, 2, out)
    else
      val out = new Array[Double](times.length * nb)
      var i = 0
      while i < times.length do
        val t = times(i)
        out(i * nb) = HrfFunctions.spmg1Deriv(t, params.p1, params.p2, params.a1)
        out(i * nb + 1) = HrfFunctions.spmg1SecondDeriv(t, params.p1, params.p2, params.a1)
        out(i * nb + 2) = HrfFunctions.spmg1DispersionTimeDeriv(t, params.p1, params.a1)
        i += 1
      Mat.unsafe(times.length, nb, out)

  private def numeric(hrf: Hrf, times: Seq[Lag], eps: Seconds): Mat =
    val nb = hrf.nbasis
    val h = eps.value
    val out = new Array[Double](times.length * nb)
    var i = 0
    while i < times.length do
      val t = times(i).value
      // A central difference at the origin straddles the causal boundary, so it
      // reports (h(eps) - 0) / 2eps: half the true one-sided slope, and for a
      // kernel with a jump at zero an arbitrarily large spurious value. Step
      // one-sided wherever the stencil would cross a boundary of the support.
      val horizon = hrf.support.horizonOption.map(_.value)
      val crossesStart = t - h < 0.0
      val crossesEnd = horizon.exists(hz => t + h > hz)
      var j = 0
      if crossesStart && !crossesEnd then
        val v0 = hrf(Lag(t)).data
        val v1 = hrf(Lag(t + h)).data
        while j < nb do
          out(i * nb + j) = (v1(j) - v0(j)) / h
          j += 1
      else if crossesEnd && !crossesStart then
        val v0 = hrf(Lag(t - h)).data
        val v1 = hrf(Lag(t)).data
        while j < nb do
          out(i * nb + j) = (v1(j) - v0(j)) / h
          j += 1
      else
        val vp = hrf(Lag(t + h)).data
        val vm = hrf(Lag(t - h)).data
        while j < nb do
          out(i * nb + j) = (vp(j) - vm(j)) / (2.0 * h)
          j += 1
      i += 1
    Mat.unsafe(times.length, nb, out)

  def doubles(hrf: Hrf, times: Seq[Double], eps: Double = 1e-4): Mat =
    apply(hrf, times.map(Lag(_)), eps.s)

import json, os, subprocess, sys, time
from pathlib import Path
root=Path(__file__).resolve().parent
env=dict(os.environ)
env.pop("JAVA_TOOL_OPTIONS", None)
if os.environ.get("SCALAFIM_REPRO_NODE_BIN"):
 env["PATH"]=os.environ["SCALAFIM_REPRO_NODE_BIN"]+os.pathsep+env["PATH"]
env["SBT_WARM_HEAP"]=os.environ.get("SCALAFIM_REPRO_HEAP","3g")
env["SBT_WARM_CPUS"]="2"
name=sys.argv[1]
commands=sys.argv[2:]
started=time.time()
with (root/(name+".log")).open("w") as log:
 result=subprocess.run(["python3","tools/build/sbt-warm",*commands],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
receipt={"commands":commands,"exit_code":result.returncode,"elapsed_seconds":time.time()-started,"source_overrides":[],"requested_heap":env["SBT_WARM_HEAP"],"requested_cpus":2,"node_version":subprocess.check_output(["node","--version"],env=env,text=True).strip()}
(root/(name+".json")).write_text(json.dumps(receipt,indent=2)+"\n")
print(json.dumps(receipt),flush=True)
sys.exit(result.returncode)

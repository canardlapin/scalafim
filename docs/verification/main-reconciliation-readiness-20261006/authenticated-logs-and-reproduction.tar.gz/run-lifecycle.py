import subprocess, sys
from pathlib import Path
root=Path(__file__).resolve().parent
suite="fitJVM/testOnly scalafim.fmri.fit.profile.ParallelBlockExecutorSuite"
commands=[suite]*10+["set fitJVM / coverageEnabled := true"]+[suite]*5+["set fitJVM / coverageEnabled := false"]
result=subprocess.run(["python3",str(root/"run-gate.py"),"lifecycle-final",*commands])
sys.exit(result.returncode)

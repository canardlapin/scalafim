package scalafim.fmri.hrf

/** Select only allocation-free count checks while the budget guards are absent. */
class ConvolutionBudgetMutationSuite extends ConvolutionDiscretizationSuite:
  override def munitTests(): Seq[munit.Test] =
    val names = Set(
      "sample budget includes zero and preserves floor semantics at the boundary",
      "cell budget refuses dimension products before integer multiplication"
    )
    val selected = super.munitTests().filter(test => names.contains(test.name))
    require(selected.map(_.name).toSet == names && selected.size == 2)
    selected

import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import tarfile
import time

repo = Path('/Users/bbuchsbaum/code/scala/scalafim')
evidence = repo / 'docs/verification/convolution-budget-20261005'
work = Path('/private/tmp/scalafim-convolution-budget-20261005')
work.mkdir(exist_ok=True)
evidence.mkdir(parents=True, exist_ok=True)
runs = []
env = dict(os.environ, COURSIER_REPOSITORIES='https://repo.maven.apache.org/maven2')

def run(name, commands, expected=0):
    cmd = ['python3', 'tools/build/sbt-warm', *commands]
    started = time.monotonic()
    with (work / f'{name}.log').open('w') as out:
        process = subprocess.run(cmd, cwd=repo, env=env, stdout=out, stderr=subprocess.STDOUT)
    record = dict(name=name, command=cmd, exit_code=process.returncode, seconds=time.monotonic()-started)
    runs.append(record)
    print(json.dumps(record), flush=True)
    if process.returncode != expected:
        print((work / f'{name}.log').read_text()[-12000:], flush=True)
        raise RuntimeError(f'{name}: expected exit {expected}, got {process.returncode}')

run('focused-jvm', ['hrfJVM/testOnly scalafim.fmri.hrf.ConvolutionDiscretizationSuite', 'designJVM/testOnly scalafim.fmri.design.event.EventResponseConvolutionSuite'])
run('focused-js', ['hrfJS/testOnly scalafim.fmri.hrf.ConvolutionDiscretizationSuite', 'designJS/testOnly scalafim.fmri.design.event.EventResponseConvolutionSuite'])

policy = repo / 'modules/hrf/shared/src/main/scala/scalafim/fmri/hrf/regressor/ConvolutionDiscretization.scala'
selector = repo / 'modules/hrf/shared/src/test/scala/scalafim/fmri/hrf/ConvolutionBudgetMutationSuite.scala'
original = policy.read_text()
mutated = original.replace(' || requested > MaxGridSamples.toDouble', '').replace(' || requested > MaxArrayCells.toDouble', '')
assert original != mutated and mutated.count('if !requested.isFinite then') == 2
selector_source = '''package scalafim.fmri.hrf

/** Select only allocation-free count checks while the budget guards are absent. */
class ConvolutionBudgetMutationSuite extends ConvolutionDiscretizationSuite:
  override def munitTests(): Seq[munit.Test] =
    val names = Set(
      "sample budget includes zero and preserves floor semantics at the boundary",
      "cell budget refuses dimension products before integer multiplication"
    )
    val selected = super.munitTests().filter(test => names.contains(test.name))
    require(selected.map(_.name).toSet == names && selected.size == 2)
    selected
'''
(work / 'ConvolutionBudgetMutationSuite.scala').write_text(selector_source)
try:
    selector.write_text(selector_source)
    policy.write_text(mutated)
    run('mutation-jvm', ['hrfJVM/testOnly scalafim.fmri.hrf.ConvolutionBudgetMutationSuite'], expected=1)
    run('mutation-js', ['hrfJS/testOnly scalafim.fmri.hrf.ConvolutionBudgetMutationSuite'], expected=1)
finally:
    policy.write_text(original)
    selector.unlink(missing_ok=True)

run('focused-restored', ['hrfJVM/testOnly scalafim.fmri.hrf.ConvolutionDiscretizationSuite', 'hrfJS/testOnly scalafim.fmri.hrf.ConvolutionDiscretizationSuite', 'designJVM/testOnly scalafim.fmri.design.event.EventResponseConvolutionSuite', 'designJS/testOnly scalafim.fmri.design.event.EventResponseConvolutionSuite'])
source_paths = [
    'modules/hrf/shared/src/main/scala/scalafim/fmri/hrf/regressor/ConvolutionDiscretization.scala',
    'modules/hrf/shared/src/main/scala/scalafim/fmri/hrf/regressor/Regressor.scala',
    'modules/hrf/shared/src/test/scala/scalafim/fmri/hrf/ConvolutionDiscretizationSuite.scala',
    'modules/design/shared/src/main/scala/scalafim/fmri/design/event/EventTerm.scala',
    'modules/design/shared/src/main/scala/scalafim/fmri/design/event/EventResponseConvolution.scala',
    'modules/design/shared/src/test/scala/scalafim/fmri/design/event/EventResponseConvolutionSuite.scala'
]
(work / 'runs.json').write_text(json.dumps(runs, indent=2) + '\n')
(work / 'verify.py').write_text(Path(__file__).read_text())
for source in source_paths:
    (work / Path(source).name).write_bytes((repo / source).read_bytes())
with tarfile.open(evidence / 'logs.tar.gz', 'w:gz') as archive:
    for path in sorted(work.iterdir()):
        archive.add(path, arcname=path.name)
receipt = dict(
    mote='bd-01M477F67P8ZJKHSCWSPCECG85',
    verified_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    base_commit=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip(),
    behavior='Kernel and drive grids are refused above 1,000,001 samples before Int conversion; complete kernel and rendered arrays are refused above 4,000,004 cells before dimension multiplication or allocation. Typed preparation, prepared evaluation and EventResponseConvolution expose ConvolutionError; legacy wrappers throw IllegalArgumentException.',
    limitation='These caps bound sampled allocations, not the direct convolution multiply/add count, which depends on active drive bins and kernel length.',
    source_sha256={source: hashlib.sha256((repo/source).read_bytes()).hexdigest() for source in source_paths},
    mutation=dict(change='Removed only the two finite count cap predicates, retaining input and finite-count validation.', selector='Two existing allocation-free count regressions, one for the sample cap and one for the cell cap.', expected='Both regressions fail on each platform.', restored=policy.read_text()==original, temporary_selector_removed=not selector.exists()),
    runs=runs,
    archive_sha256=hashlib.sha256((evidence/'logs.tar.gz').read_bytes()).hexdigest()
)
(evidence / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt, indent=2), flush=True)

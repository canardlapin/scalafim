from pathlib import Path
import subprocess, os, json, time, hashlib
root = Path('/Users/bbuchsbaum/code/scala/scalafim')
logs = Path('/private/tmp/scalafim-quadrature-verification')
logs.mkdir(exist_ok=True)
source = root / 'modules/hrf/shared/src/main/scala/scalafim/fmri/hrf/Pulse.scala'
selector = root / 'modules/hrf/shared/src/test/scala/scalafim/fmri/hrf/QuadratureMutationSuite.scala'
original = source.read_text()
needle = 'if !intervals.isFinite || intervals > MaxBoxIntervals.toDouble then'
assert original.count(needle) == 1
assert not selector.exists()
selector_text = '''package scalafim.fmri.hrf

/** Select only bounded allocations while the production work guard is absent. */
class QuadratureMutationSuite extends QuadratureSuite:
  override def munitTests(): Seq[munit.Test] =
    val names = Set(
      "box quadrature refuses one interval above its work limit",
      "box quadrature counts the partial endpoint against the budget"
    )
    val selected = super.munitTests().filter(t => names.contains(t.name))
    require(selected.map(_.name).toSet == names && selected.size == 2)
    selected
'''
(logs / 'QuadratureMutationSuite.scala').write_text(selector_text)
results = []
env = dict(os.environ, COURSIER_REPOSITORIES='https://repo.maven.apache.org/maven2')
def run(name, tasks):
    command = ['python3', 'tools/build/sbt-warm', *tasks]
    start = time.monotonic()
    with (logs / (name + '.log')).open('w') as out:
        proc = subprocess.run(command, cwd=root, env=env, stdout=out, stderr=subprocess.STDOUT)
    row = dict(name=name, command=command, exit_code=proc.returncode, seconds=time.monotonic()-start)
    results.append(row)
    (logs / 'runs.json').write_text(json.dumps(results, indent=2)+'\n')
    print(json.dumps(row), flush=True)
    return proc.returncode
try:
    source.write_text(original.replace(needle, 'if !intervals.isFinite then'))
    selector.write_text(selector_text)
    for platform in ['JVM','JS']:
        status = run('mutation-' + platform.lower(), [f'hrf{platform}/testOnly scalafim.fmri.hrf.QuadratureMutationSuite'])
        content = (logs / ('mutation-' + platform.lower() + '.log')).read_text()
        assert status != 0 and 'Failed: Total 2, Failed 2' in content, content[-6000:]
finally:
    source.write_text(original)
    selector.unlink(missing_ok=True)
assert source.read_text() == original
for name, tasks in [('hrf-restored', ['hrfJVM/test', 'hrfJS/test']), ('design-restored', ['designJVM/test', 'designJS/test'])]:
    assert run(name, tasks) == 0, name
print('Restored source; both mutations detected; full HRF and design suites passed on JVM and JS.', flush=True)

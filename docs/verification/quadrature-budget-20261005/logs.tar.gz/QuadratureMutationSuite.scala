package scalafim.fmri.hrf

/** Select only bounded allocations while the production work guard is absent. */
class QuadratureMutationSuite extends QuadratureSuite:
  override def munitTests(): Seq[munit.Test] =
    val names = Set(
      "box quadrature refuses one interval above its work limit",
      "box quadrature counts the partial endpoint against the budget"
    )
    val selected = super.munitTests().filter(t => names.contains(t.name))
    require(selected.map(_.name).toSet == names && selected.size == 2)
    selected

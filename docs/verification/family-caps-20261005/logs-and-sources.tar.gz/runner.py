from pathlib import Path
import subprocess,os,re,json,time
root=Path('/Users/bbuchsbaum/code/scala/scalafim')
logs=Path('/private/tmp/scalafim-family-caps-integrated-20261005'); logs.mkdir(exist_ok=True)
env=dict(os.environ,COURSIER_REPOSITORIES='https://repo.maven.apache.org/maven2')
gates=[('hrf-design',['hrfJVM/test','hrfJS/test','designJVM/test','designJS/test']),
 ('fit',['fitJVM/test','fitJS/test']),
 ('observed-family-consumers',['firstLevelLawsJVM/testOnly scalafim.fmri.laws.profile.ObservedFamilyAdmissionSuite scalafim.fmri.laws.profile.ObservedFamilyCertificationSuite','firstLevelLawsJS/testOnly scalafim.fmri.laws.profile.ObservedFamilyAdmissionSuite scalafim.fmri.laws.profile.ObservedFamilyCertificationSuite'])]
rows=[]
allowed="[warn] multiple main classes detected: run 'show discoveredMainClasses' to see the list"
for label,tasks in gates:
 command=['python3','tools/build/sbt-warm',*tasks]; start=time.monotonic()
 with (logs/(label+'.log')).open('w') as out:
  result=subprocess.run(command,cwd=root,env=env,stdout=out,stderr=subprocess.STDOUT)
 contents=(logs/(label+'.log')).read_text()
 counts=[dict(total=int(m[0]),failed=int(m[1]),errors=int(m[2]),passed=int(m[3])) for m in re.findall(r'(?:Passed|Failed): Total (\d+), Failed (\d+), Errors (\d+), Passed (\d+)',contents)]
 warnings=[line for line in contents.splitlines() if line.startswith('[warn]')]
 row=dict(label=label,command=command,exit_code=result.returncode,seconds=round(time.monotonic()-start,3),counts=counts,
  compiler_warnings=[w for w in warnings if w!=allowed],sbt_diagnostics=[w for w in warnings if w==allowed])
 rows.append(row); (logs/'runs.json').write_text(json.dumps(rows,indent=2)+'\n'); print(json.dumps(row),flush=True)
 if result.returncode: raise SystemExit(result.returncode)
 assert len(counts)==len(tasks) and not row['compiler_warnings'],label
 assert all(c['failed']==0 and c['errors']==0 and c['passed']>0 for c in counts),label
print('All final JVM/JS gates passed, no compiler warnings.',flush=True)

# ScalaFIM IO local handoff — 2026-09-30, temporal zero-step revision

This bundle preserves the local provider and consumer candidates and their raw evidence. It is not an upstream release or a qualified dependency pin.

## Exact source

* image4s provider: base `26a74ad99b9ee49a9555344e19b82d69a2ba50e4` → `2695f891cbec31a7f565a9b39e2554fe3b6d4b40` (four commits; previous checkpoint `e0d720f4b968f7d6deeac6978aa986e75dc2f721`).
* ScalaFIM consumer: base `04a6879828f5a7b429f679bd69c8b334815bc9b3` → `52b26c524a73db672d49029ed1f6ea62ec18de28` (three commits; previous image checkpoint `46d36b287ad3fe15c746e0f45766ac5c5887e062`, estimate checkpoint `a2be4223cf51d74cc78bdde82c48bec7944e1222`).

`source/*.bundle` contains exact commit objects relative to the listed bases. `source/*.mbox` is a readable, binary-safe patch series. `source/identity.json` lists every changed path and SHA256. To verify and import in repositories containing the base commits:

```
git -C IMAGE4S_REPO bundle verify source/provider.bundle
git -C IMAGE4S_REPO fetch source/provider.bundle HEAD
git -C SCALAFIM_REPO bundle verify source/consumer.bundle
git -C SCALAFIM_REPO fetch source/consumer.bundle HEAD
```

Check `FETCH_HEAD` against the corresponding `head` in `source/identity.json` before using either candidate. The exact local ScalaFIM build used `-Dscalafim.image4s.build=/private/tmp/scalafim-execution-20260929/image4s-provider`; no `build.sbt` pin change is included.

## Evidence

Raw logs and runner metadata are under `receipts/tests/`. The pre-fix standalone clone at provider checkpoint `e0d720f4` plus `source/pre-fix-reproducer.patch` produced the expected failure: the new zero-step test failed, while the other 14 semantic tests passed (`io-provider-zero-repro-r4.log`). Earlier attempts stopped before tests because of sandbox cache access and sbt Git-plugin worktree initialization; they are not behavioral evidence.

At the refreshed provider and consumer heads, the complete provider NIfTI suites passed JVM 59/59 and JS 40/40 (`io-provider-zero-final-r2.log`); ScalaFIM image passed JVM 380/380 and JS 351/351 (`io-image-zero-final-r2.log`). Both commands exited 0, and neither raw log contains compiler warnings. The regression covers default ordinal reading, typed refusal for each of the three unknown-unit physical assumptions at raw pixdim4=0, and unchanged positive-step assumptions with nonzero origin. The previous provider/header test already covers known physical units with zero step.

Earlier estimate IO results (JVM 17/17, JS 4/4), independent full-bundle reads (3/3 JVM: effects-only, statistic-only, deficient-rank), and the warning-clean `scalafimCompileAll` receipt remain packaged as prior-candidate evidence. The compile-all run preceded the previous ordinal Time read reidentification and this zero-step change; full image JVM/JS tests subsequently compiled and exercised both changes.

`receipts/crash-receipt.json` records 12/12 actions: four boundaries, each with a fresh JVM seed, forced halt, and fresh JVM readback. Each listed raw log is copied to `receipts/crash-logs/` under its basename. The receipt's absolute raw-log paths refer to the original execution root. This is not power-loss durability evidence. Its `classpath_sha256` hashes the classpath string, not the contents of the referenced binaries.

The test metadata documents which source checkout was used for each command. It does not cryptographically bind every loaded class to a source commit. Older estimate, independent-bundle, crash, and compile receipts remain historical evidence from the prior candidate, not reruns at the refreshed heads.

`SHA256SUMS` covers every packaged file except itself. The adjacent `.tar.gz.sha256` checks the transport archive.

## Retained gates

The wire discriminator remains `scalafim-estimates-development-1`. HDF5 needs a qualified bounded generic slice-write provider; current jhdf 0.12.0 lacks that write capability. Compact covariance/support metadata, producer/exporter replacement, workflow and pinned group references, broader access/performance and power-loss qualification remain open. The temporal ticket requires upstream provider publication and an exact qualified ScalaFIM pin. Neither ticket is closed by this bundle.

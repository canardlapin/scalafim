import json,os,subprocess,sys,time
from pathlib import Path
root=Path('/private/tmp/scalafim-plan-fixture-producer-20261006')
evidence=Path('/private/tmp/scalafim-plan-fixture-evidence-20261006')
label=sys.argv[1];commands=sys.argv[2:]
env=dict(os.environ);env['SBT_WARM_HEAP']='4g'
command=['python3','tools/build/sbt-warm',*commands]
start=time.time()
with (evidence/(label+'.log')).open('w') as output:
 result=subprocess.run(command,cwd=root,env=env,stdin=subprocess.DEVNULL,stdout=output,stderr=subprocess.STDOUT)
record={'command':command,'cwd':str(root),'exit_code':result.returncode,'elapsed_seconds':time.time()-start,'requested_heap':'4g','log':str(evidence/(label+'.log'))}
(evidence/(label+'.json')).write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record),flush=True);print((evidence/(label+'.log')).read_text()[-6000:],flush=True)
sys.exit(result.returncode)

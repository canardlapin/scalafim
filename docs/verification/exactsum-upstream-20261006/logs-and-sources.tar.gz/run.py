import json,os,subprocess,sys,time
from pathlib import Path
root=Path('/private/tmp/scalafim-exactsum-gale-20261006')
evidence=Path('/private/tmp/scalafim-exactsum-evidence-20261006')
label=sys.argv[1]
commands=sys.argv[2:]
cache=Path('/private/tmp/scalafim-exactsum-cache-20261006')
cache.mkdir(exist_ok=True)
env=dict(os.environ)
env['COURSIER_CACHE']=str(cache/'coursier')
env['SBT_OPTS']=f'-Xmx3g -XX:ActiveProcessorCount=4 -Dsbt.global.base={cache}/global -Dsbt.boot.directory={cache}/boot -Dsbt.ivy.home={cache}/ivy -Dsbt.server.autostart=false -Dsbt.supershell=false -Dsbt.color=false'
env['TERM']='dumb'
start=time.time()
command=['sbt','-batch',*commands]
with (evidence/(label+'.log')).open('w') as output:
 result=subprocess.run(command,cwd=root,env=env,stdin=subprocess.DEVNULL,stdout=output,stderr=subprocess.STDOUT)
record={'command':command,'cwd':str(root),'exit_code':result.returncode,'elapsed_seconds':time.time()-start,'heap':'3g','cpus':4,'isolated_cache':str(cache),'log':str(evidence/(label+'.log'))}
(evidence/(label+'.json')).write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record),flush=True)
print((evidence/(label+'.log')).read_text()[-7000:],flush=True)
sys.exit(result.returncode)

import json, os, subprocess, sys, time
from pathlib import Path
root=Path(__file__).resolve().parent
env=dict(os.environ)
env["JAVA_TOOL_OPTIONS"]="-Dscalafim.gale.build=/private/tmp/scalafim-exactsum-gale-20261006"
env["SBT_WARM_HEAP"]="3g"
env["SBT_WARM_CPUS"]="2"
name=sys.argv[1]
commands=sys.argv[2:]
started=time.time()
with (root/(name+".log")).open("w") as log:
 result=subprocess.run(["python3","tools/build/sbt-warm",*commands],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
receipt={"commands":commands,"exit_code":result.returncode,"elapsed_seconds":time.time()-started,"gale_override":env["JAVA_TOOL_OPTIONS"],"heap":"3g","cpus":2}
(root/(name+".json")).write_text(json.dumps(receipt,indent=2)+"\n")
print(json.dumps(receipt),flush=True)
sys.exit(result.returncode)

from pathlib import Path
import subprocess, os, re, json, time, hashlib

root = Path('/Users/bbuchsbaum/code/scala/scalafim')
logs = Path('/private/tmp/scalafim-atlas-isolation-20261006')
java_home = subprocess.check_output(['/usr/libexec/java_home', '-v', '21'], text=True).strip()
env = dict(os.environ, COURSIER_REPOSITORIES='https://repo.maven.apache.org/maven2', TEMPLATEFLOW_HOME='/private/tmp/scalafim-templateflow-20261006')
cache = '/private/tmp/scalafim-templateflow-20261006'
gates = [
    ('configure', ['show atlasJVM / Test / testGrouping', 'show atlasJS / Test / fork']),
    ('warm-parent', ['imageJVM/test', 'surfaceJVM/test']),
    ('atlas-jvm', ['atlasJVM/test']),
    ('native-repeat', ['atlasJVM/testOnly scalafim.atlas.io.MniTemplateBridgeFilesSuite']),
    ('ordinary-after', ['atlasJVM/testOnly scalafim.atlas.MniTemplateBridgeSuite']),
    ('atlas-js', ['atlasJS/test'])
]
rows = []
processes = {}
for label, tasks in gates:
    command = ['python3', 'tools/build/sbt-warm', *tasks]
    start = time.monotonic()
    observed = set()
    with (logs / (label + '.log')).open('w') as out:
        process = subprocess.Popen(command, cwd=root, env=env, stdout=out, stderr=subprocess.STDOUT)
        while process.poll() is None:
            listing = subprocess.check_output(['ps', '-axo', 'pid=,ppid=,rss=,args='], text=True)
            for line in listing.splitlines():
                parts = line.strip().split(None, 3)
                if len(parts) != 4:
                    continue
                pid, ppid, rss = map(int, parts[:3])
                args = parts[3]
                native = 'sbt.ForkMain' in args
                server = 'sbt-launch' in args and '-Dsbt.global.base=/Users/bbuchsbaum/.cache/scalafim-sbt/bases/1afc292237c3fa1b' in args
                if not native and not server:
                    continue
                observed.add(pid)
                if pid not in processes:
                    flags = subprocess.run([java_home + '/bin/jcmd', str(pid), 'VM.flags'], capture_output=True, text=True, timeout=15)
                    processes[pid] = dict(pid=pid, ppid=ppid, role='native-child' if native else 'warm-server',
                                          command=args, flags_exit_code=flags.returncode, flags=flags.stdout,
                                          flags_stderr=flags.stderr, peak_sampled_rss_kib=rss, gates=[])
                record = processes[pid]
                record['peak_sampled_rss_kib'] = max(record['peak_sampled_rss_kib'], rss)
                if label not in record['gates']:
                    record['gates'].append(label)
            time.sleep(0.25)
    contents = (logs / (label + '.log')).read_text()
    counts = [dict(total=int(m[0]), failed=int(m[1]), errors=int(m[2]), passed=int(m[3]))
              for m in re.findall(r'(?:Passed|Failed): Total (\d+), Failed (\d+), Errors (\d+), Passed (\d+)', contents)]
    skipped = [line for line in contents.splitlines() if '==> s ' in line or 'skipped' in line.lower()]
    warnings = [line for line in contents.splitlines() if line.startswith('[warn]')]
    row = dict(label=label, command=command, exit_code=process.returncode, seconds=round(time.monotonic()-start, 3),
               counts=counts, skipped=skipped, warnings=warnings, observed_pids=sorted(observed))
    rows.append(row)
    (logs/'runs.json').write_text(json.dumps(rows, indent=2)+'\n')
    (logs/'processes.json').write_text(json.dumps(list(processes.values()), indent=2)+'\n')
    print(json.dumps(row), flush=True)
    assert process.returncode == 0, label
    if label != 'configure':
        assert len(counts) == len(tasks), (label, counts)
        assert all(c['failed'] == 0 and c['errors'] == 0 and c['passed'] > 0 for c in counts), label
        assert not warnings, (label, warnings)
    if label == 'native-repeat':
        assert counts[0] == dict(total=8, failed=0, errors=0, passed=8) and not skipped
servers = [p for p in processes.values() if p['role']=='warm-server']
children = [p for p in processes.values() if p['role']=='native-child']
assert len(servers)==1, servers
assert len(children)==2, children
assert all(p['flags_exit_code']==0 and 'MaxHeapSize=3221225472' in p['flags'] and 'ActiveProcessorCount=2' in p['flags'] for p in children)
assert not any(p['role']=='native-child' and 'ordinary-after' in p['gates'] for p in processes.values())
for child in children:
    assert subprocess.run(['ps', '-p', str(child['pid'])], capture_output=True).returncode != 0
assert subprocess.run(['ps', '-p', str(servers[0]['pid'])], capture_output=True).returncode == 0
print('Asset-backed oracle passed twice in distinct bounded children; warm server survived unchanged.', flush=True)

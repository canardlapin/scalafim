from pathlib import Path
import subprocess, json, shlex, time

logs = Path('/private/tmp/scalafim-atlas-isolation-20261006')
java_home = subprocess.check_output(['/usr/libexec/java_home','-v','21'], text=True).strip()
server_pid = 60188
records = {}
deadline = time.monotonic() + 600
while time.monotonic() < deadline:
    listing = subprocess.check_output(['ps','-axo','pid=,ppid=,rss=,args='], text=True)
    for line in listing.splitlines():
        pieces = line.strip().split(None, 3)
        if len(pieces) != 4:
            continue
        pid, ppid, rss = map(int, pieces[:3])
        args = pieces[3]
        if ppid != server_pid or '/bin/java ' not in args:
            continue
        tokens = shlex.split(args)
        expanded = '\n'.join(Path(t[1:]).read_text() for t in tokens if t.startswith('@') and Path(t[1:]).is_file())
        if 'sbt.ForkMain' not in expanded and 'sbt.ForkMain' not in args:
            continue
        record = records.setdefault(pid, dict(pid=pid,ppid=ppid,role='native-child',peak_sampled_rss_kib=0,flags_exit_code=1))
        record['peak_sampled_rss_kib'] = max(record['peak_sampled_rss_kib'],rss)
        if record['flags_exit_code'] != 0:
            result = subprocess.run([java_home+'/bin/jcmd',str(pid),'VM.flags'],capture_output=True,text=True,timeout=15)
            record.update(flags_exit_code=result.returncode,flags=result.stdout,flags_stderr=result.stderr)
    (logs/'child-processes.json').write_text(json.dumps(list(records.values()),indent=2)+'\n')
    runs = json.loads((logs/'runs.json').read_text())
    if any(r['label']=='atlas-js' for r in runs):
        break
    time.sleep(0.25)
assert len(records)==2,records
assert all(r['flags_exit_code']==0 and 'MaxHeapSize=3221225472' in r['flags'] and 'ActiveProcessorCount=2' in r['flags'] for r in records.values())
assert all(subprocess.run(['ps','-p',str(pid)],capture_output=True).returncode!=0 for pid in records)
print('Two argfile-launched native children verified and exited.',flush=True)

package scalafim.fmri.hrf.family

import scalafim.fmri.hrf.{PositiveSeconds, Seconds}

class FamilySummaryMutationSuite extends munit.FunSuite:
  private def positive(value: Double): PositiveSeconds = PositiveSeconds(value).toOption.get

  test("tail sample cap mutation is detected at one extra sample"):
    val result = FamilySummaryGrid.tail(positive(250000.0), positive(1.0), 4.0)
    assertEquals(result, Left(FamilySummaryError.SampleLimitExceeded(1000001.0, FamilySummaryGrid.MaxSamples)))

  test("LWU sample cap mutation is detected at one extra sample"):
    val family = LwuFamily.make(horizon = Seconds(10000.0)).toOption.get
    val point = family.chart.point(6.0, math.log(2.0), 0.4).toOption.get
    assertEquals(family.summariesEither(point), Left(FamilySummaryError.SampleLimitExceeded(1000001.0, FamilySummaryGrid.MaxSamples)))

  test("finite last lag mutation is detected with three safe samples"):
    val result = FamilySummaryGrid.tail(positive(1e308), positive(1e308), 1.1)
    assert(result.swap.exists(_.isInstanceOf[FamilySummaryError.NonFiniteLastTime]))

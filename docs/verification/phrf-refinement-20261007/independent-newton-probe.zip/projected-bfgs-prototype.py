import importlib.util,json,time
from pathlib import Path
s=importlib.util.spec_from_file_location('reference',Path('/private/tmp/scalafim-phrf-checkpoint-20261007/tools/verification/phrf-recovery/reference.py'))
m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
np=m.np
r=m.Reference(Path('/private/tmp/scalafim-phrf-checkpoint-20261007/target/phrf-recovery-input'))
def solve(evaluate,start):
 x=start.copy();f,g=evaluate(x);H=np.eye(len(x));calls=1; resets=0
 for iteration in range(300):
  active=((x<=0)&(g>0))|((x>=1)&(g<0));pg=g.copy();pg[active]=0
  if max(abs(pg))<1e-10: return x,f,'stationary',iteration,calls
  d=-H@pg;d[((x<=0)&(d<0))|((x>=1)&(d>0))]=0
  if g@d >= -1e-12*np.linalg.norm(pg)*np.linalg.norm(d): d=-pg;H=np.eye(len(x));resets+=1
  accepted=False
  for attempt in range(30):
   candidate=np.clip(x+2.**(-attempt)*d,0,1);step=candidate-x; slope=g@step
   if slope>=0 or not np.any(step):continue
   fn,gn=evaluate(candidate);calls+=1
   if fn<=f+1e-4*slope:
    accepted=True;break
  if not accepted:return x,f,'line',iteration,calls
  nextActive=((candidate<=0)&(gn>0))|((candidate>=1)&(gn<0))
  y=gn-g;y[active]=0;ys=y@step
  if np.any(active!=nextActive):H=np.eye(len(x));ys=0
  if ys>1e-12*np.linalg.norm(step)*np.linalg.norm(y):
   Hy=H@y;H+=((1+y@Hy/ys)/ys)*np.outer(step,step)-(np.outer(step,Hy)+np.outer(Hy,step))/ys
  else: pass
  x=candidate;f=fn;g=gn
 return x,f,'iterations',300,calls
rows=[]
for ratio,voxel in [(0.1,10),(1.,3),(2.,11)]:
 _,scale,evaluate=r.problem(ratio,voxel)
 out=[]
 for start in r.starts:
  x,f,status,it,ev=solve(evaluate,start);out.append(dict(x=x.tolist(),energy=f*scale,status=status,iterations=it,evaluations=ev))
 best=min(out,key=lambda z:z['energy']);print(ratio,voxel,best,flush=True);rows.append(dict(noiseRatio=ratio,voxel=voxel,runs=out))
Path('/private/tmp/phrf-box-prototype.json').write_text(json.dumps(rows,indent=2))

package scalafim.fmri.fit.profile

import java.nio.file.{Files, Path}
import gale.linalg.DMat
import scalafim.fmri.design.hrf.KernelBasisCompilation
import scalafim.fmri.laws.profile.{DecodedTrialCheckpoint, TrialRecoveryFixture}

/** Diagnostic independent Newton trajectories; not public-path qualification. */
object TrialRefinementProbe:
  def main(args: Array[String]): Unit =
    require(args.length == 1, "output.json")
    val f = DecodedTrialCheckpoint.fixture(
      DecodedTrialCheckpoint.Config(
        DecodedTrialCheckpoint.Geometry.B0Dense,
        16,
        compilation = KernelBasisCompilation.BlockedPartial(96)
      )
    )
    val ladder = TrialRecoveryFixture(f)
    val nuisance = DMat.tabulate(f.rows, f.nuisance)((t, j) => f.baseline.designMatrix(t, j))
    val prep = TrialBandedPreparation
      .prepare(f.expanded, Some(f.whitening), Some(nuisance), 1.0)
      .fold(e => throw new IllegalArgumentException(e.message), identity)
    val chart = f.plan.basis.family.chart
    val objective = prep
      .objective(NodeGrid(chart, Vector(2, 2, 2)))
      .fold(e => throw new IllegalArgumentException(e.message), identity)
    val budget = DecodeBudget(
      maxNewtonSteps = 16,
      maxJets = 20,
      maxExactEvaluations = 40,
      maxCandidateAttempts = 12,
      stationarityStepTolerance = 1e-6
    )
    val decoder = new ShapeDecoder(objective, budget, None, 1.0)
    val starts = Vector(Vector.fill(3)(0.5)) ++ Vector.tabulate(8)(i =>
      Vector.tabulate(3)(j => if (i & (1 << j)) == 0 then 0.25 else 0.75)
    )
    val rows = ujson.Arr()
    TrialRecoveryFixture.noiseRatios.foreach: ratio =>
      val response = ladder.whiten(ladder.response(ratio))
      var voxel = 0
      while voxel < 16 do
        val runs = ujson.Arr()
        starts.foreach: start =>
          objective.pointAt(
            prep
              .encodeWhitened(Array.tabulate(f.rows)(t => response(t, voxel)))
              .fold(e => throw new IllegalArgumentException(e.message), identity)
          )
          val counters = new DecoderCounters
          val coordinates = start.indices.map(i => chart.lower(i) + start(i) * chart.width(i)).toVector
          val result = decoder.decodeFrom(counters, coordinates)
          runs.value += ujson.Obj(
            "start" -> ujson.Arr.from(start),
            "coordinates" -> ujson.Arr.from(result.coordinates),
            "energy" -> result.energy,
            "status" -> result.status.toString,
            "jets" -> counters.jets,
            "exact" -> counters.exactEvaluations,
            "steps" -> counters.newtonSteps,
            "candidates" -> counters.candidateAttempts
          )
        rows.value += ujson.Obj("noiseRatio" -> ratio, "voxel" -> voxel, "runs" -> runs)
        voxel += 1
      println(s"completed ratio=$ratio")
    val _ = Files.writeString(
      Path.of(args(0)),
      ujson.write(
        ujson.Obj("qualification" -> "not-admitted", "budgetPerStart" -> budget.toString, "records" -> rows),
        indent = 2
      ) + "\n"
    )

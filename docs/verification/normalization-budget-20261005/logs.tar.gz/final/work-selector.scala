package scalafim.fmri.hrf

/** Guards absent: sentinels stop at the first evaluation, never large work. */
class NormalizationBudgetMutationSuite extends NormalizationReferenceGridSuite:
  override def munitTests(): Seq[munit.Test] =
    val names = Set(
      "block normalization refuses composite quadrature work before evaluation",
      "work budget includes basis columns and admits the exact boundary",
      "block work budget covers exact piecewise integration with coarse precision"
    )
    val selected = super.munitTests().filter(t => names.contains(t.name))
    require(selected.map(_.name).toSet == names && selected.size == 3)
    selected

package scalafim.fmri.hrf

/** Guards absent: sentinels stop at the first evaluation, never large work. */
class NormalizationBudgetMutationSuite extends NormalizationReferenceGridSuite:
  override def munitTests(): Seq[munit.Test] =
    val names = Set(
      "empty exact pieces still charge the returned vector width without allocation",
      "incomplete component metadata cannot hide output basis width"
    )
    val selected = super.munitTests().filter(t => names.contains(t.name))
    require(selected.map(_.name).toSet == names && selected.size == 2)
    selected

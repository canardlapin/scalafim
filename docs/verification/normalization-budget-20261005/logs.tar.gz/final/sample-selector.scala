package scalafim.fmri.hrf

/** Guards absent: sentinels stop at the first evaluation, never large work. */
class NormalizationBudgetMutationSuite extends NormalizationReferenceGridSuite:
  override def munitTests(): Seq[munit.Test] =
    val names = Set(
      "legacy sample budget admits the exact boundary and refuses the next sample",
      "legacy normalization refuses tiny steps before kernel evaluation",
      "fixed reference budget admits its boundary and refuses the next sample",
      "fixed normalization refuses oversized and overflowing spans before evaluation"
    )
    val selected = super.munitTests().filter(t => names.contains(t.name))
    require(selected.map(_.name).toSet == names && selected.size == 4)
    selected

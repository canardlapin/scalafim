from pathlib import Path
import hashlib, json, os, subprocess, time
root = Path('/Users/bbuchsbaum/code/scala/scalafim')
logs = Path('/private/tmp/scalafim-normalization-budget-20261005')
source = root / 'modules/hrf/shared/src/main/scala/scalafim/fmri/hrf/NormalizationReferenceGrid.scala'
selector = root / 'modules/hrf/shared/src/test/scala/scalafim/fmri/hrf/NormalizationBudgetMutationSuite.scala'
original = source.read_text()
assert not selector.exists()
results = []
env = dict(os.environ, COURSIER_REPOSITORIES='https://repo.maven.apache.org/maven2')
def run(name, tasks):
    command = ['python3', 'tools/build/sbt-warm', *tasks]
    start = time.monotonic()
    with (logs / (name + '.log')).open('w') as out:
        proc = subprocess.run(command, cwd=root, env=env, stdout=out, stderr=subprocess.STDOUT)
    row = dict(name=name, command=command, exit_code=proc.returncode, seconds=time.monotonic()-start)
    results.append(row)
    (logs / 'runs.json').write_text(json.dumps(results, indent=2) + '\n')
    print(json.dumps(row), flush=True)
    return proc.returncode
variants = [
    ('sample', 'if !count.isFinite || count > MaxSamples.toDouble then', 'if !count.isFinite then', [
        'legacy sample budget admits the exact boundary and refuses the next sample',
        'legacy normalization refuses tiny steps before kernel evaluation',
        'fixed reference budget admits its boundary and refuses the next sample',
        'fixed normalization refuses oversized and overflowing spans before evaluation',
    ]),
    ('work', 'if !work.isFinite || work > MaxScalarEvaluations.toDouble then', 'if !work.isFinite then', [
        'block normalization refuses composite quadrature work before evaluation',
        'work budget includes basis columns and admits the exact boundary',
        'block work budget covers exact piecewise integration with coarse precision',
    ]),
]
try:
    for label, needle, mutation, names in variants:
        assert original.count(needle) == 1
        encoded_names = ',\n      '.join(json.dumps(name) for name in names)
        selector_text = f'''package scalafim.fmri.hrf

/** Guards absent: sentinels stop at the first evaluation, never large work. */
class NormalizationBudgetMutationSuite extends NormalizationReferenceGridSuite:
  override def munitTests(): Seq[munit.Test] =
    val names = Set(
      {encoded_names}
    )
    val selected = super.munitTests().filter(t => names.contains(t.name))
    require(selected.map(_.name).toSet == names && selected.size == {len(names)})
    selected
'''
        (logs / (label + '-selector.scala')).write_text(selector_text)
        source.write_text(original.replace(needle, mutation))
        selector.write_text(selector_text)
        for platform in ['JVM', 'JS']:
            name = f'mutation-{label}-{platform.lower()}'
            status = run(name, [f'hrf{platform}/testOnly scalafim.fmri.hrf.NormalizationBudgetMutationSuite'])
            content = (logs / (name + '.log')).read_text()
            assert status != 0 and f'Failed: Total {len(names)}, Failed {len(names)}' in content, content[-6000:]
        source.write_text(original)
        selector.unlink()
finally:
    source.write_text(original)
    selector.unlink(missing_ok=True)
assert source.read_text() == original
(logs / 'restoration.json').write_text(json.dumps({'sha256': hashlib.sha256(original.encode()).hexdigest(), 'restored': True}, indent=2) + '\n')
assert run('restored-focused', ['hrfJVM/testOnly scalafim.fmri.hrf.NormalizationReferenceGridSuite', 'hrfJS/testOnly scalafim.fmri.hrf.NormalizationReferenceGridSuite', 'designJVM/testOnly scalafim.fmri.design.HrfGeneratorsSuite', 'designJS/testOnly scalafim.fmri.design.HrfGeneratorsSuite']) == 0
print('Mutation evidence complete; source restored; focused suites passed on JVM and JS.', flush=True)

from pathlib import Path
import gzip,hashlib,json,os,re,subprocess,tarfile,time
source=Path('/Users/bbuchsbaum/code/scala/scalafim-eco-surface-20261021')
base=Path('/Volumes/My Passport for Mac/codex-work/scalafim-eco-u6-20261022')
base.mkdir(exist_ok=True)
root=base/'guide-consumer-20';assert not root.exists();root.mkdir()
doc=(source/'docs/standalone-composition.md').read_text()
build=re.search(r'```scala\n(.*?)\n```',doc,re.S)[1]+'\n'
(root/'build.sbt').write_text(build)
(root/'project').mkdir();(root/'project/build.properties').write_text('sbt.version=1.11.7\n')
(root/'.jvmopts').write_text('-Xms256m\n-Xmx4g\n-XX:ActiveProcessorCount=4\n-Dsbt.supershell=false\n-Dsbt.server.autostart=false\n')
(root/'.gitignore').write_text('target/\nproject/target/\nproject/project/\n.bsp/\n')
archive=Path('/Volumes/My Passport for Mac/codex-work/mvpa4s-eco-u6-20261022/qualified-private-artifacts-06.tar.gz')
def digest(path):return hashlib.file_digest(path.open('rb'),'sha256').hexdigest()
assert digest(archive)=='404e7e79248faca4f87756c85c63947036e928e42053361222f269644fbf702d'
private=base/'private-artifacts-20';assert not private.exists();private.mkdir()
with tarfile.open(archive) as tar:
    for member in tar.getmembers():
        assert (private/member.name).resolve().is_relative_to(private.resolve())
        assert member.isfile() or member.isdir()
    tar.extractall(private)
ivy=base/'guide-ivy-20';assert not ivy.exists();ivy.mkdir();(ivy/'local').symlink_to(private/'ivy-local',target_is_directory=True)
expected=json.loads((Path('/tmp')/'mvpa4s-eco-u6-independent-06.json').read_text())['private_artifact_inventory']
actual={str(p.relative_to(private/'ivy-local')):digest(p) for p in (private/'ivy-local').rglob('*') if p.is_file()}
assert actual==expected
for args in [['git','init','--quiet'],['git','config','user.name','canardlapin'],['git','config','user.email','307091466+canardlapin@users.noreply.github.com'],['git','add','.'],['git','commit','--quiet','-m','Capture exact delivered guide build']]:
    subprocess.run(args,cwd=root,check=True)
inputs={str(p.relative_to(root)):digest(p) for p in [root/'build.sbt',root/'project/build.properties',root/'.jvmopts',root/'.gitignore']}
argv=['sbt',f'-Dsbt.global.base={base}/guide-sbt-20',f'-Dsbt.ivy.home={ivy}',f'-Dsbt.coursier.home={base}/guide-coursier-20','volume/compile','atlas/compile','surface/compile','analysis/compile','show volume/Compile/fullClasspath','show atlas/Compile/fullClasspath','show surface/Compile/fullClasspath','show analysis/Compile/fullClasspath']
env=dict(os.environ,JAVA_HOME='/Users/bbuchsbaum/Library/Java/JavaVirtualMachines/openjdk-22/Contents/Home',COURSIER_CACHE=str(base/'guide-coursier-20'))
for key in ['JAVA_TOOL_OPTIONS','JDK_JAVA_OPTIONS','_JAVA_OPTIONS','SBT_OPTS','JAVA_OPTS']:env.pop(key,None)
stat=os.statvfs('/');assert stat.f_bavail*stat.f_frsize>=20*2**30,'host below20GiB buildfloor'
start=time.monotonic();result=subprocess.run(argv,cwd=root,env=env,check=False)
assert all(digest(root/p)==sha for p,sha in inputs.items())
assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=root,text=True).strip()
assert {str(p.relative_to(private/'ivy-local')):digest(p) for p in (private/'ivy-local').rglob('*') if p.is_file()}==expected
receipt={'schema':'scalafim.eco-guide-consumer.v1','source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip(),'guide_path':'docs/standalone-composition.md','guide_sha256':digest(source/'docs/standalone-composition.md'),'consumer':str(root),'consumer_inputs':inputs,'consumer_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'artifact_archive_sha256':digest(archive),'private_artifacts':expected,'argv':argv,'exit_code':result.returncode,'elapsed_seconds':time.monotonic()-start,'inputs_and_private_artifacts_unchanged':True,'limits':'Compiles the exact four JVM core consumer build from the guide; no application assertions or JS/native/release qualification. Private artifact custody reused only after archive and all120file hashes matched.'}
p=Path('/tmp/scalafim-eco-u6-guide-20.json');assert not p.exists();p.write_text(json.dumps(receipt,indent=2)+'\n');print('receipt',p,flush=True)
raise SystemExit(result.returncode)

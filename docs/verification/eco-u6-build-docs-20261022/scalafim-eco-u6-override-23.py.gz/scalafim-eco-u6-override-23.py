from pathlib import Path
import hashlib,json,os,re,subprocess,time,urllib.parse
root=Path('/Users/bbuchsbaum/code/scala/scalafim-eco-surface-20261021')
base=Path('/Volumes/My Passport for Mac/codex-work/scalafim-eco-u6-20261022')
old=json.loads((root/'docs/verification/eco-u6-cleanup-20261022/resolved-compile-boundaries-15.json').read_text())
target=Path(next(p['base'] for p in old['resolved_projects'] if p['owner']=='intaglio' and p['id']=='root')).resolve()
head=subprocess.check_output(['git','-C',str(target),'rev-parse','HEAD'],text=True).strip()
assert head=='d553c327824f9916b1c0a055226c6c5e8f77bc59'
assert not subprocess.check_output(['git','-C',str(target),'status','--porcelain','--untracked-files=no'],text=True).strip()
expected=json.dumps(str(target))
expression='eval { val expected = '+expected+'; Seq("image4s", "neuroim4s", "neurosurf4s", "neuroatlas4s", "mvpa4s").foreach { name => require(sys.props.get(name + ".intaglio.build").contains(expected), name + " missed override") }; println("all five Intaglio forwarding properties match") }'
argv=['sbt',f'-Dsbt.global.base={base}/override-sbt-23',f'-Dsbt.ivy.home={base}/override-ivy-23',f'-Dsbt.coursier.home={base}/override-coursier-23','-Dsbt.server.autostart=false',f'-Dscalafim.intaglio.build={target}',expression,'projects']
env=dict(os.environ,JAVA_HOME='/Users/bbuchsbaum/Library/Java/JavaVirtualMachines/openjdk-22/Contents/Home',COURSIER_CACHE=str(base/'override-coursier-23'))
for key in ['JAVA_TOOL_OPTIONS','JDK_JAVA_OPTIONS','_JAVA_OPTIONS','SBT_OPTS','JAVA_OPTS']:env.pop(key,None)
stat=os.statvfs('/');assert stat.f_bavail*stat.f_frsize>=20*2**30,'host below20GiB buildfloor'
source_before=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
start=time.monotonic();child=subprocess.Popen(argv,cwd=root,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
lines=[]
for line in child.stdout:
    lines.append(line);print(line,end='',flush=True)
code=child.wait();output=''.join(lines)
clean=re.sub(r'\x1b\[[0-9;]*[A-Za-z]','',output)
loaded=re.findall(r'^\[info\] In (.+)$',clean,re.M)
paths=[Path(urllib.parse.unquote(urllib.parse.urlparse(uri).path)).resolve() for uri in loaded if uri.startswith('file:')]
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==source_before
assert subprocess.check_output(['git','-C',str(target),'rev-parse','HEAD'],text=True).strip()==head
assert not subprocess.check_output(['git','-C',str(target),'status','--porcelain','--untracked-files=no'],text=True).strip()
passed=code==0 and target in paths and not any('github.com/canardlapin/intaglio.git' in uri for uri in loaded) and 'all five Intaglio forwarding properties match' in clean
receipt={'schema':'scalafim.eco-explicit-override.v1','source_commit':source_before,'target':str(target),'target_revision':head,'clean_tracked_source_before_after':True,'argv':argv,'exit_code':code,'elapsed_seconds':time.monotonic()-start,'loaded_build_uris':loaded,'forwarded_properties':['image4s','neuroim4s','neurosurf4s','neuroatlas4s','mvpa4s'],'single_loaded_intaglio_owner':passed,'limits':'Load/property/URI probe only; no Scala runtime assertions or local checkout SHA certification in the guard itself. Server autostart disabled.'}
p=Path('/tmp/scalafim-eco-u6-override-23.json');assert not p.exists();p.write_text(json.dumps(receipt,indent=2)+'\n');print('receipt',p,flush=True)
raise SystemExit(0 if passed else (code or 1))
